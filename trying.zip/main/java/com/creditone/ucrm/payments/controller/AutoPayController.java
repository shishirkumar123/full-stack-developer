package com.creditone.ucrm.payments.controller;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.processor.AutoPayConfigurationProcessor;
import com.creditone.ucrm.payments.util.ReactiveFlowHelper;
import com.creditone.ucrm.payments.validation.AutoPayConfigurationValidator;
import com.creditone.ucrm.payments.validation.AutoPayRequestValidator;
import com.ucrm.swagger.paymentservice.model.*;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;


@Slf4j
@RestController
@RequestMapping(path = "/private/creditcard/financials/payment-service")
@Validated
public class AutoPayController {
    private AutoPayConfigurationProcessor autoPayConfigurationProcessor;

    public AutoPayController(AutoPayConfigurationProcessor autoPayConfigurationProcessor) {
        this.autoPayConfigurationProcessor = autoPayConfigurationProcessor;
    }

    /***
     *
     * @param apiVersion
     * @param correlationId
     * @param customerId      used to pass to processor to get the details from DB
     * @param creditAccountId used to pass to processor to get the details from DB
     * @return mono of AutoPayConfiguration
     */
    @GetMapping(path = "customers/{customerId}/creditaccounts/{creditAccountId}/auto-pay-configuration")
    @Operation(tags = "Auto Pay", description = "getAutoPayConfiguration", summary = "Get Auto Pay Configuration")
    @ResponseStatus(HttpStatus.OK)
    public Mono<AutoPayConfiguration> getAutoPayConfiguration(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @PathVariable String customerId, @PathVariable String creditAccountId) {

        return Mono.deferContextual(context -> {

//
//            log.info(PaymentConstants.LOG_PREFIX + "Start of getAutoPayConfiguration(). Customer ID: {}, Credit Account Id: {}", context.get(PaymentConstants.CORRELATION_ID),
//                    customerId, creditAccountId);
//            AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
//
//            Mono<AutoPayConfiguration> monoResult = autoPayConfigurationProcessor.getAutoPayConfiguration(customerId, creditAccountId,
//                    context.get(PaymentConstants.CORRELATION_ID));
//            return monoResult.flatMap(autoPayConfiguration -> {
//                log.info(PaymentConstants.LOG_PREFIX + "getAutoPayConfiguration() response: {}", context.get(PaymentConstants.CORRELATION_ID), autoPayConfiguration);
//                return Mono.just(autoPayConfiguration);
//            });
            return ReactiveFlowHelper.executeReactiveFlow(context.get(PaymentConstants.CORRELATION_ID),
                    () -> AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId),
                    () -> autoPayConfigurationProcessor.getAutoPayConfiguration(customerId, creditAccountId, context.get(PaymentConstants.CORRELATION_ID)),
                    getClass().getName() + ".getAutoPayConfiguration(),  apiVersion:{}, customerId: {} , creditAccountId: {}", apiVersion, customerId, creditAccountId
            );
        });
    }

    /**
     *
     * @param apiVersion
     * @param correlationId
     * @param customerId      used to pass to processor to post the details to DB
     * @param creditAccountId used to pass to processor to post the details to DB
     * @param autoPayRequest
     * @return  mono of AutoPayResponse
     */

    @Operation(tags = "Auto Pay", description = "EnableAutoPayConfiguration", summary = "Enable Auto Pay Configuration")
    @PostMapping(path = "/customers/{customerId}/creditaccounts/{creditAccountId}/auto-pay-configuration")
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<AutoPayResponse> processEnableAutoPayConfiguration(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @PathVariable String customerId, @PathVariable String creditAccountId, @Valid @RequestBody AutoPayRequest autoPayRequest) {
        return Mono.deferContextual(context -> {
//            log.info(PaymentConstants.LOG_PREFIX + "Start of initializeAutoPaySetup(). api-version: {}, customerId: {} , creditAccountId: {}, autoPayRequest: {}",
//                    context.get(PaymentConstants.CORRELATION_ID), apiVersion, customerId, creditAccountId, autoPayRequest);
//            AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
//            AutoPayRequestValidator.validate(autoPayRequest);
//            Mono<AutoPayResponse> monoResponse = autoPayConfigurationProcessor.initializeAutoPaySetup(customerId, creditAccountId, autoPayRequest,
//                    context.get(PaymentConstants.CORRELATION_ID));
//            return monoResponse.flatMap(autoPayResponse -> {
//                log.info(PaymentConstants.LOG_PREFIX + "End of initializeAutoPaySetup(). autoPayResponse: {}", context.get(PaymentConstants.CORRELATION_ID), autoPayResponse);
//                return Mono.just(autoPayResponse);
//            });
            /// ///////////////////////////////

            return ReactiveFlowHelper.executeReactiveFlow(context.get(PaymentConstants.CORRELATION_ID),
                    () -> {
                            AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
                            AutoPayRequestValidator.validate(autoPayRequest);
                          },
                    () -> autoPayConfigurationProcessor.initializeAutoPaySetup(customerId, creditAccountId, autoPayRequest,
                    context.get(PaymentConstants.CORRELATION_ID)),
                    getClass().getName() + ".getAutoPayConfiguration(),  apiVersion:{}, customerId: {} , creditAccountId: {}", apiVersion, customerId, creditAccountId
            );
        });
    }

    /***
     *
     * @param apiVersion
     * @param correlationId
     * @param customerId      used to pass to processor to get the details from DB
     * @param creditAccountId used to pass to processor to get the details from DB
     * @return mono of void
     */
    @DeleteMapping(path = "customers/{customerId}/creditaccounts/{creditAccountId}/auto-pay-configuration")
    @Operation(tags = "Auto Pay", description = "Disable the Auto Pay Functionality for Credit Card Account", summary = "Disable Auto Pay Configuration")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> disableAutoPayConfiguration(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @PathVariable String customerId, @PathVariable String creditAccountId) {



        return Mono.deferContextual(context -> {
            String contextCorrelationId = context.getOrDefault(PaymentConstants.CORRELATION_ID, correlationId);
//            log.info(PaymentConstants.LOG_PREFIX + "Start of disableAutoPayConfiguration(). Customer ID: {}, Credit Account Id: {}", contextCorrelationId, customerId,
//                    creditAccountId);
//            AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
//
//            return autoPayConfigurationProcessor.disableAutoPayConfiguration(customerId, creditAccountId, true, contextCorrelationId)
//                    .doOnSuccess(aVoid -> log.info(PaymentConstants.LOG_PREFIX + "Successfully Shishir disabled auto-pay configuration. Correlation ID: {}", contextCorrelationId)).then();
            /// ////////////////////////////////////
            return ReactiveFlowHelper.executeReactiveFlow(context.get(PaymentConstants.CORRELATION_ID),
                    () -> AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId),
                    () -> autoPayConfigurationProcessor.disableAutoPayConfiguration(customerId, creditAccountId, true, contextCorrelationId),
                    getClass().getName() + ".disableAutoPayConfiguration(),  apiVersion:{}, customerId: {} , creditAccountId: {}", apiVersion, customerId, creditAccountId
            ).then();
        });
    }

    /***
     *
     * @param apiVersion
     * @param correlationId
     * @param customerId
     * @param creditAccountId
     * @param updateAutoPayRequest
     * @return
     */
    @Operation(tags = "Auto Pay", description = "UpdateAutoPayConfiguration", summary = "Update Auto Pay Configuration")
    @PatchMapping(path = "/customers/{customerId}/creditaccounts/{creditAccountId}/auto-pay-configuration")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Mono<AutoPayResponse> updateAutoPayConfiguration(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @PathVariable String customerId, @PathVariable String creditAccountId, @Valid @RequestBody UpdateAutoPayRequest updateAutoPayRequest) {
        return Mono.deferContextual(context -> {
//            log.info(PaymentConstants.LOG_PREFIX + "Start of updateAutoPayConfiguration(). api-version: {}, customerId: {} , creditAccountId: {}, updateAutoPayRequest: {}",
//                    context.get(PaymentConstants.CORRELATION_ID), apiVersion, customerId, creditAccountId, updateAutoPayRequest);
//            AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
//            AutoPayRequestValidator.validate(updateAutoPayRequest);
//
//            Mono<AutoPayResponse> monoResponse = autoPayConfigurationProcessor.updateAutoPayConfiguration(customerId, creditAccountId, updateAutoPayRequest,
//                    context.get(PaymentConstants.CORRELATION_ID));
//
//            return monoResponse.flatMap(autoPayResponse -> {
//                log.info(PaymentConstants.LOG_PREFIX + "End of updateAutoPayConfiguration(), autoPayResponse: {}", context.get(PaymentConstants.CORRELATION_ID).toString(),
//                        autoPayResponse);
//                return Mono.just(autoPayResponse);
//            });


            /// /////////////////////////////
            return ReactiveFlowHelper.executeReactiveFlow(context.get(PaymentConstants.CORRELATION_ID),
                    () -> {
                        AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId);
                        AutoPayRequestValidator.validate(updateAutoPayRequest);
                    },
                    () -> autoPayConfigurationProcessor.updateAutoPayConfiguration(customerId, creditAccountId, updateAutoPayRequest, context.get(PaymentConstants.CORRELATION_ID)),
                    getClass().getName() + ".getAutoPayConfiguration(),  apiVersion:{}, customerId: {} , creditAccountId: {}", apiVersion, customerId, creditAccountId
            );
        });
    }

    /***
     *
     * @param apiVersion
     * @param correlationId
     * @param customerId      used to pass to processor to get the details from DB
     * @param creditAccountId used to pass to processor to get the details from DB
     * @return mono of AutoPayConfigurationHistory
     */
    @GetMapping(path = "customers/{customerId}/creditaccounts/{creditAccountId}/auto-pay-configuration/history")
    @Operation(tags = "Auto Pay", description = "getAutoPayConfigurationHistory", summary = "Get Auto Pay Configuration History")
    @ResponseStatus(HttpStatus.OK)
    public Mono<AutoPayConfigurationHistory> getAutoPayConfigurationHistory(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @PathVariable String customerId, @PathVariable String creditAccountId) {
        return Mono.deferContextual(context -> {
            return ReactiveFlowHelper.executeReactiveFlow(context.get(PaymentConstants.CORRELATION_ID),
                    () -> AutoPayConfigurationValidator.validatePathVariables(customerId, creditAccountId),
                    () -> autoPayConfigurationProcessor.getAutoPayConfigurationHistory(customerId, creditAccountId, context.get(PaymentConstants.CORRELATION_ID)),
                    getClass().getName() + ".getAutoPayConfigurationHistory(),  apiVersion:{}, customerId: {} , creditAccountId: {}", apiVersion, customerId, creditAccountId
            );
        });
    }
}
