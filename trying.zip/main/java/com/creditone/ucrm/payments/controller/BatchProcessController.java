package com.creditone.ucrm.payments.controller;


import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.processor.PaymentBatchProcessor;
import com.creditone.ucrm.payments.processor.PaymentBatchStatusProcessor;
import com.creditone.ucrm.payments.validation.PaymentRequestValidator;
import com.ucrm.swagger.paymentservice.model.BatchProcessRequest;
import com.ucrm.swagger.paymentservice.model.BatchProcessResponse;
import com.ucrm.swagger.paymentservice.model.BatchProcessStatusResponse;
import com.ucrm.swagger.paymentservice.model.FailedPaymentResponse;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping(path = "/private/creditcard/financials/payment-service")
@Validated
public class BatchProcessController {
    private PaymentBatchProcessor paymentBatchProcessor;
    private PaymentBatchStatusProcessor paymentBatchStatusProcessor;

    public BatchProcessController(PaymentBatchProcessor paymentBatchProcessor, PaymentBatchStatusProcessor paymentBatchStatusProcessor) {
        this.paymentBatchProcessor = paymentBatchProcessor;
        this.paymentBatchStatusProcessor = paymentBatchStatusProcessor;
    }

    @Operation(tags = "batch-process", description = "Batch Process For Schedule Payment", summary = "Batch Process")
    @PostMapping(path = "/batch-process")
    @ResponseStatus(HttpStatus.OK)
    public Mono<BatchProcessResponse> initializeBatchProcess(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @RequestBody BatchProcessRequest batchProcessRequest) {
        return Mono.deferContextual(context -> {
            log.info(PaymentConstants.LOG_PREFIX + "Start of initializeBatchProcess(). api-version: {}, batchProcessRequest{}", context.get(PaymentConstants.CORRELATION_ID),
                    apiVersion, batchProcessRequest);
            PaymentRequestValidator.validateBatchProcessRequest(batchProcessRequest);
            Mono<BatchProcessResponse> monoBatchProcessResponse = paymentBatchProcessor.initializeBatchProcess(batchProcessRequest, context.get(PaymentConstants.CORRELATION_ID));
            return monoBatchProcessResponse.flatMap(batchProcessResponse -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of initializeBatchProcess(). batchProcessResponse: {}", context.get(PaymentConstants.CORRELATION_ID),
                        batchProcessResponse);
                return Mono.just(batchProcessResponse);
            });
        });
    }

    @Operation(tags = "batch-process", description = "Query Process Scheduled Payments Status", summary = "Query Process Scheduled Payments status")
    @GetMapping(path = "/batch-process/{batchProcessId}")
    @ResponseStatus(HttpStatus.OK)
    public Mono<BatchProcessStatusResponse> getBatchStatusResponse(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @PathVariable @Pattern(regexp = PaymentConstants.UUIDREGEX, message = "batchProcessId"
            + PaymentErrors.VALIDATION_UUID) String batchProcessId) {
        return Mono.deferContextual(context -> {
            log.info(PaymentConstants.LOG_PREFIX + "Start of getBatchStatusResponse(). api-Version: {}", context.get(PaymentConstants.CORRELATION_ID), apiVersion);
            Mono<BatchProcessStatusResponse> monoResponse = paymentBatchStatusProcessor.getBatchStatusResponse(batchProcessId, context.get(PaymentConstants.CORRELATION_ID));
            return monoResponse.flatMap(batchStatusResponse -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of getBatchStatusResponse(). response: {}", context.get(PaymentConstants.CORRELATION_ID), batchStatusResponse);
                return Mono.just(batchStatusResponse);
            });
        });
    }

    /***
     *
     * @param apiVersion
     * @param correlationId
     * @param batchProcessId
     * @return
     */
    @Operation(tags = "batch-process", description = "Query Process Scheduled Payments Status", summary = "Query Process Scheduled Payments status")
    @GetMapping(path = "/batch-process/{batchProcessId}/errors")
    @ResponseStatus(HttpStatus.OK)
    public Mono<FailedPaymentResponse> getBatchErrorDetailsResponse(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @PathVariable @Pattern(regexp = PaymentConstants.UUIDREGEX, message = PaymentErrors.ERROR_BATCH_PROCESS_ID_INVALID) String batchProcessId) {
        return Mono.deferContextual(context -> {
            log.info(PaymentConstants.LOG_PREFIX + "Start of getBatchStatusResponse(). api-Version: {}", context.get(PaymentConstants.CORRELATION_ID), apiVersion);
            Mono<FailedPaymentResponse> monoResponse = paymentBatchStatusProcessor.getBatchErrorDetailsResponse(batchProcessId, context.get(PaymentConstants.CORRELATION_ID));
            return monoResponse.flatMap(batchStatusResponse -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of getBatchStatusResponse(). response: {}", context.get(PaymentConstants.CORRELATION_ID), batchStatusResponse);
                return Mono.just(batchStatusResponse);
            });
        });
    }
}
