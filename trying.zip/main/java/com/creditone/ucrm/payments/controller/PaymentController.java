package com.creditone.ucrm.payments.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.creditone.ucrm.payments.processor.*;
import com.ucrm.swagger.paymentservice.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.SortField;
import com.creditone.ucrm.payments.constant.SortOrder;
import com.creditone.ucrm.payments.validation.PaymentCancelACHRequestValidator;
import com.creditone.ucrm.payments.validation.PaymentRequestValidator;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping(path = "/private/creditcard/financials/payment-service")
@Validated

@OpenAPIDefinition(info = @Info(title = PaymentConstants.PAYMENT_SERVICE, description = "Payment Service", version = "v1.24"), tags = { @Tag(name = "Payment Service") })
public class PaymentController {

	private PaymentProcessor paymentProcessor;
	private PaymentBatchProcessor paymentBatchProcessor;
	private PaymentHistoryProcessor paymentHistoryService;
	private PaymentCancellationProcessor paymentCancellationProcessor;
	private PaymentReprocessBatchProcessor paymentReprocessBatchProcessor;

	public PaymentController(PaymentProcessor paymentProcessor, PaymentBatchProcessor paymentBatchProcessor,
							 PaymentHistoryProcessor paymentHistoryService,
							 PaymentCancellationProcessor paymentCancellationProcessor, PaymentReprocessBatchProcessor paymentReprocessBatchProcessor) {
		this.paymentProcessor = paymentProcessor;
		this.paymentBatchProcessor = paymentBatchProcessor;
		this.paymentHistoryService = paymentHistoryService;
		this.paymentCancellationProcessor = paymentCancellationProcessor;
		this.paymentReprocessBatchProcessor = paymentReprocessBatchProcessor;
	}

	/**
	 * Jira Link: https://creditonebank.atlassian.net/browse/CRM-229 Accepts payment
	 * request from bff, passes it to service for further processing, and returns a
	 * Mono of DebitPaymentResponse
	 *
	 * @param apiVersion
	 * @param request
	 * @return Mono of DebitPaymentResponse
	 * @throws Exception
	 */
	@Operation(tags = "Payment Service", description = "Process Payment Request", summary = "Process Payment Request")
	@PostMapping(path = "/payment")
	@ResponseStatus(HttpStatus.CREATED)
	public Mono<PaymentServiceResponse> processDebitPayment(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @RequestBody PaymentServiceRequest request) {
		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX + "Start of processPayment(). api-version: {}, request: {}", context.get(PaymentConstants.CORRELATION_ID), apiVersion, request);
			PaymentRequestValidator.validate(request);
			Mono<PaymentServiceResponse> monoResponse = paymentProcessor.processAllPayments(request, context.get(PaymentConstants.CORRELATION_ID));
			return monoResponse.flatMap(debitPaymentResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "End of processPayment(). response: {}", context.get(PaymentConstants.CORRELATION_ID), debitPaymentResponse);
				return Mono.just(debitPaymentResponse);
			});
		});
	}

	/**
	 * Jira Link: https://creditonebank.atlassian.net/browse/CRM-220 patch method to
	 * cancelACHPayment for the provided paymentrequestid
	 *
	 * @param apiVersion
	 * @param request
	 * @return Mono of CancelACHPaymentResponse
	 * @throws Exception
	 */

	@Operation(tags = "Payment Service", description = "Cancel eligible ACH or Debit Payment Request", summary = "Cancel ACH or Debit Payment")
	@PatchMapping(path = "/payment/cancellation/{paymentRequestId}")
	@ResponseStatus(HttpStatus.OK)
	public Mono<CancelACHPaymentResponse> cancelACHPayment(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @PathVariable @Pattern(regexp = PaymentConstants.UUIDREGEX, message = "paymentRequestId"
			+ PaymentErrors.VALIDATION_UUID) String paymentRequestId, @Valid @RequestBody CancelACHPaymentRequest request) throws Exception {
		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX + "Start of cancelACHPayment(). api-Version: {}, paymentRequestId: {}, request: {}", context.get(PaymentConstants.CORRELATION_ID),
					apiVersion, paymentRequestId, request);

			PaymentCancelACHRequestValidator.validate(request);

			Mono<CancelACHPaymentResponse> monoResponse = paymentCancellationProcessor.cancelACHPayment(UUID.fromString(paymentRequestId), request,
					context.get(PaymentConstants.CORRELATION_ID));
			return monoResponse.flatMap(cancelACHPaymentResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "End of cancelACHPayment(). response: {}", context.get(PaymentConstants.CORRELATION_ID), cancelACHPaymentResponse);
				return Mono.just(cancelACHPaymentResponse);
			});
		});
	}

	@Operation(tags = "Payment Service", description = "Process Scheduled Payments Status", summary = "Process Scheduled Payments status")
	@GetMapping(path = "/schedule-status")
	@ResponseStatus(HttpStatus.OK)
	public Mono<ScheduledPaymentStatusResponse> getScheduledPaymentStatus(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId) {
		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX + "Start of schedule-status(). api-Version: {}", context.get(PaymentConstants.CORRELATION_ID), apiVersion);
			Mono<ScheduledPaymentStatusResponse> monoResponse = paymentBatchProcessor.getScheduledPaymentStatus(context.get(PaymentConstants.CORRELATION_ID));
			return monoResponse.flatMap(scheduledPaymentStatusResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "End of schedule-status(). response: {}", context.get(PaymentConstants.CORRELATION_ID), scheduledPaymentStatusResponse);
				return Mono.just(scheduledPaymentStatusResponse);
			});
		});
	}

	@GetMapping(path = "/customers/{customerId}/payments")
	@Operation(tags = "Payment Service", description = "getPaymentHistory", summary = "Payment History")
	@ResponseStatus(HttpStatus.OK)
	public Mono<PaymentHistory> getPaymentHistory(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @PathVariable @Pattern(regexp = PaymentConstants.UUIDREGEX, message = PaymentErrors.ERROR_CUSTOMER_IS_INVALID) String customerId, @RequestParam(required = false) @Pattern(regexp = PaymentConstants.UUIDREGEX, message = PaymentErrors.ERROR_CREDIT_ACCOUNT_IS_INVALID) String creditAccountId, @RequestParam(required = false) @Pattern(regexp = PaymentConstants.UUIDREGEX, message = PaymentErrors.ERROR_EXTERNAL_ACCOUNT_IS_INVALID) String externalAccountId, @RequestParam(required = false) String paymentType, @RequestParam(required = false) @Pattern(regexp = PaymentConstants.DATEFORMAT_YYYY_MM_DD, message = PaymentErrors.ERROR_START_DATE_IS_INVALID) String startDate, @RequestParam(required = false) @Pattern(regexp = PaymentConstants.DATEFORMAT_YYYY_MM_DD, message = PaymentErrors.ERROR_END_DATE_IS_INVALID) String endDate, @RequestParam(required = false) String status, @Parameter(description = "default sort order is descending") @RequestParam(name = "sort", required = false) SortOrder sortOrder, @Parameter(description = "default sort field is scheduledDate") @RequestParam(required = false) SortField sortField, @RequestParam(name = "page", required = false) String pageNumber, @RequestParam(required = false) String pageSize) {

		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX
							+ "Start of getPaymentHistory(). Customer ID: {}, Credit Account Id: {}, External AccountId: {}, PaymentType: {}, startDate: {}, endDate: {}, Status: {}, SortOrder: {}, SortField: {}, PageNumber: {}, "
							+ "PageSize: {}", context.get(PaymentConstants.CORRELATION_ID), customerId, creditAccountId, externalAccountId, paymentType, startDate, endDate, status,
					sortOrder, sortField, pageNumber, pageSize);

			Map<String, Object> parameters = new HashMap<>();
			parameters.put(PaymentConstants.CUSTOMER_ID, UUID.fromString(customerId));
			parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId != null ? UUID.fromString(creditAccountId) : null);
			parameters.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, externalAccountId != null ? UUID.fromString(externalAccountId) : null);
			parameters.put(PaymentConstants.PAYMENT_TYPE, paymentType);
			parameters.put(PaymentConstants.START_DATE, startDate);
			parameters.put(PaymentConstants.END_DATE, endDate);
			parameters.put(PaymentConstants.STATUS, status);
			parameters.put(PaymentConstants.SORT_ORDER, sortOrder != null ? sortOrder.name() : null);
			parameters.put(PaymentConstants.SORT_FIELD, sortField != null ? sortField.name() : null);
			parameters.put(PaymentConstants.PAGE_NUMBER, pageNumber);
			parameters.put(PaymentConstants.PAGE_SIZE, pageSize);
			parameters.put(PaymentConstants.CORRELATION_ID, context.get(PaymentConstants.CORRELATION_ID));

			PaymentRequestValidator.validateParameters(parameters);

			Mono<PaymentHistory> monoResult = paymentHistoryService.getPaymentHistory(parameters);
			return monoResult.flatMap(paymentHistory -> {
				log.info(PaymentConstants.LOG_PREFIX + "getPaymentHistory() response: {}", context.get(PaymentConstants.CORRELATION_ID), paymentHistory);
				return Mono.just(paymentHistory);
			});
		});
	}




	@Operation(tags = "payments-replay", description = "Replay payments with Error", summary = "Replay")
	@PostMapping(path = "/payments/replay")
	@ResponseStatus(HttpStatus.OK)
	public Mono<PaymentsReplayResponse> replayPayments(@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion, @RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId, @Valid @RequestBody PaymentsReplayRequest paymentsReplayRequest) {
		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX + "Start of replayPayments(). api-version: {}, paymentsReplayRequest{}", context.get(PaymentConstants.CORRELATION_ID), apiVersion,
					paymentsReplayRequest);
			PaymentRequestValidator.validatePaymentsReplayRequest(paymentsReplayRequest);
			Mono<PaymentsReplayResponse> monoReplaypaymentsResponse = paymentProcessor.replayPayments(paymentsReplayRequest, context.get(PaymentConstants.CORRELATION_ID));
			return monoReplaypaymentsResponse.flatMap(replayPaymentsResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "End of replayPayments(). replayPaymentsResponse: {}", context.get(PaymentConstants.CORRELATION_ID), replayPaymentsResponse);
				return Mono.just(replayPaymentsResponse);
			});
		});
	}

	/***
	 *
	 * @param apiVersion
	 * @param correlationId
	 * @return
	 */
	@Operation(tags = "reprocess-batch", description = "Restart pending payment records for Async Processing", summary = "Restart pending payment records for Async Processing")
	@GetMapping(path = "/payment/reprocess-batch")
	@ResponseStatus(HttpStatus.OK)
	public Mono<ReprocessBatchResponse> reprocessBatch(
			@RequestHeader(name = PaymentConstants.API_VERSION, required = false) String apiVersion,
			@RequestHeader(name = PaymentConstants.CORRELATION_ID, required = false) String correlationId) {
		return Mono.deferContextual(context -> {
			log.info(PaymentConstants.LOG_PREFIX + "Start of reprocessBatch(). response api-Version: {}", context.get(PaymentConstants.CORRELATION_ID), apiVersion);
			Mono<ReprocessBatchResponse> monoResponse = paymentReprocessBatchProcessor.processPendingBatchPayment(context.get(PaymentConstants.CORRELATION_ID));
			return monoResponse.flatMap(batchStatusResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "End of reprocessBatch(). response: {}", context.get(PaymentConstants.CORRELATION_ID), batchStatusResponse);
				return Mono.just(batchStatusResponse);
			});
		});
	}
}