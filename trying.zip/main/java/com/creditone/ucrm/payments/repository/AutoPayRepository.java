package com.creditone.ucrm.payments.repository;

import com.creditone.ucrm.payments.model.AutoPayEntity;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

@Repository
public interface AutoPayRepository extends R2dbcRepository<AutoPayEntity, UUID> {
    public Mono<AutoPayEntity> findByAutoPayId(UUID autopayId);

    public Mono<AutoPayEntity> findByCustomerIdAndCreditAccountId(UUID customerId, UUID creditCardAccountId);

    Mono<AutoPayEntity> findTopByCustomerIdAndCreditAccountIdOrderByUpdatedTimestampDesc(UUID customerId, UUID creditAccountId);

    Mono<Void> deleteByAutoPayId(UUID autoPayId);
    Flux<AutoPayEntity> findByAutoPaymentDayAndCreditAccountIdNotIn(Integer autoPaymentDay,List<UUID> creditAccountIds);
    Mono<Void> deleteByCustomerIdAndCreditAccountId(UUID customerId, UUID creditCardAccountId);
}