package com.creditone.ucrm.payments.repository;

import com.creditone.ucrm.payments.model.PaymentBatchEntity;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
import java.util.UUID;

@Repository
public interface PaymentBatchRepository extends R2dbcRepository<PaymentBatchEntity, UUID> {
    public Mono<PaymentBatchEntity> findByBatchId(UUID batchId);
}
