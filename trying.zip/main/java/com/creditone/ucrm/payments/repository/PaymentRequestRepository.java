package com.creditone.ucrm.payments.repository;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.creditone.ucrm.payments.model.PaymentRequestEntity;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface PaymentRequestRepository extends R2dbcRepository<PaymentRequestEntity, UUID> {
	public Mono<PaymentRequestEntity> findByPaymentRequestId(UUID paymentRequestId);
	public Mono<PaymentRequestEntity> findByPaymentRequestIdAndRequestStatus(UUID paymentRequestId, String requestStatus);
	public Mono<PaymentRequestEntity> findByPaymentRequestIdAndAccountKey(UUID paymentRequestId,UUID accountKey);

	public Mono<PaymentRequestEntity> findByPaymentRequestIdAndPaymentDateGreaterThanAndPaymentDateLessThan(
			UUID paymentRequestId, ZonedDateTime previousDay, ZonedDateTime nextDay);
	
	public Flux<PaymentRequestEntity> findByRequestStatusInAndPaymentDateGreaterThanAndPaymentDateLessThan(
		List<String> listRequestStatus, ZonedDateTime previousDay, ZonedDateTime nextDay);

	public Flux<PaymentRequestEntity> findByRequestStatusInAndPaymentDateLessThan(List<String> listRequestStatus,
		ZonedDateTime paymentDate);
	public Flux<PaymentRequestEntity> findByRequestStatusInAndPaymentDateLessThanAndCreatedByNot(List<String> listRequestStatus,
		ZonedDateTime paymentDate,String createdBy);
	public Flux<PaymentRequestEntity> findByRequestStatusInAndPaymentDateLessThanEqual(List<String> listRequestStatus,
		ZonedDateTime paymentDate);
	public Flux<PaymentRequestEntity>  findByPaymentRequestIdIn(List<UUID> paymentRequestIds);

	@Query("SELECT * FROM payments.payment_request " + "WHERE account_key=:accountKey "
			+ "AND individual_unique_identifier_key=:individualUniqueIdentifierKey "
			+ "AND request_status IN (:listRequestStatus) "
			+ "AND (payment_date >= :lastStatementDate AND payment_date <= :currentDate)")
	public Flux<PaymentRequestEntity> findExistingPaymentsToProcess(UUID accountKey, UUID individualUniqueIdentifierKey,
			List<String> listRequestStatus, LocalDateTime lastStatementDate, LocalDateTime currentDate);

}