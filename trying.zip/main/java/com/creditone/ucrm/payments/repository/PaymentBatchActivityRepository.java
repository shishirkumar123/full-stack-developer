package com.creditone.ucrm.payments.repository;

import java.util.UUID;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.creditone.ucrm.payments.model.PaymentBatchActivityEntity;
import com.creditone.ucrm.payments.model.PaymentRequestEntity;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface PaymentBatchActivityRepository extends R2dbcRepository<PaymentBatchActivityEntity, UUID> {
	public Mono<PaymentBatchActivityEntity> findByPaymentRequestId(UUID paymentRequestId);
	public Flux<PaymentBatchActivityEntity> findByPaymentBatchStatus(String paymentBatchStatus);

}