package com.creditone.ucrm.payments.exception;

import org.springframework.http.HttpStatusCode;

import java.io.Serial;

public class PaymentConflictException extends RuntimeException {

	@Serial
	private static final long serialVersionUID = 1L;
    private HttpStatusCode httpStatusCode;

    public PaymentConflictException(String errorMessage) {
        super(errorMessage);
    }

    public HttpStatusCode getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(HttpStatusCode httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }
}
