package com.creditone.ucrm.payments.exception;

import java.io.Serial;

public class PaymentException extends RuntimeException {

	@Serial
	private static final long serialVersionUID = 1L;
	
	public PaymentException(String errorMessage) {
		super(errorMessage);
	}

}