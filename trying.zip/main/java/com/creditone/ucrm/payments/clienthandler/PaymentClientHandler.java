package com.creditone.ucrm.payments.clienthandler;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.function.Function;

@Component
public class PaymentClientHandler {

	private WebClient paymentsWebClient;

	public PaymentClientHandler(WebClient paymentsWebClient) {
		this.paymentsWebClient = paymentsWebClient;
	}
	/**
	 * Invokes GET end point details with input data and returns ResponseSpec
	 * 
	 * @param url
	 * @param headers
	 * @param targetApplication
	 * @return ResponseSpec
	 */
	public ResponseSpec webClientGet(String url, Map<String, String> headers, String targetApplication) {
		var requestHeadersSpec = paymentsWebClient.get().uri(url);
		String correlationId = headers.get(PaymentConstants.CORRELATION_ID);

		if (!CollectionUtils.isEmpty(headers)) {
			for (Map.Entry<String, String> headerEntry : headers.entrySet()) {
				requestHeadersSpec.header(headerEntry.getKey(), headerEntry.getValue());
			}
		}

		return requestHeadersSpec.accept(MediaType.APPLICATION_JSON).retrieve()
				.onStatus(HttpStatusCode::isError, errorResponseMappingFunction(targetApplication, correlationId));
	}

	/***
	 *
	 * @param url
	 * @param headers
	 * @param targetApplication
	 * @param params
	 * @return
	 */
	public WebClient.ResponseSpec webClientGet(String url, Map<String, String> headers, String targetApplication,
											   MultiValueMap<String, String> params) {
		String finalUrl = url;
		if (params != null && !params.isEmpty()) {
			finalUrl = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build().toString();
		}

		var requestHeaderSpec = paymentsWebClient.get().uri(finalUrl);
		String correlationId = headers.get(PaymentConstants.CORRELATION_ID);

		if (!CollectionUtils.isEmpty(headers)) {
			for (Map.Entry<String, String> headerEntry : headers.entrySet()) {
				requestHeaderSpec.header(headerEntry.getKey(), headerEntry.getValue());
			}
		}

		return requestHeaderSpec.accept(MediaType.APPLICATION_JSON).retrieve().onStatus(HttpStatusCode::isError,
				errorResponseMappingFunction(targetApplication, correlationId));
	}

	/**
	 * Invokes POST end point details with input data and returns ResponseSpec
	 * 
	 * @param url
	 * @param requestBody
	 * @param headers
	 * @param targetApplication
	 * @return ResponseSpec
	 */
	public ResponseSpec webClientPost(String url, Object requestBody, Map<String, String> headers,
			String targetApplication) {
		var requestHeadersSpec = paymentsWebClient.post().uri(url);
		String correlationId = (String)headers.get(PaymentConstants.CORRELATION_ID);

		if (requestBody != null)
			requestHeadersSpec.contentType(MediaType.APPLICATION_JSON).body(BodyInserters.fromValue(requestBody));

		if (!CollectionUtils.isEmpty(headers))
			for (Map.Entry<String, String> headerEntry : headers.entrySet())
				requestHeadersSpec.header(headerEntry.getKey(), headerEntry.getValue());

		return requestHeadersSpec.accept(MediaType.APPLICATION_JSON).retrieve().onStatus(HttpStatusCode::isError,
				errorResponseMappingFunction(targetApplication, correlationId));
	}

	public ResponseSpec webClientPatch(String url, Object requestBody, Map<String, String> headers, String targetApplication) {
		var requestHeadersSpec = paymentsWebClient.patch().uri(url);
		String correlationId = headers.get(PaymentConstants.CORRELATION_ID);

		if (requestBody != null)
			requestHeadersSpec.contentType(MediaType.APPLICATION_JSON).body(BodyInserters.fromValue(requestBody));

		if (!CollectionUtils.isEmpty(headers))
			for (Map.Entry<String, String> headerEntry : headers.entrySet())
				requestHeadersSpec.header(headerEntry.getKey(), headerEntry.getValue());

		return requestHeadersSpec.accept(MediaType.APPLICATION_JSON).retrieve().onStatus(HttpStatusCode::isError,
				errorResponseMappingFunction(targetApplication, correlationId));
	}

	private Function<ClientResponse, Mono<? extends Throwable>> errorResponseMappingFunction(String targetApplication, String correlationId) {
		return clientResponse -> clientResponse.bodyToMono(String.class).defaultIfEmpty("Empty response").flatMap(errorResponse -> {
			String errorMessage = PaymentUtil.mapErrorResponse(errorResponse, targetApplication, correlationId);

			if (clientResponse.statusCode().is4xxClientError()) {
				PaymentDataException paymentDataException = new PaymentDataException(errorMessage);
				paymentDataException.setHttpStatusCode(clientResponse.statusCode());
				return Mono.error(paymentDataException);
			}

			return Mono.error(new PaymentException(errorMessage));
		});
	}

}