package com.creditone.ucrm.payments.clienthandler;

import org.kie.api.runtime.KieContainer;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DroolsPreLoader {

	private KieContainer accountStatusKieContainer;

	private KieContainer rtpCallKieContainer;

	public DroolsPreLoader(KieContainer accountStatusKieContainer, KieContainer rtpCallKieContainer) {
		this.accountStatusKieContainer = accountStatusKieContainer;
		this.rtpCallKieContainer = rtpCallKieContainer;
	}

	@jakarta.annotation.PostConstruct
	public void preloadRules() {
		try {
			log.info("Preloading Drools rules...");
			accountStatusKieContainer.newKieSession().dispose();
			rtpCallKieContainer.newKieSession().dispose();
			log.info("Drools rules preloaded successfully!");
		} catch (Exception e) {
			log.error("Error while preloading Drools rules", e);
		}
	}

}
