package com.creditone.ucrm.payments.events.kafka;

import java.io.Serial;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentsKafkaEvent implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;
	
	private KafkaEventHeader eventHeader;
	private PaymentRequestEventData eventData;

}