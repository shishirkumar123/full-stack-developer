package com.creditone.ucrm.payments.events.kafka;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
public class FinTransPaymentEventData implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;
    private UUID transactionId;
    private UUID paymentRequestId;
    private String status;
    private UUID creditAccountId;
    private String message;
}
