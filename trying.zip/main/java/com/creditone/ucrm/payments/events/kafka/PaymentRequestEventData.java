package com.creditone.ucrm.payments.events.kafka;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentRequestEventData implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	private UUID paymentRequestId;
	private UUID customerId;
	private UUID creditAccountId;
	private UUID externalAccountId;
	private String paymentType;
	private String paymentMode;
	private BigDecimal feeAmount;
	private BigDecimal paymentAmount;
	private String scheduledDate;
	private String channel;
	private String agentId;
	private String status;
	private String expressPayDecision;
	private String feeWaived;
	private String riskyPayment;
	private String riskLevel;
	private Integer floatDays;
	private String feeWaiverAmount;
	private String transactionDate;
	private String paymentConfirmation;
	private String fdrStatus;
	private String accountType;
	private PaymentRequestEventMetadata paymentMetadata;
	private String fdrPostedDate;
	private String fdrVerifiedDate;
	private String postedDate;
	private String createdBy;
	private String expresspayCondition;
	private String createdTimestamp;
	private String updatedBy;
	private String updatedTimestamp;

}