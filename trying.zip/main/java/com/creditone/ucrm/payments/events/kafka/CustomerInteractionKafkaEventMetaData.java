package com.creditone.ucrm.payments.events.kafka;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerInteractionKafkaEventMetaData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String channelCode;
	private String deviceType;
	private String actorType;
	private String applicationType;
	private String intentGroup;
	private String intentName;
	private ZonedDateTime eventTime;
	private String activityId;
	private String eventSource;
	private String eventSourceId;
	private String correlationId;

}