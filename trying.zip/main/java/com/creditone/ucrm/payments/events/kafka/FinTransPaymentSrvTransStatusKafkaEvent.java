package com.creditone.ucrm.payments.events.kafka;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@NoArgsConstructor
public class FinTransPaymentSrvTransStatusKafkaEvent implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

    private FinTransPaymentKafkaEventHeader eventHeader;
    private FinTransPaymentEventData eventData;
}
