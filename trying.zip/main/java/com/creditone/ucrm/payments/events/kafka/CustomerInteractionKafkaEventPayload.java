package com.creditone.ucrm.payments.events.kafka;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerInteractionKafkaEventPayload implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String businessArea;
	private String accountId;
	private String description;
	private BigDecimal amount;
	private String serviceCode;
	private String status;
	private String serviceActivityId;
	private Instant followupDate;
	private String domain;
	private String agentId;
	private String customerId;
}