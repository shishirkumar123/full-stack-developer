package com.creditone.ucrm.payments.events.kafka;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
public class PaymentsErrorEventData implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

    private UUID paymentRequestId;
    private UUID customerId;
    private String transactionType;
    private String transactionDirection;
    private String paymentDate;
    private String paymentAmount;
    private String paymentErrorCode;
    private String paymentStatus;
    private UUID transactionId;
    private String paymentType;
    private String returnDate;
}