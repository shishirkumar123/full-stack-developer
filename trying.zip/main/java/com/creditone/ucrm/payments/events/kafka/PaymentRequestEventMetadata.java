package com.creditone.ucrm.payments.events.kafka;

import java.io.Serial;
import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentRequestEventMetadata implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;
    
    private String notes;
    private String creditAccountLast4;
    private String externalAccountLast4;
    private String paymentPurpose;
    private String paymentReturnedDate;
    private String paymentReturnedCode;
    private String creditAccountType;
    private String productKey;
    private String bankName;
    private String creditAccountSystemNumber;
    private String statementDate;
    private String minimumPaymentDue;
    private String delinquentAmount;
    private String daysDelinquent;
    private String paymentEvent;
    private String agentId;
    private String thirdPartyCustomerId;
    private String collectionIntentId;
    private String communicationRequestId;
}