package com.creditone.ucrm.payments.rules.pojo;

import lombok.Data;

import java.util.Map;

@Data
public class RuleInput {
    private Map<String, Object> fields;
}