package com.creditone.ucrm.payments.rules.pojo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Data
public class RuleOutput {
    private Map<String, Object> output;

    public void setDecision(String key, Object value) {
        if (this.output == null)
            output = new HashMap<>();

        output.put(key, value);
    }
}