package com.creditone.ucrm.payments.rules.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
@Entity(name = "rules")
public class EWSRulesEntity implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    private UUID id;

    @Column(name = "if_condition")
    private String ifCondition;

    @Column(name = "then_condition")
    private String thenCondition;

    @Column(name = "rule_number")
    private int ruleNumber;

    @Column(name = "name")
    private String name;
}