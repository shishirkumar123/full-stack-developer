package com.creditone.ucrm.payments.rules.dao;

import com.creditone.ucrm.payments.rules.pojo.Rule;
import com.creditone.ucrm.payments.rules.repository.EWSRulesRepository;
import lombok.extern.slf4j.Slf4j;
import org.drools.template.ObjectDataCompiler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Slf4j
@Component
public class EWSRulesDAO {
    private String rulesTemplatePath;
    private EWSRulesRepository eWSRulesRepository;

    public EWSRulesDAO(@Value(value = "${rules.template.path}") String rulesTemplatePath,
                       EWSRulesRepository eWSRulesRepository) {
        this.rulesTemplatePath = rulesTemplatePath;
        this.eWSRulesRepository = eWSRulesRepository;
        
    }

    public String loadRules(String ruleName) throws IOException {
        List<Rule> ruleResponses = eWSRulesRepository.findByNameOrderByRuleNumberAsc(ruleName).stream().map(ruleEntity -> {
            Rule ruleResponse = new Rule();
            ruleResponse.setId(ruleEntity.getId());
            ruleResponse.setIfCondition(ruleEntity.getIfCondition());
            ruleResponse.setThenCondition(ruleEntity.getThenCondition());
            ruleResponse.setVersion(ruleEntity.getRuleNumber());
            return ruleResponse;
        }).toList();

        ObjectDataCompiler compiler = new ObjectDataCompiler();

        try {
            log.info("rulesTemplatePath: {}", rulesTemplatePath);
            String drl = compiler.compile(ruleResponses, Thread.currentThread().getContextClassLoader().getResourceAsStream(rulesTemplatePath));

            log.info("DRL for Rule: {}, {}", ruleName, drl);

            return drl;
        }
        catch (Exception e) {
            log.error("Failed compiling the rules. Reason: {}", e.getMessage(), e);
            throw e;
        }
    }
    
}