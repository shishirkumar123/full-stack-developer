package com.creditone.ucrm.payments.rules.repository;

import com.creditone.ucrm.payments.rules.entity.EWSRulesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EWSRulesRepository extends JpaRepository<EWSRulesEntity, UUID> {
    public List<EWSRulesEntity> findByNameOrderByRuleNumberAsc(String name);
}