package com.creditone.ucrm.payments.rules.pojo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Data
public class Rule {
    private UUID id;
    private String ifCondition;
    private String thenCondition;
    private int version;
    private String name;
}