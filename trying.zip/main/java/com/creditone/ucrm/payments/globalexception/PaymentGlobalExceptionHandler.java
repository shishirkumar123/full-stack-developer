package com.creditone.ucrm.payments.globalexception;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.exception.*;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.ErrorResponse;
import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ServerWebInputException;
import reactor.core.publisher.Mono;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Rest Controller Advice for Payment Service Microservice
 */
@Slf4j
@RestControllerAdvice
public class PaymentGlobalExceptionHandler {

    /**
     * Handles ConstraintViolationException thrown from Controller classes and
     * returns a well formed error response back to the client, with HTTP Status 400
     *
     * @param e ConstraintViolationException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ConstraintViolationException.class)
    public Mono<ErrorResponse> handleConstraintViolationException(ConstraintViolationException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for ConstraintViolationException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            List<String> constraintVioLationErrors = e.getConstraintViolations().stream()
                    .map(ConstraintViolation::getMessage).collect(Collectors.toList());

            List<String> errorMessages = new ArrayList<>();
            constraintVioLationErrors.forEach(s -> {
                errorMessages.add(s);
            });

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles WebExchangeBindException thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 400
     *
     * @param e WebExchangeBindException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(WebExchangeBindException.class)
    public Mono<ErrorResponse> handleWebExchangeBindException(WebExchangeBindException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for WebExchangeBindException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            List<String> errorMessages = e.getBindingResult().getFieldErrors().stream().map(err -> {
                String error = err.getField() + PaymentUtil.mapCustomError(err);
                error = PaymentUtil.getCustomizedMapping(error);
                return error;
            }).collect(Collectors.toList());

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles PaymentDataException thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 400
     *
     * @param e Exception
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(PaymentDataException.class)
    public Mono<ErrorResponse> handlePaymentDataException(PaymentDataException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for PaymentDataException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            List<String> errorMessages = new ArrayList<>();

            String error = e.getMessage();

            if (error != null) {
                for (String s : error.split(";")) {
                    errorMessages.add(s);
                }
            }

            if (CollectionUtils.isEmpty(errorMessages)) {
                errorMessages.add(error);
            }

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles PaymentDataException thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 409
     *
     * @param e Exception
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(PaymentConflictException.class)
    public Mono<ErrorResponse> PaymentDataConflictException(PaymentConflictException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for PaymentDataException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            List<String> errorMessages = new ArrayList<>();

            String error = e.getMessage();

            if (error != null) {
                for (String s : error.split(";")) {
                    errorMessages.add(s);
                }
            }

            if (CollectionUtils.isEmpty(errorMessages)) {
                errorMessages.add(error);
            }

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.CONFLICT.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles ServiceUnavailableException thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 503
     *
     * @param e ServiceUnavailableException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    @ExceptionHandler(ServiceUnavailableException.class)
    public Mono<ErrorResponse> handleServiceUnavailableException(ServiceUnavailableException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for ServiceUnavailableException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            String error = e.getMessage();
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(e.getHttpStatusCode().value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles PaymentException thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 500
     *
     * @param e PaymentException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(PaymentException.class)
    public Mono<ErrorResponse> handlePaymentException(PaymentException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for PaymentException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            String error = e.getMessage();
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ServerWebInputException.class)
    public Mono<ErrorResponse> handleServerWebInputException(ServerWebInputException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for ServerWebInputException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            Map<String, String> mapResult = getValuesServerWebInputException(e);
            String requiredType = (String)mapResult.get(PaymentConstants.REQUIRED_TYPE);
            String value = (String)mapResult.get(PaymentConstants.VALUE);

            String error = PaymentErrors.VALIDATION_ENUM_INPUT_VALUE.replace("{requiredType}", requiredType);
            error = error.replace("{value}", value);
            error = PaymentUtil.getCustomizedMapping(error);

            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    private Map<String, String> getValuesServerWebInputException(ServerWebInputException e) {
        String requiredType = "";
        String value = "";

        if(e.getCause() instanceof  TypeMismatchException) {
            TypeMismatchException typeMismatchException = (TypeMismatchException)e.getCause();
            value = typeMismatchException.getValue().toString();
            requiredType = typeMismatchException.getRequiredType().getSimpleName();
        }
        else if(e.getCause() instanceof  DecodingException) {
            DecodingException decodingException = (DecodingException)e.getCause();
            ValueInstantiationException valueInstantiationException = (ValueInstantiationException)decodingException.getCause();
            IllegalArgumentException illegalArgumentException = (IllegalArgumentException)valueInstantiationException.getCause();
            if(valueInstantiationException.getPath().size() > 0) {
                requiredType = valueInstantiationException.getPath().get(valueInstantiationException.getPath().size()-1).getFieldName();
            }
            value = illegalArgumentException.getMessage();
            value = value.replace("Unexpected value ", "");
            value = value.replace("'", "");
        }

        Map<String, String> mapResult = new HashMap<String, String>();
        mapResult.put(PaymentConstants.REQUIRED_TYPE, requiredType);
        mapResult.put(PaymentConstants.VALUE, value);

        return mapResult;
    }

    /**
     * Handles any uncaught Exception thrown from Controller classes and returns a
     * well formed error response back to the client, with HTTP Status 500
     *
     * @param e Exception
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public Mono<ErrorResponse> handleException(Exception e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for Exception. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            String error = e.getMessage();
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles PaymentServiceDataNotFoundException thrown from Controller classes and
     * returns a well-formed error response back to the client, with HTTP Status 404
     *
     * @param e ExternalAccountDataNotFoundException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(PaymentDataNotFoundException.class)
    public Mono<ErrorResponse> handlePaymentDataNotFoundException(PaymentDataNotFoundException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for PaymentDataNotFoundException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            String error = e.getMessage();
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.NOT_FOUND.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }

    /**
     * Handles PaymentServiceDataNotFoundException thrown from Controller classes and
     * returns a well-formed error response back to the client, with HTTP Status 422
     *
     * @param e ExternalAccountDataNotFoundException
     * @return Mono of ErrorResponse
     **/
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ExceptionHandler(PaymentDataUnprocessableEntityException.class)
    public Mono<ErrorResponse> handlePaymentDataUnprocessableEntityException(PaymentDataUnprocessableEntityException e) {
        return Mono.deferContextual(context -> {
            log.error(PaymentConstants.LOG_PREFIX + "Inside Controller Advice for PaymentDataUnprocessableEntityException. Failure Reason: {}", context.get(PaymentConstants.CORRELATION_ID), e.getMessage(), e);

            String error = e.getMessage();
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add(error);

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorMsg(errorMessages);
            errorResponse.setStatusCode(HttpStatus.UNPROCESSABLE_ENTITY.value());
            errorResponse.setTimestamp(String.valueOf(ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli()));

            return Mono.just(errorResponse);
        });
    }
}