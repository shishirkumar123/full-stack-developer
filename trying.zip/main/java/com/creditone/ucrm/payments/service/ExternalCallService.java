package com.creditone.ucrm.payments.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClientRequestException;

import com.creditone.ucrm.payments.clienthandler.PaymentClientHandler;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.exception.PaymentConflictException;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
//import com.ucrm.swagger.paymentservice.model.InlineResponse2001;
import com.ucrm.swagger.achtransactionservice.model.AchTransactionRequest;
import com.ucrm.swagger.achtransactionservice.model.AchTransactionResponse;
import com.ucrm.swagger.achtransactionservice.model.AchVoidPaymentRequest;
import com.ucrm.swagger.achtransactionservice.model.AchVoidPaymentResponse;
import com.ucrm.swagger.collection.model.CollectionIntentRequest;
import com.ucrm.swagger.collection.model.CollectionIntentResponse;
import com.ucrm.swagger.communicationhuapiservice.model.EnterpriseCommunicationrequest;
import com.ucrm.swagger.communicationhuapiservice.model.EnterpriseCommunicationresponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountBalanceResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountSettingResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsDetailsResponseContent;
import com.ucrm.swagger.creditcardaccountservice.model.EmailResponse;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceRequest;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceResponse;
import com.ucrm.swagger.debittransactionservice.model.DebitTransactionRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitTransactionResponse;
import com.ucrm.swagger.debittransactionservice.model.DebitVoidPaymentsRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitVoidPaymentsResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsGatewayResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsPartnerRequest;
import com.ucrm.swagger.externalaccounts.model.AccountTokenResponse;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.externalaccounts.model.ExternalAccountListResponse;
import com.ucrm.swagger.externalaccounts.model.SuppressedExtlBankAcctResponse;
import com.ucrm.swagger.externaldebitcards.model.DebitCardInfoResponse;
import com.ucrm.swagger.externaldebitcards.model.GetDebitCardTokenResponse;
import com.ucrm.swagger.externaldebitcards.model.GetDebitCardsResponse;
import com.ucrm.swagger.financialtransactionmanagementservice.model.InlineResponse2001;
import com.ucrm.swagger.financialtransactionmanagementservice.model.TransactionsVoidBody;
import com.ucrm.swagger.paymentrulesservice.model.EligiblePaymentAmountResponse;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckResponse;
import com.ucrm.swagger.paymentrulesservice.model.PaymentEligibilityDateResponse;
import com.ucrm.swagger.paymentrulesservice.model.RiskyPaymentRequest;
import com.ucrm.swagger.paymentrulesservice.model.RiskyPaymentResponse;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;

import io.netty.handler.timeout.ReadTimeoutException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class ExternalCallService {

	private PaymentClientHandler paymentClientHandler;
	private String ciamHost;
	private String ciamURI;
	private String ciamApiKey;
	private String creditCardAccountHost;
	private String creditCardAccountCardBalanceURI;
	private String creditCardAccountCreditAccountsURI;
	private String communicationHubApiHost;
	private String communicationHubApiURI;
	private String communicationHubApiApiKey;
	private String externalAccountsHost;
	private String externalAccountsTokenURI;
	private String externalAccountsExternalAccountsURI;
	private String externalDebitCardsHost;
	private String externalDebitCardsTokenURI;
	private String externalDebitCardsAccountsURI;
	private String externalDebitCardsAccountsByIdURI;
	private String paymentRulesHost;
	private String paymentRulesAllowedPaymentDatesURI;
	private String paymentRulesAllowedAmountURI;
	private String ewsServicePartnerHost;
	private String ewsServicePartnerURI;
	private String ewsServicePartnerApiKey;
	private String achTransactionHost;
	private String achTransactionURI;
	private String achTransactionApiKey;
	private String achTransactionVoidURI;
	private String debitTransactionHost;
	private String debitTransactionURI;
	private String debitTransactionApiKey;
	private String debitTransactionVoidURI;
	private String riskyPaymentURI;
	private String externalAccountsExternalAccountsByIdURI;
	private String fraudRulesURI;
	private String creditCardAccountApiKey;
	private String creditCardEmailUri;
	private String collectionsHost;
	private String collectionsIntentURI;
	private String collectionsApiKey;
	private String creditCardAccountsList;
	private String externalAccountsExternalAccountsSuppressionURI;

	private String creditCardAccountCreditAccountsSettingsURI;
	private String ftmsTransactionHost;
	private String ftmsTransactionVoidURI;
	private String ftmsTransactionApiKey;

	public ExternalCallService(PaymentClientHandler paymentClientHandler, @Value(value = "${customerdomain.host}") String ciamHost,
			@Value(value = "${customerdomain.uri}") String ciamURI, @Value("${ciam.api.key}") String ciamApiKey,
			@Value(value = "${creditcardaccount.host}") String creditCardAccountHost, @Value(value = "${creditcardaccount.cardBalance.uri}") String creditCardAccountCardBalanceURI,
			@Value(value = "${creditcardaccount.creditAccounts.uri}") String creditCardAccountCreditAccountsURI,
			@Value(value = "${creditcardaccount.list.id.uri}") String creditCardAccountsList, @Value(value = "${communication.host}") String communicationHubApiHost,
			@Value(value = "${communication.uri}") String communicationHubApiURI, @Value(value = "${communication.api.key}") String communicationHubApiApiKey,
			@Value(value = "${extaccounts.host}") String externalAccountsHost, @Value(value = "${extaccounts.token.uri}") String externalAccountsTokenURI,
			@Value(value = "${extaccounts.externalAccounts.uri}") String externalAccountsExternalAccountsURI, @Value(value = "${extdebitcards.host}") String externalDebitCardsHost,
			@Value(value = "${extdebitcards.token.uri}") String externalDebitCardsTokenURI, @Value(value = "${extdebitcards.accounts.uri}") String externalDebitCardsAccountsURI,
			@Value(value = "${paymentrules.host}") String paymentRulesHost, @Value(value = "${paymentrules.allowedPaymentDates.uri}") String paymentRulesAllowedPaymentDatesURI,
			@Value(value = "${paymentrules.allowedAmount.uri}") String paymentRulesAllowedAmountURI, @Value(value = "${ewsservicepartner.host}") String ewsServicePartnerHost,
			@Value(value = "${ewsservicepartner.uri}") String ewsServicePartnerURI, @Value(value = "${ewsservicepartner.apikey}") String ewsServicePartnerApiKey,
			@Value(value = "${achtransaction.host}") String achTransactionHost, @Value(value = "${achtransaction.uri}") String achTransactionURI,
			@Value(value = "${achtransaction.apikey}") String achTransactionApiKey, @Value(value = "${achtransaction.void.uri}") String achTransactionVoidURI,
			@Value(value = "${debittransaction.host}") String debitTransactionHost, @Value(value = "${debittransaction.uri}") String debitTransactionURI,
			@Value(value = "${debittransaction.apikey}") String debitTransactionApiKey, @Value(value = "${debittransaction.void.uri}") String debitTransactionVoidURI,
			@Value(value = "${paymentrules.riskypayment.uri}") String riskyPaymentURI,
			@Value(value = "${extaccounts.externalAccounts.id.uri}") String externalAccountsExternalAccountsByIdURI,
			@Value(value = "${extdebitcards.accounts.id.uri}") String externalDebitCardsAccountsByIdURI, @Value(value = "${paymentrules.fraudRules.uri}") String fraudRulesURI,
			@Value(value = "${creditcardaccount.creditAccounts.update.uri}") String creditCardAccountCardBalanceUpdateURI,
			@Value(value = "${creditcardaccount.apikey}") String creditCardAccountApiKey, @Value(value = "${creditcardaccount.email.uri}") String creditCardEmailUri,
			@Value(value = "${collection.host}") String collectionsHost, @Value(value = "${collection.intent.uri}") String collectionsIntentURI,
			@Value(value = "${collection.apikey}") String collectionsApiKey,
			@Value(value = "${creditcardaccount.creditAccountsSettings.uri}") String creditCardAccountCreditAccountsSettingsURI,
			@Value(value = "${extaccounts.externalAccounts.suppression.uri}") String externalAccountsExternalAccountsSuppressionURI,
			@Value(value = "${ftmstransaction.apikey}") String ftmsTransactionApiKey, @Value(value = "${ftmstransaction.void.uri}") String ftmsTransactionVoidURI,
			@Value(value = "${ftmstransaction.host}") String ftmsTransactionHost) {
		this.paymentClientHandler = paymentClientHandler;
		this.ciamHost = ciamHost;
		this.ciamURI = ciamURI;
		this.ciamApiKey = ciamApiKey;
		this.creditCardAccountHost = creditCardAccountHost;
		this.creditCardAccountCardBalanceURI = creditCardAccountCardBalanceURI;
		this.creditCardAccountCreditAccountsURI = creditCardAccountCreditAccountsURI;
		this.creditCardAccountsList = creditCardAccountsList;
		this.communicationHubApiHost = communicationHubApiHost;
		this.communicationHubApiURI = communicationHubApiURI;
		this.communicationHubApiApiKey = communicationHubApiApiKey;
		this.externalAccountsHost = externalAccountsHost;
		this.externalAccountsTokenURI = externalAccountsTokenURI;
		this.externalAccountsExternalAccountsURI = externalAccountsExternalAccountsURI;
		this.externalDebitCardsHost = externalDebitCardsHost;
		this.externalDebitCardsTokenURI = externalDebitCardsTokenURI;
		this.externalDebitCardsAccountsURI = externalDebitCardsAccountsURI;
		this.paymentRulesHost = paymentRulesHost;
		this.paymentRulesAllowedPaymentDatesURI = paymentRulesAllowedPaymentDatesURI;
		this.paymentRulesAllowedAmountURI = paymentRulesAllowedAmountURI;
		this.ewsServicePartnerHost = ewsServicePartnerHost;
		this.ewsServicePartnerURI = ewsServicePartnerURI;
		this.ewsServicePartnerApiKey = ewsServicePartnerApiKey;
		this.achTransactionHost = achTransactionHost;
		this.achTransactionURI = achTransactionURI;
		this.achTransactionApiKey = achTransactionApiKey;
		this.achTransactionVoidURI = achTransactionVoidURI;
		this.debitTransactionHost = debitTransactionHost;
		this.debitTransactionURI = debitTransactionURI;
		this.debitTransactionApiKey = debitTransactionApiKey;
		this.debitTransactionVoidURI = debitTransactionVoidURI;
		this.riskyPaymentURI = riskyPaymentURI;
		this.externalAccountsExternalAccountsByIdURI = externalAccountsExternalAccountsByIdURI;
		this.externalDebitCardsAccountsByIdURI = externalDebitCardsAccountsByIdURI;
		this.fraudRulesURI = fraudRulesURI;
		this.creditCardAccountApiKey = creditCardAccountApiKey;
		this.creditCardEmailUri = creditCardEmailUri;
		this.collectionsHost = collectionsHost;
		this.collectionsIntentURI = collectionsIntentURI;
		this.collectionsApiKey = collectionsApiKey;
		this.externalAccountsExternalAccountsSuppressionURI = externalAccountsExternalAccountsSuppressionURI;
		this.creditCardAccountCreditAccountsSettingsURI = creditCardAccountCreditAccountsSettingsURI;
		this.ftmsTransactionApiKey = ftmsTransactionApiKey;
		this.ftmsTransactionHost = ftmsTransactionHost;
		this.ftmsTransactionVoidURI = ftmsTransactionVoidURI;
	}

	// @Timed(value = "externalCallService.getCustomerDetailFromCIAM.timer")
	public Mono<EntityModelIndividualCoreIdentityResponse> getCustomerDetailFromCIAM(String customerId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to CIAM Service(). customerId {}", correlationId, customerId);
		Map<String, String> mapHeaders = new HashMap<>();
		mapHeaders.put(PaymentConstants.API_KEY, ciamApiKey);
		mapHeaders.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		String url = ciamHost.concat(ciamURI).replace(PaymentConstants.CUSTOMER_ID, customerId);

		return paymentClientHandler.webClientGet(url, mapHeaders, PaymentConstants.CIAM).bodyToMono(EntityModelIndividualCoreIdentityResponse.class).flatMap(coreIdentity -> {
			EntityModelIndividualCoreIdentityResponse entityModelIndividualCoreIdentityLogging = new EntityModelIndividualCoreIdentityResponse();
			entityModelIndividualCoreIdentityLogging.setFirstName(coreIdentity.getFirstName());
			entityModelIndividualCoreIdentityLogging.setLastName(coreIdentity.getLastName());
			log.debug(PaymentConstants.LOG_PREFIX + "Response from CIAM service: entityModelIndividualCoreIdentity {}", correlationId, entityModelIndividualCoreIdentityLogging);
			long endTime = System.nanoTime();
			long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
			log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + ciamHost + ciamURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
			return Mono.just(coreIdentity);
		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error from CIAM Service(): error: {}", correlationId, err.getMessage());
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_CIAM_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		});
	}

	public Mono<AccountDetailsResponse> getAccountsFromCreditCardAccountsService(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Accounts from CreditCardAccountService, creditAccountId: {}", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();

		String url = creditCardAccountHost.concat(creditCardAccountCreditAccountsURI).replace("{accountID}", creditAccountId);

		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToMono(AccountDetailsResponse.class)
				.defaultIfEmpty(new AccountDetailsResponse()).flatMap(accountDetailsResponse -> {
					if (accountDetailsResponse.getAccountId() == null) {
						PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_NOT_CREDIT_CARD_ACCOUNT_FOUND);
						paymentDataException.setHttpStatusCode(HttpStatusCode.valueOf(404));
						log.error(PaymentConstants.LOG_PREFIX + PaymentErrors.ERROR_NOT_CREDIT_CARD_ACCOUNT_FOUND, correlationId);
						return Mono.error(paymentDataException);
					}
					log.debug(PaymentConstants.LOG_PREFIX + "Response to Getting Accounts from CreditCardAccountService, accountDetailsResponse: {}", correlationId,
							accountDetailsResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(accountDetailsResponse);
				}).onErrorResume(err -> {
					if (err instanceof PaymentDataException exception && exception.getHttpStatusCode().value() == 404) {
						ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
						serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
						return Mono.error(serviceUnavailableException);
					}
					String logError = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: " + creditAccountId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + logError, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromCreditCardAccountsServiceByID.timer")
	public Mono<AccountDetailsResponse> getAccountsFromCreditCardAccountsServiceByID(String creditAccountID, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Accounts from CreditCardAccountService, creditAccountID: {}", correlationId, creditAccountID);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		String url = creditCardAccountHost.concat(creditCardAccountCreditAccountsURI).replace("{accountID}", creditAccountID);
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToMono(AccountDetailsResponse.class)
				.flatMap(accountDetailsResponse -> {
					log.debug(PaymentConstants.LOG_PREFIX + "Response to Getting Accounts from CreditCardAccountService, accountDetailsResponse: {}", correlationId,
							accountDetailsResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(accountDetailsResponse);
				}).onErrorResume(err -> {
					log.error(PaymentConstants.LOG_PREFIX + PaymentErrors.ERROR_CONSUMING_CREDITCARD_ACCOUNTS_SERVICE_CREDITCARD_ACCOUNT, correlationId, creditAccountID,
							err.getMessage());
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getCreditCardDetailsAccountsServiceWithStatus.timer")
	public Mono<AccountDetailsResponse> getCreditCardDetailsAccountsServiceWithStatus(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Accounts from CreditCardAccountService, creditAccountId: {}", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		String url = creditCardAccountHost.concat(creditCardAccountCreditAccountsURI).replace("{accountID}", creditAccountId);
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
			int statusCode = clientResponse.statusCode().value();
			log.info(statusCode + " response from the service");
			if (statusCode == 404) {
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_NO_RECORD_FOUND_CREDIT_ACCOUNT_ID);
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				return Mono.error(paymentDataNotFoundException);
			}
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		}).bodyToMono(AccountDetailsResponse.class).flatMap(accountDetailsResponse -> {
			long endTime = System.nanoTime();
			long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
			log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
			log.info(PaymentConstants.LOG_PREFIX + "Response to Getting Accounts from CreditCardAccountService, accountDetailsResponse: {}", correlationId, accountDetailsResponse);

			return Mono.just(accountDetailsResponse);
		}).switchIfEmpty(Mono.error(new PaymentDataNotFoundException("[]"))).onErrorResume(err -> {
			String error = PaymentErrors.ERROR_CONSUMING_CREDITCARD_ACCOUNTS_SERVICE_CREDITCARD_ACCOUNTS.replace("{creditAccountId}", creditAccountId);
			error = error.replace("{errorMessage}", err.getMessage());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		});
	}

	// @Timed(value =
	// "externalCallService.getCreditCardDetailsAccountsService.timer")
	public Mono<AccountDetailsResponse> getCreditCardDetailsAccountsService(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Accounts from CreditCardAccountService, creditAccountId: {}", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		String url = creditCardAccountHost.concat(creditCardAccountCreditAccountsURI).replace("{accountID}", creditAccountId);
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToMono(AccountDetailsResponse.class)
				.flatMap(accountDetailsResponse -> {
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting Accounts from CreditCardAccountService, accountDetailsResponse: {}", correlationId,
							accountDetailsResponse);
					return Mono.just(accountDetailsResponse);
				}).onErrorResume(err -> {
					String error = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: " + creditAccountId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.getAvailableCreditBalance.timer")
	public Mono<AccountBalanceResponse> getAvailableCreditBalance(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting available credit card balance, creditAccountId {}", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(creditCardAccountHost.concat(creditCardAccountCardBalanceURI).replace("{accountID}", creditAccountId), headers,
				PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToMono(AccountBalanceResponse.class).doOnSuccess(creditCardAccountOverviewResponse -> {
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + creditCardAccountCardBalanceURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting available Credit card balance: creditCardAccountOverviewResponse {}", correlationId,
							creditCardAccountOverviewResponse);
				}).onErrorResume(err -> {
					String logError = "Error in Getting available Credit card balance, creditAccountId: " + creditAccountId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + logError, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.getAutoPayAvailableCreditBalance.timer")
	public Mono<AccountBalanceResponse> getAutoPayAvailableCreditBalance(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Started getAutoPayAvailableCreditBalance() creditAccountId {} ", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(creditCardAccountHost.concat(creditCardAccountCardBalanceURI).replace("{accountID}", creditAccountId), headers,
				PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToMono(AccountBalanceResponse.class).doOnSuccess(creditCardAccountOverviewResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting available Credit card balance: getAutoPayAvailableCreditBalance {}", correlationId,
							creditCardAccountOverviewResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + creditCardAccountCardBalanceURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
				}).onErrorResume(err -> {
					String exceptionMessage = null;
					if (err instanceof WebClientRequestException && err.getCause() instanceof ReadTimeoutException) {
						exceptionMessage = "HTTP Timeout";
					} else {
						exceptionMessage = err.getMessage();
					}
					String error = "Failed to retrieve available Credit card balance for creditAccountId: " + creditAccountId + ", reason: " + exceptionMessage;
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getEnterpriseCommunicationresponseFromCommunicationHubApi.timer")
	public Mono<EnterpriseCommunicationresponse> getEnterpriseCommunicationresponseFromCommunicationHubApi(EnterpriseCommunicationrequest enterpriseCommunicationrequest, String templateId, String correlationId) {
		log.info(
				PaymentConstants.LOG_PREFIX
						+ "Request to Getting EnterpriseCommunicationresponse from CommunicationHubApiService, enterpriseCommunicationrequest: {}, templateId: {}",
				correlationId, enterpriseCommunicationrequest, templateId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, communicationHubApiApiKey);
		long startTime = System.nanoTime();
		String url = communicationHubApiHost.concat(communicationHubApiURI).replace("{templateId}", templateId);
		return paymentClientHandler.webClientPost(url, enterpriseCommunicationrequest, headers, PaymentConstants.COMMUNICATION_HUB_API_SERVICE)
				.bodyToMono(EnterpriseCommunicationresponse.class).doOnSuccess(enterpriseCommunicationresponse -> {
					log.info(
							PaymentConstants.LOG_PREFIX
									+ "Response to Getting EnterpriseCommunicationresponse from CommunicationHubApiService, enterpriseCommunicationresponse: {}",
							correlationId, enterpriseCommunicationresponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
				}).onErrorResume(err -> {
					String error = "Error in Getting EnterpriseCommunicationresponse from CommunicationHubApiService, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_COMMUNICATION_HUB_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.getCommunicationEmailId.timer")
	public Flux<EmailResponse> getCommunicationEmailId(PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting getCommunicationEmailId from CreditCard Account Service for paymentCommunicationDetailsRequest: {}",
				correlationId, paymentCommunicationDetailsRequest);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		String url = creditCardAccountHost.concat(creditCardEmailUri).replace("{involvementId}", paymentCommunicationDetailsRequest.getInvolvementId());
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE).bodyToFlux(EmailResponse.class)
				.switchIfEmpty(Flux.error(new PaymentDataNotFoundException("[]"))).onErrorResume(err -> {
					log.error(PaymentConstants.LOG_PREFIX + err.getMessage(), correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromExternalAccountsService.timer")
	public Mono<ExternalAccountListResponse> getAccountsFromExternalAccountsService(String customerId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to External Accounts Service for getting External Accounts (). customerId {}", correlationId, customerId);
		long startTime = System.nanoTime();
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		return paymentClientHandler
				.webClientGet(externalAccountsHost + externalAccountsExternalAccountsURI.replace(PaymentConstants.CUSTOMER_ID, customerId), headers, "External Accounts", null)
				.bodyToMono(ExternalAccountListResponse.class).flatMap(externalAccountListResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from External Accounts Service for getting External Accoounts: {}", correlationId,
							externalAccountListResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalAccountsExternalAccountsURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
					return Mono.just(externalAccountListResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming External Accounts Service for getting External Accounts, customerId: " + customerId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
					paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
					return Mono.error(paymentDataNotFoundException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromExternalAccountsServiceByID.timer")
	public Mono<BankAccountResponse> getAccountsFromExternalAccountsServiceByID(String customerId, String bankAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to External Accounts Service for getting External Accounts (). customerId {}, bankAccountId {}", correlationId, customerId,
				bankAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(
				externalAccountsHost + externalAccountsExternalAccountsByIdURI.replace(PaymentConstants.CUSTOMER_ID, customerId).replace("{externalBankAccountId}", bankAccountId),
				headers, PaymentConstants.EXTERNAL_ACCOUNTS_SERVICE, null).bodyToMono(BankAccountResponse.class).flatMap(externalAccountResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from External Accounts Service for getting External Accounts: {}", correlationId, externalAccountResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalAccountsExternalAccountsByIdURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
					return Mono.just(externalAccountResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming External Accounts Service for getting External Accounts By Id, customerId: " + customerId + ", bankAccountId: " + bankAccountId
							+ ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
					paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
					return Mono.error(paymentDataNotFoundException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountTokenFromExternalBankAccounts.timer")
	public Mono<AccountTokenResponse> getAccountTokenFromExternalBankAccounts(String customerId, String bankAccountId, String channel, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Token from External Accounts Service(). customerId: {}, bankAccountId: {}, channel: {}", correlationId,
				customerId, bankAccountId, channel);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.CHANNEL, channel);

		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(
				externalAccountsHost + externalAccountsTokenURI.replace(PaymentConstants.CUSTOMER_ID, customerId).replace(PaymentConstants.BANK_ACCOUNT_ID, bankAccountId), headers,
				PaymentConstants.EXTERNAL_ACCOUNTS_SERVICE).bodyToMono(AccountTokenResponse.class).flatMap(accountTokenResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting Token from External Accounts Service: {}", correlationId, accountTokenResponse);

					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalAccountsTokenURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(accountTokenResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming External Accounts Service for Getting Token, customerId: " + customerId + ", bankAccountId: " + bankAccountId + ", error: "
							+ err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_EXTERNAL_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromExternalDebitAccountsService.timer")
	public Mono<GetDebitCardsResponse> getAccountsFromExternalDebitAccountsService(String customerId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to External Debit Cards Service. customerId {}", correlationId, customerId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		return paymentClientHandler
				.webClientGet(externalDebitCardsHost + externalDebitCardsAccountsURI.replace(PaymentConstants.CUSTOMER_ID, customerId), headers, "External Debit Cards", null)
				.bodyToMono(GetDebitCardsResponse.class).flatMap(getDebitCardsResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from External Debit Cards Service: {}", correlationId, getDebitCardsResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalDebitCardsAccountsURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(getDebitCardsResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming External Debit Cards Service, for Getting Accounts, customerId: " + customerId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
					paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
					return Mono.error(paymentDataNotFoundException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromExternalDebitAccountsServiceById.timer")
	public Mono<DebitCardInfoResponse> getAccountsFromExternalDebitAccountsServiceById(String customerId, String bankAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to External Debit Cards Service. customerId {}, bankAccountId {}", correlationId, customerId, bankAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		return paymentClientHandler
				.webClientGet(externalDebitCardsHost + externalDebitCardsAccountsByIdURI.replace(PaymentConstants.CUSTOMER_ID, customerId).replace("{debitCardId}", bankAccountId),
						headers, "External Debit Cards", null)
				.bodyToMono(DebitCardInfoResponse.class).flatMap(getDebitCardsResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from External Debit Cards Service: {}", correlationId, getDebitCardsResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalDebitCardsAccountsByIdURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);

					return Mono.just(getDebitCardsResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming External Debit Cards Service, for Getting Accounts By Id, customerId: " + customerId + ", bankAccountId: " + bankAccountId
							+ ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
					paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
					return Mono.error(paymentDataNotFoundException);
				});
	}

	// @Timed(value =
	// "externalCallService.getTokenFromDebitExternalAccountsService.timer")
	public Mono<GetDebitCardTokenResponse> getTokenFromDebitExternalAccountsService(String customerId, String debitCardId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting Token from External Debit Cards Service(). customerId {}, debitCardId {}", correlationId, customerId,
				debitCardId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		return paymentClientHandler
				.webClientGet(externalDebitCardsHost + externalDebitCardsTokenURI.replace(PaymentConstants.CUSTOMER_ID, customerId).replace("{debitCardId}", debitCardId), headers,
						"External Debit Cards")
				.bodyToMono(GetDebitCardTokenResponse.class).flatMap(getDebitCardTokenResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting Token from External Debit Cards Service: {}", correlationId, getDebitCardTokenResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalDebitCardsTokenURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(getDebitCardTokenResponse);
				}).onErrorResume(err -> {
					String error = "Error Getting Token from External Debit Cards Service customerId: " + customerId + ", debitCardId: " + debitCardId + ", error: "
							+ err.getMessage();

					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					return Mono.error(err);
				});
	}

	// @Timed(value =
	// "externalCallService.getRangeAllowedPaymentDatesFromPaymentRulesService.timer")
	public Mono<PaymentEligibilityDateResponse> getRangeAllowedPaymentDatesFromPaymentRulesService(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting range allowed payment dates from paymentRulesService, customerId: {}, creditAccountId: {}", correlationId,
				paymentServiceRequest.getCustomerId(), paymentServiceRequest.getCreditAccountId());
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		String url = paymentRulesHost.concat(paymentRulesAllowedPaymentDatesURI).replace("{customerId}", paymentServiceRequest.getCustomerId());
		url = url.replace("{creditAccountId}", paymentServiceRequest.getCreditAccountId());
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.PAYMENT_RULES_SERVICE).bodyToMono(PaymentEligibilityDateResponse.class)
				.doOnSuccess(paymentEligibilityDateResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting range allowed payment dates from paymentRulesService: paymentEligibilityDateResponse {}",
							correlationId, paymentEligibilityDateResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + paymentRulesAllowedPaymentDatesURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
				}).onErrorResume(err -> {
					String error = "";
					if (err instanceof WebClientRequestException && err.getCause() instanceof ReadTimeoutException) {
						error = "Error in Getting range allowed payment dates from paymentRulesService, customerId: " + paymentServiceRequest.getCustomerId()
								+ ", creditCardAccount: " + paymentServiceRequest.getCreditAccountId() + ", error: TimeoutException";
					} else {
						error = "Error in Getting range allowed payment dates from paymentRulesService, customerId: " + paymentServiceRequest.getCustomerId()
								+ ", creditCardAccount: " + paymentServiceRequest.getCreditAccountId() + ", error: " + err.getMessage();
					}

					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_RULES_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getRiskAssesmentPaymentRulesService.timer")
	public Mono<RiskyPaymentResponse> getRiskAssesmentPaymentRulesService(PaymentServiceRequest paymentServiceRequest, RiskyPaymentRequest riskyPaymentRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting riskYPyament from paymentRulesService, request: {}", correlationId, riskyPaymentRequest);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		String url = paymentRulesHost.concat(riskyPaymentURI);
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientPost(url, riskyPaymentRequest, headers, PaymentConstants.PAYMENT_RULES_SERVICE).bodyToMono(RiskyPaymentResponse.class)
				.doOnSuccess(riskyPaymentResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting riskyPaymentResponse from paymentRulesService, riskyPaymentResponse: {}", correlationId,
							riskyPaymentResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
				}).onErrorResume(err -> {
					String error = "Error in Risky payment check from paymentRulesService, customerId: " + paymentServiceRequest.getCustomerId() + ", creditCardAccount: "
							+ paymentServiceRequest.getCreditAccountId() + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_RULES_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getRangeAllowedAmountFromPaymentRulesService.timer")
	public Mono<EligiblePaymentAmountResponse> getRangeAllowedAmountFromPaymentRulesService(PaymentServiceRequest request, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting range allowed amount from paymentRulesService, customerId: {}, creditAccountId: {}", correlationId,
				request.getCustomerId(), request.getCreditAccountId());
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		String url = paymentRulesHost.concat(paymentRulesAllowedAmountURI).replace("{customerId}", request.getCustomerId());
		url = url.replace("{creditAccountId}", request.getCreditAccountId());
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.PAYMENT_RULES_SERVICE).bodyToMono(EligiblePaymentAmountResponse.class)
				.doOnSuccess(eligiblePaymentAmountResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting range allowed amount from paymentRulesService: eligiblePaymentAmountResponse {}", correlationId,
							eligiblePaymentAmountResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + paymentRulesAllowedAmountURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

				}).onErrorResume(err -> {
					String error = "Error in Getting range allowed amount from paymentRulesService, customerId: " + request.getCustomerId() + ", creditCardAccount: "
							+ request.getCreditAccountId() + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_RULES_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.getPlasticCodeForCustomerIdAndCreditAccountId.timer")
	public Mono<String> getPlasticCodeForCustomerIdAndCreditAccountId(String customerId, String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to getPlasticCodeForCustomerIdAndCreditAccountId, customerId {}, creditAccountId {}", correlationId, customerId,
				creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
		multiValueMap.add("individualId", customerId);
		return paymentClientHandler.webClientGet(creditCardAccountHost.concat(creditCardAccountsList), headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE, multiValueMap)
				.bodyToMono(AccountsDetailsResponse.class).flatMap(accountsDetailsResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to getPlasticCodeForCustomerIdAndCreditAccountId: accountsDetailsResponse {}", correlationId,
							accountsDetailsResponse);
					String plasticDesignCode = null;
					AccountsDetailsResponseContent accountDetailsObj = accountsDetailsResponse.getContent().stream()
							.filter(account -> account.getAccountId().toString().equals(creditAccountId)).findFirst().orElse(null);
					if (accountDetailsObj != null) {
						plasticDesignCode = accountDetailsObj.getDevice().getPlasticDesignCode();
					}
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + creditCardAccountsList + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(plasticDesignCode);
				}).onErrorResume(err -> {
					String error = "";
					if (err instanceof WebClientRequestException && err.getCause() instanceof ReadTimeoutException) {
						error = "Error in Getting plastic code from Credit card accounts list for, customerId: " + customerId + ", creditCardAccount: " + creditAccountId
								+ ", error: TimeoutException";
					} else {
						error = "Error in Getting plastic code from Credit card accounts list for customerId: " + customerId + ", creditCardAccount: " + creditAccountId
								+ ", error: " + err.getMessage();
					}
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_DEBIT_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.callEWSServicePartnerValidation.timer")
	public Mono<EwsGatewayResponse> callEWSServicePartnerValidation(EwsPartnerRequest ewsPartnerRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, ewsServicePartnerApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to Account Validation from EWS Service Partner: {}", correlationId, ewsPartnerRequest);
		return paymentClientHandler.webClientPost(ewsServicePartnerHost + ewsServicePartnerURI, ewsPartnerRequest, headers, PaymentConstants.EWS_SERVICE_PARTNER)
				.bodyToMono(EwsGatewayResponse.class).flatMap(ewsGatewayResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Account Validation from EWS Service Partner: {}", correlationId, ewsGatewayResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + ewsServicePartnerURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(ewsGatewayResponse);
				}).onErrorResume(err -> {
					String error = "Error in Getting Account Validation from EWS Service Partner, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_EWS_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.callACHTransactionServicePayment.timer")
	public Mono<AchTransactionResponse> callACHTransactionServicePayment(AchTransactionRequest achTransactionRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, achTransactionApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to ACH Transaction Service Call: {}", correlationId, achTransactionRequest);
		return paymentClientHandler.webClientPost(achTransactionHost + achTransactionURI, achTransactionRequest, headers, PaymentConstants.ACH_TRANSACTION_SERVICE)
				.bodyToMono(AchTransactionResponse.class).flatMap(achTransactionResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to ACH Transaction Service Call:: {}", correlationId, achTransactionResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + achTransactionURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(achTransactionResponse);
				});
	}

	// @Timed(value = "externalCallService.callACHTransactionServiceCallVoid.timer")
	public Mono<AchVoidPaymentResponse> callACHTransactionServiceCallVoid(AchVoidPaymentRequest achVoidPaymentsRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, achTransactionApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to ACH Transaction Service Void Call: {}", correlationId, achVoidPaymentsRequest);
		return paymentClientHandler.webClientPatch(achTransactionHost + achTransactionVoidURI, achVoidPaymentsRequest, headers, PaymentConstants.ACH_TRANSACTION_SERVICE)
				.bodyToMono(AchVoidPaymentResponse.class).flatMap(achVoidPaymentResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to ACH Transaction Service Void Call: {}", correlationId, achVoidPaymentResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + achTransactionVoidURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(achVoidPaymentResponse);
				}).onErrorResume(err -> {
					String error = "Error consuming void ACH Transaction Service Void Call, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACH_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.callDebitTransactionServicePayment.timer")
	public Mono<DebitTransactionResponse> callDebitTransactionServicePayment(DebitTransactionRequest debitTransactionRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, debitTransactionApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to Debit Transaction Service Call: {}", correlationId, debitTransactionRequest);
		return paymentClientHandler.webClientPost(debitTransactionHost + debitTransactionURI, debitTransactionRequest, headers, "Debit Transaction Service")
				.bodyToMono(DebitTransactionResponse.class).flatMap(debitTransactionResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Debit Transaction Service Call:: {}", correlationId, debitTransactionResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + debitTransactionURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(debitTransactionResponse);
				});
	}

	// @Timed(value = "externalCallService.updateCreditBalance.timer")
	public Mono<UpdateAccountBalanceResponse> updateCreditBalance(PaymentServiceRequest paymentServiceRequest, UpdateAccountBalanceRequest creditCardbalanceRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to Update available credit card balance, payment request {}", correlationId, creditCardbalanceRequest);
		String url = creditCardAccountHost.concat(creditCardAccountCardBalanceURI).replace("{accountID}", paymentServiceRequest.getCreditAccountId());
		return paymentClientHandler.webClientPatch(url, creditCardbalanceRequest, headers, "Credit Card Service").bodyToMono(UpdateAccountBalanceResponse.class)
				.flatMap(response -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to credit card Update balance Call: {}", correlationId, response);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + creditCardAccountCardBalanceURI + PaymentConstants.MILLISECONDS, correlationId,
							elapsedTime);
					return Mono.just(response);
				}).onErrorResume(err -> {
					String errorLog = "Error in update Credit Card Balance from CreditCardAccountService, creditAccountId: " + paymentServiceRequest.getCreditAccountId()
							+ ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + errorLog, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value =
	// "externalCallService.callDebitTransactionServiceCallVoid.timer")
	public Mono<DebitVoidPaymentsResponse> callDebitTransactionServiceCallVoid(DebitVoidPaymentsRequest debitVoidPaymentsRequest, String correlationId) {
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, debitTransactionApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to Debit Transaction Service Void Call: {}", correlationId, debitVoidPaymentsRequest);
		return paymentClientHandler.webClientPatch(debitTransactionHost + debitTransactionVoidURI, debitVoidPaymentsRequest, headers, "Debit Transaction Service")
				.bodyToMono(DebitVoidPaymentsResponse.class).flatMap(response -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Debit Transaction Service Void Call: {}", correlationId, response);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + debitTransactionVoidURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(response);
				}).onErrorResume(err -> {
					String error = "Error consuming void debit Transaction Service, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_DEBIT_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	// @Timed(value = "externalCallService.getFraudRulesPaymentRulesService.timer")
	public Mono<FraudCheckResponse> getFraudRulesPaymentRulesService(FraudCheckRequest fraudRulerequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to getFraudRulesPaymentRulesService, request: {}", correlationId, fraudRulerequest);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		String url = paymentRulesHost.concat(fraudRulesURI);
		return paymentClientHandler.webClientPost(url, fraudRulerequest, headers, PaymentConstants.PAYMENT_RULES_SERVICE).bodyToMono(FraudCheckResponse.class)
				.doOnSuccess(fraudruleResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting fraud Rules from paymentRulesService, fraudRulesResponse: {}", correlationId, fraudruleResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
				}).onErrorResume(err -> {
					String lggError = "Error in Getting fraud Rules from paymentRulesService, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + lggError, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_RULES_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});

	}

	// @Timed(value = "externalCallService.getCollectionIntent.timer")
	public Mono<CollectionIntentResponse> getCollectionIntent(CollectionIntentRequest collectionIntentRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to Getting getCollectionIntent  , collectionIntentRequest: {} ", correlationId, collectionIntentRequest);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, collectionsApiKey);
		String url = collectionsHost.concat(collectionsIntentURI);
		long startTime = System.nanoTime();
		return paymentClientHandler.webClientPost(url, collectionIntentRequest, headers, PaymentConstants.COLLECTION_API).bodyToMono(CollectionIntentResponse.class)
				.doOnSuccess(collectionIntent -> {
					log.info(
							PaymentConstants.LOG_PREFIX + "Response to collectionIntentRequest CollectionIntentResponse from getCollectionIntent api, collectionIntentResponse: {}",
							correlationId, collectionIntent);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
				}).onErrorResume(err -> {
					String error = "Error in Getting CollectionIntentResponse from getCollectionIntent, error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataException paymentDataException = new PaymentDataException(error);
					paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
					return Mono.error(paymentDataException);
				});
	}

	// @Timed(value =
	// "externalCallService.getAccountsFromExternalAccountsService.timer")
	public Mono<SuppressedExtlBankAcctResponse> getAccountsFromExternalAccountsSuppressions(String customerId, String bankAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Request to External Accounts Service for getting Suppresed External Accounts (). customerId {}, bankAccountId {}", correlationId,
				customerId, bankAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		long startTime = System.nanoTime();
		return paymentClientHandler
				.webClientGet(externalAccountsHost + externalAccountsExternalAccountsSuppressionURI.replace(PaymentConstants.BANK_ACCOUNT_ID, bankAccountId), headers,
						"External Accounts", null)
				.bodyToMono(SuppressedExtlBankAcctResponse.class).switchIfEmpty(Mono.error(new PaymentDataNotFoundException(PaymentErrors.ACCOUNT_NOT_IN_SUPPRESSLIST)))
				.flatMap(externalSuppressAccountListResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from External Accounts Service for getting Suppresed External Accoounts: {}", correlationId,
							externalSuppressAccountListResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + externalAccountsExternalAccountsSuppressionURI + PaymentConstants.MILLISECONDS,
							correlationId, elapsedTime);
					return Mono.just(externalSuppressAccountListResponse);
				}).onErrorResume(err -> {
					if (err instanceof PaymentDataNotFoundException) {
						return Mono.error(new PaymentDataNotFoundException(PaymentErrors.ACCOUNT_NOT_IN_SUPPRESSLIST));
					}
					String error = "Error consuming External Accounts Service for getting Suppresed External Accounts, customerId: " + customerId + ", bankAccountId: "
							+ bankAccountId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_IS_INVALID);
					paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
					return Mono.error(paymentDataException);
				});
	}

	public Mono<Boolean> getCeaseAndDesistFromCreditCardAccountsService(String creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Inside getCeaseAndDesistFromCreditCardAccountsService method, creditAccountId: {}", correlationId, creditAccountId);
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_KEY, creditCardAccountApiKey);
		long startTime = System.nanoTime();

		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
		multiValueMap.add("settingType", "SUPPRESSION_GROUP_CODE");

		String url = creditCardAccountHost.concat(creditCardAccountCreditAccountsSettingsURI).replace("{accountID}", creditAccountId);
		return paymentClientHandler.webClientGet(url, headers, PaymentConstants.CREDIT_CARD_ACCOUNT_SERVICE, multiValueMap).bodyToFlux(AccountSettingResponse.class).collectList()
				.flatMap(listAccountSettingResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "accountSettingResponse value : {}", correlationId, listAccountSettingResponse);
					Optional<AccountSettingResponse> optAccountSettingResponseObj = listAccountSettingResponse.stream().filter(res -> res.getSettingData() != null).findFirst();

					if (!optAccountSettingResponseObj.isPresent()) {
						return Mono.just(false);
					}

					if (optAccountSettingResponseObj.isPresent() && optAccountSettingResponseObj.get().getSettingData().equalsIgnoreCase("CA")) {
						return Mono.just(true);
					}

					log.info(PaymentConstants.LOG_PREFIX + "Response to Getting Accounts from CreditCardAccountService, accountDetailsResponse: {}", correlationId,
							listAccountSettingResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + url + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);

					return Mono.just(false);
				}).onErrorResume(err -> {
					if (err instanceof PaymentDataException && ((PaymentDataException) err).getHttpStatusCode().value() == 404) {
						ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
						serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
						return Mono.error(serviceUnavailableException);
					}
					String error = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: " + creditAccountId + ", error: " + err.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}

	public Mono<InlineResponse2001> callFTMSTransactionVoidCall(UUID paymentRequestId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of callFTMSTransactionVoidCall() in service class . paymentRequestId: {}", correlationId, paymentRequestId);
		TransactionsVoidBody transactionsVoidBody = new TransactionsVoidBody();
		transactionsVoidBody.setPaymentRequestId(String.valueOf(paymentRequestId));
		Map<String, String> headers = new HashMap<>();
		headers.put(PaymentConstants.API_KEY, ftmsTransactionApiKey);
		headers.put(PaymentConstants.CORRELATION_ID, correlationId);
		headers.put(PaymentConstants.API_VERSION, PaymentConstants.V1);
		long startTime = System.nanoTime();
		log.info(PaymentConstants.LOG_PREFIX + "Request to FTMS Transaction Service Void Call: {}", correlationId, paymentRequestId);
		return paymentClientHandler.webClientPatch(ftmsTransactionHost + ftmsTransactionVoidURI, transactionsVoidBody, headers, PaymentConstants.FTMS_TRANSACTION_SERVICE)
				.bodyToMono(InlineResponse2001.class).flatMap(inLineResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Response from FTMS Transaction Service Void Call: {}", correlationId, inLineResponse);
					long endTime = System.nanoTime();
					long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
					log.debug(PaymentConstants.LOG_PREFIX + PaymentConstants.TIME_TAKEN + ftmsTransactionVoidURI + PaymentConstants.MILLISECONDS, correlationId, elapsedTime);
					return Mono.just(inLineResponse);
				}).onErrorResume(err -> {
					String error = "Error calling FTMS Transaction Void Service, error: " + err.getMessage();
					if (err instanceof PaymentDataException
							&& (((PaymentDataException) err).getHttpStatusCode().value() == 409 || ((PaymentDataException) err).getHttpStatusCode().value() == 404)) {
						PaymentConflictException paymentCannotVoidException = new PaymentConflictException(PaymentErrors.ERROR_FTMS_TRANSACTION_SERVICE_POSTED_RESPONSE);
						return Mono.error(paymentCannotVoidException);
					}
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_FTMS_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE);
					serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
					return Mono.error(serviceUnavailableException);
				});
	}
}