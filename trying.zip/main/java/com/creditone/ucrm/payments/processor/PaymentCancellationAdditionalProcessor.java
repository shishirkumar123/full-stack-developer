package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dto.AutoPayDBResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class PaymentCancellationAdditionalProcessor {

	private String paymentZoneId;

	public PaymentCancellationAdditionalProcessor(@Value(value = "${payment.zoneId}") String paymentZoneId) {
		this.paymentZoneId = paymentZoneId;
	}

	public JSONObject fillNote(PaymentCommunicationResponse paymentCommunicationResponse, CancelACHPaymentRequest cancelACHPaymentRequest, String notes, String paymentEvent) {
		JSONObject jsonResult = new JSONObject();
		ZonedDateTime zonedDateTime = PaymentUtil.utcNow();
		String date = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATETIMEFORMAT_RESPONSE);

		jsonResult.put(PaymentConstants.DATE, date);

		jsonResult.put(PaymentConstants.NOTES, notes);

		jsonResult.put(PaymentConstants.PAYMENT_EVENT, paymentEvent);

		jsonResult.put(PaymentConstants.AGENT_ID, cancelACHPaymentRequest.getAgentId());

		jsonResult.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentCommunicationResponse.getCommunicationRequestId());

		return jsonResult;
	}

	public Map<String, Object> getPaymentAmountPaymentPurpose(AutoPayDBResponse autoPayDBResponse, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject autoPayDataParams;
		try {
			autoPayDataParams = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
		} catch (ParseException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}

		Map<String, Object> mapResult = new HashMap<String, Object>();
		mapResult.put(PaymentConstants.PAYMENT_AMOUNT, PaymentMapper.convertObjectToBigDecimal((Object) autoPayDataParams.get(PaymentConstants.PAYMENT_AMOUNT)));
		mapResult.put(PaymentConstants.PAYMENT_PURPOSE, (String) autoPayDataParams.get(PaymentConstants.PAYMENT_PURPOSE));
		mapResult.put(PaymentConstants.PAYMENTDATE, (String) autoPayDataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE));

		return mapResult;
	}

	public Map<String, Object> getParamsForCancelOrVoidCommunication(Map<String, Object> parameters, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		Map<String, Object> parametersForDisableAutoPayCommunication = new HashMap<>();
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CUSTOMER_ID, parameters.get(PaymentConstants.CUSTOMER_ID));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CREDIT_ACCOUNT_ID, parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CORRELATION_ID, correlationId);
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PLASTICCODE, parameters.get(PaymentConstants.PLASTICCODE));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENT_AMOUNT, parameters.get(PaymentConstants.PAYMENT_AMOUNT));
		String paymentDate = (paymentRequestDataDBResponse.getPaymentDate() != null) ? PaymentUtil.formatDate(paymentRequestDataDBResponse.getPaymentDate(),
				PaymentConstants.YYYY_MM_DD) : null;
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENTDATE, paymentDate);
		parametersForDisableAutoPayCommunication.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, parameters.get(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.INVOLVEMENT_ID, parameters.get(PaymentConstants.INVOLVEMENT_ID));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CARD_TYPE, parameters.get(PaymentConstants.CARD_TYPE));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CARD_LAST4, parameters.get(PaymentConstants.CARD_LAST4));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PLASTICCODE, parameters.get(PaymentConstants.PLASTICCODE));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PRODUCT_KEY, parameters.get(PaymentConstants.PRODUCT_KEY));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.FIRST_NAME, parameters.get(PaymentConstants.FIRST_NAME));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.LAST_NAME, parameters.get(PaymentConstants.LAST_NAME));

		return parametersForDisableAutoPayCommunication;
	}

	public Map<String, Object> getParamsForAutoPayCancelCommunication(Map<String, Object> parameters, AutoPayDBResponse autoPayDBResponse, String correlationId) {
		Map<String, Object> parametersForDisableAutoPayCommunication = new HashMap<>();
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CUSTOMER_ID, parameters.get(PaymentConstants.CUSTOMER_ID));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CREDIT_ACCOUNT_ID, parameters.get(PaymentConstants.CUSTOMER_ID));
		parametersForDisableAutoPayCommunication.put(PaymentConstants.CORRELATION_ID, correlationId);
		String paymentDueDate = null;

		Map<String, Object> mapPaymentAmountPaymentPurpose = getPaymentAmountPaymentPurpose(autoPayDBResponse, correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal((Object) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENT_AMOUNT));

		if (autoPayDBResponse.getPaymentDay() != null)
			paymentDueDate = getPaymentDate(autoPayDBResponse.getPaymentDay());
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount);
		parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENTDATE, paymentDueDate);
		parametersForDisableAutoPayCommunication.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, parameters.get(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD));
		return parametersForDisableAutoPayCommunication;
	}

	private String getPaymentDate(Integer autoPaymentDay) {
		ZonedDateTime currentDate = ZonedDateTime.now(ZoneId.of(paymentZoneId));
		Integer days = autoPaymentDay - (currentDate.getDayOfMonth());
		ZonedDateTime dueDate = currentDate.plusDays(days);
		return PaymentUtil.formatDate(dueDate, PaymentConstants.YYYY_MM_DD);
	}
}
