package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dao.PaymentBatchDAO;
import com.creditone.ucrm.payments.dao.PaymentBatchMapper;
import com.creditone.ucrm.payments.dto.PaymentBatchDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.ucrm.swagger.paymentservice.model.BatchProcessStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import com.ucrm.swagger.paymentservice.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Component
public class PaymentBatchStatusProcessor {
    private PaymentBatchDAO paymentBatchDAO;

    public PaymentBatchStatusProcessor(PaymentBatchDAO paymentBatchDAO) {
        this.paymentBatchDAO = paymentBatchDAO;
    }
    public Mono<BatchProcessStatusResponse> getBatchStatusResponse(String batchProcessId, String correlationId) {
        Mono<PaymentBatchDBResponse> monoPaymentBatchDBResponse = paymentBatchDAO.findByBatchId(UUID.fromString(batchProcessId), correlationId);
        return monoPaymentBatchDBResponse.flatMap(paymentBatchDBResponse -> {
            Integer processedCount = paymentBatchDBResponse.getProcessedCount();
            Integer errorCount = paymentBatchDBResponse.getErrorCount();
            BatchProcessStatusResponse.StatusEnum status = getStatusEnum(processedCount, errorCount);

            BatchProcessStatusResponse batchProcessStatusResponse = new BatchProcessStatusResponse();
            batchProcessStatusResponse.setProcessed(processedCount);
            batchProcessStatusResponse.setFailedToProcess(errorCount);
            batchProcessStatusResponse.setStatus(status);

            return Mono.just(batchProcessStatusResponse);
        });
    }

    private static BatchProcessStatusResponse.StatusEnum getStatusEnum(Integer processedCount, Integer errorCount) {
        BatchProcessStatusResponse.StatusEnum status = null;

        if(processedCount == 0 && errorCount == 0) {
            status = BatchProcessStatusResponse.StatusEnum.IN_PROGRESS;
        }
        else if(processedCount > 0 && errorCount == 0) {
            status = BatchProcessStatusResponse.StatusEnum.COMPLETED;
        }
        else if(processedCount == 0 && errorCount > 0) {
            status = BatchProcessStatusResponse.StatusEnum.ERROR;
        }
        else if(processedCount > 0 && errorCount > 0) {
            status = BatchProcessStatusResponse.StatusEnum.PARTIALLY_COMPLETED ;
        }

        return status;
    }

    public Mono<FailedPaymentResponse> getBatchErrorDetailsResponse(String batchProcessId, String correlationId) {
        Mono<PaymentBatchDBResponse> monoPaymentBatchDBResponse = paymentBatchDAO.findByBatchId(UUID.fromString(batchProcessId), correlationId);
        FailedPaymentResponse failedPaymentResponse = new FailedPaymentResponse();
        List<PaymentRequestId> paymentRequestIdList =new ArrayList<>();

        return monoPaymentBatchDBResponse.flatMap(paymentBatchDBResponse -> {
            JSONArray parameterJson =  PaymentBatchMapper.getJSONObjectForMappingFromParameterFromBatchResponse(paymentBatchDBResponse, correlationId);
            for (int i =0;i<parameterJson.size(); i++ ) {
                JSONObject jsonObject = (JSONObject) parameterJson.get(i);
                PaymentRequestId paymentRequestId = new PaymentRequestId();
                String failedPaymentId = String.valueOf(jsonObject.get(PaymentConstants.PAYMENT_ID + ": "));
                if (null != failedPaymentId && paymentBatchDBResponse.getErrorCount() >0) {
                    paymentRequestId.setPaymentRequestId(failedPaymentId);
                }
                else{
                    PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_BATCH_PROCESS_ID_INVALID);
                    paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
                    return Mono.error(paymentDataNotFoundException);
                }
                paymentRequestIdList.add(paymentRequestId);
            }
            failedPaymentResponse.setFailedPaymentRequestIds(paymentRequestIdList);
            return Mono.just(failedPaymentResponse);
        });
    }
}