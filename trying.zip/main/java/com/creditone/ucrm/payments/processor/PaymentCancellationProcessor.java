package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.*;
import com.creditone.ucrm.payments.dto.*;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.PaymentsKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.exception.PaymentDataUnprocessableEntityException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.achtransactionservice.model.AchVoidPaymentRequest;
import com.ucrm.swagger.achtransactionservice.model.AchVoidPaymentResponse;
import com.ucrm.swagger.debittransactionservice.model.DebitVoidPaymentsRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitVoidPaymentsResponse;
import com.ucrm.swagger.financialtransactionmanagementservice.model.InlineResponse2001;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentResponse;

import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class PaymentCancellationProcessor {

	private String paymentZoneId;
	private PaymentDAO dao;
	private AutoPayDAO autoPayDAO;
	private ExternalCallService externalCallService;
	private PaymentProcessor paymentProcessor;
	private PaymentCommunicationProcessor paymentCommunicationProcessor;
	private TransactionalOperator transactionalOperator;
	private CustomerInteractionProducerProcessor customerInteractionProducerProcessor;
	private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;
	private PaymentKafkaProducerProcessor paymentKafkaProducerProcessor;
	private PaymentCancellationAdditionalProcessor paymentCancellationAdditionalProcessor;

	public PaymentCancellationProcessor(PaymentDAO dao, AutoPayDAO autoPayDAO, ExternalCallService externalCallService, PaymentProcessor paymentProcessor, PaymentCommunicationProcessor paymentCommunicationProcessor, TransactionalOperator transactionalOperator, @Value(value = "${payment.zoneId}") String paymentZoneId, CustomerInteractionProducerProcessor customerInteractionProducerProcessor, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig, PaymentKafkaProducerProcessor paymentKafkaProducerProcessor, PaymentCancellationAdditionalProcessor paymentCancellationAdditionalProcessor) {
		this.dao = dao;
		this.autoPayDAO = autoPayDAO;
		this.externalCallService = externalCallService;
		this.paymentProcessor = paymentProcessor;
		this.paymentCommunicationProcessor = paymentCommunicationProcessor;
		this.paymentZoneId = paymentZoneId;
		this.transactionalOperator = transactionalOperator;
		this.customerInteractionProducerProcessor = customerInteractionProducerProcessor;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
		this.paymentKafkaProducerProcessor = paymentKafkaProducerProcessor;
		this.paymentCancellationAdditionalProcessor = paymentCancellationAdditionalProcessor;
	}

	public Mono<CancelACHPaymentResponse> cancelACHPayment(UUID paymentRequestId, CancelACHPaymentRequest req, String correlationId) throws PaymentDataNotFoundException {
		log.info(PaymentConstants.LOG_PREFIX + "Start of cancelACHPayment(). req: {},  paymentRequestId: {}", correlationId, req.toString(), paymentRequestId);
		Mono<CancelACHPaymentResponse> cancelACHPaymentResponse = null;
		if (Boolean.TRUE.equals(req.getIsAutoPay())) {
			if (!req.getPaymentStatus().equals(PaymentStatus.CANCEL.name())) {
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				return Mono.error(paymentDataNotFoundException);
			}
			cancelACHPaymentResponse = cancelPaymentAndAutoPayDBUpdate(paymentRequestId, req, correlationId);
		} else if (Boolean.FALSE.equals(req.getIsAutoPay())) {
			if (req.getPaymentStatus().equals(PaymentStatus.VOID.name())) {
				cancelACHPaymentResponse = cancelPaymentVoid(paymentRequestId, req, correlationId);
			} else {
				cancelACHPaymentResponse = cancelACHPaymentNotVoid(paymentRequestId, req, correlationId);
			}
		}
		return cancelACHPaymentResponse;
	}

	private Mono<CancelACHPaymentResponse> cancelPaymentVoid(UUID paymentRequestId, CancelACHPaymentRequest req, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of cancelPaymentVoid method with paymentRequestId:{}, cancelACHPaymentRequest: {}", correlationId, paymentRequestId, req.toString());
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestId);
		parameters.put(PaymentConstants.CANCEL_ACH_PAYMENT_REQUEST, req);
		parameters.put(PaymentConstants.CORRELATION_ID, correlationId);

		return dao.getProcessedOrPendingPaymentRequest(paymentRequestId, req, correlationId).flatMap(entity -> {
			if (!entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.VOID.name()) && entity.getPaymentType().equals(PaymentConstants.DEBIT)) {
				return voidDebitPayment(entity, req, parameters, correlationId);
			} else if (!entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.VOID.name()) && entity.getPaymentType().equals(PaymentConstants.ACH)) {
				return voidACHPayment(entity, req, parameters, correlationId);
			} else {
				return cancelPaymentAlreadyVoided(entity, correlationId);
			}
		});
	}

	private Mono<CancelACHPaymentResponse> voidDebitPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, CancelACHPaymentRequest cancelACHPaymentRequest, Map<String, Object> parameters, String correlationId) {
		return debitPaymentServiceCallToUpdateVoidStatus(paymentRequestDataDBResponse.getPaymentRequestId(), cancelACHPaymentRequest.getPaymentStatus(), correlationId).flatMap(
				debitVoidResponse -> {
					String customerId = (paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey() != null) ? String.valueOf(
							paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()) : null;
					String creditAccountId = (paymentRequestDataDBResponse.getAccountKey() != null) ? String.valueOf(paymentRequestDataDBResponse.getAccountKey()) : null;
					Mono<Map<String, Object>> monoParameters = buildParametersForCancellation(customerId, creditAccountId, cancelACHPaymentRequest, correlationId);
					return monoParameters.flatMap(communicationParameters -> {
						Map<String, Object> responseFromCIAMAndCreditCard = getDataFromDbResponse(paymentRequestDataDBResponse);
						communicationParameters.putAll(responseFromCIAMAndCreditCard);
						Map<String, Object> paramsForVoidCommunication = paymentCancellationAdditionalProcessor.getParamsForCancelOrVoidCommunication(communicationParameters, paymentRequestDataDBResponse,
								correlationId);
						return sendCommunication(paramsForVoidCommunication, correlationId).flatMap(communicationResponse -> {
							//JSONObject noteJSONObject = fillNote(communicationResponse, cancelACHPaymentRequest, PaymentConstants.NOTES_VOID_PAYMENT, PaymentConstants.VOID);
							JSONObject noteJSONObject = paymentCancellationAdditionalProcessor.fillNote(communicationResponse, cancelACHPaymentRequest,
									PaymentConstants.NOTES_VOID_PAYMENT, PaymentConstants.VOID);
							JSONParser parser = new JSONParser();
							JSONObject paymentRequestData = null;
							try {
								paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
							} catch (ParseException e) {
								PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
								paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
								return Mono.error(paymentDataException);
							}
							JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
							paymentMetadata.add(noteJSONObject);
							paymentRequestData.put(PaymentConstants.FDR_STATUS, PaymentStatus.VOID.name());
							paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
							return dao.updatePaymentEntityPaymentRequestData(paymentRequestDataDBResponse.getPaymentRequestId(), paymentRequestData, correlationId)
									.flatMap(updatedPaymentRequestDataDBResponse -> {
										parameters.put(PaymentConstants.DEBIT_VOID_PAYMENTS_RESPONSE, debitVoidResponse);
										CustomerInteractionEvent eventForVoid = CustomerInteractionProducerMapper.mapEventForVoidPayment(paymentRequestDataDBResponse, correlationId,
												customerInteractionDescriptionConfig);
										return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(eventForVoid, correlationId).flatMap(publishResponseForVoid -> {
											return manageVoidResponse(parameters);
										});
									}).onErrorResume(err -> {
										log.error(PaymentConstants.LOG_PREFIX + "Error Updating Database " + err.getMessage(), correlationId);
										return Mono.error(err);
									});
						}).onErrorResume(Mono::error);
					});
				});
	}

	private Map<String, Object> getDataFromDbResponse(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		Map<String, Object> dbDataMap = new HashMap<String, Object>();
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = null;
		try {
			paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		} catch (ParseException e) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		
		if (paymentRequestData != null) {
			dbDataMap.put(PaymentConstants.PAYMENT_AMOUNT, PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT)));
			JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
			for (int i = 0; i < paymentMetadata.size(); i++) {
				JSONObject processedJson = (JSONObject) paymentMetadata.get(i);
				String paymentStatus = (String) processedJson.get(PaymentConstants.PAYMENT_EVENT);
				if (PaymentStatus.PROCESSED.getValue().equalsIgnoreCase(paymentStatus)) {
					dbDataMap.put(PaymentConstants.INVOLVEMENT_ID, processedJson.get(PaymentConstants.INVOLVEMENT_ID));
					dbDataMap.put(PaymentConstants.CARD_TYPE, processedJson.get(PaymentConstants.CARD_TYPE));
					dbDataMap.put(PaymentConstants.CARD_LAST4, processedJson.get(PaymentConstants.CREDIT_ACCOUNT_LAST4));
					dbDataMap.put(PaymentConstants.PLASTICCODE, processedJson.get(PaymentConstants.PLASTIC_DESIGN_CODE));
					dbDataMap.put(PaymentConstants.PRODUCT_KEY, processedJson.get(PaymentConstants.PRODUCT_KEY));
				}
			}
		}
		return dbDataMap;
	}

	public Mono<DebitVoidPaymentsResponse> debitPaymentServiceCallToUpdateVoidStatus(UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.debug("Start of debitPaymentServiceCallToUpdateVoidStatus(). paymentRequestId: {}, paymentStatus: {}", paymentRequestId, paymentStatus);
		DebitVoidPaymentsRequest debitVoidPaymentsRequest = PaymentCancellationMapper.mapDebitVoidPaymentsRequest(paymentRequestId, paymentStatus);
		return externalCallService.callDebitTransactionServiceCallVoid(debitVoidPaymentsRequest, correlationId);
	}

	private Mono<CancelACHPaymentResponse> voidACHPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, CancelACHPaymentRequest cancelACHPaymentRequest, Map<String, Object> parameters, String correlationId) {
		log.debug("Start of voidACHPayment(). paymentRequestDataDBResponse: {}, cancelACHPaymentRequest: {}", paymentRequestDataDBResponse, cancelACHPaymentRequest);
		return Mono.zip(achPaymentServiceCallToUpdateVoidStatus(paymentRequestDataDBResponse.getPaymentRequestId(), cancelACHPaymentRequest.getPaymentStatus(), correlationId),
				fTMSTransactionVoidCall(paymentRequestDataDBResponse.getPaymentRequestId(), cancelACHPaymentRequest.getPaymentStatus(), correlationId)).flatMap(tuple -> {
			AchVoidPaymentResponse achVoidPaymentResponse = tuple.getT1();
			InlineResponse2001 inlineResponse2001 = tuple.getT2();
			log.info("InlineResponse2001: {}", inlineResponse2001.toString());
			String customerId = (paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey() != null) ? String.valueOf(
					paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()) : null;
			String creditAccountId = (paymentRequestDataDBResponse.getAccountKey() != null) ? String.valueOf(paymentRequestDataDBResponse.getAccountKey()) : null;
			Mono<Map<String, Object>> monoParameters = buildParametersForCancellation(customerId, creditAccountId, cancelACHPaymentRequest, correlationId);
			return monoParameters.flatMap(communicationParameters -> {
				Map<String, Object> responseFromCIAMAndCreditCard = getDataFromDbResponse(paymentRequestDataDBResponse);
				communicationParameters.putAll(responseFromCIAMAndCreditCard);
				Map<String, Object> paramsForVoidCommunication = paymentCancellationAdditionalProcessor.getParamsForCancelOrVoidCommunication(communicationParameters, paymentRequestDataDBResponse, correlationId);
				return sendCommunication(paramsForVoidCommunication, correlationId).flatMap(communicationResponse -> {
					return returnPaymentJSONObject(paymentRequestDataDBResponse, communicationResponse, cancelACHPaymentRequest).flatMap(paymentRequestData -> {
						paymentRequestDataDBResponse.setRequestStatus(PaymentStatus.VOID.name());
						paymentRequestDataDBResponse.setUpdatedTimestamp(LocalDateTime.now());
						parameters.put(PaymentConstants.PAYMENT_METADATA, paymentRequestData);
						return updatePaymentEntityAndManageVoidResponse(paymentRequestDataDBResponse, parameters, correlationId, achVoidPaymentResponse, paymentRequestData);
					});
				}).flatMap(result -> {
					PaymentsKafkaEvent paymentsKafkaEvent = PaymentKafkaProducerMapper.mapDataDBResponseToPaymentsKakfaEvent(paymentRequestDataDBResponse, cancelACHPaymentRequest,
							correlationId);
					paymentKafkaProducerProcessor.publish(paymentsKafkaEvent, correlationId).subscribe();
					return Mono.just(result);
				}).onErrorResume(Mono::error);
			});
		}).onErrorResume(err -> {
			String error = "Error calling Service, error: " + err.getMessage();
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			return Mono.error(err);
		});
	}

	public Mono<JSONObject> returnPaymentJSONObject(PaymentRequestDataDBResponse paymentRequestDataDBResponse, PaymentCommunicationResponse communicationResponse, CancelACHPaymentRequest cancelACHPaymentRequest) {
		JSONObject noteJSONObject = paymentCancellationAdditionalProcessor.fillNote(communicationResponse, cancelACHPaymentRequest, PaymentConstants.NOTES_VOID_PAYMENT,
				PaymentConstants.VOID);
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = null;
		try {
			paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		} catch (ParseException e) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			log.error("Error in parsing paymentRequestDataDBResponse.");
			return Mono.error(paymentDataException);
		}
		JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		paymentRequestData.put(PaymentConstants.FDR_STATUS, PaymentStatus.VOID.name());
		paymentMetadata.add(noteJSONObject);
		paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);

		return Mono.just(paymentRequestData);
	}

	public Mono<InlineResponse2001> fTMSTransactionVoidCall(UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of fTMSTransactionVoidCall(). paymentRequestId: {}, paymentStatus: {}", correlationId, paymentRequestId, paymentStatus);
		return externalCallService.callFTMSTransactionVoidCall(paymentRequestId, correlationId);
	}

	private Mono<CancelACHPaymentResponse> updatePaymentEntityAndManageVoidResponse(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> parameters, String correlationId, AchVoidPaymentResponse achTransactionResponse, JSONObject paymentRequestData) {
		parameters.put(PaymentConstants.UPDATED_TIMESTAMP, paymentRequestDataDBResponse.getUpdatedTimestamp());
		return manageVoidResponse(parameters).flatMap(cancelACHPaymentResponse -> {
						CustomerInteractionEvent eventForVoid = CustomerInteractionProducerMapper.mapEventForVoidPayment(paymentRequestDataDBResponse, correlationId,
								customerInteractionDescriptionConfig);
						return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(eventForVoid, correlationId).map(publishResponseForVoid -> {
							return cancelACHPaymentResponse;
						});
					});
				
	}

	public Mono<AchVoidPaymentResponse> achPaymentServiceCallToUpdateVoidStatus(UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of achPaymentServiceCallToUpdateVoidStatus(). paymentRequestId: {}, paymentStatus: {}", correlationId, paymentRequestId,
				paymentStatus);
		AchVoidPaymentRequest achVoidPaymentsRequest = PaymentCancellationMapper.mapACHVoidPaymentsRequest(paymentRequestId, paymentStatus);
		return externalCallService.callACHTransactionServiceCallVoid(achVoidPaymentsRequest, correlationId);
	}

	private Mono<CancelACHPaymentResponse> manageVoidResponse(Map<String, Object> parameters) {
		UUID paymentRequestId = (UUID) parameters.get(PaymentConstants.PAYMENT_REQUEST_ID);
		CancelACHPaymentRequest req = (CancelACHPaymentRequest) parameters.get(PaymentConstants.CANCEL_ACH_PAYMENT_REQUEST);
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);
		parameters.put(PaymentConstants.STATUS, req.getPaymentStatus());
			parameters.put(PaymentConstants.UPDATED_BY, req.getAgentId());
		return dao.updatePaymentEntityStatus(parameters).flatMap(paymentRequestDataDBResponse -> {
				CancelACHPaymentResponse res = PaymentCancellationMapper.mapCancelACHPaymentResponse(paymentRequestId.toString(), PaymentConstants.PAYMENT_VOID_SUCCESS,
						paymentRequestDataDBResponse.getUpdatedTimestamp().toString());
				log.debug(PaymentConstants.LOG_PREFIX + "Response from cancelACHPayment(). response: {},  paymentRequestId: {}", correlationId, res);
				return Mono.just(res);
			});
		
	}

	private Mono<CancelACHPaymentResponse> cancelPaymentAlreadyVoided(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForCancellation(paymentRequestDataDBResponse, correlationId,
				customerInteractionDescriptionConfig);
		CancelACHPaymentResponse res = PaymentCancellationMapper.mapCancelACHPaymentResponse(paymentRequestDataDBResponse.getPaymentRequestId().toString(),
				PaymentConstants.PAYMENT_VOID_SUCCESS, paymentRequestDataDBResponse.getUpdatedTimestamp().toString());
		log.debug(PaymentConstants.LOG_PREFIX + "Response from cancelACHPayment(). response: {},  paymentRequestId: {}", correlationId, res);
		return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId)
				.flatMap(publishResponse -> Mono.just(res));
	}

	private Mono<CancelACHPaymentResponse> cancelACHPaymentNotVoid(UUID paymentRequestId, CancelACHPaymentRequest req, String correlationId) {
		return dao.cancelScheduledPaymentRequest(paymentRequestId, req, correlationId).flatMap(paymentRequestDataDBResponse -> {
			log.info(PaymentConstants.LOG_PREFIX + "cancelACHPaymentNotVoid response, paymentRequestDataDBResponse: {}", correlationId, paymentRequestDataDBResponse);
			String customerId = (paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey() != null) ? String.valueOf(
					paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()) : null;
			String creditAccountId = (paymentRequestDataDBResponse.getAccountKey() != null) ? String.valueOf(paymentRequestDataDBResponse.getAccountKey()) : null;
			Mono<Map<String, Object>> monoParameters = buildParametersForCancellation(customerId, creditAccountId, req, correlationId);
			return monoParameters.flatMap(parameters -> {
				Map<String, Object> responseFromCIAMAndCreditCard = getDataFromDbResponse(paymentRequestDataDBResponse);
				parameters.putAll(responseFromCIAMAndCreditCard);
				Map<String, Object> paramsForCancelCommunication = paymentCancellationAdditionalProcessor.getParamsForCancelOrVoidCommunication(parameters, paymentRequestDataDBResponse, correlationId);
				return sendCommunication(paramsForCancelCommunication, correlationId).flatMap(communicationResponse -> {
					JSONObject noteJSONObject = paymentCancellationAdditionalProcessor.fillNote(communicationResponse, req, PaymentConstants.NOTES_VOID_PAYMENT, PaymentStatus.CANCEL.name());
					JSONParser parser = new JSONParser();
					JSONObject paymentRequestData = null;
					try {
						paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
					} catch (ParseException e) {
						PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
						paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
						return Mono.error(paymentDataException);
					}
					JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
					paymentRequestData.put(PaymentConstants.FDR_STATUS, PaymentStatus.CANCEL.name());
					paymentMetadata.add(noteJSONObject);
					paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
					paymentRequestDataDBResponse.setRequestStatus(PaymentStatus.CANCEL.name());
					paymentRequestDataDBResponse.setUpdatedTimestamp(LocalDateTime.now());
					return dao.updatePaymentEntityPaymentRequestData(paymentRequestDataDBResponse.getPaymentRequestId(), paymentRequestData, correlationId)
							.flatMap(updatedPaymentRequestDataDBResponse -> {
								paymentRequestDataDBResponse.setRequestStatus( PaymentStatus.CANCEL.name());
								CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForCancellation(updatedPaymentRequestDataDBResponse, correlationId,
										customerInteractionDescriptionConfig);
								CancelACHPaymentResponse res = PaymentCancellationMapper.mapCancelACHPaymentResponse(paymentRequestDataDBResponse.getPaymentRequestId().toString(),
										PaymentConstants.PAYMENT_CANCELLATION_SUCCESS, paymentRequestDataDBResponse.getUpdatedTimestamp().toString());
								log.debug(PaymentConstants.LOG_PREFIX + "Response from cancelACHPayment(). response: {},  paymentRequestId: {}", correlationId, res);
								return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId)
										.flatMap(publishResponse -> Mono.just(res));
							}).onErrorResume(err -> {
								log.error(PaymentConstants.LOG_PREFIX + "Error Updating Database: " + err.getMessage(), correlationId);
								return Mono.error(err);
							});
				}).flatMap(result -> {
					PaymentsKafkaEvent paymentsKafkaEvent = PaymentKafkaProducerMapper.mapDataDBResponseToPaymentsKakfaEvent(paymentRequestDataDBResponse, req, correlationId);
					paymentKafkaProducerProcessor.publish(paymentsKafkaEvent, correlationId).subscribe();
					return Mono.just(result);
				}).onErrorResume(Mono::error);
			});
		});
	}

	private Mono<CancelACHPaymentResponse> cancelPaymentAndAutoPayDBUpdate(UUID paymentRequestId, CancelACHPaymentRequest req, String correlationId) {
		Mono<PaymentRequestDataDBResponse> dbResponseMono = dao.findByPaymentRequestId(paymentRequestId, correlationId);
		return dbResponseMono.hasElement().flatMap(hasElement -> {
			if (Boolean.FALSE.equals(hasElement)) {
				log.error(PaymentConstants.LOG_PREFIX + "Record with paymentRequestId: " + paymentRequestId + " Not Found", correlationId);
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataNotFoundException);
			}
			return dbResponseMono.flatMap(paymentRequestDBResponse -> {
				String customerId = String.valueOf(paymentRequestDBResponse.getIndividualUniqueIdentifierKey());
				String creditAccountId = String.valueOf(paymentRequestDBResponse.getAccountKey());
				return checkAutoPayRecordExist(customerId, creditAccountId, correlationId).flatMap(autoPayDBResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "auto pay response, autoPayDBResponse: {}", correlationId, autoPayDBResponse);
					String cancelCurrentMonth = PaymentUtil.formatDate(ZonedDateTime.now(ZoneId.of(paymentZoneId)), PaymentConstants.MM_YYYY);
					if (PaymentCancellationMapper.isAutoPayAlreadyCancelled(autoPayDBResponse.getAutoPayData(), cancelCurrentMonth, correlationId)) {
						PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
								PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_UNENROLLED);
						paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
						return Mono.error(paymentDataUnprocessableEntityException);
					}
					autoPayDBResponse.setAutoPayData(
							Json.of(AutoPayMapper.getUpdatedAutoPayData(autoPayDBResponse.getAutoPayData(), req.getAgentId(), cancelCurrentMonth, correlationId).toJSONString()));
					return updatePaymentRequestAndAutoPayDB(req, paymentRequestDBResponse, autoPayDBResponse, correlationId).as(transactionalOperator::transactional)
							.flatMap(updatedTimeStamp -> {
								log.info(PaymentConstants.LOG_PREFIX + "Updated auto pay response, autoPayDBResponse: {}", correlationId, autoPayDBResponse);
								Mono<Map<String, Object>> monoParameters = buildParametersForAutoPayCancellation(customerId, creditAccountId, correlationId);
								return monoParameters.flatMap(parameters -> {
									Map<String, Object> paramsForAutoPayCancelCommunication = paymentCancellationAdditionalProcessor.getParamsForAutoPayCancelCommunication(parameters, autoPayDBResponse, correlationId);
									return sendAutoPayCancelCommunication(paramsForAutoPayCancelCommunication, correlationId).flatMap(communicationResponse -> {
										log.info(PaymentConstants.LOG_PREFIX + "send auto pay cancel communication, communicationResponse: {}", correlationId,
												communicationResponse);
										CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForCancellation(paymentRequestDBResponse, correlationId,
												customerInteractionDescriptionConfig);
										CancelACHPaymentResponse res = PaymentCancellationMapper.mapCancelACHPaymentResponse(paymentRequestId.toString(),
												PaymentConstants.PAYMENT_CANCELLATION_SUCCESS, updatedTimeStamp);
										log.debug(PaymentConstants.LOG_PREFIX + "Response from cancelPaymentAndAutoPayDBUpdate(). response: {},  paymentRequestId: {}",
												correlationId, res);
										return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId)
												.flatMap(publishResponse -> Mono.just(res));
									}).onErrorResume(Mono::error);
								});
							});
				});
			});
		});

	}

	private Mono<String> updatePaymentRequestAndAutoPayDB(com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest req, PaymentRequestDataDBResponse paymentRequestDBResponse, AutoPayDBResponse autoPayDBResponse, String correlationId) {
		return dao.cancelScheduledAutoPayRequest(req, paymentRequestDBResponse, correlationId).flatMap(updatedPaymentRequestDBResponse -> {
			log.info(PaymentConstants.LOG_PREFIX + "Updated payment_request response, updatedPaymentRequestDBResponse: {}", correlationId, updatedPaymentRequestDBResponse);
			return autoPayDAO.updateAutoPayConfiguration(autoPayDBResponse, correlationId).flatMap(updatedResponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "Updated payment_request response, updatedPaymentRequestDBResponse: {}", correlationId, updatedPaymentRequestDBResponse);
				return Mono.just(updatedPaymentRequestDBResponse.getUpdatedTimestamp().toString());
			});
		});
	}

	public Mono<Map<String, Object>> buildParametersForAutoPayCancellation(String customerId, String creditAccountId, String correlationId) {
		PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
		paymentServiceRequest.setCustomerId(customerId);
		paymentServiceRequest.setCreditAccountId(creditAccountId);
		return paymentProcessor.getCustomerNameFromCIAMAndCreditCardMapResponse(paymentServiceRequest, correlationId).flatMap(responseFromCIAMAndCreditCard -> {
			log.info(PaymentConstants.LOG_PREFIX + "Fetched responseFromCIAMAndCreditCard: {}", correlationId, responseFromCIAMAndCreditCard);
			if (!responseFromCIAMAndCreditCard.containsKey("firstName") || !responseFromCIAMAndCreditCard.containsKey("lastName")) {
				log.error(PaymentConstants.LOG_PREFIX + "Invalid customerId:{} ", correlationId, customerId);
				PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
						PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_PROCESSED);
				paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
				return Mono.error(paymentDataUnprocessableEntityException);
			}
			Map<String, Object> parameters = new HashMap<>();
			parameters.put(PaymentConstants.CUSTOMER_ID, customerId);
			parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
			parameters.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, responseFromCIAMAndCreditCard);
			return Mono.just(parameters);
		});

	}

	private Mono<Map<String, Object>> buildParametersForCancellation(String customerId, String creditAccountId, CancelACHPaymentRequest req, String correlationId) {
		PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
		paymentServiceRequest.setCustomerId(customerId);
		paymentServiceRequest.setCreditAccountId(creditAccountId);
		return externalCallService.getCustomerDetailFromCIAM(paymentServiceRequest.getCustomerId(), correlationId).flatMap(responseFromCIAM -> {
			log.info(PaymentConstants.LOG_PREFIX + "Fetched responseFromCIAMAndCreditCard: {}", correlationId, responseFromCIAM);
			if ((responseFromCIAM.getFirstName() == null) || (responseFromCIAM.getLastName() == null)) {
				log.error(PaymentConstants.LOG_PREFIX + "Invalid customerId:{} ", correlationId, customerId);
				PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
						PaymentErrors.ERROR_PAYMENT_CAN_NOT_BE_PROCESSED);
				paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
				return Mono.error(paymentDataUnprocessableEntityException);
			}
			Map<String, Object> parameters = new HashMap<>();
			parameters.put(PaymentConstants.CUSTOMER_ID, customerId);
			parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
			parameters.put(PaymentConstants.FIRST_NAME, responseFromCIAM.getFirstName());
			parameters.put(PaymentConstants.LAST_NAME, responseFromCIAM.getLastName());
			return Mono.just(parameters);

		});
	}

	public Mono<PaymentCommunicationResponse> sendAutoPayCancelCommunication(Map<String, Object> parameters, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of sendDisableAutoPayCommunication: parameters:{} ", correlationId, parameters);
		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = AutoPayMapper.getAutoPayCommunicationDetailsRequest(parameters);
		PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
		paymentCommunicationRequest.setPaymentRequestId(UUID.randomUUID());
		paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.CANCEL_PAYMENT);
		paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
		paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
		log.info(PaymentConstants.LOG_PREFIX + " PaymentCommunicationRequest:{} ", correlationId, paymentCommunicationDetailsRequest);
		return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
	}

	public Mono<PaymentCommunicationResponse> sendCommunication(Map<String, Object> parameters, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of sendCommunication: parameters:{} ", correlationId, parameters);
		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = PaymentCancellationMapper.getCancelCommunicationDetailsRequest(parameters);
		PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
		paymentCommunicationRequest.setPaymentRequestId(UUID.randomUUID());
		paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.CANCEL_PAYMENT);
		paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
		paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
		log.info(PaymentConstants.LOG_PREFIX + " PaymentCommunicationRequest:{} ", correlationId, paymentCommunicationDetailsRequest);
		return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
	}

	public Mono<AutoPayDBResponse> checkAutoPayRecordExist(String customerId, String creditAccountId, String correlationId) {
		return autoPayDAO.findByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId);
	}
}
