package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.externalaccounts.model.ExternalAccountListResponse;
import com.ucrm.swagger.externaldebitcards.model.DebitCardInfoResponse;
import com.ucrm.swagger.externaldebitcards.model.GetDebitCardsResponse;
import com.ucrm.swagger.paymentservice.model.PageDetails;
import com.ucrm.swagger.paymentservice.model.PaymentHistory;
import com.ucrm.swagger.paymentservice.model.PaymentRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.relational.core.query.Criteria;
import org.springframework.data.relational.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.*;

import static org.springframework.data.relational.core.query.Criteria.where;

@Slf4j
@Component
public class PaymentHistoryProcessor {
	private PaymentDAO dao;
	private ExternalCallService externalCallService;

	public PaymentHistoryProcessor(PaymentDAO dao, ExternalCallService externalCallService) {
		this.dao = dao;
		this.externalCallService = externalCallService;
	}

	public Mono<PaymentHistory> getPaymentHistory(Map<String, Object> parameters) {
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);
		log.debug(PaymentConstants.LOG_PREFIX + "Start of getPaymentHistory(). parameters: {}", correlationId, parameters);

		return validateCustomer(parameters, correlationId).flatMap(valid -> {
			Mono<Map<String, Object>> monoMapFluxPaymentRequest = getFluxPaymentRequest(parameters);
			return monoMapFluxPaymentRequest.flatMap(mapFluxPaymentRequest -> {
				Flux<PaymentRequest> fluxPaymentRequest = (Flux<PaymentRequest>) mapFluxPaymentRequest.get(PaymentConstants.FLUX_PAYMENT_REQUEST);

				PaymentHistory paymentHistory = new PaymentHistory();

				return fluxPaymentRequest.collectList().flatMap(paymentRequestList -> {
					paymentHistory.setPaymentRequests(paymentRequestList);

					PageDetails pageDetails = new PageDetails();
					pageDetails.setPageNumber((Integer) mapFluxPaymentRequest.get(PaymentConstants.PAGE_NUMBER));
					pageDetails.setPageSize((Integer) mapFluxPaymentRequest.get(PaymentConstants.PAGE_SIZE));
					pageDetails.setSortOrder((String) mapFluxPaymentRequest.get(PaymentConstants.SORT_ORDER));
					pageDetails.setSortField((String) mapFluxPaymentRequest.get(PaymentConstants.SORT_FIELD));
					pageDetails.setTotalRecords((Integer) mapFluxPaymentRequest.get(PaymentConstants.TOTAL_RECORDS));

					paymentHistory.setPageDetails(pageDetails);

					log.debug(PaymentConstants.LOG_PREFIX + "Response of getPaymentHistory(). paymentHistory: {}", correlationId, paymentHistory);

					return Mono.just(paymentHistory);
				});
			});
		});
	}
	
	private Mono<String> validateCustomer(Map<String, Object> parameters, String correlationId) {
		String creditAccountId = Objects.toString(parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID), null);
		String externalAccountId = Objects.toString(parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_ID), null);
		String customerId = Objects.toString(parameters.get(PaymentConstants.CUSTOMER_ID), null);

		return externalCallService.getCustomerDetailFromCIAM(customerId, correlationId).flatMap(coreIdentity -> {
			if (creditAccountId != null && externalAccountId != null) {
				return Mono
						.zip(validateCreditCardAccountId(creditAccountId, correlationId),
								validateExternalAccountId(customerId, externalAccountId, correlationId))
						.flatMap(tuple -> {
							return Mono.just("validated");
						});
			}
			else if (creditAccountId != null) {
				return validateCreditCardAccountId(creditAccountId, correlationId)
						.flatMap(creditAccountOverview -> {
							return Mono.just("validated");
						});
			}
			else if (externalAccountId != null) {
				return validateExternalAccountId(customerId, externalAccountId, correlationId)
						.flatMap(creditAccountOverview -> {
							return Mono.just("validated");
						});
			}

			return Mono.just("validated");
		});

	}

	private Mono<String> validateCreditCardAccountId(String creditAccountId, String correlationId) {
		return externalCallService.getAccountsFromCreditCardAccountsServiceByID(creditAccountId, correlationId)
				.flatMap(response -> {
					return Mono.just(response.getAccountId().toString());
				});

	}

	private Mono<String> validateExternalAccountId(String customerId, String bankAccountId, String correlationId) {
		Mono<ExternalAccountListResponse> monoExternalAccountListResponse = externalCallService.getAccountsFromExternalAccountsService(customerId, correlationId);
		return monoExternalAccountListResponse.flatMap(externalAccountListResponse -> {
			BankAccountResponse bankAccountResponse = externalAccountListResponse.getExternalAccountList().stream()
					.filter(x -> x.getBankAccountId().toString().equals(bankAccountId)).findFirst().orElse(null);

			if (bankAccountResponse == null) {
				log.error(PaymentConstants.LOG_PREFIX + "bankAccountId: {} not found for customerId: {}", correlationId, bankAccountId, customerId);
				return validateExternalAccountIdDebitCards(customerId, bankAccountId, correlationId);
			}

			return Mono.just(bankAccountResponse.getBankAccountId().toString());
		});
	}

	private Mono<String> validateExternalAccountIdDebitCards(String customerId, String bankAccountId, String correlationId) {
		Mono<GetDebitCardsResponse> monoGetDebitCardsResponse = externalCallService.getAccountsFromExternalDebitAccountsService(customerId, correlationId);
		return monoGetDebitCardsResponse.flatMap(getDebitCardsResponse -> {
			DebitCardInfoResponse debitCardInfoResponse = getDebitCardsResponse.getDebitCardList().stream()
					.filter(x -> x.getDebitCardId().toString().equals(bankAccountId)).findFirst().orElse(null);

			if (debitCardInfoResponse == null) {
				log.error(PaymentConstants.LOG_PREFIX + "Debit bankAccountId: {} not found for customerId: {}", correlationId, bankAccountId, customerId);
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				return Mono.error(paymentDataNotFoundException);
			}
			return Mono.just(debitCardInfoResponse.getDebitCardId().toString());
		});
	}

	private Mono<Map<String, Object>> getFluxPaymentRequest(Map<String, Object> parameters) {
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);

		Map<String, Object> mapResultPageable = generatePageable(parameters);
		Pageable pageable = (Pageable) mapResultPageable.get(PaymentConstants.PAGEABLE);

		Criteria criteria = getCriteria(parameters);

		Query query = Query.query(criteria);
		
		Flux<PaymentRequest> fluxPaymentRequest = null;

		if (parameters.get(PaymentConstants.PAGE_SIZE) == null) {
			Query querySorted = query.sort(pageable.getSort());
			fluxPaymentRequest = dao.findByQuery(querySorted, correlationId);
		} else {
			Query queryWithPageable = query.with(pageable);
			fluxPaymentRequest = dao.findByQuery(queryWithPageable, correlationId);
		}

		mapResultPageable.put(PaymentConstants.FLUX_PAYMENT_REQUEST, fluxPaymentRequest);

		Mono<Long> monoCountPaymentRequest = dao.countByQuery(query, correlationId);
		return monoCountPaymentRequest.flatMap(countPaymentRequest -> {
			mapResultPageable.put(PaymentConstants.TOTAL_RECORDS, countPaymentRequest.intValue());
			if (parameters.get(PaymentConstants.PAGE_SIZE) == null) {
				mapResultPageable.replace(PaymentConstants.PAGE_NUMBER, 1);
				mapResultPageable.replace(PaymentConstants.PAGE_SIZE, countPaymentRequest.intValue());
			}
			return Mono.just(mapResultPageable);
		});
	}
	
	private Criteria getCriteria(Map<String, Object> parameters) {
		String paymentType = parameters.get(PaymentConstants.PAYMENT_TYPE) != null
				? (String) parameters.get(PaymentConstants.PAYMENT_TYPE)
				: null;
		String status = parameters.get(PaymentConstants.STATUS) != null
				? (String) parameters.get(PaymentConstants.STATUS)
				: null;
		String startDate = parameters.get(PaymentConstants.START_DATE) != null
				? (String) parameters.get(PaymentConstants.START_DATE)
				: null;
		String endDate = parameters.get(PaymentConstants.END_DATE) != null
				? (String) parameters.get(PaymentConstants.END_DATE)
				: null;
		String creditAccountId = parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID) != null
				? parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID).toString()
				: null;
		String externalAccountId = parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_ID) != null
				? parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_ID).toString()
				: null;
		UUID customerId = (UUID) parameters.get(PaymentConstants.CUSTOMER_ID);

		Criteria criteria = where("individualUniqueIdentifierKey").is(customerId);
		criteria = validatePaymentTypeCriteria(criteria, paymentType);
		criteria = validateStatusCriteria(criteria, status);
		criteria = validateCreditAccountCriteria(criteria, creditAccountId);
		criteria = validateExternalAccountCriteria(criteria, externalAccountId);
		criteria = validateDateCriteria(criteria, startDate, endDate, status);

		return criteria;
	}

	private Criteria validatePaymentTypeCriteria(Criteria criteria, String paymentType) {
		if (paymentType != null) {
			criteria = criteria.and("paymentType").is(paymentType);
		}

		return criteria;
	}

	private Criteria validateStatusCriteria(Criteria criteria, String status) {
		if (status != null) {
			criteria = criteria.and("requestStatus").is(status).ignoreCase(true);
		}

		return criteria;
	}

	private Criteria validateCreditAccountCriteria(Criteria criteria, String creditAccountId) {
		if (creditAccountId != null) {
			criteria = criteria.and("accountKey").is(creditAccountId);
		}

		return criteria;
	}

	private Criteria validateExternalAccountCriteria(Criteria criteria, String externalAccountId) {
		if (externalAccountId != null) {
			criteria = criteria.and("externalAccountKey").is(externalAccountId);
		}

		return criteria;
	}

	private Criteria validateDateCriteria(Criteria criteria, String startDate, String endDate, String status) {
		if (startDate != null) {
			if (endDate != null) {
				criteria = criteria.and("paymentDate").greaterThan(PaymentUtil.getZonedDateTime(startDate))
						.and("paymentDate").lessThan(PaymentUtil.getZonedDateTime(endDate));
			} else {
				criteria = criteria.and("paymentDate").greaterThan(PaymentUtil.getZonedDateTime(startDate));
			}
		} else {
			if (status != null) {
				if (status.equalsIgnoreCase(PaymentStatus.SCHEDULE.name())) {
					startDate = String.valueOf(LocalDate.now());
					criteria = criteria.and("paymentDate").greaterThan(PaymentUtil.getZonedDateTime(startDate));
				}
			}
		}

		return criteria;
	}

	private Map<String, Object> generatePageable(Map<String, Object> parameters) {
		String pageNumberParameter = (parameters.get(PaymentConstants.PAGE_NUMBER) != null
				? (String) parameters.get(PaymentConstants.PAGE_NUMBER)
				: null);
		String pageSizeParameter = (parameters.get(PaymentConstants.PAGE_SIZE) != null
				? (String) parameters.get(PaymentConstants.PAGE_SIZE)
				: null);
		String sortOrderParameter = (parameters.get(PaymentConstants.SORT_ORDER) != null
				? (String) parameters.get(PaymentConstants.SORT_ORDER)
				: null);
		String sortFieldParameter = (parameters.get(PaymentConstants.SORT_FIELD) != null
				? (String) parameters.get(PaymentConstants.SORT_FIELD)
				: null);

		Integer pageNumber = definePageNumer(pageNumberParameter);
		Integer pageSize = definePageSize(pageSizeParameter);
		String sortField = defineSortField(sortFieldParameter);
		Sort sortOrder = defineSortOrder(sortField, sortOrderParameter);

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sortOrder);

		Map<String, Object> mapResult = new HashMap<String, Object>();
		mapResult.put(PaymentConstants.PAGEABLE, pageable);
		mapResult.put(PaymentConstants.PAGE_NUMBER, pageNumber + 1);

		return editPagebleMapResponse(mapResult, pageSize, sortOrderParameter, sortField);
	}

	private Integer definePageNumer(String pageNumberParameter) {
		Integer pageNumber = 0;

		if (pageNumberParameter != null) {
			pageNumber = Integer.valueOf(pageNumberParameter) - 1;
		}

		return pageNumber;
	}

	private Integer definePageSize(String pageSizeParameter) {
		Integer pageSize = 10;

		if (pageSizeParameter != null) {
			pageSize = Integer.valueOf(pageSizeParameter);
		}

		return pageSize;
	}

	private String defineSortField(String sortFieldParameter) {
		String sortField = "paymentDate";

		if (sortFieldParameter != null) {
			sortField = Arrays.stream(SortField.values()).filter(sf -> sf.name().equalsIgnoreCase(sortFieldParameter))
					.findFirst().get().getEntityField();
		}

		return sortField;
	}

	private Sort defineSortOrder(String sortField, String sortOrderParameter) {
		Sort sortOrder = Sort.by(sortField).descending();

		if (sortOrderParameter != null) {
			if (sortOrderParameter.equalsIgnoreCase(SortOrder.asc.name())) {
				sortOrder = Sort.by(sortField).ascending();
			}
		}

		return sortOrder;
	}

	private Map<String, Object> editPagebleMapResponse(Map<String, Object> mapResult, Integer pageSize,
			String sortOrderParameter, String sortField) {
		mapResult.put(PaymentConstants.PAGE_SIZE, pageSize);

		if (sortOrderParameter != null) {
			if (sortOrderParameter.equalsIgnoreCase(SortOrder.asc.name())) {
				mapResult.put(PaymentConstants.SORT_ORDER, SortOrder.asc.name());
			} else {
				mapResult.put(PaymentConstants.SORT_ORDER, SortOrder.desc.name());
			}
		} else {
			mapResult.put(PaymentConstants.SORT_ORDER, SortOrder.desc.name());
		}

		final String finalSortField = sortField;
		String sortOrderFieldResult = "";

		Optional<SortField> optSortField = Arrays.stream(SortField.values())
				.filter(sf -> sf.getEntityField().equalsIgnoreCase(finalSortField)).findFirst();
		if (optSortField.isPresent()) {
			sortOrderFieldResult = optSortField.get().name();
		}

		mapResult.put(PaymentConstants.SORT_FIELD, sortOrderFieldResult);

		return mapResult;
	}
}