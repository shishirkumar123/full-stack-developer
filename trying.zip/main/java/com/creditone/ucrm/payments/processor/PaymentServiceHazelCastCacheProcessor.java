package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class PaymentServiceHazelCastCacheProcessor {
	public HazelcastInstance hazelCastInstance;
	private Long paymentRequestIdCacheTimeout;

	public PaymentServiceHazelCastCacheProcessor(HazelcastInstance hazelCastInstance,
			@Value(value = "${payment.request.cache.timeout}") Long paymentRequestIdCacheTimeout) {
		this.hazelCastInstance = hazelCastInstance;
		this.paymentRequestIdCacheTimeout = paymentRequestIdCacheTimeout;
	}

	public String getDuplicatePaymentRecord(String key, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside getDuplicatePaymentRecord(), key  - {}", correlationId, key);
		IMap<String, String> mapRecords = hazelCastInstance.getMap(PaymentConstants.PAYMENT_REQUEST_ID_MAP);
		return mapRecords.get(key);
	}

	public String pushPaymentRecord(String key, String paymentRequestId, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside pushPaymentRecord(), key  - {}, paymentRequestID - {}", correlationId, key, paymentRequestId);
		IMap<String, String> mapRecords = hazelCastInstance.getMap(PaymentConstants.PAYMENT_REQUEST_ID_MAP);
		return mapRecords.putIfAbsent(key, paymentRequestId, paymentRequestIdCacheTimeout, TimeUnit.SECONDS);
	}
}