package com.creditone.ucrm.payments.processor;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Component;

import com.creditone.ucrm.payments.constant.AutopayNotifiedStatus;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.PaymentBatchDAO;
import com.creditone.ucrm.payments.dao.PaymentBatchMapper;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dao.ProcessAutoPayNotifiedPaymentsMapper;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.validation.PaymentRecordDatabaseValidator;
import com.ucrm.swagger.paymentservice.model.BatchProcessResponse;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class ProcessScheduledPaymentsProcessor {
	private PaymentDAO dao;
	private PaymentBatchDAO paymentBatchDAO;
	private PaymentProcessor paymentProcessor;
	private ExternalCallService externalCallService;

	public ProcessScheduledPaymentsProcessor(PaymentDAO dao, PaymentBatchDAO paymentBatchDAO, PaymentProcessor paymentProcessor, ExternalCallService externalCallService) {
		this.dao = dao;
		this.paymentBatchDAO = paymentBatchDAO;
		this.paymentProcessor = paymentProcessor;
		this.externalCallService = externalCallService;
	}

	public Mono<BatchProcessResponse> processScheduledPayments(ZonedDateTime localDateTimeNowUTC, List<String> listStatus, Map<String, Object> parameters, String correlationId) {
		List<UUID> listRecordsProcessed = new ArrayList<UUID>();
		List<UUID> listRecordsError = new ArrayList<UUID>();
		List<String> listErrorRecordsInserted = new ArrayList<String>();

		log.debug(PaymentConstants.LOG_PREFIX + "Inside processScheduledPayments(): localDateTimeNowUTC: {}, listStatus: {}, parameters: {} ", correlationId, localDateTimeNowUTC,
				listStatus, parameters);
		Flux<PaymentRequestDataDBResponse> payments = dao.findByRequestStatusInAndPaymentDateLessThanAndCreatedBy(listStatus, localDateTimeNowUTC, PaymentConstants.PAYMENT_SYNC,
				correlationId);

		payments.flatMap(paymentRequestDataDBResponse -> {
			Mono<Map<String, Object>> monoResultProcessScheduledPayment = processScheduledPayment(paymentRequestDataDBResponse, correlationId);
			return monoResultProcessScheduledPayment.flatMap(mapResultProcessScheduledPayment -> {
				Map<String, Object> parametersMethod = new HashMap<String, Object>();
				parametersMethod.put(PaymentConstants.MAP_RESULT_PROCESS_SCHEDULED_PAYMENT, mapResultProcessScheduledPayment);
				parametersMethod.put(PaymentConstants.UUID_RECORD_PROCESSED, listRecordsProcessed);
				parametersMethod.put(PaymentConstants.ERROR_RECORD_PROCESSED, listRecordsError);
				parametersMethod.put(PaymentConstants.PAYMENT_REQUEST_DB_RESPONSE, paymentRequestDataDBResponse);
				parametersMethod.put(PaymentConstants.CORRELATION_ID, correlationId);
				String paymentReqId = (String) mapResultProcessScheduledPayment.get(PaymentConstants.ERROR_PAYMENT_REQUEST_ID);
				if (paymentReqId != null)
					listErrorRecordsInserted.add(paymentReqId);
				parameters.put(PaymentConstants.ERROR_PAYMENTS_LIST, listErrorRecordsInserted);
				return manageMapResultScheduledPayment(parametersMethod);
			});
		}).collectList().flatMap(results -> {
			ProcessAutoPayNotifiedPaymentsMapper.mapParameterForSaveOrUpdatePaymentBatchEntity(parameters, listRecordsProcessed, listRecordsError);

			return paymentBatchDAO.saveOrUpdatePaymentBatchEntity(parameters, correlationId).flatMap(batchUpdated -> {
				return Mono.just(true);
			});
		}).subscribe();

		BatchProcessResponse batchProcessResponse = ProcessAutoPayNotifiedPaymentsMapper.mapBatchProcessResponseFromMapToProcessAutoPayNotifiedPayments(parameters);
		return Mono.just(batchProcessResponse);
	}

	private Mono<Boolean> manageMapResultScheduledPayment(Map<String, Object> parametersMethod) {
		Map<String, Object> mapResultProcessScheduledPayment = (Map<String, Object>) parametersMethod.get(PaymentConstants.MAP_RESULT_PROCESS_SCHEDULED_PAYMENT);
		List<UUID> listRecordsProcessed = (List<UUID>) parametersMethod.get(PaymentConstants.UUID_RECORD_PROCESSED);
		List<UUID> listRecordsError = (List<UUID>) parametersMethod.get(PaymentConstants.ERROR_RECORD_PROCESSED);
		PaymentRequestDataDBResponse paymentRequestDataDBResponse = (PaymentRequestDataDBResponse) parametersMethod.get(PaymentConstants.PAYMENT_REQUEST_DB_RESPONSE);
		String correlationId = (String) parametersMethod.get(PaymentConstants.CORRELATION_ID);

		String statusResult = (String) mapResultProcessScheduledPayment.get(PaymentConstants.STATUS);
		if (AutopayNotifiedStatus.PROCESSED.name().equals(statusResult)) {
			listRecordsProcessed.add((UUID) mapResultProcessScheduledPayment.get(PaymentConstants.UUID_RECORD_PROCESSED));
		} else if (AutopayNotifiedStatus.ERROR.name().equals(statusResult)) {
			listRecordsError.add(paymentRequestDataDBResponse.getPaymentRequestId());
			Throwable err = (Throwable) mapResultProcessScheduledPayment.get(PaymentConstants.ERROR_RECORD_PROCESSED);
			log.error(PaymentConstants.LOG_PREFIX + err.getMessage(), correlationId);
		}

		return Mono.just(true);
	}

	private Mono<Map<String, Object>> processScheduledPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Mapping entity to Payment Request {}", correlationId, paymentRequestDataDBResponse);
		Map<String, Object> mapRequest = new HashMap<String, Object>();
		try {
			PaymentBatchMapper.formPaymentRequestDataFromDBResponse(paymentRequestDataDBResponse, mapRequest);
		} catch (ParseException e) {
			return updateErrorStatus(paymentRequestDataDBResponse, e, correlationId);
		}

		return externalCallService.getAccountTokenFromExternalBankAccounts(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString(),
				paymentRequestDataDBResponse.getExternalAccountKey().toString(),
				mapRequest.get(PaymentConstants.CHANNEL) != null ? mapRequest.get(PaymentConstants.CHANNEL).toString() : null, correlationId).flatMap(accountTokenResp -> {
					PaymentDataTransferRequest dtoRequest = null;
					PaymentServiceRequest paymentServiceRequest = null;
					try {
						paymentServiceRequest = (PaymentServiceRequest) mapRequest.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
						PaymentRecordDatabaseValidator.validatePaymentRecordVerificationData(paymentRequestDataDBResponse, PaymentConstants.SCHEDULE_ORIGIN);
						dtoRequest = PaymentMapper.mapPaymentDtoRequest(paymentServiceRequest, paymentRequestDataDBResponse.getPaymentRequestId(),
								paymentRequestDataDBResponse.getPaymentRequestId().toString(), correlationId);
						dtoRequest.setCorrelationId(correlationId);
						dtoRequest.setIsSchedulePayment(false);
						dtoRequest.setStatus(PaymentStatus.PROCESSED.name());
						dtoRequest.setCollectionIntentId(
								mapRequest.get(PaymentConstants.COLLECTION_INTENT_ID) != null ? mapRequest.get(PaymentConstants.COLLECTION_INTENT_ID).toString() : null);
						dtoRequest.setInvolvementId(mapRequest.get(PaymentConstants.INVOLVEMENT_ID) != null ? mapRequest.get(PaymentConstants.INVOLVEMENT_ID).toString() : null);
					} catch (PaymentDataException e) {
						return updateErrorStatus(paymentRequestDataDBResponse, e, correlationId);
					} catch (ParseException e) {
						Map<String, Object> mapResult = new HashMap<String, Object>();
						mapResult.put(PaymentConstants.STATUS, AutopayNotifiedStatus.ERROR.name());
						mapResult.put(PaymentConstants.ERROR_RECORD_PROCESSED, new PaymentDataException("Error Mapping PaymentRequestEntity: " + e.toString()));
						mapResult.put(PaymentConstants.ERROR_PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId().toString());
						return Mono.just(mapResult);
					}

					dtoRequest.setOneTimeAccessToken(accountTokenResp.getMetadata().getOneTimeAccessToken().toString());
					dtoRequest.setGrantAccessToken(accountTokenResp.getMetadata().getGrantAccessToken().toString());
					dtoRequest.setReceiverAccountRoutingNumber(accountTokenResp.getRoutingNumber());
					dtoRequest.setReceiverAccountType(accountTokenResp.getAccountType());
					Mono<PaymentServiceResponse> monoPaymentServiceResponse = paymentProcessor.sendSavedAchDebitPaymentRequest(dtoRequest, paymentServiceRequest,
							dtoRequest.getPaymentRequestId(), correlationId);
					return monoPaymentServiceResponse.flatMap(paymentServiceResponse -> {
						log.debug(PaymentConstants.LOG_PREFIX + "Payment {} processed", correlationId, paymentRequestDataDBResponse.getPaymentRequestId().toString());
						Map<String, Object> mapResult = new HashMap<String, Object>();
						mapResult.put(PaymentConstants.UUID_RECORD_PROCESSED, paymentRequestDataDBResponse.getPaymentRequestId());
						mapResult.put(PaymentConstants.STATUS, AutopayNotifiedStatus.PROCESSED.name());
						return Mono.just(mapResult);
					}).onErrorResume(err -> {
						return updateErrorStatus(paymentRequestDataDBResponse, err, correlationId);
					});
				}).onErrorResume(err -> {
					return updateErrorStatus(paymentRequestDataDBResponse, err, correlationId);
				});

	}

	private Mono<Map<String, Object>> updateErrorStatus(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Throwable e, String correlationId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId());
		parameters.put(PaymentConstants.STATUS, PaymentStatus.ERROR.name());
		parameters.put(PaymentConstants.UPDATED_BY, paymentRequestDataDBResponse.getCreatedBy());
		parameters.put(PaymentConstants.UPDATED_TIMESTAMP, LocalDateTime.now());
		parameters.put(PaymentConstants.CORRELATION_ID, correlationId);
		dao.updatePaymentEntityStatus(parameters).subscribe();

		String error = "Error Processing Payment: " + paymentRequestDataDBResponse.getPaymentRequestId().toString() + ", Error: " + e.getMessage();

		Map<String, Object> mapResult = new HashMap<String, Object>();
		mapResult.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId());
		mapResult.put(PaymentConstants.STATUS, AutopayNotifiedStatus.ERROR.name());
		mapResult.put(PaymentConstants.ERROR_RECORD_PROCESSED, new PaymentDataException(error));
		mapResult.put(PaymentConstants.ERROR_PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		return Mono.just(mapResult);
	}
}