package com.creditone.ucrm.payments.processor;


import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentKafkaConsumerMapper;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.validation.PaymentRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.kafka.core.reactive.ReactiveKafkaConsumerTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Slf4j
@Component
public class PaymentTransactionKafkaConsumerProcessor implements CommandLineRunner {

	private ReactiveKafkaConsumerTemplate<String, AchPartnerMoneyMovementKafkaEvent> reactiveKafkaPaymentTransactionConsumerTemplate;

	private PaymentTransactionKafkaProducerProcessor paymentTransactionKafkaProducerProcessor;

	private PaymentDAO paymentDAO;

	private PaymentCommunicationProcessor paymentCommunicationProcessor;

	public PaymentTransactionKafkaConsumerProcessor(@Qualifier("reactiveKafkaPaymentTransactionConsumerTemplate") ReactiveKafkaConsumerTemplate<String, AchPartnerMoneyMovementKafkaEvent> reactiveKafkaPaymentTransactionConsumerTemplate,
                                                    PaymentTransactionKafkaProducerProcessor paymentTransactionKafkaProducerProcessor,
                                                    PaymentDAO paymentDAO, PaymentCommunicationProcessor paymentCommunicationProcessor) {
		this.reactiveKafkaPaymentTransactionConsumerTemplate = reactiveKafkaPaymentTransactionConsumerTemplate;
        this.paymentTransactionKafkaProducerProcessor = paymentTransactionKafkaProducerProcessor;
        this.paymentDAO = paymentDAO;
        this.paymentCommunicationProcessor = paymentCommunicationProcessor;
    }

	public Flux<AchPartnerMoneyMovementKafkaEvent> consumeMoneyMovementKafkaEvents() {
		log.debug("Start of consumeMoneyMovementKafkaEvents()");

		Flux<ConsumerRecord<String, AchPartnerMoneyMovementKafkaEvent>> fluxConsumer = reactiveKafkaPaymentTransactionConsumerTemplate.receiveAutoAck();
		if (fluxConsumer == null) {
			log.info("Flux AchPartnerMoneyMovementKafkaEvent consumer is null and we are returning empty flux");
			return Flux.empty();
		}

		return fluxConsumer.map(ConsumerRecord::value).onErrorContinue((err, achPartnerMoneyMovementKafkaEvent) -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error Mapping AchPartnerMoneyMovementKafkaEvent Consumer Record, error: {}", "", err.getMessage());
		}).doOnNext(achPartnerMoneyMovementKafkaEvent -> {
			boolean recordLog = logEvent(achPartnerMoneyMovementKafkaEvent);
			if (recordLog) {
				boolean validRecord = validateRecord(achPartnerMoneyMovementKafkaEvent);

				if (validRecord) {
					processMoneyMovementKafkaEvent(achPartnerMoneyMovementKafkaEvent);
					
				}
			}
		});
	}

	/***
	 * Processes a valid money movement kafka event.
	 * @param achPartnerMoneyMovementKafkaEvent
	 * @return
	 */
	private void processMoneyMovementKafkaEvent(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of processMoneyMovementKafkaEvent(): achPartnerMoneyMovementKafkaEvent: {} ", achPartnerMoneyMovementKafkaEvent.getEventHeader().getTraceId(), achPartnerMoneyMovementKafkaEvent);
		String correlationId = achPartnerMoneyMovementKafkaEvent.getEventHeader().getTraceId();
		Mono<PaymentCommunicationResponse> monoPaymentCommunicationResponse = callPaymentCommunication(UUID.fromString(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId()),
				correlationId);
		monoPaymentCommunicationResponse.flatMap(paymentCommunicationResponse -> {
			return paymentDAO.updatePaymentRequestStatus(achPartnerMoneyMovementKafkaEvent, paymentCommunicationResponse, correlationId)
					.flatMap(paymentRequestDataDBResponse -> {
						return paymentTransactionKafkaProducerProcessor.publishPaymentTransactionEventToKafka(achPartnerMoneyMovementKafkaEvent, paymentRequestDataDBResponse, correlationId);
					});
		}).subscribe();
	}

	private Mono<PaymentCommunicationResponse> callPaymentCommunication(UUID paymentRequestId, String correlationId) {
		PaymentCommunicationRequest paymentCommunicationRequest = PaymentKafkaConsumerMapper.mapPaymentCommunicationRequestForPosted(paymentRequestId);

		Mono<PaymentCommunicationDetailsRequest> monoPaymentCommunicationDetailsRequest = paymentCommunicationProcessor.fillPaymentCommunicationDetailsRequest(paymentCommunicationRequest, correlationId);
		return monoPaymentCommunicationDetailsRequest.flatMap(paymentCommunicationDetailsRequest -> {
			paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
			return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
		}).onErrorResume(err -> {
			PaymentCommunicationResponse paymentCommunicationResponse = new PaymentCommunicationResponse();
			paymentCommunicationResponse.setCommunicationStatus(PaymentConstants.FAILURE);
			return Mono.just(paymentCommunicationResponse);
		});
	}

	/**
	 * Logs the received moneyMovement event
	 */
	public boolean logEvent(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent) {
		if (achPartnerMoneyMovementKafkaEvent.getEventData() == null) {
			log.error(PaymentConstants.LOG_PREFIX + "Received event without data",
					achPartnerMoneyMovementKafkaEvent.getEventHeader() != null && achPartnerMoneyMovementKafkaEvent.getEventHeader().getTraceId() != null ? achPartnerMoneyMovementKafkaEvent.getEventHeader()
							.getTraceId() : "");
			return false;
		}
		log.info(PaymentConstants.LOG_PREFIX + "Data received " + "achTransactionId {}," + "status {}," + "updatedTimestamp {}", achPartnerMoneyMovementKafkaEvent.getEventHeader().getTraceId(),
				achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getAchTransactionId(), achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getStatus(),
				achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getUpdatedTimestamp());
		return true;
	}

	/**
	 * Validates the moneyMovement event.
	 */
	public boolean validateRecord(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent) {
		boolean validRecord = false;

		try {
			PaymentRequestValidator.validateMoneyMovementKafkaEvent(achPartnerMoneyMovementKafkaEvent);
			validRecord = true;
		}
		catch (PaymentDataException e) {
			log.error(PaymentConstants.LOG_PREFIX + e.getMessage(), achPartnerMoneyMovementKafkaEvent.getEventHeader().getTraceId());
		}

		return validRecord;
	}

	@Override
	public void run(String... args) {
		// we have to trigger consumption
		Flux<AchPartnerMoneyMovementKafkaEvent> flux = consumeMoneyMovementKafkaEvents();
		if (flux == null) {
			log.info("Flux was null and we are closing LegacyToModern Consumer");
			return;
		}
		flux.doOnError(err -> {
			log.info("Error on PaymentTransactionKafka Consumer Event Flux: {}, StackTrace: {}", err.getMessage(), err);
		}).subscribe();
	}

}