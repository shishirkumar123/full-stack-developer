package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.*;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.collection.model.CollectionIntentRequest;
import com.ucrm.swagger.paymentservice.model.*;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.security.NoSuchAlgorithmException;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
@Component
public class PaymentReprocessBatchProcessor {
    private PaymentDAO dao;
    private PaymentBatchDAO paymentBatchDAO;
    private PaymentBatchActivityDAO paymentBatchActivityDAO;
    private ExternalCallService externalCallService;
    private PaymentCommunicationProcessor paymentCommunicationProcessor;
    private NotifyAutopayProcessor notifyAutopayProcessor;
    private PaymentProcessor paymentProcessor;
    private ProcessAutoPayNotifiedPaymentsProcessor processAutoPayNotifiedPaymentsProcessor;
    private ProcessScheduledPaymentsProcessor processScheduledPaymentsProcessor;
    private PaymentKafkaProducerProcessor kafkaProducerService;
    private String autopayScheduleDays;
    private String paymentZoneId;
    private String collectionIntentType;
    private Integer maxReprocessRetries;

    public PaymentReprocessBatchProcessor(PaymentDAO dao, PaymentBatchDAO paymentBatchDAO, PaymentBatchActivityDAO paymentBatchActivityDAO, NotifyAutopayProcessor notifyAutopayProcessor,
                                          ProcessAutoPayNotifiedPaymentsProcessor processAutoPayNotifiedPaymentsProcessor, ProcessScheduledPaymentsProcessor processScheduledPaymentsProcessor,
                                          PaymentCommunicationProcessor paymentCommunicationProcessor, PaymentProcessor paymentProcessor, ExternalCallService externalCallService,
                                          PaymentKafkaProducerProcessor kafkaProducerService, @Value(value = "${autopaySchedule.days}") String autopayScheduleDays,
                                          @Value(value = "${payment.zoneId}") String paymentZoneId, @Value(value = "${collection.intent.type}") String collectionIntentType,
                                          @Value(value = "${max.reprocess.retries}") Integer maxReprocessRetries) {
        this.dao = dao;
        this.paymentBatchDAO = paymentBatchDAO;
        this.paymentBatchActivityDAO = paymentBatchActivityDAO;
        this.notifyAutopayProcessor = notifyAutopayProcessor;
        this.processAutoPayNotifiedPaymentsProcessor = processAutoPayNotifiedPaymentsProcessor;
        this.paymentCommunicationProcessor = paymentCommunicationProcessor;
        this.processScheduledPaymentsProcessor = processScheduledPaymentsProcessor;
        this.paymentProcessor = paymentProcessor;
        this.externalCallService = externalCallService;
        this.kafkaProducerService = kafkaProducerService;
        this.autopayScheduleDays = autopayScheduleDays;
        this.paymentZoneId = paymentZoneId;
        this.collectionIntentType = collectionIntentType;
        this.maxReprocessRetries = maxReprocessRetries;
    }

    public Mono<ReprocessBatchResponse> processPendingBatchPayment(String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of processPendingBatchPayment.", correlationId);
        ReprocessBatchResponse reprocessBatchResponse = new ReprocessBatchResponse();
        return paymentBatchActivityDAO.findByPaymentBatchStatusAndCreatedTimestamp(PaymentStatus.PENDING.name(), correlationId).flatMap(paymentBatchActivityResponse -> {
            log.info(PaymentConstants.LOG_PREFIX + "Response of findByPaymentBatchStatusAndCreatedTimestamp {}.", correlationId, paymentBatchActivityResponse);
            return dao.findByPaymentRequestIdAndRequestStatus(paymentBatchActivityResponse.getPaymentRequestId(), PaymentStatus.PROCESSED.name(),correlationId).flatMap(paymentRequestDataDBResponse -> {
                log.info(PaymentConstants.LOG_PREFIX + "Response of findByPaymentRequestIdAndRequestStatus {}.", correlationId, paymentRequestDataDBResponse);
                try {
                    List<String> pendingTaskTypeList = null;
                    PaymentServiceRequest paymentServiceRequest = PaymentBatchMapper.fromPaymentRequestDataDBResponseToPaymentServiceRequest(paymentRequestDataDBResponse);
                    PaymentDataTransferRequest paymentRequestDto = PaymentMapper.mapPaymentDtoRequest(paymentServiceRequest, paymentRequestDataDBResponse, correlationId);
                    if (paymentBatchActivityResponse.getPaymentRequestData() != null) {
                        pendingTaskTypeList = PaymentUtil.getPendingTaskType(paymentBatchActivityResponse.getPaymentRequestData(), correlationId);
                    }
                    if (pendingTaskTypeList != null && !pendingTaskTypeList.isEmpty())
                        processPaymentBatchActivity(paymentServiceRequest, paymentRequestDto, pendingTaskTypeList, correlationId);
                } catch (ParseException e) {
                    return paymentDataException(e);
                }
                return Mono.just(paymentRequestDataDBResponse.getPaymentRequestId());
            });
        }).onErrorResume(err-> {
            log.error(PaymentConstants.LOG_PREFIX + "error in processPendingBatchPayment(), error: {}", correlationId, err.getMessage());
            return Mono.empty();
        }).collectList().map((pendingPaymentRequestIds) -> {
            return getReprocessBatchResponse(correlationId, pendingPaymentRequestIds, reprocessBatchResponse);
        });
    }

    private static Mono<UUID> paymentDataException(ParseException e) {
        PaymentDataException paymentDataException = new PaymentDataException(e.getMessage());
        paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
        return Mono.error(paymentDataException);
    }

    private static ReprocessBatchResponse getReprocessBatchResponse(String correlationId, List<UUID> pendingPaymentRequestIds, ReprocessBatchResponse reprocessBatchResponse) {
        log.info(PaymentConstants.LOG_PREFIX + "Total pending payments count: {}", correlationId, pendingPaymentRequestIds.size());
        reprocessBatchResponse.setPendingBatchPayments(pendingPaymentRequestIds.size());
        if (pendingPaymentRequestIds.size() == 0) {
            reprocessBatchResponse.setMessage("No records pending");
        } else {
            reprocessBatchResponse.setMessage("Batch processing Started");
        }
        log.info(PaymentConstants.LOG_PREFIX + "End of processPendingBatchPayment() pending payment Ids: {}", correlationId, pendingPaymentRequestIds);
        return reprocessBatchResponse;
    }

    public void processPaymentBatchActivity(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, List<String> pendingTaskTypeList, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of processPaymentBatchActivity. paymentRequestDto: {}", correlationId, paymentRequestDto);

        externalCallService.getCustomerDetailFromCIAM(paymentServiceRequest.getCustomerId(), correlationId).flatMap(response -> {
            log.debug(PaymentConstants.LOG_PREFIX + "Response of getCustomerDetailFromCIAM {}.", correlationId, response);
            AtomicBoolean retryProcessFailed = new AtomicBoolean(false);
            paymentRequestDto.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_PROCESSED.name());
            paymentRequestDto.setFirstName(response.getFirstName());
            paymentRequestDto.setLastName(response.getLastName());
            PaymentCommunicationRequest paymentCommunicationRequest = PaymentMapper.getPaymentCommunicationRequest(paymentServiceRequest, paymentRequestDto,
                    paymentRequestDto.getPaymentRequestId());

            String confirmationCode = null;
            try {  confirmationCode = dao.generateConfirmationCode(paymentRequestDto.getPaymentRequestId());
            } catch (NoSuchAlgorithmException e) { log.error("Error in generating confirmation code, error: {}", e.getMessage()); }

            paymentRequestDto.setConfirmationCode(confirmationCode);
            paymentCommunicationRequest.getPaymentCommunicationDetailsRequest().setReferenceNum(paymentRequestDto.getConfirmationCode());
            paymentRequestDto.setCollectionIntentType(collectionIntentType);

            Map<String, Object> parameters = buildParameters(paymentServiceRequest, paymentRequestDto, pendingTaskTypeList, correlationId);
            return paymentCommunicationProcess(parameters, retryProcessFailed, paymentCommunicationRequest, correlationId)
                    .flatMap(commResponse -> collectionProcess(parameters, retryProcessFailed, correlationId)
                            .flatMap(collectionResponse -> publishKafkaProcess(parameters, retryProcessFailed, correlationId)
                                    .flatMap(kafkaResponse -> {
                                        if(PaymentConstants.SUCCESS.equalsIgnoreCase(commResponse) &&
                                                PaymentConstants.SUCCESS.equalsIgnoreCase(collectionResponse) &&
                                                PaymentConstants.SUCCESS.equalsIgnoreCase(kafkaResponse)) {
                                            return paymentBatchActivityDAO.updateReprocessStatus(paymentRequestDto.getPaymentRequestId(), PaymentConstants.STATUS_COMPLETE,correlationId)
                                                    .flatMap(responseId->{
                                                        log.info(PaymentConstants.LOG_PREFIX + "End of processPaymentBatchActivity, updateReprocessStatus(): response {}", correlationId, responseId);
                                                        return  Mono.empty();
                                                    });
                                        }
                                log.info(PaymentConstants.LOG_PREFIX + "End of processPaymentBatchActivity.", correlationId);
                                return Mono.empty();
                            })));
        }).doOnError(error -> log.error(PaymentConstants.LOG_PREFIX + "Error processing record. error: {}", correlationId, error.getMessage())).subscribe();
    }

    private Map<String, Object> buildParameters(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, List<String> pendingTaskTypeList, String correlationId) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
        parameters.put(PaymentConstants.PAYMENT_DATA_TRANSFER_REQUEST, paymentRequestDto);
        parameters.put(PaymentConstants.PENDING_TASK_TYPE_LIST, pendingTaskTypeList);
        return parameters;
    }

    private Mono<String> paymentCommunicationProcess(Map<String, Object> parameters, AtomicBoolean retryProcessFailed, PaymentCommunicationRequest paymentCommunicationRequest, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of paymentCommunicationProcess. paymentCommunicationRequest: {} and retryProcessFailed: {}", correlationId,
                paymentCommunicationRequest, retryProcessFailed.get());
        PaymentDataTransferRequest paymentRequestDto = (PaymentDataTransferRequest) parameters.get(PaymentConstants.PAYMENT_DATA_TRANSFER_REQUEST);
        List<String> pendingTaskTypeList = (List<String>) parameters.get(PaymentConstants.PENDING_TASK_TYPE_LIST);
        if (!pendingTaskTypeList.contains(PaymentConstants.COMMUNICATION)) {
            return Mono.just(PaymentConstants.SUCCESS);
        }
        return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId).flatMap(paymentCommunicationResponse -> {
            log.info(PaymentConstants.LOG_PREFIX + "Response of paymentCommunication {}.", correlationId, paymentCommunicationResponse);
            paymentRequestDto.setCommunicationRequestId(paymentCommunicationResponse.getCommunicationRequestId());
            if (paymentCommunicationResponse.getCommunicationRequestId() != null) {
                return kafkaProducerService.publishEventToKafka(paymentRequestDto, UUID.fromString(correlationId))
                        .flatMap(paymentRequestId -> {
                            return paymentBatchActivityDAO.updateReprocessStatusAndCount(paymentRequestDto, PaymentConstants.COMMUNICATION, paymentCommunicationResponse.getCommunicationRequestId(), correlationId).flatMap(responseId -> {
                                log.info(PaymentConstants.LOG_PREFIX + "End of paymentCommunicationProcess for successful reprocess. paymentRequestDataDBResponse(): response {}",
                                        correlationId, responseId);
                                return Mono.just(PaymentConstants.SUCCESS);
                            });
                        });
            } else {
                return retryFailedProcessForPaymentCommunication(retryProcessFailed, correlationId, paymentRequestDto);
            }
        });
    }

    private Mono<String> retryFailedProcessForPaymentCommunication(AtomicBoolean retryProcessFailed, String correlationId, PaymentDataTransferRequest paymentRequestDto) {
        if (!retryProcessFailed.get()) {
            retryProcessFailed.set(true);
            return updateReprocessStatusAndCountForFailure(paymentRequestDto, correlationId).flatMap(responseId -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of paymentCommunicationProcess for failure and DB update. updateReprocessStatusAndCountForFailure() response: {}",
                        correlationId, responseId);
                return Mono.just(PaymentConstants.FAILED);
            });
        } else {
            log.info(PaymentConstants.LOG_PREFIX + "End of paymentCommunicationProcess for failure.", correlationId);
            return Mono.just(PaymentConstants.FAILED);
        }
    }

    private Mono<String> collectionProcess(Map<String, Object> parameters, AtomicBoolean retryProcessFailed, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of collectionProcess. retryProcessFailed flag: {}", correlationId, retryProcessFailed.get());
        PaymentDataTransferRequest paymentRequestDto = (PaymentDataTransferRequest) parameters.get(PaymentConstants.PAYMENT_DATA_TRANSFER_REQUEST);
        PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
        List<String> pendingTaskTypeList = (List<String>) parameters.get(PaymentConstants.PENDING_TASK_TYPE_LIST);
        if (!pendingTaskTypeList.contains(PaymentConstants.COLLECTION_UPDATE)) {
            return Mono.just(PaymentConstants.SUCCESS);
        }

        CollectionIntentRequest collectionIntentRequest = PaymentMapper.getCollectionIntentRequest(paymentServiceRequest, paymentRequestDto,
                paymentRequestDto.getPaymentRequestId(), correlationId);
        return paymentProcessor.getCollectionIntentId(collectionIntentRequest, correlationId).flatMap(collectionIntentResponse -> {
            log.info(PaymentConstants.LOG_PREFIX + "Response of getCollectionIntentId(): {}.", correlationId, collectionIntentResponse);
            paymentRequestDto.setCollectionIntentId(collectionIntentResponse.getCollectionIntentId());
            if (collectionIntentResponse.getCollectionIntentId() != null) {
                return kafkaProducerService.publishEventToKafka(paymentRequestDto, UUID.fromString(correlationId))
                        .flatMap(paymentRequestId -> {
                            return paymentBatchActivityDAO.updateReprocessStatusAndCount(paymentRequestDto, PaymentConstants.COLLECTION_UPDATE, null, correlationId).flatMap(responseId -> {
                                log.debug(PaymentConstants.LOG_PREFIX + "End of collectionProcess. Response from updateReprocessStatusAndCount(): {}", correlationId, responseId);
                                return Mono.just(PaymentConstants.SUCCESS);
                            });
                        });
            } else {
                return retryFailedProcessForCollectionProcess(retryProcessFailed, correlationId, paymentRequestDto);
            }
        });
    }

    private Mono<String> retryFailedProcessForCollectionProcess(AtomicBoolean retryProcessFailed, String correlationId, PaymentDataTransferRequest paymentRequestDto) {
        if (!retryProcessFailed.get()) {
            retryProcessFailed.set(true);
            return updateReprocessStatusAndCountForFailure(paymentRequestDto, correlationId).flatMap(responseId -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of collectionProcess. Failure and update DB response from updateReprocessStatusAndCount(): {}", correlationId,
                        responseId);
                return Mono.just(PaymentConstants.FAILED);
            });
        } else {
            log.info(PaymentConstants.LOG_PREFIX + "End of collectionProcess.", correlationId);
            return Mono.just(PaymentConstants.FAILED);
        }
    }

    private Mono<String> publishKafkaProcess(Map<String, Object> parameters, AtomicBoolean retryProcessFailed, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of publishKafkaProcess. retryProcessFailed flag: {}", correlationId, retryProcessFailed.get());
        PaymentDataTransferRequest paymentRequestDto = (PaymentDataTransferRequest) parameters.get(PaymentConstants.PAYMENT_DATA_TRANSFER_REQUEST);
        List<String> pendingTaskTypeList = (List<String>) parameters.get(PaymentConstants.PENDING_TASK_TYPE_LIST);

        if (!pendingTaskTypeList.contains(PaymentConstants.KAFKA_MESSAGE)) {
            return Mono.just(PaymentConstants.SUCCESS);
        }
        return kafkaProducerService.publishEventToKafka(paymentRequestDto, null).flatMap(paymentId -> {
            log.info(PaymentConstants.LOG_PREFIX + "Response of publishEventToKafka(): {}.", correlationId, paymentId);
            return paymentBatchActivityDAO.updateReprocessStatusAndCount(paymentRequestDto, PaymentConstants.KAFKA_MESSAGE, null, correlationId).flatMap(responseId -> {
                log.info(PaymentConstants.LOG_PREFIX + "End of publishKafkaProcess. Response from updateReprocessStatusAndCount(): {}", correlationId, responseId);
                return Mono.just(PaymentConstants.SUCCESS);
            });
        }).doOnError(error -> {
            if (!retryProcessFailed.get()) {
                retryProcessFailed.set(true);
                paymentBatchActivityDAO.updateReprocessStatusAndCountForFailure(paymentRequestDto, maxReprocessRetries, correlationId).flatMap(responseId -> {
                    log.info(PaymentConstants.LOG_PREFIX + "End of publishKafkaProcess. Response from updateReprocessStatusAndCountForFailure(). response: {}", correlationId,
                            responseId);
                    return Mono.just(PaymentConstants.FAILED);
                });
            }
        });
    }

    private Mono<String> updateReprocessStatusAndCountForFailure(PaymentDataTransferRequest paymentRequestDto, String correlationId) {
        return paymentBatchActivityDAO.updateReprocessStatusAndCountForFailure(paymentRequestDto, maxReprocessRetries, correlationId).flatMap(responseId -> {
            log.debug(PaymentConstants.LOG_PREFIX + "Response from updateReprocessStatusAndCountForFailure. response: {}", correlationId, responseId);
            return Mono.just(responseId.toString());
        });
    }
}