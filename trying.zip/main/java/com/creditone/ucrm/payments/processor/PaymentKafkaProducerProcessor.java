package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.dao.PaymentKafkaProducerMapper;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.PaymentsKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.model.PaymentBatchActivityEntity;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.SenderRecord;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class PaymentKafkaProducerProcessor {
	private String topic;

	private String dlqTopic;

	private ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent> reactiveKafkaProducerTemplate;

	public PaymentKafkaProducerProcessor(ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent> reactiveKafkaProducerTemplate, @Value("${kafka.producer.topic}") String topic,
			@Value("${kafka.producer.dlqTopic}") String dlqTopic) {
		this.reactiveKafkaProducerTemplate = reactiveKafkaProducerTemplate;
		this.topic = topic;
		this.dlqTopic = dlqTopic;
	}

	/**
	 * Calls createACHPaymentEvent method to create an instance of
	 * PaymentsKafkaEvent, and publishes the event to Kafka
	 * 
	 * @param paymentServiceRequest
	 * @param paymentRequestId
	 * @param status
	 * @return Mono of UUID
	 */
	public Mono<UUID> publishEventToKafka(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String status, String correlationId, Map<String, Object> resultMap) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of publishEventToKafka(). paymentServiceRequest: {}, paymentRequestId: {}, status: {}, resultMap: {}", correlationId,
				paymentServiceRequest, paymentRequestId, status, resultMap);

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
		parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestId);
		parameters.put(PaymentConstants.STATUS, status);
		parameters.put(PaymentConstants.MAP_RESULT, resultMap);
		parameters.put(PaymentConstants.CORRELATION_ID, correlationId);

		PaymentsKafkaEvent event = PaymentKafkaProducerMapper.mapPaymentsKafkaEventFromPaymentServiceRequest(parameters);

		return publish(event, correlationId);
	}

	public Mono<UUID> publishEventToKafka(PaymentDataTransferRequest paymentRequestDto, UUID correlationId) {
		PaymentsKafkaEvent event = PaymentKafkaProducerMapper.mapPaymentsKafkaEventFromPaymentServiceDto(paymentRequestDto);

		return publish(event, paymentRequestDto.getCorrelationId());
	}

	public Mono<PaymentRequestDataDBResponse> publishFdrEventToKafka(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		PaymentsKafkaEvent event = null;
		try {
			event = PaymentKafkaProducerMapper.mapFdrPaymentsKafkaEventFromDatabase(paymentRequestDataDBResponse, correlationId.toString());
		} catch (ParseException e) {
			log.info(PaymentConstants.LOG_PREFIX + "Error while parsing paymentRequestDataDBResponse : {}", correlationId, paymentRequestDataDBResponse);

		}

		return publish(event, correlationId).flatMap(result -> {
			return Mono.just(paymentRequestDataDBResponse);
		});
	}

	public Mono<UUID> publishEventToKafka(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String paymentErrorCode, String paymentReturnedDate, String correlationId)
			throws ParseException {
		// Temporary change to info level to validate the db record to be mapped as
		// publishing event
		log.info(PaymentConstants.LOG_PREFIX + "Start of publishEventToKafka(). paymentRequestDataDBResponse: {}, paymentErrorCode: {}, paymentReturnedDate: {}", correlationId,
				paymentRequestDataDBResponse, paymentErrorCode, paymentReturnedDate);
		// End Temporary change to info level to validate the db record to be mapped as
		// publishing event

		PaymentsKafkaEvent event = PaymentKafkaProducerMapper.mapPaymentsKafkaEventFromDatabase(paymentRequestDataDBResponse, correlationId);
		event.getEventData().getPaymentMetadata().setPaymentReturnedCode(paymentErrorCode);
		event.getEventData().getPaymentMetadata().setPaymentReturnedDate(paymentReturnedDate);

		return publish(event, correlationId);
	}

	public Mono<UUID> publishReplayEventToKafka(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		// Temporary change to info level to validate the db record to be mapped as
		// publishing event
		log.info(PaymentConstants.LOG_PREFIX + "Start of publishEventToKafka(). paymentRequestDataDBResponse: {}", correlationId, paymentRequestDataDBResponse);
		// End Temporary change to info level to validate the db record to be mapped as
		// publishing event

		PaymentsKafkaEvent event = null;
		try {
			event = PaymentKafkaProducerMapper.mapPaymentsKafkaEventFromDatabase(paymentRequestDataDBResponse, correlationId);
		} catch (ParseException e) {
			log.info(PaymentConstants.LOG_PREFIX + "Error while parsing paymentRequestDataDBResponse : {}", correlationId, paymentRequestDataDBResponse);
		}

		return publish(event, correlationId);
	}

	public Mono<UUID> publish(PaymentsKafkaEvent event, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of publish method: {}", correlationId, event);
		SenderRecord<String, PaymentsKafkaEvent, Object> producerRecord = SenderRecord.create(topic, null, null, null, event, null);
		log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent to be published: {}", correlationId, event);
		reactiveKafkaProducerTemplate.send(producerRecord).doOnSuccess(result -> {
			log.info(PaymentConstants.LOG_PREFIX + "Event successfully published. Record Metadata: partition-{}, offset-{}, record-{}", correlationId,
					result.recordMetadata().partition(), result.recordMetadata().offset(), producerRecord);
		}).doOnError(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error publishing event to topic-{}, reason: {}, record: {}", correlationId, topic, e.getMessage(), producerRecord);
			log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent to be published: {}", correlationId, event);
			SenderRecord<String, PaymentsKafkaEvent, Object> dlqProducerRecord = SenderRecord.create(dlqTopic, null, null, null, event, null);
			reactiveKafkaProducerTemplate.send(dlqProducerRecord).doOnSuccess(dlqResult -> {
				log.info(PaymentConstants.LOG_PREFIX + "Event successfully published to dlq topic. Record Metadata: partition-{}, offset-{}, record: {}", correlationId,
						dlqResult.recordMetadata().partition(), dlqResult.recordMetadata().offset(), dlqProducerRecord);
			}).doOnError(ex -> {
				log.error(PaymentConstants.LOG_PREFIX + "Error publishing event to dlq topic-{}, reason: {}, record: {}", correlationId, dlqTopic, ex.getMessage(),
						dlqProducerRecord);
				throw new PaymentException(
						"Error publishing event to kafka topic - " + topic + ": Reason - " + e.getMessage() + "; dlq topic - " + dlqTopic + ": Reason - " + ex.getMessage());
			}).subscribe();
		}).subscribe();

		return Mono.just(event.getEventData().getPaymentRequestId());
	}
}