package com.creditone.ucrm.payments.processor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentType;
import com.creditone.ucrm.payments.dao.AutoPayDAO;
import com.creditone.ucrm.payments.dao.AutoPayHistoryMapper;
import com.creditone.ucrm.payments.dao.AutoPayMapper;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dto.*;
import com.creditone.ucrm.payments.exception.*;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.creditcardaccountservice.model.AccountBalanceResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.paymentservice.model.AutoPayConfiguration;
import com.ucrm.swagger.paymentservice.model.AutoPayConfigurationHistory;
import com.ucrm.swagger.paymentservice.model.AutoPayRequest;
import com.ucrm.swagger.paymentservice.model.AutoPayResponse;
import com.ucrm.swagger.paymentservice.model.PaymentMetadata;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import com.ucrm.swagger.paymentservice.model.UpdateAutoPayRequest;

import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple3;
import reactor.util.function.Tuples;

@Slf4j
@Component
public class AutoPayConfigurationProcessor {
    private AutoPayDAO autoPayDAO;
    private ExternalCallService externalCallService;
    private PaymentProcessor paymentProcessor;
    private PaymentCommunicationProcessor paymentCommunicationProcessor;
    private PaymentRulesProcessor paymentRulesProcessor;
    String bankruptRule;
    String fraudRule;
    String abandonRule;
    String chargeOffRule;
    String accountInDeleteProcessRule;
    String activeCreditProtectionClaimsRule;
    String accountInDeleteProcessIReason;
    String accountInDeleteProcessIIReason;
    String activeCreditProtectionClaimsIReason;
    String activeCreditProtectionClaimsIIReason;
    String activeCreditProtectionClaimsIIIReason;
    String activeCreditProtectionClaimsIVReason;
    String paymentZoneId;

    public AutoPayConfigurationProcessor(AutoPayDAO autoPayDAO, ExternalCallService externalCallService, PaymentProcessor paymentProcessor, PaymentCommunicationProcessor paymentCommunicationProcessor, PaymentRulesProcessor paymentRulesProcessor, @Value(value = "${bankrupt.rule}") String bankruptRule, @Value(value = "${fraud.rule}") String fraudRule, @Value(value = "${abandon.rule}") String abandonRule, @Value(value = "${changeOff.rule}") String chargeOffRule, @Value(value = "${accountInDeleteProcess.rule}") String accountInDeleteProcessRule, @Value(value = "${accountInDeleteProcessI.reason}") String accountInDeleteProcessIReason, @Value(value = "${accountInDeleteProcessII.reason}") String accountInDeleteProcessIIReason, @Value(value = "${activeCreditProtectionClaims.rule}") String activeCreditProtectionClaimsRule, @Value(value = "${activeCreditProtectionClaimsI.reason}") String activeCreditProtectionClaimsIReason, @Value(value = "${activeCreditProtectionClaimsII.reason}") String activeCreditProtectionClaimsIIReason, @Value(value = "${activeCreditProtectionClaimsIII.reason}") String activeCreditProtectionClaimsIIIReason, @Value(value = "${activeCreditProtectionClaimsIV.reason}") String activeCreditProtectionClaimsIVReason, @Value(value = "${payment.zoneId}") String paymentZoneId) {
        this.bankruptRule = bankruptRule;
        this.fraudRule = fraudRule;
        this.abandonRule = abandonRule;
        this.chargeOffRule = chargeOffRule;
        this.accountInDeleteProcessRule = accountInDeleteProcessRule;
        this.accountInDeleteProcessIReason = accountInDeleteProcessIReason;
        this.accountInDeleteProcessIIReason = accountInDeleteProcessIIReason;
        this.activeCreditProtectionClaimsRule = activeCreditProtectionClaimsRule;
        this.activeCreditProtectionClaimsIReason = activeCreditProtectionClaimsIReason;
        this.activeCreditProtectionClaimsIIReason = activeCreditProtectionClaimsIIReason;
        this.activeCreditProtectionClaimsIIIReason = activeCreditProtectionClaimsIIIReason;
        this.activeCreditProtectionClaimsIVReason = activeCreditProtectionClaimsIVReason;

        this.autoPayDAO = autoPayDAO;
        this.externalCallService = externalCallService;
        this.paymentCommunicationProcessor = paymentCommunicationProcessor;
        this.paymentProcessor = paymentProcessor;
        this.paymentRulesProcessor = paymentRulesProcessor;
        this.paymentZoneId = paymentZoneId;

    }

    public Mono<AutoPayConfiguration> getAutoPayConfiguration(String customerId, String creditAccountId, String correlationId) {
        log.debug(PaymentConstants.LOG_PREFIX + "Start of getAutoPayConfiguration(), customerId: {}, creditAccountId: {}", correlationId, customerId, creditAccountId);

        Mono<AccountDetailsResponse> monoCreditCardListResponse = externalCallService.getCreditCardDetailsAccountsServiceWithStatus(creditAccountId, correlationId);
        return monoCreditCardListResponse.flatMap(response -> {
            Mono<AutoPayDBResponse> monoAutoPayDBResponse = autoPayDAO.findByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId);
            return monoAutoPayDBResponse.flatMap(autoPayDBResponse -> {
                log.info(PaymentConstants.LOG_PREFIX + "findByCustomerIdAndCreditAccountId() response: {}", correlationId, autoPayDBResponse);
                return Mono.just(AutoPayMapper.mappingFromAutoPayDBResponseToAutoConfiguration(autoPayDBResponse, correlationId));
            });
        });
    }

    public Mono<AutoPayConfigurationHistory> getAutoPayConfigurationHistory(String customerId, String creditAccountId, String correlationId) {
        log.debug(PaymentConstants.LOG_PREFIX + "Start of getAutoPayConfigurationHistory(), customerId: {}, creditAccountId: {}", correlationId, customerId, creditAccountId);

        Mono<AccountDetailsResponse> monoCreditCardListResponse = externalCallService.getCreditCardDetailsAccountsServiceWithStatus(creditAccountId, correlationId);
        return monoCreditCardListResponse.flatMap(response -> {
            log.info(PaymentConstants.LOG_PREFIX + "Fetched getCreditCardDetailsAccountsService response : {}", correlationId, response);

            Mono<AutoPayHistoryDBResponse> monoAutoPayHistoryDBResponse = autoPayDAO.findByCustomerIdAndCreditAccountIdHistory(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId);
            return monoAutoPayHistoryDBResponse.hasElement().flatMap(hasElement -> {
                if (Boolean.FALSE.equals(hasElement)) {
                    log.error(PaymentConstants.LOG_PREFIX + "Record with customerId: " + customerId + " and creditAccountId: " + creditAccountId + " Not Found", correlationId);
                    return Mono.empty();
                }
                return monoAutoPayHistoryDBResponse.flatMap(autoPayHistoryDBResponse -> {
                    return Mono.just(AutoPayHistoryMapper.mappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(autoPayHistoryDBResponse, correlationId));
                });
            });
        });
    }

    public Mono<Boolean> disableAutoPayConfiguration(String customerId, String creditAccountId, boolean sendNotification, String correlationId) {
        log.debug(PaymentConstants.LOG_PREFIX + "Start of disableAutoPayConfiguration(), customerId: {}, creditAccountId: {}, sendNotification: {}", correlationId, customerId, creditAccountId, sendNotification);
        return Mono.zip(checkAutoPayRecordExist(customerId, creditAccountId, correlationId), checkAutoPayHistoryRecordExist(customerId, creditAccountId, null, correlationId)).flatMap(tuple -> {
            AutoPayDBResponse autoPayDBResponse = tuple.getT1();
            AutoPayHistoryDBResponse autoPayHistoryDBResponse = tuple.getT2();
            PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
            paymentServiceRequest.setCustomerId(customerId);
            paymentServiceRequest.setCreditAccountId(creditAccountId);
            return paymentProcessor.getCustomerNameFromCIAMAndCreditCardMapResponse(paymentServiceRequest, correlationId).flatMap(responseFromCIAMAndCreditCard -> {
                log.info(PaymentConstants.LOG_PREFIX + "Fetched responseFromCIAMAndCreditCard: {}", correlationId, responseFromCIAMAndCreditCard);
                if (!responseFromCIAMAndCreditCard.containsKey("firstName") || !responseFromCIAMAndCreditCard.containsKey("lastName")) {
                    log.error(PaymentConstants.LOG_PREFIX + "Invalid customerId:{} ", correlationId, customerId);
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_NO_RECORD_FOUND_AUTOPAY);
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                }

                log.info(PaymentConstants.LOG_PREFIX + "AutoPayHistoryDBResponse response: {}", correlationId, autoPayHistoryDBResponse);
                Map<String, Object> parameters = new HashMap<>();
                parameters.put(PaymentConstants.CUSTOMER_ID, customerId);
                parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
                parameters.put(PaymentConstants.CORRELATION_ID, correlationId);
                Map<String, Object> mapPaymentAmountPaymentPurpose = getPaymentAmountPaymentPurpose(autoPayDBResponse, correlationId);

                String paymentDueDate = (String) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENTDATE);

                parameters.put(PaymentConstants.PAYMENT_AMOUNT, PaymentMapper.convertObjectToBigDecimal((Object) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENT_AMOUNT)));
                parameters.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, responseFromCIAMAndCreditCard);
                parameters.put(PaymentConstants.PAYMENTDATE, paymentDueDate);

                return autoPayDAO.disableAutoPay(autoPayDBResponse, UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId).flatMap(autoPayDisabled -> {
                    if (sendNotification) {
                        return sendDisableAutoPayCommunication(parameters, correlationId).flatMap(paymentCommunicationResponse -> {
                            String communicationRequestId = paymentCommunicationResponse.getCommunicationRequestId();
                            return updateAutoPayHistoryDBResponse(autoPayDBResponse, autoPayHistoryDBResponse, communicationRequestId, PaymentConstants.DISABLED, correlationId).flatMap(updatedAutoPayHistoryDBResponse -> {
                                return autoPayDAO.updateAutoPayHistory(updatedAutoPayHistoryDBResponse, communicationRequestId, PaymentConstants.FALSE, correlationId).flatMap(updatedHistoryResponse -> {
                                    return Mono.just(true);
                                });
                            });
                        });
                    }

                    return updateAutoPayHistoryDBResponse(autoPayDBResponse, autoPayHistoryDBResponse, null, PaymentConstants.DISABLED, correlationId).flatMap(updatedAutoPayHistoryDBResponse -> {
                        return autoPayDAO.updateAutoPayHistory(updatedAutoPayHistoryDBResponse, null, PaymentConstants.FALSE, correlationId).flatMap(updatedHistoryResponse -> {
                            return Mono.just(true);
                        });
                    });
                });
            });
        });
    }

    private Map<String, Object> getPaymentAmountPaymentPurpose(AutoPayDBResponse autoPayDBResponse, String correlationId) {
        JSONParser parser = new JSONParser();
        JSONObject autoPayDataParams;
        try {
            autoPayDataParams = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
        }
        catch (ParseException e) {
            String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
            log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            throw paymentDataException;
        }

        Map<String, Object> mapResult = new HashMap<>();
        Object paymentAmount = (Object) autoPayDataParams.get(PaymentConstants.PAYMENT_AMOUNT);
        mapResult.put(PaymentConstants.PAYMENT_AMOUNT, PaymentMapper.convertObjectToBigDecimal(paymentAmount));
        mapResult.put(PaymentConstants.PAYMENT_PURPOSE, (String) autoPayDataParams.get(PaymentConstants.PAYMENT_PURPOSE));
        mapResult.put(PaymentConstants.PAYMENTDATE, (String) autoPayDataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE));

        return mapResult;
    }

    @SuppressWarnings("unchecked")
    public Mono<AutoPayHistoryDBResponse> updateAutoPayHistoryDBResponse(AutoPayDBResponse autoPayDBResponse, AutoPayHistoryDBResponse autoPayHistoryDBResponse, String communicationRequestId, String status, String correlationId) {
        JSONParser parser = new JSONParser();
        try {
            JSONObject autoPayHistoryData = (JSONObject) parser.parse(autoPayHistoryDBResponse.getAutoPayHistoryData().asString());
            JSONObject autoPayDataParams = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
            JSONObject autoPayHistoryDBResponseJson = AutoPayHistoryMapper.mappingFromAutoPayDBResponseToJSON(autoPayDataParams, autoPayDBResponse, communicationRequestId, status);
            Long maxVersion = null;
            JSONObject maxVersionObj = null;

            if (autoPayHistoryData != null && autoPayHistoryData.get(PaymentConstants.AUTO_PAY_HISTORY) != null) {
                List<JSONObject> autoPayHistoryList = (List<JSONObject>) autoPayHistoryData.get(PaymentConstants.AUTO_PAY_HISTORY);
                // getting version from autoPayHistoryData
                if (autoPayHistoryList != null && !autoPayHistoryList.isEmpty()) {
                    maxVersionObj = autoPayHistoryList.stream().max(Comparator.comparing(a -> Long.parseLong(a.getOrDefault(PaymentConstants.VERSION, "0").toString()))).orElse(null);
                    maxVersion = (maxVersionObj != null) ? Long.parseLong(maxVersionObj.getOrDefault(PaymentConstants.VERSION, "0").toString()) : 0L;
                    if (maxVersionObj == null) {
                        log.warn(PaymentErrors.PREVIOUS_VERSION_NOT_AVAILABLE + " AutoPayId: " + autoPayHistoryDBResponse.getAutoPayId());
                    }
                }
                // Adding record with DISABLE status for update auto-pay
                if (status.equalsIgnoreCase(PaymentConstants.ENABLED) && autoPayHistoryList != null) {
                    if (maxVersion != null) {
                        maxVersion = maxVersion + 1;
                        JSONObject newAutoPayHistoryRecord = AutoPayHistoryMapper.mapAutopayDisableEntry(maxVersionObj, maxVersion);
                        autoPayHistoryList.add(newAutoPayHistoryRecord);
                    }
                }
                autoPayHistoryDBResponseJson.put(PaymentConstants.VERSION, (maxVersion != null) ? maxVersion + 1 : 1);
                autoPayHistoryList.add(autoPayHistoryDBResponseJson);
            }
            autoPayHistoryDBResponse.setAutoPayHistoryData(Json.of(autoPayHistoryData.toJSONString()));
            autoPayHistoryDBResponse.setUpdatedBy(autoPayDBResponse.getUpdatedBy());
            autoPayHistoryDBResponse.setUpdatedTimestamp(PaymentUtil.utcNow());
            return Mono.just(autoPayHistoryDBResponse);
        }
        catch (ParseException e) {
            String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
            log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            return Mono.error(paymentDataException);
        }
    }

    public Mono<PaymentCommunicationResponse> sendDisableAutoPayCommunication(Map<String, Object> parameters, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of sendDisableAutoPayCommunication: parameters:{} ", correlationId, parameters);
        PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = AutoPayMapper.getAutoPayCommunicationDetailsRequest(parameters);
        PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
        paymentCommunicationRequest.setPaymentRequestId(UUID.randomUUID());
        paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.DISABLE_AUTOPAY);
        paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
        paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
        log.info(PaymentConstants.LOG_PREFIX + "PaymentCommunicationRequest: {} ", correlationId, paymentCommunicationDetailsRequest);
        return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
    }

    public Mono<AutoPayResponse> initializeAutoPaySetup(String customerId, String creditAccountId, AutoPayRequest request, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of initializeAutoPaySetup: {}", correlationId, request);
        return validateCreditCardUsingAccountsService(customerId, creditAccountId, correlationId)
                .flatMap(result -> {
                    log.info(PaymentConstants.LOG_PREFIX + "Credit card validation result: {}", correlationId, result);
                    return Mono.just(new AutoPayResponse());
                }).flatMap(result -> {
                    Mono<Map<String, Object>> monoParameters = buildParameters(customerId, creditAccountId, request, correlationId);
                    return monoParameters.flatMap(parameters -> {
                        AccountBalanceResponse overviewResponse = (AccountBalanceResponse) parameters.get(PaymentConstants.CREDIT_CARD_ACCOUNT_OVERVIEW_RESPONSE);
                        getPaymentAmountFromAccountBalanceResponse(request, overviewResponse);
                        return validateCreditCard(parameters, correlationId).flatMap(isValid -> {
                            if (Boolean.TRUE.equals(isValid)) {
                                Mono<AutoPayDBResponse> monoAutoPayDBResponse = autoPayDAO.saveOrUpdateAutoPayEntity(parameters, correlationId);
                                return monoAutoPayDBResponse.flatMap(autoPayDBResponseSaved -> {
                                    Mono<PaymentCommunicationResponse> monoPaymentCommunicationResponse = sendEnableAutoPayCommunication(parameters, correlationId);
                                    return monoPaymentCommunicationResponse.flatMap(paymentCommunicationResponse -> {
                                        Mono<AutoPayHistoryDBResponse> monoAutoPayHistoryDBResponse = autoPayDAO.saveOrUpdateAutoPayHistoryEntity(parameters, autoPayDBResponseSaved, paymentCommunicationResponse, correlationId);
                                        return monoAutoPayHistoryDBResponse.flatMap(autoPayHistoryDBResponse -> {
                                            return Mono.just(AutoPayMapper.maptoEnableAutoPayResponse(request, parameters));
                                        });
                                    });
                                });
                            }
                            log.info(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "CreditCard is not eligible for Autopay");
                            ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
                            serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
                            return Mono.error(serviceUnavailableException);
                        });
                    });
                });
    }

    private Mono<Object> deleteRecord(String customerId, String creditAccountId, String correlationId, String reason) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of deleteRecord for customerId {} and creditAccountId {} ", correlationId, customerId, creditAccountId);
        return autoPayDAO.deleteByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId)
                .flatMap(result -> {
                    log.info(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "Invalid Credit Card");
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_AUTOPAY_VALIDATION);
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                });
    }

    private Mono<Object> validateCreditCardUsingAccountsService(String customerId, String creditAccountId, String correlationId) {
        return externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId).flatMap(creditCardDetailsResponses -> {
            if (creditCardDetailsResponses.getDaysDelinquentCount().compareTo(BigDecimal.ZERO) > 0) {
                log.debug(PaymentConstants.LOG_PREFIX + "Record deleted when Account is delinquent with customerId: {} and creditAccountId: {}", correlationId, customerId, creditAccountId);
                return deleteRecord(customerId, creditAccountId, correlationId, PaymentConstants.DELINQUENT);
            }
            return paymentRulesProcessor.isValidCReditCardAccountAndEmailCheck(creditCardDetailsResponses, correlationId).flatMap(validCreditCardMap -> {
                if (validCreditCardMap.get("flag").equalsIgnoreCase("true")) {
                    return deleteRecord(customerId, creditAccountId, correlationId, PaymentConstants.INVALID_STATUS);
                }
                return Mono.just(new AutoPayResponse());
            });
        }).flatMap(isValidCard -> {
            log.info("CeaseAndDesistGroupCA validation starts :");
            Mono<Boolean> accountSettingResponseBoolean = externalCallService.getCeaseAndDesistFromCreditCardAccountsService(creditAccountId, correlationId);
            return accountSettingResponseBoolean.flatMap(accountSettingBooleanValue-> {
                log.info("Cease and Desist flag : " + accountSettingBooleanValue);
                if (accountSettingBooleanValue) {
                    return deleteRecord(customerId, creditAccountId, correlationId, PaymentConstants.CEASE_DESIST)
                            .flatMap(res -> {
                                log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in CeaseAndDesist section with customerId: {} and creditAccountId: {}", correlationId, customerId, creditAccountId);
                                return Mono.just(accountSettingBooleanValue);
                            });
                }
                return Mono.just(isValidCard);
            });
        });
    }

    private static void getPaymentAmountFromAccountBalanceResponse(AutoPayRequest request, AccountBalanceResponse overviewResponse) {
        if (AutoPayRequest.PaymentPurposeEnum.MINIMUM_PAYMENT.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
            request.setPaymentAmount(overviewResponse.getMinimumPayment());
        } else if (AutoPayRequest.PaymentPurposeEnum.CURRENT_BALANCE.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
            request.setPaymentAmount(overviewResponse.getCurrentBalance());
        } else if (AutoPayRequest.PaymentPurposeEnum.STATEMENT_BALANCE.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
            request.setPaymentAmount(overviewResponse.getStatementBalance());
        }
    }

    private Mono<Map<String, Object>> buildParameters(String customerId, String creditAccountId, AutoPayRequest autoPayRequest, String correlationId) {
        Map<String, Object> parameters = new HashMap<>();
        PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
        paymentServiceRequest.setCustomerId(customerId);
        paymentServiceRequest.setCreditAccountId(creditAccountId);
        parameters.put(PaymentConstants.CUSTOMER_ID, customerId);
        parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
        parameters.put(PaymentConstants.AUTO_PAY_REQUEST, autoPayRequest);
        parameters.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);

        return fillParametersForAutopayInitiation(parameters, correlationId);
    }

    private Mono<Map<String, Object>> fillParametersForAutopayInitiation(Map<String, Object> parameters, String correlationId) {
        return getDetailsFromExternalCallServiceForAutoPayProcessing(correlationId, parameters).flatMap(tuple -> {
            Map<String, String> responseFromCIAMAndCreditCard = tuple.getT1();
            AccountBalanceResponse creditCardDetailsResponse = tuple.getT2();
            BankAccountResponse bankResponse = tuple.getT3();
            log.debug(PaymentConstants.LOG_PREFIX + "Fetched responses from CIAM, CreditCard, and Bank: {}", correlationId);
            if (!responseFromCIAMAndCreditCard.containsKey("firstName") || !responseFromCIAMAndCreditCard.containsKey("lastName")) {
                log.error(PaymentConstants.LOG_PREFIX + "Invalid customer ID: {}", correlationId);
                PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_PROCESSED);
                paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                return Mono.error(paymentDataException);
            }
            if (bankResponse.getBankName().isEmpty() || bankResponse.getBankAccountLast4().isEmpty()) {
                PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_PROCESSED);
                paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                return Mono.error(paymentDataException);
            }
            if (creditCardDetailsResponse.getDueDate() == null) {
                PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_PROCESSED_32);
                paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
                return Mono.error(paymentDataUnprocessableEntityException);
            }

            String customerId = (String)parameters.get(PaymentConstants.CUSTOMER_ID);
            AutoPayRequest autoPayRequest = (AutoPayRequest) parameters.get(PaymentConstants.AUTO_PAY_REQUEST);
            String creditAccountId = (String)parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);

            Integer paymentDueDay = creditCardDetailsResponse.getDueDate().getDayOfMonth();
            String paymentPurpose = String.valueOf(autoPayRequest.getPaymentPurpose());
            log.debug(PaymentConstants.LOG_PREFIX + "Payment Purpose: {}", correlationId, paymentPurpose);
            if (autoPayRequest.getPaymentPurpose().toString().equalsIgnoreCase(AutoPayRequest.PaymentPurposeEnum.OTHER.name())) {
                BigDecimal paymentAmount = autoPayRequest.getPaymentAmount();
                log.debug(PaymentConstants.LOG_PREFIX + "Payment Amount: {}", correlationId, paymentAmount);
            }
            LocalDate paymentDueDate = creditCardDetailsResponse.getDueDate();
            LocalDate currentDate = LocalDate.now(ZoneId.of(paymentZoneId));
            String firstAutoPayDate = String.valueOf(getFirstAutoPayEnrollmentDate(currentDate, paymentDueDate, paymentDueDay));
            parameters.put(PaymentConstants.CREDIT_CARD_ACCOUNT_OVERVIEW_RESPONSE, creditCardDetailsResponse);
            parameters.put(PaymentConstants.PAYMENT_PURPOSE, autoPayRequest.getPaymentPurpose().toString());
            parameters.put(PaymentConstants.FIRST_AUTO_PAY_DATE, firstAutoPayDate);
            parameters.put(PaymentConstants.CUSTOMER_ID, customerId != null ? customerId : null);
            parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId != null ? creditAccountId : null);
            parameters.put(PaymentConstants.JSON_PROPERTY_DUE_IN_DAYS, paymentDueDay.toString() != null ? paymentDueDay : null);
            parameters.put(PaymentConstants.AUTO_PAY_REQUEST, autoPayRequest);
            parameters.put(PaymentConstants.CARD_LAST4, responseFromCIAMAndCreditCard.get(PaymentConstants.CARD_LAST4));

            parameters.put(PaymentConstants.EXTERNAL_BANK_NAME, bankResponse.getBankName());
            parameters.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, bankResponse.getBankAccountLast4());
            parameters.put(PaymentConstants.PAYMENTDATE, firstAutoPayDate);
            log.info(PaymentConstants.LOG_PREFIX + "Start of saveAutoPayConfiguration with parameters: {}", correlationId, parameters);
            parameters.put(PaymentConstants.PAYMENT_AMOUNT, autoPayRequest.getPaymentAmount() != null ? autoPayRequest.getPaymentAmount() : 0);
            parameters.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, responseFromCIAMAndCreditCard);
            return Mono.just(parameters);
        });
    }

    private Mono<Boolean> validateCreditCard(Map<String, Object> parameters, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of validateCreditCard(): correlationId: {}", correlationId, parameters);
        String creditAccountId = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);
        return externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId).flatMap(creditCardDetailsResponses -> {
            return paymentRulesProcessor.isValidCReditCardAccount(creditCardDetailsResponses).flatMap(inValidCreditCard -> {
                if (Boolean.TRUE.equals(inValidCreditCard)) {
                    log.info(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "Invalid Credit Card");
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "Invalid Credit Card");
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                }
                if (paymentRulesProcessor.isAutopaySuppressed(creditCardDetailsResponses) || paymentRulesProcessor.isCeaseAndDesistGroupCA(creditCardDetailsResponses)) {
                    log.info(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "Autopay Suppressed or Is Cease and Desist");
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.AUTOPAY_VALIDATION_FAILED + "Autopay Suppressed or Is Cease and Desist");
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                }
                return Mono.just(paymentRulesProcessor.isAutoPayEligible(creditCardDetailsResponses));
            });

        }).onErrorResume(e -> {
            String error = PaymentErrors.CREDIT_CARD_VALIDATION_ERROR.replace("{errorMessage}", e.getMessage());
            log.debug(PaymentConstants.LOG_PREFIX + error, correlationId);
            return Mono.just(false);
        });
    }

    private Mono<Tuple3<Map<String, String>, AccountBalanceResponse, BankAccountResponse>> getDetailsFromExternalCallServiceForAutoPayProcessing(String correlationId, Map<String, Object> parameters) {
        String customerId = (String) parameters.get(PaymentConstants.CUSTOMER_ID);
        String creditAccountId = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);
        AutoPayRequest request = (AutoPayRequest) parameters.get(PaymentConstants.AUTO_PAY_REQUEST);
        PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
        return paymentProcessor.getCustomerNameFromCIAMAndCreditCardMapResponse(paymentServiceRequest, correlationId).flatMap(map -> {
            return Mono
                    .zip(externalCallService.getAutoPayAvailableCreditBalance(creditAccountId, correlationId),
                            externalCallService.getAccountsFromExternalAccountsServiceByID(customerId, request.getExternalAccountId(), correlationId),
                            paymentProcessor.validateExternalAccountsSuppression(customerId, request.getExternalAccountId(), correlationId, PaymentType.ACH.name()))
                    .flatMap(tuple3 -> {
                        return Mono.just(Tuples.of(map, tuple3.getT1(), tuple3.getT2(), tuple3.getT3()));
                    });
        });
    }

    private Mono<PaymentCommunicationResponse> sendEnableAutoPayCommunication(Map<String, Object> parameters, String correlationId) {
        log.debug(PaymentConstants.LOG_PREFIX + "Start of sendEnableAutoPayCommunication: parameters:{}", correlationId, parameters);
        PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = AutoPayMapper.getAutoPayCommunicationDetailsRequest(parameters);
        PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
        paymentCommunicationRequest.setPaymentRequestId(UUID.randomUUID());

        if (String.valueOf(PaymentMetadata.PaymentPurposeEnum.MINIMUM_PAYMENT).equalsIgnoreCase((String) parameters.get(PaymentConstants.PAYMENT_PURPOSE))) {
            paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.AUTO_PAY_ENROLL_MINIMUM_DUE);
        }
        else if (String.valueOf(PaymentMetadata.PaymentPurposeEnum.STATEMENT_BALANCE).equalsIgnoreCase((String) parameters.get(PaymentConstants.PAYMENT_PURPOSE))) {
            paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.AUTO_PAY_ENROLL_STATEMENT_BALANCE);
        }
        else {
            paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.AUTO_PAY_ENROLL_STATEMENT_OTHER);
        }
        paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
        paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
        log.debug(PaymentConstants.LOG_PREFIX + " PaymentCommunicationRequest:{} ", correlationId, paymentCommunicationDetailsRequest);
        return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
    }

    private LocalDate getFirstAutoPayEnrollmentDate(LocalDate currentDate, LocalDate paymentDueDate, Integer autoPaymentDay) {
        if (currentDate.isAfter(paymentDueDate) || autoPaymentDay <= 3) {
            return paymentDueDate.plusMonths(1);
        }
        return paymentDueDate;
    }

    public Mono<AutoPayResponse> updateAutoPayConfiguration(String customerId, String creditAccountId, UpdateAutoPayRequest request, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of updateAutoPayConfiguration() customerId: {}, creditAccountId: {}, UpdateAutoPayRequest: {}", correlationId, customerId, creditAccountId, request);
        Mono<AccountDetailsResponse> monoCreditCardAccountOverviewResponse = externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId);
        return monoCreditCardAccountOverviewResponse.flatMap(accountDetailsResponse -> {
            return validateCreditCardAccountOverviewResponse(customerId, creditAccountId, accountDetailsResponse, correlationId);
        }).flatMap(accountDetailsResponse -> {
            return validateCeaseAndDesistFromCreditCardAccountsService(customerId, customerId, accountDetailsResponse, correlationId);
        }).flatMap(accountSettingResponseMono -> {
            return Mono.zip(checkAutoPayRecordExist(customerId, creditAccountId, correlationId), checkAutoPayHistoryRecordExist(customerId, creditAccountId, request, correlationId))
                    .flatMap(tuple -> {
                        return validateResponseFromCIAMAndCreditCard(customerId, creditAccountId, correlationId)
                                .flatMap(responseFromCIAMAndCreditCard -> {
                                    return validateBankAccountResponse(customerId, request, correlationId)
                                            .flatMap(bankAccountResponse -> {
                                                Mono<BigDecimal> paymentAmountMono = (request.getPaymentAmount() != null) ? Mono.just(request.getPaymentAmount()) : getPaymentAmountFromAccountBalanceResponse(creditAccountId, request, correlationId);
                                                return paymentAmountMono.flatMap(paymentAmount -> {
                                                    AutoPayDBResponse autoPayDBResponse = tuple.getT1();
                                                    AutoPayHistoryDBResponse autoPayHistoryDBResponse = tuple.getT2();
                                                    log.info(PaymentConstants.LOG_PREFIX + "monoAutoPayDBResponse response: {}", correlationId, autoPayDBResponse);

                                                    Map<String, Object> mapPaymentAmountPaymentPurpose = null;
                                                    try {
                                                        mapPaymentAmountPaymentPurpose = getPaymentAmountPaymentPurpose(autoPayDBResponse, correlationId);
                                                    }
                                                    catch(PaymentDataException e) {
                                                        PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(PaymentErrors.ERROR_PAYMENT_BATCH_PROCESS);
                                                        paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
                                                        return Mono.error(paymentDataUnprocessableEntityException);
                                                    }
                                                    String paymentDueDate = (String) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENTDATE);
                                                    String paymentPurpose = (request.getPaymentPurpose() != null) ? String.valueOf(request.getPaymentPurpose()) : null;
                                                    String bankName = bankAccountResponse.getBankName();
                                                    String bankAccountLast4 = bankAccountResponse.getBankAccountLast4();

                                                    Map<String, Object> parameters = new HashMap<>();
                                                    putFirstBlockParameters(customerId, creditAccountId, bankName, parameters);
                                                    putSecondBlockParameters(request, bankAccountLast4, paymentPurpose, parameters);
                                                    putThirdBlockParameters(paymentDueDate, responseFromCIAMAndCreditCard, paymentAmount, parameters);

                                                    return updateAutPayDataSendAndUpdateCommunication(request, parameters, autoPayDBResponse, autoPayHistoryDBResponse, correlationId);
                                                });
                                            });
                                });
                    });
        });
    }

    private Mono<AccountDetailsResponse> validateCreditCardAccountOverviewResponse(String customerId, String creditAccountId, AccountDetailsResponse accountDetailsResponse, String correlationId) {
        if (accountDetailsResponse.getDaysDelinquentCount().compareTo(BigDecimal.ZERO) > 0) {
            return logDaysDelinquentCountGreaterThanZero(customerId, creditAccountId, correlationId);
        }
        return paymentRulesProcessor.isValidCReditCardAccountAndEmailCheck(accountDetailsResponse, correlationId).flatMap(validCreditCardMap -> {
            if (validCreditCardMap.get("flag").equalsIgnoreCase("true")) {
                return logFlagTrue(customerId, creditAccountId, correlationId);
            }

            return Mono.just(accountDetailsResponse);
        });
    }

    private Mono<AccountDetailsResponse> logDaysDelinquentCountGreaterThanZero(String customerId, String creditAccountId, String correlationId) {
        return autoPayDAO.deleteByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId)
                .flatMap(result -> {
                    log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in validateCreditCard() with customerId: {} and creditAccountId: {}", correlationId, customerId, creditAccountId);
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_ACCOUNT_INELIGIBLE_FOR_AUTOPLAY);
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                });
    }

    private Mono<AccountDetailsResponse> logFlagTrue(String customerId, String creditAccountId, String correlationId) {
        return autoPayDAO.deleteByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId)
                .flatMap(result -> {
                    log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in validateCreditCard() with customerId: {} and creditAccountId: {}", correlationId, customerId, creditAccountId);
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_ACCOUNT_INELIGIBLE_FOR_AUTOPLAY);
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                });
    }

    private Mono<AccountDetailsResponse> validateCeaseAndDesistFromCreditCardAccountsService(String customerId, String creditAccountId, AccountDetailsResponse accountDetailsResponse, String correlationId) {
        Mono<Boolean> monoAccountSettingResponseBoolean = externalCallService.getCeaseAndDesistFromCreditCardAccountsService(creditAccountId, correlationId);

        return monoAccountSettingResponseBoolean.flatMap(accountSettingResponse -> {
            log.info("Cease and Desist Boolean flag value : " + accountSettingResponse);
            if (accountSettingResponse) {
                return deleteRecord(customerId, creditAccountId, correlationId, PaymentConstants.CEASE_DESIST)
                        .flatMap(res -> {
                            log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in CeaseAndDesist section with customerId: {} and creditAccountId: {}", correlationId, customerId, creditAccountId);
                            return Mono.just(accountDetailsResponse);
                        });
            }
            return Mono.just(accountDetailsResponse);
        });
    }

    private Mono<Map<String, String>> validateResponseFromCIAMAndCreditCard(String customerId, String creditAccountId, String correlationId) {
        PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
        paymentServiceRequest.setCustomerId(customerId);
        paymentServiceRequest.setCreditAccountId(creditAccountId);

        return paymentProcessor.getCustomerNameFromCIAMAndCreditCardMapResponse(paymentServiceRequest, correlationId)
                .flatMap(responseFromCIAMAndCreditCardConsumed -> {
                    return Mono.just(responseFromCIAMAndCreditCardConsumed);
                }).onErrorResume(err -> {
                    ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE);
                    serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
                    return Mono.error(serviceUnavailableException);
                }).flatMap(responseFromCIAMAndCreditCard -> {
                    log.info(PaymentConstants.LOG_PREFIX + "Fetched responseFromCIAMAndCreditCard: {}", correlationId, responseFromCIAMAndCreditCard);
                    if (!responseFromCIAMAndCreditCard.containsKey("firstName") || !responseFromCIAMAndCreditCard.containsKey("lastName")) {
                        log.error(PaymentConstants.LOG_PREFIX + "Invalid customerId:{} ", correlationId, customerId);
                        PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_AUTOPAY_CANNOT_BE_PROCESSED);
                        paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                        return Mono.error(paymentDataException);
                    }

                    return Mono.just(responseFromCIAMAndCreditCard);
                });
    }

    private Mono<BankAccountResponse> validateBankAccountResponse(String customerId, UpdateAutoPayRequest updateAutoPayRequest, String correlationId) {
        return externalCallService.getAccountsFromExternalAccountsServiceByID(customerId, updateAutoPayRequest.getExternalAccountId(), correlationId)
                .flatMap(bankAccountResponseConsumed -> {
                    return Mono.just(bankAccountResponseConsumed);
                }).onErrorResume(err -> {
                    PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INVALID);
                    paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                    return Mono.error(paymentDataException);
                }).flatMap(bankAccountResponse -> {
                    return Mono.just(bankAccountResponse);
                });
    }

    private Mono<BigDecimal> getPaymentAmountFromAccountBalanceResponse(String creditAccountId, UpdateAutoPayRequest request, String correlationId) {
        Mono<AccountBalanceResponse> autoPayAvailableCreditBalance = externalCallService.getAutoPayAvailableCreditBalance(creditAccountId, correlationId);
        return autoPayAvailableCreditBalance.flatMap(accountBalanceResponse -> {
            if (AutoPayRequest.PaymentPurposeEnum.MINIMUM_PAYMENT.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
                request.setPaymentAmount(accountBalanceResponse.getMinimumPayment());
            } else if (AutoPayRequest.PaymentPurposeEnum.CURRENT_BALANCE.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
                request.setPaymentAmount(accountBalanceResponse.getCurrentBalance());
            } else if (AutoPayRequest.PaymentPurposeEnum.STATEMENT_BALANCE.toString().equalsIgnoreCase(request.getPaymentPurpose().toString())) {
                request.setPaymentAmount(accountBalanceResponse.getStatementBalance());
            }
            return Mono.just(request.getPaymentAmount());
        });
    }

    private void putFirstBlockParameters(String customerId, String creditAccountId, String bankName, Map<String, Object> parameters) {
        parameters.put(PaymentConstants.CUSTOMER_ID, customerId);
        parameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
        parameters.put(PaymentConstants.EXTERNAL_BANK_NAME, bankName);
    }

    private void putSecondBlockParameters(UpdateAutoPayRequest request, String bankAccountLast4, String paymentPurpose, Map<String, Object> parameters) {
        parameters.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, bankAccountLast4);
        parameters.put(PaymentConstants.PAYMENT_PURPOSE, paymentPurpose);
        parameters.put(PaymentConstants.UPDATE_AUTO_PAY_REQUEST, request);
    }

    private void putThirdBlockParameters(String paymentDueDate, Map<String, String> responseFromCIAMAndCreditCard, BigDecimal paymentAmount, Map<String, Object> parameters) {
        parameters.put(PaymentConstants.PAYMENTDATE, paymentDueDate);
        parameters.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, responseFromCIAMAndCreditCard);
        parameters.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount);
    }

    private Mono<AutoPayResponse> updateAutPayDataSendAndUpdateCommunication(UpdateAutoPayRequest request, Map<String, Object> parameters, AutoPayDBResponse autoPayDBResponse, AutoPayHistoryDBResponse autoPayHistoryDBResponse, String correlationId) {
        try {
            autoPayDBResponse.setAutoPayData(Json.of(AutoPayMapper.getUpdateJsonObject(parameters, autoPayDBResponse.getAutoPayData(), correlationId).toJSONString()));
        }
        catch(PaymentDataException e) {
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            return Mono.error(paymentDataException);
        }
        autoPayDBResponse.setUpdatedBy(request.getAgentId());
        return sendAndUpdateCommunication(parameters, autoPayDBResponse, autoPayHistoryDBResponse, correlationId);
    }

    private Mono<AutoPayResponse> sendAndUpdateCommunication(Map<String, Object> parameters, AutoPayDBResponse autoPayDBResponse, AutoPayHistoryDBResponse autoPayHistoryDBResponse, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of sendAndUpdateCommunication with parameters: {}, autoPayDBResponse {}, autoPayHistoryDBResponse {}", correlationId, parameters, autoPayDBResponse, autoPayHistoryDBResponse);
        return autoPayDAO.updateAutoPayConfiguration(autoPayDBResponse, correlationId).flatMap(autoPayDBResponseUpdated -> {
            log.info(PaymentConstants.LOG_PREFIX + "Updated auto pay response, autoPayDBResponse: {}", correlationId, autoPayDBResponse);
            Map<String, Object> parametersForDisableAutoPayCommunication = getParametersForDisableAutoPayCommunication(parameters, autoPayDBResponse, correlationId);
            return sendDisableAutoPayCommunication(parametersForDisableAutoPayCommunication, correlationId).flatMap(paymentCommunicationResponse -> {
                return sendEnableAutoPayCommunication(parameters, correlationId).flatMap(paymentCommunicationResponseEnabled -> {
                    String communicationRequestId = paymentCommunicationResponseEnabled.getCommunicationRequestId();
                    parameters.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);
                    return updateAutoPayHistoryDBResponse(autoPayDBResponse, autoPayHistoryDBResponse, communicationRequestId, PaymentConstants.ENABLED, correlationId).flatMap(updatedAutoPayHistoryDBResponse ->{
                        log.info(PaymentConstants.LOG_PREFIX + "Updated auto pay history response object: {}", correlationId, updatedAutoPayHistoryDBResponse);
                        Mono<AutoPayHistoryDBResponse> monoAutoPayHistoryDBResponse = autoPayDAO.updateAutoPayHistory(updatedAutoPayHistoryDBResponse, communicationRequestId, PaymentConstants.TRUE, correlationId);
                        return monoAutoPayHistoryDBResponse.flatMap(autoPayHistoryDBResponseSecondUpdate -> {
                            AutoPayResponse autoPayResponse = AutoPayMapper.mapToAutoPayResponseFromUpdateAutoPayResponse(parameters);
                            return Mono.just(autoPayResponse);
                        }).onErrorResume(err -> {
                            log.warn(PaymentConstants.LOG_PREFIX + PaymentErrors.AUTOPAY_HISTORY_UPDATE_FAILED, correlationId, err.getMessage());
                            return autoPayDAO.saveAutoPayHistory(updatedAutoPayHistoryDBResponse, communicationRequestId, PaymentConstants.TRUE, correlationId).flatMap(autoPayHistoryDBResponseThirdUpdate -> {
                                AutoPayResponse autoPayResponse = AutoPayMapper.mapToAutoPayResponseFromUpdateAutoPayResponse(parameters);
                                return Mono.just(autoPayResponse);
                            });
                        });
                    });
                });
            });
        });
    }

    private Map<String, Object> getParametersForDisableAutoPayCommunication(Map<String, Object> parameters, AutoPayDBResponse autoPayDBResponse, String correlationId) {
        Map<String, Object> parametersForDisableAutoPayCommunication = new HashMap<>();
        parametersForDisableAutoPayCommunication.put(PaymentConstants.CUSTOMER_ID, parameters.get(PaymentConstants.CUSTOMER_ID));
        parametersForDisableAutoPayCommunication.put(PaymentConstants.CREDIT_ACCOUNT_ID, parameters.get(PaymentConstants.CUSTOMER_ID));
        parametersForDisableAutoPayCommunication.put(PaymentConstants.CORRELATION_ID, correlationId);
        Map<String, Object> mapPaymentAmountPaymentPurpose = getPaymentAmountPaymentPurpose(autoPayDBResponse, correlationId);
        BigDecimal paymentAmount = (BigDecimal) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENT_AMOUNT);
        String paymentDueDate = (String) mapPaymentAmountPaymentPurpose.get(PaymentConstants.PAYMENTDATE);
        parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount);
        parametersForDisableAutoPayCommunication.put(PaymentConstants.PAYMENTDATE, paymentDueDate);
        parametersForDisableAutoPayCommunication.put(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD, parameters.get(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD));
        return parametersForDisableAutoPayCommunication;
    }

    public Mono<AutoPayDBResponse> checkAutoPayRecordExist(String customerId, String creditAccountId, String correlationId) {
        Mono<AutoPayDBResponse> monoAutoPayDBResponse = autoPayDAO.findByCustomerIdAndCreditAccountId(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId);
        return monoAutoPayDBResponse.flatMap(autoPayDBResponse -> {
           return Mono.just(autoPayDBResponse);
        }).onErrorResume(err -> {
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_NO_RECORD_FOUND_AUTOPAY);
            paymentDataException.setHttpStatusCode(HttpStatus.NOT_FOUND);
            return Mono.error(paymentDataException);
        });
    }

    public Mono<AutoPayHistoryDBResponse> checkAutoPayHistoryRecordExist(String customerId, String creditAccountId, UpdateAutoPayRequest request, String correlationId) {
        Mono<AutoPayHistoryDBResponse> monoAutoPayHistoryDBResponse = autoPayDAO.findByCustomerIdAndCreditAccountIdHistory(UUID.fromString(customerId), UUID.fromString(creditAccountId), correlationId);
        return monoAutoPayHistoryDBResponse.hasElement().flatMap(hasElement -> {
            if (Boolean.FALSE.equals(hasElement)) {
                log.warn(PaymentConstants.LOG_PREFIX + PaymentErrors.AUTO_PAY_HISTORY_RECORD_NOT_FOUND, correlationId, customerId, creditAccountId);
                return getAutoPayHistoryDBResponseMono(customerId, creditAccountId, request);
            }
            return monoAutoPayHistoryDBResponse;
        });
    }

    private Mono<AutoPayHistoryDBResponse> getAutoPayHistoryDBResponseMono(String customerId, String creditAccountId, UpdateAutoPayRequest request) {
        AutoPayHistoryDBResponse autoPayHistoryDBResponse = new AutoPayHistoryDBResponse();
        autoPayHistoryDBResponse.setCustomerId(UUID.fromString(customerId));
        autoPayHistoryDBResponse.setCreditAccountId(UUID.fromString(creditAccountId));
        autoPayHistoryDBResponse.setAutoPayId(AutoPayDAO.getAutoPayId(customerId, creditAccountId));
        autoPayHistoryDBResponse.setCreatedBy(request.getAgentId() != null ? request.getAgentId() : null);
        autoPayHistoryDBResponse.setUpdatedBy(request.getAgentId() != null ? request.getAgentId() : null);
        autoPayHistoryDBResponse.setCreatedTimestamp(ZonedDateTime.now());
        autoPayHistoryDBResponse.setAutoPayHistoryData(AutoPayHistoryMapper.mappingFromUpdateAutoPayRequestToAutoPayHistoryData(request));
        return Mono.just(autoPayHistoryDBResponse);
    }

}