package com.creditone.ucrm.payments.processor;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.reactive.ReactiveKafkaConsumerTemplate;
import org.springframework.stereotype.Component;

import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.FDRStatus;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.CustomerInteractionProducerMapper;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.FinTransPaymentSrvTransStatusKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.util.PaymentUtil;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class FinTransactionKafkaConsumerProcessor implements CommandLineRunner {
	private ReactiveKafkaConsumerTemplate<String, FinTransPaymentSrvTransStatusKafkaEvent> reactiveKafkaFinTransactionConsumerTemplate;
	private PaymentDAO paymentDao;
	private PaymentKafkaProducerProcessor kafkaProducerService;

	private CustomerInteractionProducerProcessor customerInteractionProducerProcessor;
	private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;

	public FinTransactionKafkaConsumerProcessor(ReactiveKafkaConsumerTemplate<String, FinTransPaymentSrvTransStatusKafkaEvent> reactiveKafkaFinTransactionConsumerTemplate,
			PaymentDAO paymentDao, PaymentKafkaProducerProcessor kafkaProducerService, CustomerInteractionProducerProcessor customerInteractionProducerProcessor,
			CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		this.reactiveKafkaFinTransactionConsumerTemplate = reactiveKafkaFinTransactionConsumerTemplate;
		this.paymentDao = paymentDao;
		this.kafkaProducerService = kafkaProducerService;
		this.customerInteractionProducerProcessor = customerInteractionProducerProcessor;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
	}

	public Flux<FinTransPaymentSrvTransStatusKafkaEvent> consumePaymentsKafkaEvent() {
		log.debug("Start of consumePaymentsKafkaEvent()");

		Flux<ConsumerRecord<String, FinTransPaymentSrvTransStatusKafkaEvent>> fluxConsumer = reactiveKafkaFinTransactionConsumerTemplate.receiveAutoAck();
		if (fluxConsumer == null) {
			log.info("Flux consumer is null and we are returning empty flux");
			return Flux.empty();
		}

		return fluxConsumer.map(ConsumerRecord::value).onErrorContinue((err, finTransStatusevent) -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error Mapping Consumer Record, error: {}", "", err.getMessage());
		}).doOnNext(finTransStatusevent -> {
			boolean recordMapped = logEvent(finTransStatusevent);
			if (recordMapped) {
				processRecord(finTransStatusevent);

			}
		}).onErrorContinue((err, finTransStatusevent) -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error Processing Record: {}", "", err.toString());
		});
	}

	private boolean logEvent(FinTransPaymentSrvTransStatusKafkaEvent finTransStatusevent) {
		if (finTransStatusevent.getEventData() == null) {
			log.error(PaymentConstants.LOG_PREFIX + "Received event without data",
					finTransStatusevent.getEventHeader() != null && finTransStatusevent.getEventHeader().getTraceId() != null ? finTransStatusevent.getEventHeader().getTraceId()
							: "");
			return false;
		}

		log.info(
				PaymentConstants.LOG_PREFIX
						+ "Data received correlationID {}, getTraceId {}, eventSource {}, transactionId {}, paymentRequestId {}, status {}, creditAccountId {}, message {}",
				finTransStatusevent.getEventHeader().getTraceId(), finTransStatusevent.getEventHeader().getEventCreatedTimestamp(),
				finTransStatusevent.getEventHeader().getEventSource(), finTransStatusevent.getEventData().getTransactionId(),
				finTransStatusevent.getEventData().getPaymentRequestId(), finTransStatusevent.getEventData().getStatus(), finTransStatusevent.getEventData().getCreditAccountId(),
				finTransStatusevent.getEventData().getMessage());

		return true;
	}

	public void processRecord(FinTransPaymentSrvTransStatusKafkaEvent finTransStatusevent) {
		Mono<Boolean> monoExistsPayment = paymentDao.existsById(finTransStatusevent.getEventData().getPaymentRequestId(), finTransStatusevent.getEventHeader().getTraceId());
		monoExistsPayment.flatMap(existsPayment -> {
			return processExistsPayment(existsPayment, finTransStatusevent, finTransStatusevent.getEventHeader().getTraceId());
		}).doOnError(err -> {
			log.error(PaymentConstants.LOG_PREFIX + err.getMessage(), finTransStatusevent.getEventHeader().getTraceId());
		}).subscribe();
	}

	public Mono<PaymentRequestDataDBResponse> processExistsPayment(Boolean existsPayment, FinTransPaymentSrvTransStatusKafkaEvent finTransStatusevent, String correlationId) {
		if (!existsPayment) {
			String error = PaymentErrors.ERROR_ACH_ERROR_NOT_ONE_RECORD_DATABASE_FOUND.replaceAll("\\{paymentId\\}",
					finTransStatusevent.getEventData().getPaymentRequestId().toString());
			error = error.replaceAll("\\{numberOfRecords\\}", "0");

			return Mono.error(new PaymentDataException(error));
		}
		return updateDatabase(finTransStatusevent);

	}

	public Mono<PaymentRequestDataDBResponse> updateDatabase(FinTransPaymentSrvTransStatusKafkaEvent paymentsKafkaEvent) {
		Mono<PaymentRequestDataDBResponse> monoResult = paymentDao.findByPaymentRequestId(paymentsKafkaEvent.getEventData().getPaymentRequestId(),
				paymentsKafkaEvent.getEventHeader().getTraceId());

		return monoResult.flatMap(paymentRequestDataDBResponse -> {
			JSONParser parser = new JSONParser();
			JSONObject paymentRequestData = null;

			try {
				paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
			} catch (ParseException e) {
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}
			String fdrStartusInDb = String.valueOf(paymentRequestData.get(PaymentConstants.FDR_STATUS));
			if (!FDRStatus.POSTED.name().equalsIgnoreCase(fdrStartusInDb)) {
				return editUpdatingParameters(paymentsKafkaEvent, paymentRequestData, paymentRequestDataDBResponse).flatMap(paymentRequestDbresponse -> {
					return kafkaProducerService.publishFdrEventToKafka(paymentRequestDbresponse, paymentsKafkaEvent.getEventHeader().getTraceId());

				});
			} else {
				PaymentRequestDataDBResponse emptyResponse = new PaymentRequestDataDBResponse();
				return Mono.just(emptyResponse);
			}
		}).onErrorResume(err -> {
			return Mono.error(err);
		});
	}

	private Mono<PaymentRequestDataDBResponse> editUpdatingParameters(FinTransPaymentSrvTransStatusKafkaEvent paymentsKafkaEvent, JSONObject paymentRequestData, PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId());
		parameters.put(PaymentConstants.CUSTOMER_ID, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
		parameters.put(PaymentConstants.UPDATED_BY, PaymentConstants.SYSTEM);
		parameters.put(PaymentConstants.UPDATED_TIMESTAMP, LocalDateTime.now());
		parameters.put(PaymentConstants.CORRELATION_ID, paymentsKafkaEvent.getEventHeader().getTraceId());

		JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
		paymentRequestData.put(PaymentConstants.FDR_STATUS, paymentsKafkaEvent.getEventData().getStatus());
		if (FDRStatus.POSTED.name().equalsIgnoreCase(paymentsKafkaEvent.getEventData().getStatus())) {
			paymentRequestData.put(PaymentConstants.FDR_POSTED_DATE,
					PaymentUtil.formatDate(paymentsKafkaEvent.getEventHeader().getEventCreatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
			paymentRequestData.put(PaymentConstants.FDR_VERIFIED_DATE, null);
		} else if (FDRStatus.VERIFIED.name().equalsIgnoreCase(paymentsKafkaEvent.getEventData().getStatus())) {
			paymentRequestData.put(PaymentConstants.FDR_VERIFIED_DATE,
					PaymentUtil.formatDate(paymentsKafkaEvent.getEventHeader().getEventCreatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
		}
		parameters.put(PaymentConstants.PAYMENT_METADATA, paymentRequestData);
		return paymentDao.updatePaymentEntityFdrStatus(parameters).flatMap(response -> {

			if (FDRStatus.VERIFIED.name().equalsIgnoreCase(paymentsKafkaEvent.getEventData().getStatus())) {
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForPaymentBalanceVerified(response,
						(String) parameters.get(PaymentConstants.CORRELATION_ID), customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, (String) parameters.get(PaymentConstants.CORRELATION_ID))
						.flatMap(publishResponse -> {
							return Mono.just(response);
						});
			}
			if (FDRStatus.POSTED.name().equalsIgnoreCase(paymentsKafkaEvent.getEventData().getStatus())) {
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForFDRStatusUpdate(paymentRequestDataDBResponse,
						paymentsKafkaEvent.getEventHeader().getTraceId(), customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, (String) parameters.get(PaymentConstants.CORRELATION_ID))
						.flatMap(publishResponse -> {
							return Mono.just(response);
						});
			}
			return Mono.just(response);
		}).onErrorResume(err -> {
			return Mono.error(new PaymentException(err.getMessage()));
		});
	}

	@Override
	public void run(String... args) { // we have to trigger consumption
		Flux<FinTransPaymentSrvTransStatusKafkaEvent> flux = consumePaymentsKafkaEvent();
		if (flux == null) {
			log.info("Flux was null and we are closing Consumer");
			return;
		}
		flux.doOnError(err -> {
			log.info("Error on Consumer Event Flux: {}, StackTrace: {}", err.getMessage(), err);
		}).subscribe();
	}
}