package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.dao.CustomerInteractionProducerMapper;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentKafkaConsumerMapper;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.PaymentsErrorKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.creditone.ucrm.payments.validation.PaymentRecordDatabaseValidator;
import com.creditone.ucrm.payments.validation.PaymentRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.reactive.ReactiveKafkaConsumerTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class PaymentKafkaConsumerProcessor implements CommandLineRunner {
    private ReactiveKafkaConsumerTemplate<String, PaymentsErrorKafkaEvent> reactiveKafkaConsumerTemplate;
    private PaymentDAO paymentDao;
    private PaymentKafkaProducerProcessor kafkaProducerService;
    private PaymentCommunicationProcessor paymentCommunicationProcessor;
    private CustomerInteractionProducerProcessor customerInteractionProducerProcessor;
    private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;

    public PaymentKafkaConsumerProcessor(ReactiveKafkaConsumerTemplate<String, PaymentsErrorKafkaEvent> reactiveKafkaConsumerTemplate,
                                         PaymentDAO paymentDao,
                                         PaymentKafkaProducerProcessor kafkaProducerService,
                                         PaymentCommunicationProcessor paymentCommunicationProcessor,
                                         CustomerInteractionProducerProcessor customerInteractionProducerProcessor, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
        this.reactiveKafkaConsumerTemplate = reactiveKafkaConsumerTemplate;
        this.paymentDao = paymentDao;
        this.kafkaProducerService = kafkaProducerService;
        this.paymentCommunicationProcessor = paymentCommunicationProcessor;
        this.customerInteractionProducerProcessor = customerInteractionProducerProcessor;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
	}

    public Flux<PaymentsErrorKafkaEvent> consumePaymentsKafkaEvent() {
        log.debug("Start of consumePaymentsKafkaEvent()");

        Flux<ConsumerRecord<String, PaymentsErrorKafkaEvent>> fluxConsumer = reactiveKafkaConsumerTemplate.receiveAutoAck();
        if(fluxConsumer == null){
            log.info("Flux consumer is null and we are returning empty flux");
            return Flux.empty();
        }

        return fluxConsumer.map(ConsumerRecord::value)
                .onErrorContinue((err, paymentsErrorKafkaEvent) -> {
                    log.error(PaymentConstants.LOG_PREFIX + "Error Mapping Consumer Record, error: {}", "", err.getMessage());
                })
                .doOnNext(paymentsErrorKafkaEvent -> {
                    boolean recordMapped = logEvent(paymentsErrorKafkaEvent);
                    if (recordMapped) {
                        boolean validRecord = validateRecord(paymentsErrorKafkaEvent);

                        if (validRecord) {
                            processRecord(paymentsErrorKafkaEvent);
                        }
                    }
                })
                .onErrorContinue((err, paymentsErrorKafkaEvent) -> {
                    log.error(PaymentConstants.LOG_PREFIX + "Error Processing Record: {}", "", err.toString());
                });
    }

    private boolean logEvent(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent){
        if (paymentsErrorKafkaEvent.getEventData() == null) {
            log.error(PaymentConstants.LOG_PREFIX + "Received event without data", paymentsErrorKafkaEvent.getEventHeader() != null && paymentsErrorKafkaEvent.getEventHeader().getTraceId() != null ?
                    paymentsErrorKafkaEvent.getEventHeader().getTraceId() : "");
            return false;
        }

        log.info(PaymentConstants.LOG_PREFIX + "Data received paymentRequestId {}, customerId {}, transactionType {}, transactionDirection {}, paymentDate {}, paymentAmount {}, paymentErrorCode {}, paymentStatus {}, transactionId {}, " +
                        "paymentType {}, returnDate {}", paymentsErrorKafkaEvent.getEventHeader().getTraceId(), paymentsErrorKafkaEvent.getEventData().getPaymentRequestId(), paymentsErrorKafkaEvent.getEventData().getCustomerId(),
                paymentsErrorKafkaEvent.getEventData().getTransactionType(), paymentsErrorKafkaEvent.getEventData().getTransactionDirection(), paymentsErrorKafkaEvent.getEventData().getPaymentDate(),
                paymentsErrorKafkaEvent.getEventData().getPaymentAmount(), paymentsErrorKafkaEvent.getEventData().getPaymentErrorCode(), paymentsErrorKafkaEvent.getEventData().getPaymentStatus(),
                paymentsErrorKafkaEvent.getEventData().getTransactionId(), paymentsErrorKafkaEvent.getEventData().getPaymentType(), paymentsErrorKafkaEvent.getEventData().getReturnDate());

        return true;
    }

    private boolean validateRecord(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent) {
        boolean validRecord = false;

        try {
            PaymentRequestValidator.validateKafkaACHErrorPayload(paymentsErrorKafkaEvent);
        }
        catch (PaymentDataException e) {
            log.error(PaymentConstants.LOG_PREFIX + e.getMessage(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
        }

        try {
            validateTransactionType(paymentsErrorKafkaEvent);
            validRecord = true;
        }
        catch (PaymentDataException e) {
            log.info(PaymentConstants.LOG_PREFIX + e.getMessage(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
        }

        return validRecord;
    }

    private void validateTransactionType(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent){
        if(!paymentsErrorKafkaEvent.getEventData().getTransactionType().toUpperCase().equalsIgnoreCase(TransactionType.CREDITCARDPAYMENT.name())){
            String error = PaymentErrors.WARNING_ACH_ERROR_IGNORED_MESSAGE_BECAUSE_TRANSACTION_TYPE
                    .replaceAll("\\{transactionType\\}", paymentsErrorKafkaEvent.getEventData().getTransactionType());
            error = error.replaceAll("\\{paymentId\\}", paymentsErrorKafkaEvent.getEventData().getPaymentRequestId().toString());
            throw new PaymentDataException(error);
        }
    }

    private void processRecord(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent) {
        Mono<Boolean> monoExistsPayment = paymentDao.existsById(paymentsErrorKafkaEvent.getEventData().getPaymentRequestId(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
        monoExistsPayment.flatMap(existsPayment -> {
            return processExistsPayment(existsPayment, paymentsErrorKafkaEvent, paymentsErrorKafkaEvent.getEventData().getReturnDate(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
        }).doOnError(err -> {
            log.error(PaymentConstants.LOG_PREFIX + err.getMessage(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
        }).doOnSuccess(paymentRequestDataDBResponse -> {
            try {
                publishKafka(paymentRequestDataDBResponse, paymentsErrorKafkaEvent.getEventData().getPaymentErrorCode(), paymentsErrorKafkaEvent.getEventData().getReturnDate(), paymentsErrorKafkaEvent.getEventHeader().getTraceId());
            }
            catch (ParseException e) {
                log.error(PaymentConstants.LOG_PREFIX + "Error publishing kafka message: " + e.toString() + ", paymentRequestId: {}", paymentsErrorKafkaEvent.getEventHeader().getTraceId(), paymentRequestDataDBResponse.getPaymentRequestId());
            }
        }).subscribe();
    }

    private Mono<PaymentRequestDataDBResponse> processExistsPayment(Boolean existsPayment, PaymentsErrorKafkaEvent paymentsKafkaEvent, String returnDate, String correlationId){
        if(!existsPayment){
            String error = PaymentErrors.ERROR_ACH_ERROR_NOT_ONE_RECORD_DATABASE_FOUND.replaceAll("\\{paymentId\\}",
                    paymentsKafkaEvent.getEventData().getPaymentRequestId().toString());
            error = error.replaceAll("\\{numberOfRecords\\}", "0");

            return Mono.error(new PaymentDataException(error));
        }

        Mono<PaymentCommunicationResponse> monoPaymentCommunicationResponse = callPaymentCommunication(paymentsKafkaEvent.getEventData().getPaymentRequestId(), returnDate, correlationId);
        return monoPaymentCommunicationResponse.flatMap(paymentCommunicationResponse -> {
            Mono<PaymentRequestDataDBResponse> monoResult = updateDatabase(paymentsKafkaEvent, paymentCommunicationResponse, correlationId);
            return monoResult
                    .flatMap(paymentRequestDataDBResponse -> {
                        CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForReturnPayment(paymentCommunicationResponse, paymentRequestDataDBResponse, correlationId, customerInteractionDescriptionConfig);
                        return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId)
                                .map(publishResponse -> {
                                    return paymentRequestDataDBResponse;
                                });
                    });
        });
    }

    private Mono<PaymentCommunicationResponse> callPaymentCommunication(UUID paymentRequestId, String returnDate, String correlationId) {
        PaymentCommunicationRequest paymentCommunicationRequest = PaymentKafkaConsumerMapper.mapPaymentCommunicationRequestForKafkaConsumer(paymentRequestId);

        Mono<PaymentCommunicationDetailsRequest> monoPaymentCommunicationDetailsRequest = paymentCommunicationProcessor.fillPaymentCommunicationDetailsRequest(paymentCommunicationRequest, correlationId);
        return monoPaymentCommunicationDetailsRequest.flatMap(paymentCommunicationDetailsRequest -> {
            paymentCommunicationDetailsRequest.setReturnDate(returnDate);
            paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
            return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
        });
    }

    private Mono<PaymentRequestDataDBResponse> updateDatabase(PaymentsErrorKafkaEvent paymentsKafkaEvent, PaymentCommunicationResponse paymentCommunicationResponse, String correlationId){
        Mono<PaymentRequestDataDBResponse> monoResult = paymentDao.findByPaymentRequestId(paymentsKafkaEvent.getEventData().getPaymentRequestId(), paymentsKafkaEvent.getEventHeader().getTraceId());

        return monoResult.flatMap(paymentRequestDataDBResponse -> {
            try {
                PaymentRecordDatabaseValidator.validatePaymentRecordVerificationData(paymentRequestDataDBResponse, PaymentConstants.KAFKA_CONSUMER_ORIGIN);
            }
            catch (ParseException e) {
                log.error(PaymentConstants.LOG_PREFIX + "Error parsing Json to Validate Database Record: " + e.toString(), correlationId);
                PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
                paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                return Mono.error(paymentDataException);
            }

            return editUpdatingParameters(paymentsKafkaEvent, paymentCommunicationResponse, paymentRequestDataDBResponse);
        }).onErrorResume(err -> {
            return Mono.error(err);
        });
    }

    private Mono<PaymentRequestDataDBResponse> editUpdatingParameters(PaymentsErrorKafkaEvent paymentsKafkaEvent, PaymentCommunicationResponse paymentCommunicationResponse, PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId());
        parameters.put(PaymentConstants.PAYMENT_TYPE, paymentRequestDataDBResponse.getPaymentType());
        parameters.put(PaymentConstants.CUSTOMER_ID, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
        parameters.put(PaymentConstants.STATUS, PaymentStatus.RETURNED.name());
        parameters.put(PaymentConstants.UPDATED_BY, PaymentConstants.SYSTEM);
        parameters.put(PaymentConstants.UPDATED_TIMESTAMP, LocalDateTime.now());
        parameters.put(PaymentConstants.CORRELATION_ID, paymentsKafkaEvent.getEventHeader().getTraceId());

        JSONObject noteJSONObject = fillNote(paymentCommunicationResponse, paymentsKafkaEvent);
        JSONParser parser = new JSONParser();
        JSONObject paymentRequestData = null;

        try {
            paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
        }
        catch(ParseException e) {
            log.error(PaymentConstants.LOG_PREFIX + "Error parsing Json to Validate Database Record: " + e.toString(), paymentsKafkaEvent.getEventHeader().getTraceId());
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            return Mono.error(paymentDataException);
        }

        JSONArray paymentMetadata =  (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
        paymentMetadata.add(noteJSONObject);
        paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
        paymentRequestData.put(PaymentConstants.PAYMENT_RETURN_CODE, paymentsKafkaEvent.getEventData().getPaymentErrorCode());
        paymentRequestData.put(PaymentConstants.PAYMENT_RETURN_DATE, paymentsKafkaEvent.getEventData().getReturnDate());

        parameters.put(PaymentConstants.PAYMENT_METADATA, paymentRequestData);

        return paymentDao.updatePaymentEntityStatus(parameters)
                .onErrorResume(err -> {
                    return Mono.error(new PaymentException(err.getMessage()));
                });
    }

    private JSONObject fillNote(PaymentCommunicationResponse paymentCommunicationResponse, PaymentsErrorKafkaEvent paymentsKafkaEvent) {
        JSONObject jsonResult = new JSONObject();

        ZonedDateTime zonedDateTime = PaymentUtil.utcNow();
        String date = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATETIMEFORMAT_RESPONSE);

        jsonResult.put(PaymentConstants.DATE, date);

        jsonResult.put(PaymentConstants.NOTES, PaymentConstants.NOTES_KAFKA_CONSUMER);

        jsonResult.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentCommunicationResponse.getCommunicationRequestId());

        return jsonResult;
    }

    private void publishKafka(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String paymentErrorCode, String paymentReturnDate, String correlationId) throws ParseException {
        kafkaProducerService.publishEventToKafka(paymentRequestDataDBResponse, paymentErrorCode, paymentReturnDate, correlationId);

        String successMessage = PaymentErrors.ERROR_ACH_INFO_RECORD_PROCESSED.replaceAll("\\{paymentId\\}", paymentRequestDataDBResponse.getPaymentRequestId().toString());
        log.info(PaymentConstants.LOG_PREFIX + successMessage, correlationId);
    }

    @Override
    public void run(String... args) {
        // we have to trigger consumption
        Flux<PaymentsErrorKafkaEvent> flux = consumePaymentsKafkaEvent();
        if(flux == null){
            log.info("Flux was null and we are closing Consumer");
            return;
        }
        flux.doOnError(err -> {
            log.info("Error on Consumer Event Flux: {}, StackTrace: {}", err.getMessage(), err);
        }).subscribe();
    }
}