package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.AutopayNotifiedStatus;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.constant.PaymentType;
import com.creditone.ucrm.payments.dao.*;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.ucrm.swagger.collection.model.CollectionIntentRequest;
import com.ucrm.swagger.creditcardaccountservice.model.AccountBalanceResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountSettingResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsGatewayResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsPartnerRequest;
import com.ucrm.swagger.externalaccounts.model.AccountTokenResponse;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.externalaccounts.model.SuppressedExtlBankAcctResponse;
import com.ucrm.swagger.paymentservice.model.BatchProcessResponse;
import com.ucrm.swagger.paymentservice.model.PaymentMetadata;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
@Component
public class ProcessAutoPayNotifiedPaymentsProcessor {
	private PaymentDAO dao;
	private PaymentBatchDAO paymentBatchDAO;
	private PaymentProcessor paymentProcessor;
	private ExternalCallService externalCallService;
	private AutoPayDAO autoPayDAO;
	private PaymentRulesProcessor paymentRulesProcessor;
	private AutoPayConfigurationProcessor autoPayConfigurationProcessor;
	private String collectionIntentType;
	public ProcessAutoPayNotifiedPaymentsProcessor(PaymentDAO dao, PaymentBatchDAO paymentBatchDAO, PaymentProcessor paymentProcessor, ExternalCallService externalCallService,
			AutoPayDAO autoPayDAO, PaymentRulesProcessor paymentRulesProcessor, AutoPayConfigurationProcessor autoPayConfigurationProcessor,@Value(value = "${collection.intent.type}") String collectionIntentType) {
		this.dao = dao;
		this.paymentBatchDAO = paymentBatchDAO;
		this.paymentProcessor = paymentProcessor;
		this.externalCallService = externalCallService;
		this.autoPayDAO = autoPayDAO;
		this.paymentRulesProcessor = paymentRulesProcessor;
		this.autoPayConfigurationProcessor = autoPayConfigurationProcessor;
		this.collectionIntentType=collectionIntentType;
	}

	public Mono<BatchProcessResponse> processAutoPayNotifiedPayments(ZonedDateTime localDateTimeNowPST, Map<String, Object> parameters, String correlationId) {
		List<UUID> listRecordsProcessed = new ArrayList<UUID>();
		List<UUID> listRecordsError = new ArrayList<UUID>();
		List<String> listErrorRecordsInserted = new ArrayList<String>();
		List<String> status = Arrays.asList(PaymentStatus.AUTOPAY_NOTIFIED.name());
		Flux<PaymentRequestDataDBResponse> payments = dao.findByRequestStatusInAndPaymentDateLessThan(status, localDateTimeNowPST, correlationId);
		payments.flatMap(paymentRequestDataDBResponse -> {
			Mono<Map<String, Object>> monoResultProcessAutoPayNotifiedPayment = processAutoPayNotifiedPayment(paymentRequestDataDBResponse, correlationId);
			return monoResultProcessAutoPayNotifiedPayment.flatMap(mapResultProcessAutoPay -> {
				Map<String, Object> parametersMethod = new HashMap<String, Object>();
				parametersMethod.put(PaymentConstants.MAP_RESULT_PROCESS_AUTOPAY, mapResultProcessAutoPay);
				parametersMethod.put(PaymentConstants.UUID_RECORD_NOTIFIED, listRecordsProcessed);
				parametersMethod.put(PaymentConstants.ERROR_RECORD_NOTIFIED, listRecordsError);
				parametersMethod.put(PaymentConstants.PAYMENT_REQUEST_DB_RESPONSE, paymentRequestDataDBResponse);
				parametersMethod.put(PaymentConstants.CORRELATION_ID, correlationId);
				if (mapResultProcessAutoPay.get(PaymentConstants.ERROR_PAYMENT_REQUEST_ID) != null)
					listErrorRecordsInserted.add((String) mapResultProcessAutoPay.get(PaymentConstants.ERROR_PAYMENT_REQUEST_ID));

				parameters.put(PaymentConstants.ERROR_PAYMENTS_LIST, listErrorRecordsInserted);
				return manageMapResultProcessAutoPay(parametersMethod);
			});
		}).collectList().flatMap(results -> {
			ProcessAutoPayNotifiedPaymentsMapper.mapParameterForSaveOrUpdatePaymentBatchEntity(parameters, listRecordsProcessed, listRecordsError);
			return paymentBatchDAO.saveOrUpdatePaymentBatchEntity(parameters, correlationId).flatMap(batchUpdated -> {
				return Mono.just(true);
			});
		}).subscribe();

		BatchProcessResponse batchProcessResponse = ProcessAutoPayNotifiedPaymentsMapper.mapBatchProcessResponseFromMapToProcessAutoPayNotifiedPayments(parameters);
		return Mono.just(batchProcessResponse);
	}

	private Mono<Map<String, Object>> processAutoPayNotifiedPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		return validateCreditCard(paymentRequestDataDBResponse, correlationId).flatMap(mapResultProcessAutoPay -> {
			String statusResult = (String) mapResultProcessAutoPay.get(PaymentConstants.STATUS);
			if (!AutopayNotifiedStatus.VALID.name().equals(statusResult)) {
				return Mono.just(mapResultProcessAutoPay);
			}

			JSONObject parameters = null;
			try {
				parameters = parseJsonString(paymentRequestDataDBResponse.getPaymentRequestData().asString(), correlationId);
			}
			catch (PaymentDataException e) {
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}

			Map<String, Object> inputParameters = getInputParametersForProcessAutopayNotified(paymentRequestDataDBResponse, parameters);

			return validExternalBankAccountAndCalculateAmountGetStatus(paymentRequestDataDBResponse, mapResultProcessAutoPay, inputParameters, correlationId);
		}).onErrorResume(err -> {
			Map<String, Object> mapResultProcessAutoPayError = new HashMap<String, Object>();
			mapResultProcessAutoPayError.put(PaymentConstants.STATUS, AutopayNotifiedStatus.ERROR.name());
			mapResultProcessAutoPayError.put(PaymentConstants.ERROR_RECORD_NOTIFIED, err);
			mapResultProcessAutoPayError.put(PaymentConstants.ERROR_PAYMENT_REQUEST_ID, paymentRequestDataDBResponse.getPaymentRequestId().toString());
			return Mono.just(mapResultProcessAutoPayError);
		});
	}

	private Mono<Map<String, Object>> validateCreditCardAndSendEmail(PaymentRequestDataDBResponse paymentRequestDataDBResponse, AccountDetailsResponse creditCardAccountOverviewResponse, String correlationId) {
		Map<String, Object> mapResultProcessAutoPay = new HashMap<String, Object>();
		return paymentRulesProcessor.isValidCReditCardAccountAndEmailCheck(creditCardAccountOverviewResponse, correlationId).flatMap(validCreditCardMap -> {
			if (validCreditCardMap.get("flag").equalsIgnoreCase("true")) {
				mapResultProcessAutoPay.put(PaymentConstants.STATUS, AutopayNotifiedStatus.INVALID_NO_NOTIFICATION.name());
				return autoPayDAO.deleteByCustomerIdAndCreditAccountId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey(),
						paymentRequestDataDBResponse.getAccountKey(), correlationId).flatMap(result -> {
							log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in validateCreditCard() with customerId: {} and creditAccountId: {}", correlationId,
									paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey(), paymentRequestDataDBResponse.getAccountKey());
							try {
								PaymentServiceRequest paymentServiceRequest = PaymentBatchMapper.fromPaymentRequestDataDBResponseToPaymentServiceRequest(paymentRequestDataDBResponse);
								if (validCreditCardMap.get("emailFlag").equalsIgnoreCase("true")) {
									return paymentProcessor.sendAutoPaymentNotification(paymentServiceRequest, correlationId, paymentRequestDataDBResponse.getPaymentRequestId())
											.flatMap(paymentCommunicationResponse -> {
												log.debug(PaymentConstants.LOG_PREFIX + "Response of sendAutoPaymentNotification(). response: {}", correlationId,
														paymentCommunicationResponse);
												return Mono.just(mapResultProcessAutoPay);
											});
								}
							}
							catch (ParseException e) {
								PaymentDataException paymentDataException = new PaymentDataException(e.getMessage());
								paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
								return Mono.error(paymentDataException);
							}
							return Mono.just(mapResultProcessAutoPay);
						});
			}
			if (!paymentRulesProcessor.isAutoPayEligible(creditCardAccountOverviewResponse)) {
				mapResultProcessAutoPay.put(PaymentConstants.STATUS, AutopayNotifiedStatus.INVALID_NO_NOTIFICATION.name());
			}
			else {
				mapResultProcessAutoPay.put(PaymentConstants.STATUS, AutopayNotifiedStatus.VALID.name());
			}
			return Mono.just(mapResultProcessAutoPay);
		});
	}

	private Mono<Map<String, Object>> validateCreditCard(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of validateCreditCard(): paymentRequestDataDBResponse: {}", correlationId, paymentRequestDataDBResponse);
		Map<String, Object> mapResultProcessAutoPay = new HashMap<String, Object>();
		AtomicReference<String> accountId = new AtomicReference<>("");
		String customerId = paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString();
		String creditAccountId = paymentRequestDataDBResponse.getAccountKey().toString();
		Mono<AccountDetailsResponse> monoCreditCardAccountOverviewResponse = externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId);
		return monoCreditCardAccountOverviewResponse.flatMap(creditCardAccountOverviewResponse -> {
			accountId.set(creditCardAccountOverviewResponse.getAccountId().toString());
			return validateCreditCardAndSendEmail(paymentRequestDataDBResponse, creditCardAccountOverviewResponse, correlationId).flatMap(resMp -> {
				return externalCallService.getAccountsFromExternalAccountsServiceByID(customerId, paymentRequestDataDBResponse.getExternalAccountKey().toString(), correlationId)
						.flatMap(bankAccountResponse -> {
							return updateMapResultProcessAutoPay(creditCardAccountOverviewResponse, bankAccountResponse, mapResultProcessAutoPay);
						});
			});
		}).flatMap(mapResult -> {
			return checkCeaseAndDesistFromCreditCardAccountsService(paymentRequestDataDBResponse, mapResultProcessAutoPay, creditAccountId, correlationId).flatMap(result -> {
				return Mono.just(mapResultProcessAutoPay);
			});
		}).flatMap(mapResult -> {
			Mono<Object> suppressedExtlBankAcctResponseMono = paymentProcessor.validateExternalAccountsSuppression(customerId, accountId.toString(), correlationId, PaymentType.ACH.name());
			return suppressedExtlBankAcctResponseMono.flatMap(suppressedExtlBankAcctRespMono -> {
				log.info("suppressedExtlBankAcctRespMono response :" + suppressedExtlBankAcctRespMono.toString());
				Mono<Boolean> delRecord = autoPayDAO.deleteByCustomerIdAndCreditAccountId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey(),
						paymentRequestDataDBResponse.getAccountKey(), correlationId);
				return delRecord.flatMap(res -> {
					try {
						PaymentServiceRequest paymentServiceRequest = PaymentBatchMapper.fromPaymentRequestDataDBResponseToPaymentServiceRequest(paymentRequestDataDBResponse);
						return paymentProcessor.sendAutoPaymentNotification(paymentServiceRequest, correlationId, paymentRequestDataDBResponse.getPaymentRequestId())
								.flatMap(paymentCommunicationResponse -> {
									log.debug(PaymentConstants.LOG_PREFIX + "Response of sendAutoPaymentNotification(). response: {}", correlationId, paymentCommunicationResponse);
									mapResultProcessAutoPay.put(PaymentConstants.STATUS, AutopayNotifiedStatus.VALID.name());
									return Mono.just(mapResultProcessAutoPay);
								});
					} catch (ParseException e) {
						log.error("Error in parsing ");
					}
					return Mono.just(mapResultProcessAutoPay);
				});
			}).onErrorResume(err -> {
				if (err instanceof PaymentDataNotFoundException) {
					log.debug(PaymentConstants.LOG_PREFIX + "Error Response when account is suppressed(). errResponse: {}", correlationId, err.getMessage());
				}
				return Mono.error(err);
			});
		});
	}

	private static Mono<Map<String, Object>> updateMapResultProcessAutoPay(AccountDetailsResponse creditCardAccountOverviewResponse, BankAccountResponse bankAccountResponse, Map<String, Object> mapResultProcessAutoPay) {
		String cardType = (creditCardAccountOverviewResponse.getDevice() != null) ? creditCardAccountOverviewResponse.getDevice().getNetwork() : "";
		String plasticDesignCode = (creditCardAccountOverviewResponse.getDevice() != null) ? creditCardAccountOverviewResponse.getDevice().getPlasticDesignCode() : "";
		String deliquencyFlag = String.valueOf(creditCardAccountOverviewResponse.getDeliquencyFlag());
		String externalBankName = bankAccountResponse.getBankName();
		String externalAccountType = bankAccountResponse.getAccountType();
		mapResultProcessAutoPay.put(PaymentConstants.CARD_TYPE, cardType);
		mapResultProcessAutoPay.put(PaymentConstants.PLASTIC_DESIGN_CODE, plasticDesignCode);
		mapResultProcessAutoPay.put(PaymentConstants.EXTERNAL_BANK_NAME, externalBankName);
		mapResultProcessAutoPay.put(PaymentConstants.EXT_ACCNT_TYPE, externalAccountType);
		mapResultProcessAutoPay.put(PaymentConstants.DELIQUENCY_FLAG, deliquencyFlag);
		return Mono.just(mapResultProcessAutoPay);
	}

	private Mono<Boolean> checkCeaseAndDesistFromCreditCardAccountsService(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapResultProcessAutoPay, String creditAccountId, String correlationId) {
		Mono<Boolean> accountSettingResponseBoolean = externalCallService.getCeaseAndDesistFromCreditCardAccountsService(creditAccountId, correlationId);
		return accountSettingResponseBoolean.flatMap(accountSettingResponse -> {
			log.info("SettingData in AccountSettingResponse : " + accountSettingResponse);
			if (accountSettingResponse) {
				return autoPayDAO.deleteByCustomerIdAndCreditAccountId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey(), paymentRequestDataDBResponse.getAccountKey(), correlationId)
						.flatMap(res -> {
							log.debug(PaymentConstants.LOG_PREFIX + "Record deleted in CeaseAndDesist section with customerId: {} and creditAccountId: {}", correlationId, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey(), creditAccountId);
							return Mono.just(accountSettingResponse);
						});
			}

			return Mono.just(accountSettingResponse);
		});
	}

	private Map<String, Object> getInputParametersForProcessAutopayNotified(PaymentRequestDataDBResponse paymentRequestDataDBResponse, JSONObject parameters) {
		Map<String, Object> inputParameters = new HashMap<String, Object>();
		inputParameters.put(PaymentConstants.CUSTOMER_ID, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString());
		inputParameters.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, paymentRequestDataDBResponse.getExternalAccountKey().toString());
		inputParameters.put(PaymentConstants.CREDIT_ACCOUNT_ID, paymentRequestDataDBResponse.getAccountKey().toString());
		inputParameters.put(PaymentConstants.CHANNEL, (String) parameters.get(PaymentConstants.CHANNEL));
		inputParameters.put(PaymentConstants.PAYMENT_METADATA, (JSONArray) parameters.get(PaymentConstants.PAYMENT_METADATA));
		inputParameters.put(PaymentConstants.PAYMENT_AMOUNT, PaymentMapper.convertObjectToBigDecimal((Object) parameters.get(PaymentConstants.PAYMENT_AMOUNT)));
		inputParameters.put(PaymentConstants.PAYMENT_MODE, (String) parameters.get(PaymentConstants.PAYMENT_MODE));

		return inputParameters;
	}

	private Mono<Map<String, Object>> validExternalBankAccountAndCalculateAmountGetStatus(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapResultProcessAutoPay, Map<String, Object> inputParameters, String correlationId) {
		return validExternalBankAccount(mapResultProcessAutoPay, inputParameters, correlationId).flatMap(mapResultProcessAutoPayValidationExternalAccount -> {
			String statusResult = (String) mapResultProcessAutoPayValidationExternalAccount.get(PaymentConstants.STATUS);
			if (!AutopayNotifiedStatus.VALID.name().equals(statusResult)) {
				return Mono.just(mapResultProcessAutoPayValidationExternalAccount);
			}

			JSONArray jsonArrayMetadata = (JSONArray) inputParameters.get(PaymentConstants.PAYMENT_METADATA);
			JSONObject firstNote = (JSONObject) jsonArrayMetadata.get(0);
			String paymentPurpose = (String) firstNote.get(PaymentConstants.PAYMENT_PURPOSE);
			inputParameters.put(PaymentConstants.AGENT_ID, firstNote.get(PaymentConstants.AGENT_ID));
			inputParameters.put(PaymentConstants.PAYMENT_MODE, firstNote.get(PaymentConstants.PAYMENT_MODE));
			Mono<Map<String, Object>> monoMapStatusAmount = calculateAmountGetStatus(paymentRequestDataDBResponse, paymentRequestDataDBResponse.getAccountKey().toString(),
					paymentPurpose, correlationId);
			return monoMapStatusAmount.flatMap(mapStatusPayment -> {
				if (mapStatusPayment.get(PaymentConstants.PAYMENT_AMOUNT) == null) {
					mapStatusPayment.put(PaymentConstants.PAYMENT_AMOUNT, inputParameters.get(PaymentConstants.PAYMENT_AMOUNT));
				}
				inputParameters.put(PaymentConstants.COLLECTION_INTENT, collectionIntentType);
				CollectionIntentRequest collectionIntentRequest = PaymentMapper.getCollectionIntentRequest(paymentRequestDataDBResponse,inputParameters, correlationId);
				return paymentProcessor.getCollectionIntentId(collectionIntentRequest, correlationId).flatMap(collectionIntentResponse -> {
					mapStatusPayment.put(PaymentConstants.COLLECTION_INTENT_ID, collectionIntentResponse.getCollectionIntentId());
					mapStatusPayment.put(PaymentConstants.CARD_TYPE, mapResultProcessAutoPay.get(PaymentConstants.CARD_TYPE));
					mapStatusPayment.put(PaymentConstants.PLASTIC_DESIGN_CODE, mapResultProcessAutoPay.get(PaymentConstants.PLASTIC_DESIGN_CODE));
					mapStatusPayment.put(PaymentConstants.EXTERNAL_BANK_NAME, mapResultProcessAutoPay.get(PaymentConstants.EXTERNAL_BANK_NAME));
					mapStatusPayment.put(PaymentConstants.EXT_ACCNT_TYPE, mapResultProcessAutoPay.get(PaymentConstants.EXT_ACCNT_TYPE));
					mapStatusPayment.put(PaymentConstants.DELIQUENCY_FLAG, mapResultProcessAutoPay.get(PaymentConstants.DELIQUENCY_FLAG));

					return dao.updatePaymentRequestEntityStatus(paymentRequestDataDBResponse, mapStatusPayment, correlationId).flatMap(paymentRequestId -> {
						mapResultProcessAutoPayValidationExternalAccount.put(PaymentConstants.UUID_RECORD_NOTIFIED, paymentRequestDataDBResponse.getPaymentRequestId());
						mapResultProcessAutoPayValidationExternalAccount.put(PaymentConstants.STATUS, AutopayNotifiedStatus.PROCESSED.name());
						return Mono.just(mapResultProcessAutoPayValidationExternalAccount);
					});
				});
			});
		});
	}

	private Mono<Map<String, Object>> validExternalBankAccount(Map<String, Object> mapResultProcessAutoPay, Map<String, Object> inputParameters, String correlationId) {
		String customerId = (String) inputParameters.get(PaymentConstants.CUSTOMER_ID);
		String externalAccountId = (String) inputParameters.get(PaymentConstants.EXTERNAL_ACCOUNT_ID);
		String channel = (String) inputParameters.get(PaymentConstants.CHANNEL);
		String creditAccountId = (String) inputParameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);

		Mono<AccountTokenResponse> monoAccountTokenResponse = externalCallService.getAccountTokenFromExternalBankAccounts(customerId, externalAccountId, channel, correlationId);
		return monoAccountTokenResponse.flatMap(accountTokenResponse -> {
			EwsPartnerRequest ewsPartnerRequest = PaymentMapper.mapEwsPartnerRequest(customerId, accountTokenResponse, channel);
			Mono<EwsGatewayResponse> monoEwsGatewayResponse = externalCallService.callEWSServicePartnerValidation(ewsPartnerRequest, correlationId);
			return monoEwsGatewayResponse.flatMap(ewsGatewayResponse -> {
				Map<String, Object> mapInput = new HashMap<String, Object>();
				mapInput.put(PaymentConstants.EWS_GATEWAY_RESPONSE, ewsGatewayResponse);
				mapInput.put(PaymentConstants.MAP_RESULT, mapResultProcessAutoPay);
				mapInput.put(PaymentConstants.CUSTOMER_ID, customerId);
				mapInput.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, externalAccountId);
				mapInput.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);
				mapInput.put(PaymentConstants.CORRELATION_ID, correlationId);
				mapInput.put(PaymentConstants.CHANNEL, channel);

				return processEwsGatewayResponseForValidateExternalBankAccount(mapInput, mapResultProcessAutoPay);
			});
		});
	}

	private Mono<Map<String, Object>> processEwsGatewayResponseForValidateExternalBankAccount(Map<String, Object> mapInput, Map<String, Object> mapResult) {
		return paymentRulesProcessor.validateEwsGatewayResponse(mapInput).flatMap(validatedEwsGatewayResponse -> {
			if (!validatedEwsGatewayResponse) {
				mapResult.put(PaymentConstants.STATUS, AutopayNotifiedStatus.INVALID_NO_NOTIFICATION.name());
				return Mono.just(mapResult);
			}

			mapResult.put(PaymentConstants.STATUS, AutopayNotifiedStatus.VALID.name());
			return Mono.just(mapResult);
		});
	}

	private Mono<Map<String, Object>> calculateAmountGetStatus(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String creditAccountId, String paymentPurpose, String correlationId) {
		return externalCallService.getAvailableCreditBalance(creditAccountId, correlationId).flatMap(creditCardAccountOverview -> {
			return handlePaymentPurpose(paymentRequestDataDBResponse, paymentPurpose, creditCardAccountOverview, correlationId);
		});
	}

	private JSONObject parseJsonString(String jsonString, String correlationId) {
		JSONParser parser = new JSONParser();
		try {
			return (JSONObject) parser.parse(jsonString);
		}
		catch (ParseException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
	}

	private Mono<Map<String, Object>> handlePaymentPurpose(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String paymentPurpose, AccountBalanceResponse accountBalanceResponse, String correlationId) {
		Map<String, Object> mapResult = new HashMap<String, Object>();

		if (PaymentMetadata.PaymentPurposeEnum.MINIMUM_PAYMENT.toString().equals(paymentPurpose)) {
			return handleMinimumPayment(paymentRequestDataDBResponse, accountBalanceResponse, correlationId);
		}
		else if (PaymentMetadata.PaymentPurposeEnum.STATEMENT_BALANCE.toString().equals(paymentPurpose)) {
			return handleStatementBalance(accountBalanceResponse);
		}
		else if (PaymentMetadata.PaymentPurposeEnum.OTHER.toString().equals(paymentPurpose)) {
			return handleOtherAmount(paymentRequestDataDBResponse, accountBalanceResponse, correlationId);
		}
		else {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_PURPOSE_IS_INVALID);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}
	}

	private Mono<Map<String, Object>> handleMinimumPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, AccountBalanceResponse accountBalanceResponse, String correlationId) {
		Map<String, Object> mapResult = new HashMap<String, Object>();

		double minimumPayment = accountBalanceResponse.getMinimumPayment().doubleValue();
		AtomicReference<String> status = new AtomicReference<>((String) (minimumPayment <= 0 ? PaymentStatus.NO_DUE.name() : PaymentStatus.SCHEDULE.name()));

		return getTotalPayments(paymentRequestDataDBResponse, accountBalanceResponse, correlationId).flatMap(totalPayments -> {
			double autoPayAmount = Math.max(0, minimumPayment - totalPayments);
			if (autoPayAmount == 0) {
				status.set(PaymentStatus.NO_DUE.name());
			} else {
				status.set(PaymentStatus.SCHEDULE.name());
				mapResult.put(PaymentConstants.PAYMENT_AMOUNT, BigDecimal.valueOf(autoPayAmount));
			}

			mapResult.put(PaymentConstants.STATUS, status.get());

			return Mono.just(mapResult);
		});
	}

	private Mono<Double> getTotalPayments(PaymentRequestDataDBResponse paymentRequestDataDBResponse, AccountBalanceResponse accountBalanceResponse, String correlationId) {
		ZonedDateTime lastStatementDate = accountBalanceResponse.getStatementDate().atStartOfDay(ZoneId.systemDefault());
		ZonedDateTime currentDate = ZonedDateTime.now();
		List<String> status = Arrays.asList(PaymentStatus.PROCESSED.name(), PaymentStatus.PENDING.name());

		Map<String, Object> getPaymentDates = new HashMap<String, Object>();
		getPaymentDates.put(PaymentConstants.LAST_STATEMENT_DATE, lastStatementDate);
		getPaymentDates.put(PaymentConstants.CURRENT_DATE, currentDate);
		getPaymentDates.put(PaymentConstants.ACCOUNT_KEY, paymentRequestDataDBResponse.getAccountKey());
		getPaymentDates.put(PaymentConstants.INDIVIDUAL_UNIQUE_IDENTIFIER_KEY, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());

		Flux<PaymentRequestDataDBResponse> responseFlux = dao.findPaymentsBetweenDates(getPaymentDates, status, correlationId);
		return responseFlux.collectList().flatMap(payments -> {
			if (payments.isEmpty()) {
				return Mono.just(Double.valueOf(0));
			}

			double totalPayments = payments.stream().map(payment -> {
				return parseJsonString(payment.getPaymentRequestData().asString(), correlationId);
			}).mapToDouble(paymentDataParams -> (paymentDataParams.containsKey(PaymentConstants.PAYMENT_AMOUNT) && paymentDataParams != null)
					? Double.parseDouble(paymentDataParams.get(PaymentConstants.PAYMENT_AMOUNT).toString())
					: 0).sum();

			return Mono.just(totalPayments);
		}).onErrorResume(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error Getting TotalPayments, error: {}", e.getMessage());
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_GETTING_FINAL_TOTAL_PAYMENT);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		});
	}

	private Mono<Map<String, Object>> handleStatementBalance(AccountBalanceResponse accountBalanceResponse) {
		Map<String, Object> mapResult = new HashMap<String, Object>();
		double currentBalance = accountBalanceResponse.getCurrentBalance().doubleValue();
		double statementBalance = accountBalanceResponse.getStatementBalance().doubleValue();

		double paymentAmount = Double.valueOf(0.0);

		AtomicReference<String> status = new AtomicReference<>((String) (PaymentStatus.SCHEDULE.name()));
		if (currentBalance < statementBalance) {
			paymentAmount = currentBalance;
		} else {
			paymentAmount = statementBalance;
		}

		if (currentBalance <= 0) {
			status.set(PaymentStatus.NO_DUE.name());
		}

		mapResult.put(PaymentConstants.PAYMENT_AMOUNT, BigDecimal.valueOf(paymentAmount));
		mapResult.put(PaymentConstants.STATUS, status.get());

		return Mono.just(mapResult);
	}

	private Mono<Map<String, Object>> handleOtherAmount(PaymentRequestDataDBResponse paymentRequestDataDBResponse, AccountBalanceResponse accountBalanceResponse, String correlationId) {
		Map<String, Object> mapResult = new HashMap<String, Object>();
		AtomicReference<String> status = new AtomicReference<>("");

		if (accountBalanceResponse.getCurrentBalance().compareTo(BigDecimal.valueOf(0)) <= 0) {
			status.set(PaymentStatus.NO_DUE.name());

			mapResult.put(PaymentConstants.STATUS, status);
			return Mono.just(mapResult);
		}

		JSONObject dataParams = parseJsonString(paymentRequestDataDBResponse.getPaymentRequestData().asString(), correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal((Object) dataParams.get(PaymentConstants.PAYMENT_AMOUNT));

		return getTotalPayments(paymentRequestDataDBResponse, accountBalanceResponse, correlationId).flatMap(totalPayments -> {
			double autoPayAmount = Math.max(0, paymentAmount.doubleValue() - totalPayments);

			if (autoPayAmount == 0) {
				status.set(PaymentStatus.NO_DUE.name());
			} else if (accountBalanceResponse.getCurrentBalance().doubleValue() < autoPayAmount) {
				status.set(PaymentStatus.SCHEDULE.name());
				mapResult.put(PaymentConstants.PAYMENT_AMOUNT, accountBalanceResponse.getCurrentBalance());
			} else {
				mapResult.put(PaymentConstants.PAYMENT_AMOUNT, BigDecimal.valueOf(autoPayAmount));
				status.set(PaymentStatus.SCHEDULE.name());
			}

			mapResult.put(PaymentConstants.STATUS, status);
			return Mono.just(mapResult);
		});
	}

	/**
	 * Mehtod to validate the result of the process for each notified record, to
	 * check if it was processed to schedule or no due, or did not passed
	 * validations and needs to be enrolled, or it sent and error and needs to be
	 * accounted that way
	 *
	 * @param parametersMethod
	 * @return Mono of Boolean True if no error registered
	 */

	private Mono<Boolean> manageMapResultProcessAutoPay(Map<String, Object> parametersMethod) {
		Map<String, Object> mapResultProcessAutoPay = (Map<String, Object>) parametersMethod.get(PaymentConstants.MAP_RESULT_PROCESS_AUTOPAY);
		List<UUID> listRecordsProcessed = (List<UUID>) parametersMethod.get(PaymentConstants.UUID_RECORD_NOTIFIED);
		List<UUID> listRecordsError = (List<UUID>) parametersMethod.get(PaymentConstants.ERROR_RECORD_NOTIFIED);
		PaymentRequestDataDBResponse paymentRequestDataDBResponse = (PaymentRequestDataDBResponse) parametersMethod.get(PaymentConstants.PAYMENT_REQUEST_DB_RESPONSE);
		String correlationId = (String) parametersMethod.get(PaymentConstants.CORRELATION_ID);

		String statusResult = (String) mapResultProcessAutoPay.get(PaymentConstants.STATUS);
		if (AutopayNotifiedStatus.PROCESSED.name().equals(statusResult)) {
			processSuccessfulRecord(listRecordsProcessed, mapResultProcessAutoPay);
		} else if (AutopayNotifiedStatus.ERROR.name().equals(statusResult)) {
			processErrorRecord(listRecordsError, paymentRequestDataDBResponse.getPaymentRequestId(), mapResultProcessAutoPay, correlationId);
		} else if (AutopayNotifiedStatus.INVALID_NOTIFICATION.name().equals(statusResult)) {
			processInvalidRecordWithNotification(paymentRequestDataDBResponse, mapResultProcessAutoPay, listRecordsProcessed, correlationId);
		} else if (AutopayNotifiedStatus.INVALID_NO_NOTIFICATION.name().equals(statusResult)) {
			processInvalidRecordWithoutNotification(paymentRequestDataDBResponse, mapResultProcessAutoPay, listRecordsProcessed, correlationId);
		}

		return Mono.just(true);
	}

	private void processSuccessfulRecord(List<UUID> listRecordsInserted, Map<String, Object> mapResultProcessAutoPay) {
		listRecordsInserted.add((UUID) mapResultProcessAutoPay.get(PaymentConstants.UUID_RECORD_NOTIFIED));
	}

	private void processErrorRecord(List<UUID> listRecordsError, UUID errorRecord, Map<String, Object> mapResultProcessAutoPay, String correlationId) {
		listRecordsError.add(errorRecord);
		Throwable err = (Throwable) mapResultProcessAutoPay.get(PaymentConstants.ERROR_RECORD_NOTIFIED);
		String error = "Error Scheduling Notified Autopay Payment, Error: " + err.getMessage();
		log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
	}

	private void processInvalidRecordWithNotification(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapResultProcessAutoPay, List<UUID> listRecordsProcessed, String correlationId) {
		processSuccessfulRecord(listRecordsProcessed, mapResultProcessAutoPay);
		dao.updatePaymentRequestEntityStatus(PaymentStatus.PAYMENT_ACCOUNT_VERIFICATION_FAILED.name(), paymentRequestDataDBResponse.getPaymentRequestId(), correlationId)
				.flatMap(paymentRequestId -> {
					return autoPayConfigurationProcessor.disableAutoPayConfiguration(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString(),
							paymentRequestDataDBResponse.getAccountKey().toString(), true, correlationId);
				}).subscribe();
	}

	private void processInvalidRecordWithoutNotification(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapResultProcessAutoPay, List<UUID> listRecordsProcessed, String correlationId) {
		processSuccessfulRecord(listRecordsProcessed, mapResultProcessAutoPay);
		dao.updatePaymentRequestEntityStatus(PaymentStatus.PAYMENT_ACCOUNT_VERIFICATION_FAILED.name(), paymentRequestDataDBResponse.getPaymentRequestId(), correlationId)
				.flatMap(paymentRequestId -> {
					return autoPayConfigurationProcessor.disableAutoPayConfiguration(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString(),
							paymentRequestDataDBResponse.getAccountKey().toString(), false, correlationId);
				}).subscribe();
	}
}