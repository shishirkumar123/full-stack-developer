package com.creditone.ucrm.payments.processor;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dao.PaymentCommunicationMapper;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.validation.PaymentCommunicationValidator;
import com.ucrm.swagger.communicationhuapiservice.model.EnterpriseCommunicationrequest;
import com.ucrm.swagger.communicationhuapiservice.model.EnterpriseCommunicationresponse;
import com.ucrm.swagger.creditcardaccountservice.model.EmailResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class PaymentCommunicationProcessor {
	private PaymentDAO dao;
	private ExternalCallService externalCallService;
	private String mapCommunicationTypePath;

	public PaymentCommunicationProcessor(PaymentDAO dao, ExternalCallService externalCallService,
			@Value(value = "${communication.mapCommunicationType.path}") String mapCommunicationTypePath) {
		this.dao = dao;
		this.externalCallService = externalCallService;
		this.mapCommunicationTypePath = mapCommunicationTypePath;
	}

	public Mono<PaymentCommunicationResponse> paymentCommunication(PaymentCommunicationRequest paymentCommunicationRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of paymentCommunication(). paymentCommunicationRequest: {}", correlationId, paymentCommunicationRequest);
		Mono<PaymentCommunicationDetailsRequest> monoPaymentCommunicationDetailsRequest = getPaymentCommunicationDetailsRequest(paymentCommunicationRequest, correlationId);

		return monoPaymentCommunicationDetailsRequest.flatMap(paymentCommunicationDetailsRequest -> {
			return getCommunicationEmail(paymentCommunicationRequest, paymentCommunicationDetailsRequest, correlationId).flatMap(paymentCommunicationDetailsRequestwithEmail->{
						try {
							PaymentCommunicationValidator.validate(paymentCommunicationDetailsRequestwithEmail, paymentCommunicationRequest.getCommunicationIntent());
						}
						catch (PaymentDataException e) {
							String error = "Error Validating PaymentCommunicationDetailsRequest: " + e.getMessage();
							log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
							ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_COMMUNICATION_HUB_UNAVAILABLE_RESPONSE);
							serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
							return Mono.error(serviceUnavailableException);
						}

						return processPaymentCommunicationDetailsRequest(paymentCommunicationRequest, paymentCommunicationDetailsRequestwithEmail, correlationId);
					});
		}).onErrorResume(err -> {
			return getErrorResponse();
		});
	}

	private Mono<PaymentCommunicationDetailsRequest> getPaymentCommunicationDetailsRequest(PaymentCommunicationRequest paymentCommunicationRequest, String correlationId) {
		if (paymentCommunicationRequest.getPaymentCommunicationDetailsRequest() == null) {
			if (paymentCommunicationRequest.getCommunicationIntent() == PaymentCommunicationIntent.PAYMENT_RETURNED) {
				String error = PaymentErrors.ERROR_COMMUNICATION_INTENT_PAYMENT_RETURNED_WITHOUT_PROVIDED_COMMUNICATION_DETAILS;
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_COMMUNICATION_HUB_UNAVAILABLE_RESPONSE);
				serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
				return Mono.error(serviceUnavailableException);
			}
			return fillPaymentCommunicationDetailsRequest(paymentCommunicationRequest, correlationId);
		}
		else {
			PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = paymentCommunicationRequest.getPaymentCommunicationDetailsRequest();
			return Mono.just(paymentCommunicationDetailsRequest);
		}
	}

	public Mono<PaymentCommunicationDetailsRequest> fillPaymentCommunicationDetailsRequest(PaymentCommunicationRequest paymentCommunicationRequest, String correlationId) {
		Mono<Map<String, Object>> monoParametersDatabase = getParametersFromTable(paymentCommunicationRequest.getPaymentRequestId(), correlationId);
		return monoParametersDatabase.flatMap(parametersDatabase -> {
			String customerId = ((UUID) parametersDatabase.get(PaymentConstants.CUSTOMER_ID_PARAM)).toString();
			String creditAccountId = ((UUID) parametersDatabase.get(PaymentConstants.CREDIT_ACCOUNT_ID)).toString();

			Mono<EntityModelIndividualCoreIdentityResponse> monoEntityModelIndividualCoreIdentity = externalCallService.getCustomerDetailFromCIAM(customerId, correlationId);
			return monoEntityModelIndividualCoreIdentity.flatMap(entityModelIndividualCoreIdentity -> {
				return externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId)
						.flatMap(creditCardDetailsResponse -> {
							Map<String, Object> parametersValidation = new HashMap<>();
							parametersValidation.put(PaymentConstants.PARAMETERS_DATABASE, parametersDatabase);
							parametersValidation.put(PaymentConstants.PAYMENT_COMMUNICATION_INTENT, paymentCommunicationRequest.getCommunicationIntent());
							parametersValidation.put(PaymentConstants.ENTITY_MODEL_INDIVIDUAL_CORE_IDENTITY, entityModelIndividualCoreIdentity);
							parametersValidation.put(PaymentConstants.CREDITCARD_DETAILS_RESPONSE, creditCardDetailsResponse);
							parametersValidation.put(PaymentConstants.CUSTOMER_ID_PARAM, customerId);
							parametersValidation.put(PaymentConstants.CREDIT_ACCOUNT_ID, creditAccountId);

							return mapPaymentCommunicationDetailsRequestFromDatabase(parametersValidation, correlationId);
						});

			});
		});
	}

	private Mono<Map<String, Object>> getParametersFromTable(UUID paymentRequestId, String correlationId) {
		Map<String, Object> mapResult = new HashMap<String, Object>();

		Mono<PaymentRequestDataDBResponse> monoPaymentRequestDataDBResponse = dao
				.findByPaymentRequestId(paymentRequestId, correlationId);
		return monoPaymentRequestDataDBResponse.flatMap(paymentRequestDataDBResponse -> {
			try {
				fillParametersFromDatabaseResponse(mapResult, paymentRequestDataDBResponse);
			}
			catch (ParseException e) {
				log.error(PaymentConstants.LOG_PREFIX + "Error parsing json: {}", correlationId, e.toString());
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}

			return Mono.just(mapResult);
		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error getting record database: {}", correlationId,
					err.getMessage());
			return Mono.error(err);
		});
	}

	public void fillParametersFromDatabaseResponse(Map<String, Object> mapResult, PaymentRequestDataDBResponse paymentRequestDataDBResponse) throws ParseException {
		mapResult.put(PaymentConstants.CUSTOMER_ID_PARAM, paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
		mapResult.put(PaymentConstants.CREDIT_ACCOUNT_ID, paymentRequestDataDBResponse.getAccountKey());

		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		mapResult.put(PaymentConstants.PAYMENTAMOUNT,PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT)));
		if (paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION) != null) {
			mapResult.put(PaymentConstants.REFERENCENUM, (String) paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION));
		}

		mapResult.put(PaymentConstants.PAYMENTDATE, paymentRequestDataDBResponse.getPaymentDate());
	}

	private Mono<PaymentCommunicationDetailsRequest> mapPaymentCommunicationDetailsRequestFromDatabase(
			Map<String, Object> parametersValidation, String correlationId) {
		try {
			PaymentCommunicationValidator.validateFromDatabaseAndRequest(parametersValidation);
		}
		catch (PaymentDataException e) {
			String error = "Error on parameters to build PaymentCommunicationDetailsRequest, error: {errorMessage}".replace("{errorMessage}", e.getMessage());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_COMMUNICATION_HUB_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		}

		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = PaymentCommunicationMapper.mapPaymentCommunicationDetailsRequestFromDatabase(parametersValidation);

		return Mono.just(paymentCommunicationDetailsRequest);
	}

	private Mono<PaymentCommunicationResponse> getErrorResponse() {
		PaymentCommunicationResponse paymentCommunicationResponse = new PaymentCommunicationResponse();
		paymentCommunicationResponse.setCommunicationStatus(PaymentConstants.FAILURE);
		return Mono.just(paymentCommunicationResponse);
	}
	private Mono<PaymentCommunicationDetailsRequest> getCommunicationEmail(
			PaymentCommunicationRequest paymentCommunicationRequest,
			PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, String correlationId) {
			long startTime = System.nanoTime();
			Flux<EmailResponse> emailDataResponse = externalCallService.getCommunicationEmailId(paymentCommunicationDetailsRequest, correlationId);
			log.info(PaymentConstants.LOG_PREFIX + "response of paymentCommunication(). paymentCommunicationResponse: {}", correlationId, emailDataResponse);
			long endTime = System.nanoTime();
			long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
			log.debug("Time Taken for  getCommunicationEmail  in Milliseconds:  " + elapsedTime);
			Mono<String>  emailAddress= emailDataResponse.filter(email->email.getPriority().equalsIgnoreCase("PRIMARY")).next().map(email->email.getEmailData().getEmailAddress());
			return emailAddress.flatMap(email -> {
				log.info(PaymentConstants.LOG_PREFIX + "response of paymentCommunication(). email: {}", correlationId, email);
				paymentCommunicationDetailsRequest.setEmailAddress(email);
				return Mono.just(paymentCommunicationDetailsRequest);
			});
	}
	private Mono<PaymentCommunicationResponse> processPaymentCommunicationDetailsRequest(PaymentCommunicationRequest paymentCommunicationRequest, PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, String correlationId) {
		Mono<Map<String, Object>> monoMapCommunicationType = getMonoMapCommunicationType(paymentCommunicationRequest, paymentCommunicationDetailsRequest, correlationId);
		return monoMapCommunicationType.flatMap(mapCommunicationType -> {
			Map<String, Object> parameters = PaymentCommunicationMapper.mapCommunicationValues(paymentCommunicationDetailsRequest, paymentCommunicationRequest.getCommunicationIntent());

			List<String> listCommunicationAttributes = (List<String>) mapCommunicationType.get(PaymentConstants.COMMUNICATION_ATTRIBUTES);
			String templateId = (String) mapCommunicationType.get(PaymentConstants.COMMUNICATION_TEMPLATE);

			String messageData = buildMessageData(listCommunicationAttributes, parameters);
			EnterpriseCommunicationrequest enterpriseCommunicationrequest = PaymentCommunicationMapper.mapEnterpriseCommunicationrequest(paymentCommunicationDetailsRequest.getEmailAddress(),
					paymentCommunicationDetailsRequest.getCustomerId().toString(), messageData);

			Mono<EnterpriseCommunicationresponse> monoEnterpriseCommunicationresponse = externalCallService.getEnterpriseCommunicationresponseFromCommunicationHubApi(enterpriseCommunicationrequest, templateId, correlationId);
			return monoEnterpriseCommunicationresponse.flatMap(enterpriseCommunicationresponse -> {
				log.info(PaymentConstants.LOG_PREFIX + "response of paymentCommunication(). paymentCommunicationResponse: {}", correlationId, enterpriseCommunicationresponse);
				return getSuccessResponse(enterpriseCommunicationresponse.getRequestId(), correlationId);
			});
		});
	}

	private Mono<Map<String, Object>> getMonoMapCommunicationType(PaymentCommunicationRequest paymentCommunicationRequest, PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, String correlationId) {
		Map<String, Object> mapCommunicationType = null;
		try {
			mapCommunicationType = getMapCommunicationType(paymentCommunicationRequest.getCommunicationIntent(), correlationId);
		}
		catch (IOException e) {
			String error = "Error Reading Map Communication Type, customerId: " + paymentCommunicationDetailsRequest.getCustomerId().toString() + ", error: " + e.getMessage();
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			return Mono.error(new PaymentDataException(error));
		}
		catch (ParseException ex) {
			String error = "Error Reading Map Communication Type, customerId: " + paymentCommunicationDetailsRequest.getCustomerId().toString() + ", error: " + ex.toString();

			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			return Mono.error(new PaymentDataException(error));
		}

		if (mapCommunicationType == null) {
			String error = PaymentErrors.ERROR_MAP_COMMUNICATION_TYPE_NOT_FOUND.replace("{customerId}", paymentCommunicationDetailsRequest.getCustomerId().toString());
			error = error.replace("{communicationIntent}", paymentCommunicationRequest.getCommunicationIntent().name());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			return Mono.error(new PaymentDataException(error));
		}

		return Mono.just(mapCommunicationType);
	}

	public Map<String, Object> getMapCommunicationType(PaymentCommunicationIntent paymentCommunicationIntent, String correlationId) throws IOException, ParseException {
		log.info(PaymentConstants.LOG_PREFIX + "Request to getMapCommunicationType, communicationIntent: {}", correlationId, paymentCommunicationIntent);

		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(mapCommunicationTypePath);
		String jsonString = new String(is.readAllBytes(), "UTF-8");
		JSONParser parser = new JSONParser();
		JSONArray jsonArray = (JSONArray) parser.parse(jsonString);

		List<Map<String, Object>> listMaps = fillJsonArray(jsonArray);

		Optional<Map<String, Object>> optMap = listMaps.stream()
				.filter(m -> ((String) m.get(PaymentConstants.COMMUNICATION_INTENT))
						.equalsIgnoreCase(paymentCommunicationIntent.name()))
				.findFirst();
		Map<String, Object> mapResult = optMap.isPresent() ? optMap.get() : null;
		log.info(PaymentConstants.LOG_PREFIX + "Response to getMapCommunicationType, mapResult: {}", correlationId, mapResult);

		return mapResult;
	}

	private List<Map<String, Object>> fillJsonArray(JSONArray jsonArray) {
		List<Map<String, Object>> listMaps = new ArrayList<Map<String, Object>>();

		JSONObject jsonObject = null;
		Map<String, Object> mapRow = null;
		List<String> listAttributes = null;

		JSONArray jsonArrayAttributes = null;

		for (int i = 0; i < jsonArray.size(); i++) {
			mapRow = new HashMap<String, Object>();
			listAttributes = new ArrayList<String>();
			jsonObject = (JSONObject) jsonArray.get(i);

			jsonArrayAttributes = (JSONArray) jsonObject.get("communication_attributes");
			for (int j = 0; j < jsonArrayAttributes.size(); j++) {
				listAttributes.add((String) jsonArrayAttributes.get(j));
			}

			mapRow.put(PaymentConstants.COMMUNICATION_TEMPLATE, (String) jsonObject.get("communication_template"));
			mapRow.put(PaymentConstants.COMMUNICATION_ATTRIBUTES, listAttributes);
			mapRow.put(PaymentConstants.COMMUNICATION_INTENT, (String) jsonObject.get("communication_intent"));

			listMaps.add(mapRow);
		}

		return listMaps;
	}

	public String buildMessageData(List<String> listCommunicationAttributes, Map<String, Object> parameters) {
		StringBuffer result = new StringBuffer("[{");
		if (listCommunicationAttributes.size() > 0) {
			result.append("\"" + listCommunicationAttributes.get(0) + "\":\""
					+ (String) parameters.get(listCommunicationAttributes.get(0)) + "\"");
		}

		for (int i = 1; i < listCommunicationAttributes.size(); i++) {
			if (parameters.get(listCommunicationAttributes.get(i)) != null) {
				if (listCommunicationAttributes.get(i).equalsIgnoreCase(PaymentConstants.TRANSACTIONAMOUNT)
						|| listCommunicationAttributes.get(i).equalsIgnoreCase(PaymentConstants.OTHERAMOUNT)) {
					result.append(",\"" + listCommunicationAttributes.get(i) + "\":\""
							+ (BigDecimal) parameters.get(listCommunicationAttributes.get(i)) + "\"");
				} else if(listCommunicationAttributes.get(i).equalsIgnoreCase(PaymentConstants.PAYMENTAMOUNT)){
					result.append(",\"" + listCommunicationAttributes.get(i) + "\":\""
							+ (BigDecimal) parameters.get(listCommunicationAttributes.get(i)) + "\"");
				}else {
					result.append(",\"" + listCommunicationAttributes.get(i) + "\":\""
							+ (String) parameters.get(listCommunicationAttributes.get(i)) + "\"");
				}
			}
		}

		result.append("}]");

		return result.toString();
	}

	private Mono<PaymentCommunicationResponse> getSuccessResponse(String communicationRequestId, String correlationId) {
		PaymentCommunicationResponse paymentCommunicationResponse = new PaymentCommunicationResponse();
		paymentCommunicationResponse.setCommunicationStatus(PaymentConstants.SUCCESS);
		paymentCommunicationResponse.setCommunicationRequestId(communicationRequestId);

		log.info(PaymentConstants.LOG_PREFIX + "Response of paymentCommunication(). paymentCommunicationResponse: {}", correlationId, paymentCommunicationResponse);

		return Mono.just(paymentCommunicationResponse);
	}
}