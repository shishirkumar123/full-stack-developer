package com.creditone.ucrm.payments.processor;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.AutoPayDAO;
import com.creditone.ucrm.payments.dao.AutoPayMapper;
import com.creditone.ucrm.payments.dao.PaymentBatchDAO;
import com.creditone.ucrm.payments.dao.PaymentBatchMapper;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dto.AutoPayDBResponse;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsInvolvementResponse;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class NotifyAutopayProcessor {
	private PaymentDAO dao;
	private PaymentBatchDAO paymentBatchDAO;
	private AutoPayDAO autoPayDAO;
	private PaymentCommunicationProcessor paymentCommunicationProcessor;
	private ExternalCallService externalCallService;
	String autopayNotifyDays;
	private String paymentZoneId;

	public NotifyAutopayProcessor(PaymentDAO dao, AutoPayDAO autoPayDAO, PaymentBatchDAO paymentBatchDAO, PaymentCommunicationProcessor paymentCommunicationProcessor,
			ExternalCallService externalCallService, @Value(value = "${autopay.notify.days}") String autopayNotifyDays, @Value(value = "${payment.zoneId}") String paymentZoneId) {
		this.dao = dao;
		this.paymentBatchDAO = paymentBatchDAO;
		this.autoPayDAO = autoPayDAO;
		this.autopayNotifyDays = autopayNotifyDays;
		this.paymentCommunicationProcessor = paymentCommunicationProcessor;
		this.externalCallService = externalCallService;
		this.paymentZoneId = paymentZoneId;
	}

	/**
	 * This method reads the autopayconfigurations and validate if it is 10 days
	 * before the configuration applicable date. If it is sends a notification to
	 * customer and saves the record in payment table with auto_paid notified status
	 * 
	 * @param parameters
	 * @param correlationId
	 * @return a Mono Boolean with value true
	 */
	public Mono<Boolean> notifyAutoPayConfiguredPayments(Map<String, Object> parameters, String correlationId) {
		List<UUID> listRecordsInserted = new ArrayList<UUID>();
		List<String> listErrorRecordsInserted = new ArrayList<String>();
		ZonedDateTime currentDayTime = PaymentUtil.zoneByIdToUTCTimeNow(paymentZoneId);
		ZonedDateTime notifyingDateTime = currentDayTime.plusDays(Integer.valueOf(autopayNotifyDays));
		ZonedDateTime paymentDateEnd = notifyingDateTime.withHour(0).withMinute(0).withSecond(0).withNano(0).plusDays(1);
		ZonedDateTime paymentDateStart = notifyingDateTime.withHour(23).withMinute(59).withSecond(59).withNano(9).minusDays(1);
		Integer notifiedDay = notifyingDateTime.getDayOfMonth();
		Flux<PaymentRequestDataDBResponse> autoPayNotifiedPaymentrequests = dao.findAutoPayPaymentsToNotified(List.of(PaymentStatus.AUTOPAY_NOTIFIED.name()), paymentDateStart,
				paymentDateEnd, correlationId);
		Mono<List<UUID>> creditAccountIdListMono = autoPayNotifiedPaymentrequests.flatMap(paymentRequestData -> {
			return Mono.just(paymentRequestData.getAccountKey());
		}).collectList().flatMap(Mono::just);

		return creditAccountIdListMono.flatMap(creditAccountIdList -> {
			Flux<AutoPayDBResponse> fluxAutoPayDBResponse = autoPayDAO.findByAutoPaymentDay(creditAccountIdList, notifiedDay, correlationId);
			return fluxAutoPayDBResponse.flatMap(autoPayDBResponse -> {
				Mono<Map<String, Object>> monoResultProcessAutoPay = processAutoPay(autoPayDBResponse, correlationId);
				return monoResultProcessAutoPay.flatMap(mapResultProcessAutoPay -> {
					boolean recordSuccessful = (Boolean) mapResultProcessAutoPay.get(PaymentConstants.RECORD_SUCCESSFUL_TO_NOTIFY);
					if (recordSuccessful) {
						processSuccessfulRecord(listRecordsInserted, mapResultProcessAutoPay);
					} else {
						processErrorRecord(mapResultProcessAutoPay, listErrorRecordsInserted, correlationId);
					}

					return Mono.just(true);
				});
			}).collectList().flatMap(results -> {
				parameters.put(PaymentConstants.PROCESS_COUNT, listRecordsInserted.size());
				parameters.put(PaymentConstants.ERROR_COUNT, results.size() - listRecordsInserted.size());
				parameters.put(PaymentConstants.END_TIME, ZonedDateTime.now());
				parameters.put(PaymentConstants.STATUS, PaymentBatchMapper.getBatchProcessingStatus(listRecordsInserted.size(), results.size() - listRecordsInserted.size()));
				parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, listRecordsInserted);
				parameters.put(PaymentConstants.ERROR_PAYMENTS_LIST, listErrorRecordsInserted);

				return paymentBatchDAO.saveOrUpdatePaymentBatchEntity(parameters, correlationId).flatMap(batchUpdated -> {
					return Mono.just(true);
				});
			});
		});

	}

	/**
	 * Method to validate if the record should be notified, send the notification
	 * and save the record, and return metadata of the result to be reported in the
	 * batch result
	 * 
	 * @param autoPayDBResponse
	 * @param correlationId
	 * @return Mono of Map with flags if record was valid to notify, result of
	 *         notification if applies, uuid of the record inserted or the error
	 *         thrown
	 */
	private Mono<Map<String, Object>> processAutoPay(AutoPayDBResponse autoPayDBResponse, String correlationId) {
		Map<String, Object> mapResult = new HashMap<String, Object>();
		Mono<UUID> monoRecordNotified = processNotifyAutopayPayment(autoPayDBResponse, correlationId);
		return monoRecordNotified.flatMap(uuidRecordNotified -> {
			mapResult.put(PaymentConstants.UUID_RECORD_NOTIFIED, uuidRecordNotified);
			mapResult.put(PaymentConstants.RECORD_SUCCESSFUL_TO_NOTIFY, true);
			return Mono.just(mapResult);
		}).onErrorResume(err -> {
			List<String> errorMsgList = Arrays.stream(err.getMessage().split(":")).toList();
			mapResult.put(PaymentConstants.ERROR_PAYMENT_REQUEST_ID, errorMsgList.get(1));
			mapResult.put(PaymentConstants.ERROR_RECORD_NOTIFIED, err);
			mapResult.put(PaymentConstants.RECORD_SUCCESSFUL_TO_NOTIFY, false);
			return Mono.just(mapResult);
		});
	}

	/**
	 * Method to process the validated configured autopay configuration record. It
	 * will get amount that should be recorded, save the record, send the
	 * notification and return the uuid of the inserted record
	 * 
	 * @param autoPayDBResponse
	 * @param correlationId
	 * @return a Mono with the UUID of the payment record inserted with status
	 *         notified_autopay
	 */
	private Mono<UUID> processNotifyAutopayPayment(AutoPayDBResponse autoPayDBResponse, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject autoPayDBData = null;
		try {
			autoPayDBData = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX, "Error Parsing autoPayDBData: " + e.toString() + ", on record {}", correlationId, autoPayDBResponse.getAutoPayId().toString());
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		String paymentPurpose = (String) autoPayDBData.get(PaymentConstants.PAYMENT_PURPOSE);
		BigDecimal paymentAmountConfigured = PaymentMapper.convertObjectToBigDecimal((Object) autoPayDBData.get(PaymentConstants.PAYMENT_AMOUNT));

		ZonedDateTime zonedDateTime = PaymentUtil.getZonedDateTimeWithOffsetDays(Long.valueOf(autopayNotifyDays));

		Mono<BigDecimal> monoPaymentAmount = getPaymentAmount(autoPayDBResponse.getCreditAccountId().toString(), paymentPurpose, paymentAmountConfigured, correlationId);
		return monoPaymentAmount.flatMap(paymentAmountValidated -> {
			Map<String, Object> parametersForProcessNotifyAutopayPayment = null;
			try {
				parametersForProcessNotifyAutopayPayment = PaymentBatchMapper.fillParametersForProcessNotifyAutopayPayment(autoPayDBResponse, zonedDateTime, paymentAmountValidated,
						correlationId);
			} catch (ParseException e) {
				log.error("Error Parsing autoPayDBData: " + e.toString());
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}

			return saveNotifyAutopayPayment(parametersForProcessNotifyAutopayPayment, correlationId);
		});
	}

	private void processSuccessfulRecord(List<UUID> listRecordsInserted, Map<String, Object> mapResultProcessAutoPay) {
		listRecordsInserted.add((UUID) mapResultProcessAutoPay.get(PaymentConstants.UUID_RECORD_NOTIFIED));
	}

	private void processErrorRecord(Map<String, Object> mapResultProcessAutoPay, List<String> listErrorRecordsInserted, String correlationId) {
		listErrorRecordsInserted.add((String) mapResultProcessAutoPay.get(PaymentConstants.ERROR_PAYMENT_REQUEST_ID));
		Throwable err = (Throwable) mapResultProcessAutoPay.get(PaymentConstants.ERROR_RECORD_NOTIFIED);
		String error = "Error Notifying AutoPay Payment, Error: " + err.getMessage();
		log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
	}

	/**
	 * Method to save and notify autopayPayment
	 * 
	 * @param parametersForProcessNotifyAutopayPayment
	 * @param correlationId
	 * @return Mono of UUID of the record payment inserted in database
	 */
	private Mono<UUID> saveNotifyAutopayPayment(Map<String, Object> parametersForProcessNotifyAutopayPayment, String correlationId) {
		Mono<UUID> monoSavedRecord = dao.saveNotifiedPayment(parametersForProcessNotifyAutopayPayment);
		return monoSavedRecord.flatMap(paymentRequestId -> {
			PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parametersForProcessNotifyAutopayPayment.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
			String customerId = paymentServiceRequest.getCustomerId();
			Mono<EntityModelIndividualCoreIdentityResponse> monoEntityModelIndividualCoreIdentity = externalCallService.getCustomerDetailFromCIAM(customerId, correlationId);
			return monoEntityModelIndividualCoreIdentity.flatMap(entityModelIndividualCoreIdentity -> {
				parametersForProcessNotifyAutopayPayment.put(PaymentConstants.FIRST_NAME, entityModelIndividualCoreIdentity.getFirstName());
				parametersForProcessNotifyAutopayPayment.put(PaymentConstants.LAST_NAME, entityModelIndividualCoreIdentity.getLastName());

				return fillCreditAccountDataNotifyAutopay(parametersForProcessNotifyAutopayPayment, paymentRequestId, correlationId);
			});
		});
	}

	private Mono<UUID> fillCreditAccountDataNotifyAutopay(Map<String, Object> parametersForProcessNotifyAutopayPayment, UUID paymentRequestId, String correlationId) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parametersForProcessNotifyAutopayPayment.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		String creditAccountId = paymentServiceRequest.getCreditAccountId();

		return externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId).flatMap(accountDetailsResponse -> {
			parametersForProcessNotifyAutopayPayment.put(PaymentConstants.CARD_LAST4, accountDetailsResponse.getDevice().getDeviceLast4());
			parametersForProcessNotifyAutopayPayment.put(PaymentConstants.CARD_TYPE, accountDetailsResponse.getDevice().getNetwork());

			if (accountDetailsResponse.getAccountInvolvements() == null) {
				return Mono.error(new PaymentDataException("Not AccountInvolvements Found to Send email"));
			}

			Optional<AccountsInvolvementResponse> optAccountInvolvement = accountDetailsResponse.getAccountInvolvements().stream()
					.filter(account -> account.getAccountInvolvementType() != null && "PRIMARY".equalsIgnoreCase(account.getAccountInvolvementType())).findFirst();
			if (optAccountInvolvement.isEmpty()) {
				return Mono.error(new PaymentDataException("Not Involvment Id Found to Send email"));
			}
			String involvementId = optAccountInvolvement.get().getInvolvementId().toString();
			parametersForProcessNotifyAutopayPayment.put(PaymentConstants.INVOLVEMENT_ID, involvementId);

			PaymentCommunicationRequest paymentCommunicationRequest = PaymentBatchMapper.mapPaymentCommunicationRequestForNotifyAutoPay(paymentRequestId);
			PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = AutoPayMapper
					.getNotifyAutoPayCommunicationDetailsRequest(parametersForProcessNotifyAutopayPayment);
			paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
			Mono<PaymentCommunicationResponse> monoPaymentCommunicationResponse = paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId);
			return monoPaymentCommunicationResponse.flatMap(paymentCommunicationResponse -> {
				return Mono.just(paymentRequestId);
			});
		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error sending notification autopay: " + err.getMessage(), correlationId);
			if (err.getMessage().equals(PaymentErrors.ERROR_NOT_CREDIT_CARD_ACCOUNT_FOUND)) {
				return dao.updateNotifiedPayment(paymentRequestId, PaymentStatus.AUTO_PAY_ERROR.name(), correlationId).flatMap(recordUpdated -> {
					return Mono.error(new PaymentDataException("No Credit Account Found when Sending Notification for Payment Request: " + paymentRequestId));
				});
			} else {
				return Mono.just(paymentRequestId);
			}
		});
	}

	/**
	 * This Method will receive the credit accountId configured and Payment Purpose
	 * and paymentAmount Configured, and according to those data and if any
	 * validation required return the correct payment amount
	 * 
	 * @param creditAccountId
	 * @param paymentPurpose
	 * @param paymentAmountConfigured
	 * @param correlationId
	 * @return Mono of the double value of the correct payment amount
	 */
	private Mono<BigDecimal> getPaymentAmount(String creditAccountId, String paymentPurpose, BigDecimal paymentAmountConfigured, String correlationId) {
		/*
		 * Mono<CreditCardAccountOverviewResponse> monoCreditCardAccountOverviewResponse
		 * = externalCallService.getAvailableCreditBalance(creditAccountId,
		 * correlationId); return monoCreditCardAccountOverviewResponse.flatMap(
		 * creditCardAccountOverviewResponse -> { Double result = Double.valueOf(0.0);
		 * if(paymentPurpose.equals(PaymentMetadata.PaymentPurposeEnum.MINIMUM_PAYMENT.
		 * name())) { result = creditCardAccountOverviewResponse.getMinimumPayment(); }
		 * else
		 * if(paymentPurpose.equals(PaymentMetadata.PaymentPurposeEnum.STATEMENT_BALANCE
		 * .name())) { result = creditCardAccountOverviewResponse.getStatementBalance();
		 * } else
		 * if(paymentPurpose.equals(PaymentMetadata.PaymentPurposeEnum.OTHER.name())) {
		 * result = paymentAmountConfigured; }
		 * 
		 * return Mono.just(result); });
		 */

		return Mono.just(paymentAmountConfigured);
	}
}