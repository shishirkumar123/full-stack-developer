package com.creditone.ucrm.payments.processor;

import java.time.ZonedDateTime;
import java.util.*;

import com.creditone.ucrm.payments.constant.BatchStatusUpdate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dao.PaymentBatchDAO;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.*;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class PaymentBatchProcessor {
	private PaymentDAO dao;
	private PaymentBatchDAO paymentBatchDAO;
	private String autopayScheduleDays;
	private String paymentZoneId;
    private NotifyAutopayProcessor notifyAutopayProcessor;
	private ProcessAutoPayNotifiedPaymentsProcessor processAutoPayNotifiedPaymentsProcessor;
	private ProcessScheduledPaymentsProcessor processScheduledPaymentsProcessor;

	public PaymentBatchProcessor(PaymentDAO dao,
                                 PaymentBatchDAO paymentBatchDAO,
                                 NotifyAutopayProcessor notifyAutopayProcessor,
								 ProcessAutoPayNotifiedPaymentsProcessor processAutoPayNotifiedPaymentsProcessor,
								 ProcessScheduledPaymentsProcessor processScheduledPaymentsProcessor,
                                 @Value(value = "${autopaySchedule.days}")  String autopayScheduleDays,
								 @Value(value = "${payment.zoneId}") String paymentZoneId) {
		this.dao = dao;
		this.paymentBatchDAO = paymentBatchDAO;
		this.autopayScheduleDays = autopayScheduleDays;
        this.notifyAutopayProcessor = notifyAutopayProcessor;
		this.processAutoPayNotifiedPaymentsProcessor = processAutoPayNotifiedPaymentsProcessor;
		this.processScheduledPaymentsProcessor = processScheduledPaymentsProcessor;
		this.paymentZoneId = paymentZoneId;
	}

	private UUID getBatchId(ZonedDateTime startTime, BatchProcessRequest.BatchProcessTypeEnum batchProcessType) {
		String value = startTime.toString() + batchProcessType.toString();
		UUID batchId = UUIDGenerator.generateType5UUID(value);
		return batchId;
	}

	public Mono<BatchProcessResponse> initializeBatchProcess(BatchProcessRequest batchProcessRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of initializeBatchProcess: batchProcessRequest: {}", correlationId, batchProcessRequest);
		ZonedDateTime startTime = PaymentUtil.utcNow();
		ZonedDateTime localDateTimeUTC = PaymentUtil.getZonedDateTimeUTC(correlationId,paymentZoneId);
		ZonedDateTime paymentDate = startTime.plusDays(Long.parseLong(autopayScheduleDays));
		List<String> listStatus = Arrays.asList(PaymentStatus.SCHEDULE.name(), PaymentStatus.RETRYABLE.name());
		UUID batchId = getBatchId(startTime, batchProcessRequest.getBatchProcessType());
		String batchType = batchProcessRequest.getBatchProcessType().toString();
        Map<String, Object> parameters = getMapForBatchProcess(batchProcessRequest, batchId, startTime, batchType);
		return saveBatchProcessEntity(parameters, correlationId).flatMap(batchProcessResponse -> {
			log.info(PaymentConstants.LOG_PREFIX + " batchProcessResponse: {}", correlationId, batchProcessResponse);
			batchProcessResponse.setBatchId(batchId.toString());
			if (BatchProcessRequest.BatchProcessTypeEnum.PROCESS_SCHEDULE_PAYMENT.toString().equalsIgnoreCase(batchProcessRequest.getBatchProcessType().toString())) {
				processScheduledPaymentsProcessor.processScheduledPayments(localDateTimeUTC, listStatus, parameters, correlationId).subscribe();
			}
			else if (PaymentConstants.SCHEDULE_AUTOPAY.equalsIgnoreCase(batchProcessRequest.getBatchProcessType().toString())) {
				processAutoPayNotifiedPaymentsProcessor.processAutoPayNotifiedPayments(paymentDate, parameters, correlationId).subscribe();
			}
            else if (BatchProcessRequest.BatchProcessTypeEnum.PROCESS_AUTO_PAY_NOTIFICATION.equals(batchProcessRequest.getBatchProcessType())) {
				notifyAutopayProcessor.notifyAutoPayConfiguredPayments(parameters, correlationId).subscribe();
            }
			return Mono.just(batchProcessResponse);
		});
	}

    private static Map<String, Object> getMapForBatchProcess(BatchProcessRequest batchProcessRequest, UUID batchId, ZonedDateTime startTime, String batchType) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(PaymentConstants.BATCH_ID, batchId);
        parameters.put(PaymentConstants.START_TIME, startTime);
        parameters.put(PaymentConstants.BATCH_TYPE, batchType);
        parameters.put(PaymentConstants.BATCH_PROCESS_REQUEST, batchProcessRequest);
		parameters.put(PaymentConstants.STATUS, BatchStatusUpdate.IN_PROGRESS.name());
        return parameters;
    }

	private Mono<BatchProcessResponse> saveBatchProcessEntity(Map<String, Object> parameters, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of saveBatchProcessEntity: parameters: {}", correlationId, parameters);
		return paymentBatchDAO.saveOrUpdatePaymentBatchEntity(parameters, correlationId).map(processedBatch -> {
			BatchProcessResponse batchProcessResponse = new BatchProcessResponse();
			batchProcessResponse.setBatchId(processedBatch.getBatchId().toString());
			return batchProcessResponse;
		});
	}

	/**
	 * This method gets the scheduled payments status.
	 *
	 * @param
	 * @return a Mono containing the response object of the
	 *         ScheduledPaymentsResponse
	 * @throws
	 **/
	public Mono<ScheduledPaymentStatusResponse> getScheduledPaymentStatus(String correlationId) {
		ZonedDateTime localDateTimeNowUTC = PaymentUtil.getZonedDateTimeUTC(correlationId);
		log.debug(PaymentConstants.LOG_PREFIX + "ZonedDateTime UTC {}", correlationId, localDateTimeNowUTC);
		List<String> listStatus = Arrays.asList(PaymentStatus.SCHEDULE.name());
		Flux<PaymentRequestDataDBResponse> payments = dao.findByRequestStatusInAndPaymentDateLessThan(listStatus, localDateTimeNowUTC, correlationId);
		Mono<Long> monoCountPayments = payments.count();
		return monoCountPayments.flatMap(countPayments -> {
			ScheduledPaymentStatusResponse scheduledPaymentsResponse = new ScheduledPaymentStatusResponse();
			scheduledPaymentsResponse.setPaymentCount(countPayments.intValue());
			return Mono.just(scheduledPaymentsResponse);
		});
	}
}