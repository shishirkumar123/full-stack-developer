package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.Channel;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.constant.PaymentType;
import com.creditone.ucrm.payments.dao.CustomerInteractionProducerMapper;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
import com.creditone.ucrm.payments.rules.pojo.RuleInput;
import com.creditone.ucrm.payments.rules.pojo.RuleOutput;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.creditone.ucrm.payments.validation.PaymentRequestValidator;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.ewsservicepartner.model.AcctStatus;
import com.ucrm.swagger.ewsservicepartner.model.EwsGatewayResponse;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.externaldebitcards.model.DebitCardInfoResponse;
import com.ucrm.swagger.paymentrulesservice.model.BlockedDate;
import com.ucrm.swagger.paymentrulesservice.model.EligiblePaymentAmountResponse;
import com.ucrm.swagger.paymentrulesservice.model.PaymentEligibilityDateResponse;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import lombok.extern.slf4j.Slf4j;
import org.drools.util.StringUtils;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Slf4j
@Component
public class PaymentRulesProcessor {
	private KieContainer accountStatusKieContainer;
	private KieContainer rtpCallKieContainer;
	private List<String> accountStatusList;
	private String feeAmount;
	private String bankruptRule;
	private String fraudRule;
	private String abandonRule;
	private String chargeOffRule;
	private String accountInDeleteProcessRule;
	private String accountInDeleteProcessIReason;
	private String accountInDeleteProcessIIReason;
	private String activeCreditProtectionClaimsRule;
	private String activeCreditProtectionClaimsIReason;
	private String activeCreditProtectionClaimsIIReason;
	private String activeCreditProtectionClaimsIIIReason;
	private String activeCreditProtectionClaimsIVReason;
	private String lostRule;
	private String stolenRule;

	private CustomerInteractionProducerProcessor customerInteractionProducerProcessor;
	private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;
	private static final Tuple2<String, String> FAILED_RULE_RESPONSE = Tuples.of("Inconclusive", "No result returned from Rule Engine");

	public PaymentRulesProcessor(@Qualifier("accountStatusKieContainer") KieContainer accountStatusKieContainer, @Qualifier("rtpCallKieContainer") KieContainer rtpCallKieContainer,
			@Value("#{'${account.status.list}'.split(',')}") List<String> accountStatusList, @Value(value = "${fee.amount}") String feeAmount,
			@Value(value = "${bankrupt.rule}") String bankruptRule, @Value(value = "${fraud.rule}") String fraudRule, @Value(value = "${abandon.rule}") String abandonRule,
			@Value(value = "${changeOff.rule}") String chargeOffRule, @Value(value = "${accountInDeleteProcess.rule}") String accountInDeleteProcessRule,
			@Value(value = "${accountInDeleteProcessI.reason}") String accountInDeleteProcessIReason,
			@Value(value = "${accountInDeleteProcessII.reason}") String accountInDeleteProcessIIReason,
			@Value(value = "${activeCreditProtectionClaims.rule}") String activeCreditProtectionClaimsRule,
			@Value(value = "${activeCreditProtectionClaimsI.reason}") String activeCreditProtectionClaimsIReason,
			@Value(value = "${activeCreditProtectionClaimsII.reason}") String activeCreditProtectionClaimsIIReason,
			@Value(value = "${activeCreditProtectionClaimsIII.reason}") String activeCreditProtectionClaimsIIIReason,
			@Value(value = "${activeCreditProtectionClaimsIV.reason}") String activeCreditProtectionClaimsIVReason, @Value(value = "${lost.rule}") String lostRule,
			@Value(value = "${stolen.rule}") String stolenRule, CustomerInteractionProducerProcessor customerInteractionProducerProcessor,
			CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		this.accountStatusKieContainer = accountStatusKieContainer;
		this.accountStatusList = accountStatusList;
		this.feeAmount = feeAmount;
		this.bankruptRule = bankruptRule;
		this.fraudRule = fraudRule;
		this.abandonRule = abandonRule;
		this.chargeOffRule = chargeOffRule;
		this.accountInDeleteProcessRule = accountInDeleteProcessRule;
		this.accountInDeleteProcessIReason = accountInDeleteProcessIReason;
		this.accountInDeleteProcessIIReason = accountInDeleteProcessIIReason;
		this.activeCreditProtectionClaimsRule = activeCreditProtectionClaimsRule;
		this.activeCreditProtectionClaimsIReason = activeCreditProtectionClaimsIReason;
		this.activeCreditProtectionClaimsIIReason = activeCreditProtectionClaimsIIReason;
		this.activeCreditProtectionClaimsIIIReason = activeCreditProtectionClaimsIIIReason;
		this.activeCreditProtectionClaimsIVReason = activeCreditProtectionClaimsIVReason;
		this.rtpCallKieContainer = rtpCallKieContainer;
		this.lostRule = lostRule;
		this.stolenRule = stolenRule;
		this.customerInteractionProducerProcessor = customerInteractionProducerProcessor;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
	}

	public Mono<PaymentDataTransferRequest> validateEligiblePaymentAmount(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest mapResult, EligiblePaymentAmountResponse eligiblePaymentAmountResponse, String correlationId) {
		Double minPaymentAmount = eligiblePaymentAmountResponse.getMinPaymentAmount();
		Double maxPaymentAmount = eligiblePaymentAmountResponse.getMaxPaymentAmount();
		Boolean isBetweenAmount = (Double.valueOf(paymentServiceRequest.getPaymentAmount().toString()).compareTo(minPaymentAmount) >= 0)
				&& (Double.valueOf(paymentServiceRequest.getPaymentAmount().toString()).compareTo(maxPaymentAmount) <= 0);

		if (!isBetweenAmount) {
			String error = PaymentErrors.ERROR_ELIGIBLE_AMOUNT.replace("{paymentAmount}", String.valueOf(paymentServiceRequest.getPaymentAmount()));
			error = error.replace("{minPaymentAmount}", String.valueOf(minPaymentAmount));
			error = error.replace("{maxPaymentAmount}", String.valueOf(maxPaymentAmount));
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_RULES_PAYMENT_AMOUNT);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, mapResult.getPaymentRequestId(),
					PaymentConstants.INVALID_AMOUNT, customerInteractionDescriptionConfig);
			return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
				return Mono.error(paymentDataException);
			});
		}

		return Mono.just(mapResult);
	}

	public Mono<PaymentDataTransferRequest> validateEligiblePaymentDates(PaymentServiceRequest paymentServiceRequest, PaymentEligibilityDateResponse paymentEligibilityDateResponse, PaymentDataTransferRequest mapResult, String correlationId) {
		LocalDate localScheduledDate = PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		if (paymentEligibilityDateResponse.getNextEligiblePaymentDate().equals("") || paymentEligibilityDateResponse.getLastEligiblePaymentDate().equals("")) {
			String error = PaymentErrors.ERROR_ELIGIBLE_PAYMENT_DATE_EMPTY_DATES_RESPONSE;
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_RULES_PAYMENT_DATE);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, mapResult.getPaymentRequestId(),
					PaymentConstants.INVALID_DATE, customerInteractionDescriptionConfig);
			return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
				return Mono.error(paymentDataException);
			});
		}

		LocalDate localNextEligiblePaymentDate = PaymentUtil.parseDate(paymentEligibilityDateResponse.getNextEligiblePaymentDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
		LocalDate localLastEligiblePaymentDate = PaymentUtil.parseDate(paymentEligibilityDateResponse.getLastEligiblePaymentDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
		Boolean isBetween = localScheduledDate.compareTo(localNextEligiblePaymentDate) >= 0 && localScheduledDate.compareTo(localLastEligiblePaymentDate) <= 0;

		if (!isBetween) {
			String error = PaymentErrors.ERROR_ELIGIBLE_PAYMENT_DATE.replace("{scheduledDate}", paymentServiceRequest.getScheduledDate());
			error = error.replace("{nextEligiblePaymentDate}", paymentEligibilityDateResponse.getNextEligiblePaymentDate());
			error = error.replace("{lastEligiblePaymentDate}", paymentEligibilityDateResponse.getLastEligiblePaymentDate());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_RULES_PAYMENT_DATE_VALIDATION);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, mapResult.getPaymentRequestId(),
					PaymentConstants.INVALID_DATE, customerInteractionDescriptionConfig);
			return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
				return Mono.error(paymentDataException);
			});
		}

		return validateBlockedDates(paymentServiceRequest, paymentEligibilityDateResponse, mapResult, correlationId);
	}

	private Mono<PaymentDataTransferRequest> validateBlockedDates(PaymentServiceRequest paymentServiceRequest, PaymentEligibilityDateResponse paymentEligibilityDateResponse, PaymentDataTransferRequest mapResult, String correlationId) {
		LocalDate localBlockedDate = null;
		LocalDate localScheduledDate = PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		for (BlockedDate blockedDate : paymentEligibilityDateResponse.getBlockedDates()) {
			localBlockedDate = PaymentUtil.parseDate(blockedDate.getDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
			if (localBlockedDate.isEqual(localScheduledDate)) {
				String error = PaymentErrors.ERROR_ELIGIBLE_PAYMENT_DATE_BLOCKED_DATE.replace("{scheduledDate}", paymentServiceRequest.getScheduledDate());
				error = error.replace("{blockedDate}", blockedDate.getDate());
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_RULES_PAYMENT_DATE_VALIDATION);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId,
						mapResult.getPaymentRequestId(), PaymentConstants.INVALID_DATE, customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
					return Mono.error(paymentDataException);
				});
			}
		}

		return Mono.just(mapResult);
	}

	public Mono<Map<String, Object>> validateDebitCardEligibility(PaymentServiceRequest paymentServiceRequest, Map<String, Object> mapResult, DebitCardInfoResponse debitCardInfoResponse, String correlationId) {
		if (!debitCardInfoResponse.getDebitCardId().toString().equalsIgnoreCase(paymentServiceRequest.getExternalAccountId())) {
			String error = PaymentErrors.ERROR_DEBIT_EXTERNAL_ACCOUNT_NOT_FOUND_IN_DEBIT_ACCOUNTS_LIST.replace("{customerId}", paymentServiceRequest.getCustomerId());
			error = error.replace("{externalAccount}", paymentServiceRequest.getExternalAccountId());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INELIGIBLE);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		mapResult.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, debitCardInfoResponse.getCardLast4());

		if (!debitCardInfoResponse.getPaymentEligible()) {
			String error = PaymentErrors.ERROR_DEBIT_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT.replace("{customerId}", paymentServiceRequest.getCustomerId());
			error = error.replace("{externalAccount}", paymentServiceRequest.getExternalAccountId());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INELIGIBLE);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		return Mono.just(mapResult);
	}

	public Mono<Map<String, Object>> validateExternalAccountsEligiblePaymentFlag(PaymentServiceRequest paymentServiceRequest, Map<String, Object> responseMap, BankAccountResponse bankAccountResponse, String correlationId, UUID paymentRequestId) {
		responseMap.put(PaymentConstants.EXTERNALACNT_ELIGIBILITY, bankAccountResponse.getPaymentEligible());

		if (!paymentServiceRequest.getChannel().equalsIgnoreCase(Channel.AGENT.name())) {
			if (!bankAccountResponse.getPaymentEligible()) {
				responseMap.put(PaymentConstants.EXTERNALACNT_ELIGIBILITY, bankAccountResponse.getPaymentEligible());
				String logError = PaymentErrors.ERROR_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT.replace("{customerId}", paymentServiceRequest.getCustomerId());
				logError = logError.replace("{externalAccount}", paymentServiceRequest.getExternalAccountId());
				log.error(PaymentConstants.LOG_PREFIX + logError, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INELIGIBLE);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, paymentRequestId,
						PaymentConstants.INELIGIBLE_EXTERNAL_ACCOUNT, customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
					return Mono.error(paymentDataException);
				});
			}

			if (paymentServiceRequest.getPaymentMode().equals(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT)) {
				responseMap.put(PaymentConstants.EXTERNALACNT_ELIGIBILITY, bankAccountResponse.getExpressPayEligible());

				if (!bankAccountResponse.getExpressPayEligible()) {
					String error = PaymentErrors.ERROR_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_EXPRESS_PAYMENT.replace("{customerId}", paymentServiceRequest.getCustomerId());
					error = error.replace("{externalAccount}", paymentServiceRequest.getExternalAccountId());
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INELIGIBLE);
					paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
					CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, paymentRequestId,
							PaymentConstants.INELIGIBLE_EXTERNAL_ACCOUNT, customerInteractionDescriptionConfig);
					return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
						return Mono.error(paymentDataException);
					});
				}
			}
		}
		return Mono.just(responseMap);
	}

	public Mono<AccountDetailsResponse> validateCreditCardAccountsEligiblePaymentFlag(PaymentServiceRequest paymentServiceRequest, AccountDetailsResponse accountDetailsResponse, String correlationId, UUID paymentRequestId) {
		if (!paymentServiceRequest.getChannel().equalsIgnoreCase(Channel.AGENT.name())) {
			if (!accountDetailsResponse.getPaymentEligible()) {// creditCardEligibility
				String errorLog = PaymentErrors.ERROR_CREDITCARD_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT.replace("{customerId}", paymentServiceRequest.getCustomerId());
				errorLog = errorLog.replace("{creditCardAccount}", paymentServiceRequest.getCreditAccountId());
				log.error(PaymentConstants.LOG_PREFIX + errorLog, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CREDITCARD_ACCOUNT_INELIGIBLE);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, paymentRequestId,
						PaymentConstants.INELIGIBLE_ACCOUNT, customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
					return Mono.error(paymentDataException);
				});
			}

			if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.ACH.name())) {
				if (paymentServiceRequest.getPaymentMode().equals(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT)) {
					if (!accountDetailsResponse.getExpressPayEligible()) {
						String errorLog = PaymentErrors.ERROR_CREDITCARD_ACCOUNT_NOT_ELIGIBLE_FOR_EXPRESS_PAYMENT.replace("{customerId}", paymentServiceRequest.getCustomerId());
						errorLog = errorLog.replace("{creditCardAccount}", paymentServiceRequest.getCreditAccountId());
						log.error(PaymentConstants.LOG_PREFIX + errorLog, correlationId);
						PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CREDITCARD_ACCOUNT_EXPRESS_PAY_INELIGIBLE);
						paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
						CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForEligibilityFailed(paymentServiceRequest, correlationId, paymentRequestId,
								PaymentConstants.INELIGIBLE_ACCOUNT, customerInteractionDescriptionConfig);
						return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
							return Mono.error(paymentDataException);
						});
					}
				}
			}
		}
		return Mono.just(accountDetailsResponse);
	}

	public Mono<Boolean> validateEligibleScheduleDate(PaymentServiceRequest paymentServiceRequest, PaymentEligibilityDateResponse paymentEligibilityDateResponse, String correlationId) {
		LocalDate localScheduledDate = PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		if (paymentEligibilityDateResponse.getNextEligiblePaymentDate().equals("") || paymentEligibilityDateResponse.getLastEligiblePaymentDate().equals("")) {
			log.error(PaymentConstants.LOG_PREFIX + PaymentErrors.ERROR_ELIGIBLE_PAYMENT_DATE_EMPTY_DATES_RESPONSE, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_DATE_ELIGIBILITY);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		if (!PaymentRequestValidator.validateBlockDates(paymentServiceRequest, paymentEligibilityDateResponse, correlationId)) {
			String error = PaymentErrors.ERROR_SCHEDULED_PAYMENT_DATE_BLOCKED_DATE.replace("{scheduledDate}", paymentServiceRequest.getScheduledDate());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_DATE_ELIGIBILITY);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}
		LocalDate localNextEligiblePaymentDate = PaymentUtil.parseDate(paymentEligibilityDateResponse.getNextEligiblePaymentDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
		LocalDate localLastEligiblePaymentDate = PaymentUtil.parseDate(paymentEligibilityDateResponse.getLastEligiblePaymentDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
		Boolean isBetween = localScheduledDate.compareTo(localNextEligiblePaymentDate) >= 0 && localScheduledDate.compareTo(localLastEligiblePaymentDate) <= 0;

		if (!isBetween) {
			String error = PaymentErrors.ERROR_ELIGIBLE_PAYMENT_DATE.replace("{scheduledDate}", paymentServiceRequest.getScheduledDate());
			error = error.replace("{nextEligiblePaymentDate}", paymentEligibilityDateResponse.getNextEligiblePaymentDate());
			error = error.replace("{lastEligiblePaymentDate}", paymentEligibilityDateResponse.getLastEligiblePaymentDate());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(error);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}
		return Mono.just(true);
	}

	public Mono<Boolean> validateEwsGatewayResponse(EwsGatewayResponse ewsGatewayResponse, PaymentDataTransferRequest requestDtoObject) {
		String customerId = requestDtoObject.getCustomerId();
		String externalAccountId = requestDtoObject.getExternalAccountId();
		String correlationId = requestDtoObject.getCorrelationId();

		if (ewsGatewayResponse == null || ewsGatewayResponse.getAoAResponse() == null || ewsGatewayResponse.getAoAResponse().getResult() == null) {
			String errorLog = PaymentErrors.ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NULL.replace("{customerId}", customerId);
			errorLog = errorLog.replace("{externalAccountId}", externalAccountId);
			log.error(PaymentConstants.LOG_PREFIX + errorLog, correlationId);
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_EWS_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		}
		requestDtoObject.setFNameMtch(ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getFnameMtch());
		requestDtoObject.setLNameMtch(ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getLnameMtch());
		requestDtoObject.setSSNMtch(ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getSsNMtch());
		requestDtoObject.setNameMtch(ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getNameMtch());

		Tuple2<String, String> accountStatusRuleResponse = verifyAccountStatus(ewsGatewayResponse.getAoAResponse().getResult().getAcctStatus(), correlationId);
		if (!(accountStatusList.stream().anyMatch(accountStatusRuleResponse.getT1()::equalsIgnoreCase))
				&& (!(requestDtoObject.getChannel() != null && (requestDtoObject.getChannel().toString()).equalsIgnoreCase(Channel.AGENT.name())))) {
			String error = PaymentErrors.ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NOT_VALID_STATUS.replace("{status}", accountStatusRuleResponse.getT1());
			error = error.replace("{customerId}", customerId);
			error = error.replace("{externalAccountId}", externalAccountId);
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EWS_VALIDATION);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForFailedPayment(correlationId, requestDtoObject, customerInteractionDescriptionConfig);
			return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
				return Mono.error(paymentDataException);
			});
		}

		return Mono.just(true);
	}

	public Mono<Boolean> validateEwsGatewayResponse(Map<String, Object> parametersMethod) {
		EwsGatewayResponse ewsGatewayResponse = (EwsGatewayResponse) parametersMethod.get(PaymentConstants.EWS_GATEWAY_RESPONSE);
		Map<String, Object> mapResult = (Map<String, Object>) parametersMethod.get(PaymentConstants.MAP_RESULT);
		String customerId = (String) parametersMethod.get(PaymentConstants.CUSTOMER_ID);
		String externalAccountId = (String) parametersMethod.get(PaymentConstants.EXTERNAL_ACCOUNT_ID);
		String correlationId = (String) parametersMethod.get(PaymentConstants.CORRELATION_ID);

		if (ewsGatewayResponse == null || ewsGatewayResponse.getAoAResponse() == null || ewsGatewayResponse.getAoAResponse().getResult() == null) {
			String errorLog = PaymentErrors.ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NULL.replace("{customerId}", customerId);
			errorLog = errorLog.replace("{externalAccountId}", externalAccountId);
			log.error(PaymentConstants.LOG_PREFIX + errorLog, correlationId);
			ServiceUnavailableException serviceUnavailableException = new ServiceUnavailableException(PaymentErrors.ERROR_EWS_UNAVAILABLE_RESPONSE);
			serviceUnavailableException.setHttpStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
			return Mono.error(serviceUnavailableException);
		}

		mapResult.put(PaymentConstants.F_NAME_MATCH, ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getFnameMtch());
		mapResult.put(PaymentConstants.L_NAME_MATCH, ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getLnameMtch());
		mapResult.put(PaymentConstants.SSN_MATCH, ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getSsNMtch());
		mapResult.put(PaymentConstants.NAME_MATCH, ewsGatewayResponse.getAoAResponse().getResult().getAcctOwner().getNameMtch());

		Tuple2<String, String> accountStatusRuleResponse = verifyAccountStatus(ewsGatewayResponse.getAoAResponse().getResult().getAcctStatus(), correlationId);
		if (!(accountStatusList.stream().anyMatch(accountStatusRuleResponse.getT1()::equalsIgnoreCase)) && (!(parametersMethod.get(PaymentConstants.CHANNEL) != null
				&& (parametersMethod.get(PaymentConstants.CHANNEL).toString()).equalsIgnoreCase(Channel.AGENT.name())))) {
			String error = PaymentErrors.ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NOT_VALID_STATUS.replace("{status}", accountStatusRuleResponse.getT1());
			error = error.replace("{customerId}", customerId);
			error = error.replace("{externalAccountId}", externalAccountId);
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EWS_VALIDATION);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		return Mono.just(true);

	}

	private Tuple2<String, String> verifyAccountStatus(AcctStatus acctStatus, String correlationId) {
		RuleInput input = new RuleInput();
		Map<String, Object> ruleInput = new HashMap<>();
		ruleInput.put("primary_status_code", acctStatus != null ? acctStatus.getPrimStatusCd() : null);
		ruleInput.put("secondary_status_code", acctStatus != null ? acctStatus.getSecStatusCd() : null);
		ruleInput.put("additional_status_code", acctStatus != null ? acctStatus.getAddStatusCd() : null);
		input.setFields(ruleInput);

		log.info(PaymentConstants.LOG_PREFIX + "Input to Account Status Rules: {}", correlationId, ruleInput);

		RuleOutput output = new RuleOutput();

		KieSession kieSession = accountStatusKieContainer.newKieSession();
		kieSession.setGlobal("output", output);
		kieSession.insert(input);
		kieSession.fireAllRules(1);
		kieSession.dispose();

		String decision = output.getOutput() != null && output.getOutput().get("status") != null ? output.getOutput().get("status").toString() : null;
		String comment = output.getOutput() != null && output.getOutput().get("comment") != null ? output.getOutput().get("comment").toString() : null;

		log.info(PaymentConstants.LOG_PREFIX + "Account Status Rule Response: {}, Reason: {}", correlationId, decision, comment);

		if (decision != null && comment != null) {
			return Tuples.of(decision, comment);
		} else {
			return FAILED_RULE_RESPONSE;
		}
	}

	public Mono<Boolean> verifyRtpCallStatus(PaymentDataTransferRequest paymentData, PaymentServiceRequest paymentRequest, String correlationId) {
		RuleInput input = new RuleInput();
		Map<String, Object> ruleInput = new HashMap<>();
		ruleInput.put("payment_type", paymentRequest.getPaymentType() != null ? paymentRequest.getPaymentType() : null);
		// ruleInput.put("payment_mode", paymentRequest.getPaymentMode() != null ?
		// paymentRequest.getPaymentMode().name() : null);
		ruleInput.put("expressPayDecesion", paymentData.getExpressPayDecesion() != null ? paymentData.getExpressPayDecesion().toString() : null);
		ruleInput.put("riskyPayment", paymentData.getRiskyPayment() != null ? paymentData.getRiskyPayment().toString() : null);
		ruleInput.put("feeWaived", paymentData.getFeeWaived() != null ? paymentData.getFeeWaived().toString() : null);
		input.setFields(ruleInput);

		log.info(PaymentConstants.LOG_PREFIX + "Input to Account Status Rules: {}", correlationId, ruleInput);

		RuleOutput output = new RuleOutput();

		KieSession kieSession = rtpCallKieContainer.newKieSession();
		kieSession.setGlobal("output", output);
		kieSession.insert(input);
		kieSession.fireAllRules(1);
		kieSession.dispose();
		log.info(PaymentConstants.LOG_PREFIX + "RTP Call Rule Response: {}, Reason: {}", correlationId, output);

		String decision = output.getOutput() != null && output.getOutput().get("rtp_call") != null ? output.getOutput().get("rtp_call").toString() : null;

		log.info(PaymentConstants.LOG_PREFIX + "RTP Call Rule Response: {}, Reason: {}", correlationId, decision);

		if (decision != null && "TRUE".equalsIgnoreCase(decision)) {
			return Mono.just(true);
		} else {
			return Mono.just(false);
		}
	}
//to verify feeWaived
	public Boolean verifyFeeAmount(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Input verifyFeeAmount paymentServiceRequest: {}, feeAmount: {}", paymentServiceRequest, feeAmount);

		if ((paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.ACH.name())
				&& paymentServiceRequest.getPaymentMode().getValue().equals(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue())
				&& (paymentServiceRequest.getFeeAmount().compareTo(new BigDecimal(feeAmount)) == 0))
				|| (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.DEBIT.name())
						&& (paymentServiceRequest.getFeeAmount().compareTo(new BigDecimal(feeAmount)) == 0))) {
			log.info(PaymentConstants.LOG_PREFIX + "Response verifyFeeAmount response: {}", correlationId, false);
			return false;
		}

		log.info(PaymentConstants.LOG_PREFIX + "Response verifyFeeAmount response: {}", correlationId, true);
		return true;
	}

	/**
	 * Method from processAutoPayNotifiedPayment to validate external status in
	 * CreditCardAccountOverviewResponse
	 * 
	 * @param response
	 * @return
	 */
	public Mono<Boolean> isValidCReditCardAccount(AccountDetailsResponse response) {

		if (response.getExternalStatus().equalsIgnoreCase(bankruptRule) || response.getExternalStatus().equalsIgnoreCase(fraudRule)
				|| response.getExternalStatus().equalsIgnoreCase(abandonRule) || response.getExternalStatus().equalsIgnoreCase(chargeOffRule)) {
			return Mono.just(true);
		}
		if (response.getExternalStatus().equalsIgnoreCase(accountInDeleteProcessRule) && (!response.getExternalReasonCode().equalsIgnoreCase(accountInDeleteProcessIReason)
				&& !response.getExternalReasonCode().equalsIgnoreCase(accountInDeleteProcessIIReason))) {
			return Mono.just(true);
		}
		if (response.getExternalStatus().equalsIgnoreCase(activeCreditProtectionClaimsRule)
				&& (response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIReason)
						|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIIReason)
						|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIIIReason)
						|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIVReason))) {
			return Mono.just(true);
		}

		return Mono.just(false);
	}

	public boolean isAutopaySuppressed(AccountDetailsResponse accountBalanceResponse) {
		// Need Logic to determine if autopay is suppressed
		return false;
	}

	public boolean isCeaseAndDesistGroupCA(AccountDetailsResponse accountBalanceResponse) {
		// Need Logic to check for cease and desist group CA
		return false;
	}

	public boolean isAutoPayEligible(AccountDetailsResponse accountDetailResponse) {
		return accountDetailResponse.getAutoPayEligible();
	}

	public Mono<Map<String, String>> isValidCReditCardAccountAndEmailCheck(AccountDetailsResponse response, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of isValidCReditCardAccountAndEmailCheck(): AccountDetailsResponse: {}", correlationId, response);
		Map<String, String> resultMp = new HashMap<>();
		resultMp.put(PaymentStatus.FLAG.getValue(), PaymentStatus.FALSE.getValue());
		resultMp.put(PaymentStatus.EMAIL_FLAG.getValue(), PaymentStatus.FALSE.getValue());
		log.info("response.getExternalStatus() :" + response.getExternalStatus());
		String status = StringUtils.EMPTY;
		if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.REVOKED.getValue()))
			status = "E";
		else if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.BANK_RUPT.getValue()))
			status = "B";
		else if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.ABANDON.getValue()) || response.getExternalStatus().equalsIgnoreCase(PaymentStatus.DELETE.getValue()))
			status = "I";
		else if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.CHARGE_OFF.getValue()))
			status = "Z";
		else if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.LOST.getValue()))
			status = "L";
		else if (response.getExternalStatus().equalsIgnoreCase(PaymentStatus.STOLEN.getValue()))
			status = "U";
		List externalStatusLt = Arrays.asList(bankruptRule, fraudRule, abandonRule, chargeOffRule, lostRule, stolenRule);
		if (externalStatusLt.contains(status)) {
			resultMp.put(PaymentStatus.FLAG.getValue(), PaymentStatus.TRUE.getValue());
			resultMp.put(PaymentStatus.EMAIL_FLAG.getValue(), PaymentStatus.FALSE.getValue());
		}
		if (status.equalsIgnoreCase(accountInDeleteProcessRule) && (!response.getExternalReasonCode().equalsIgnoreCase(accountInDeleteProcessIReason)
				&& !response.getExternalReasonCode().equalsIgnoreCase(accountInDeleteProcessIIReason))) {
			resultMp.put(PaymentStatus.FLAG.getValue(), PaymentStatus.TRUE.getValue());
			resultMp.put(PaymentStatus.EMAIL_FLAG.getValue(), PaymentStatus.TRUE.getValue());
		}
		if (status.equalsIgnoreCase(activeCreditProtectionClaimsRule) && (response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIReason)
				|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIIReason)
				|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIIIReason)
				|| response.getExternalReasonCode().equalsIgnoreCase(activeCreditProtectionClaimsIVReason))) {
			resultMp.put(PaymentStatus.FLAG.getValue(), PaymentStatus.TRUE.getValue());
			resultMp.put(PaymentStatus.EMAIL_FLAG.getValue(), PaymentStatus.TRUE.getValue());
		}

		log.info("resultMp :" + resultMp.get("flag") + " emailFlag value=" + resultMp.get("emailFlag"));
		return Mono.just(resultMp);
	}
}