package com.creditone.ucrm.payments.processor;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.SenderRecord;

@Slf4j
@Component
public class CustomerInteractionProducerProcessor {
	private String customerInteractionTopic;

	private String customerInteractionDlqTopic;

	private ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent> reactiveCustomerInteractionProducerTemplate;


	public CustomerInteractionProducerProcessor(@Value("${kafka.producer.customer_interaction.topic}") String customerInteractionTopic,
                                                @Value("${kafka.producer.customer_interaction.dlqTopic}") String customerInteractionDlqTopic,
                                                ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent> reactiveCustomerInteractionProducerTemplate) {
        this.customerInteractionTopic = customerInteractionTopic;
        this.customerInteractionDlqTopic = customerInteractionDlqTopic;
        this.reactiveCustomerInteractionProducerTemplate = reactiveCustomerInteractionProducerTemplate;
    }

	public Mono<String> publishCustomerInteractionKafkaEvent(CustomerInteractionEvent event, String correlationId){
		SenderRecord<String, CustomerInteractionEvent, Object> producerRecord = SenderRecord.create(customerInteractionTopic, null, null, null, event, null);

		log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent to be published: {}", correlationId, event);

		reactiveCustomerInteractionProducerTemplate.send(producerRecord).doOnSuccess(result -> {
			log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent successfully published. Record Metadata: partition-{}, offset-{}, record-{}", correlationId, result.recordMetadata().partition(), result.recordMetadata().offset(), producerRecord);
		}).doOnError(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error publishing  CustomerInteractionEvent to topic-{}, reason: {}, record: {}", correlationId, customerInteractionTopic, e.getMessage(), producerRecord);
			log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent to be published: {}", correlationId, event);
			SenderRecord<String, CustomerInteractionEvent, Object> dlqProducerRecord = SenderRecord.create(customerInteractionDlqTopic, null, null, null, event, null);
			reactiveCustomerInteractionProducerTemplate.send(dlqProducerRecord).doOnSuccess(dlqResult -> {
				log.info(PaymentConstants.LOG_PREFIX + "Event successfully published CustomerInteractionEvent to dlq topic. Record Metadata: partition-{}, offset-{}, record: {}", correlationId, dlqResult.recordMetadata().partition(), dlqResult.recordMetadata().offset(),
						dlqProducerRecord);
			}).doOnError(ex -> {
				log.error(PaymentConstants.LOG_PREFIX + "Error publishing CustomerInteractionEvent to dlq topic-{}, reason: {}, record: {}", correlationId, customerInteractionDlqTopic, ex.getMessage(), dlqProducerRecord);
				throw new PaymentException("Error publishing CustomerInteractionEvent to kafka topic - " + customerInteractionTopic + ": Reason - " + e.getMessage() + "; dlq topic - " + customerInteractionDlqTopic + ": Reason - " + ex.getMessage());
			}).subscribe();
		}).subscribe();

		return Mono.just("SUCCESS");
	}
}