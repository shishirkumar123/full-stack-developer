package com.creditone.ucrm.payments.processor;


import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.dao.CustomerInteractionProducerMapper;
import com.creditone.ucrm.payments.dao.PaymentKafkaProducerMapper;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.PaymentsKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.SenderRecord;

@Slf4j
@Component
public class PaymentTransactionKafkaProducerProcessor {

	private String topic;

	private String dlqTopic;
	private String customerInteractionTopic;

	private String customerInteractionDlqTopic;

	private ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent> reactiveCustomerInteractionProducerTemplate;
	private ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent> reactiveKafkaProducerTemplate;

	private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;

	public PaymentTransactionKafkaProducerProcessor(@Value("${kafka.producer.topic}") String topic,
                                                    @Value("${kafka.producer.dlqTopic}") String dlqTopic,
													@Value("${kafka.producer.customer_interaction.topic}") String customerInteractionTopic,
													@Value("${kafka.producer.customer_interaction.dlqTopic}") String customerInteractionDlqTopic,
                                                    ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent> reactiveCustomerInteractionProducerTemplate,
                                                    ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent> reactiveKafkaProducerTemplate, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		this.topic = topic;
		this.dlqTopic = dlqTopic;
        this.customerInteractionTopic = customerInteractionTopic;
        this.customerInteractionDlqTopic = customerInteractionDlqTopic;
        this.reactiveCustomerInteractionProducerTemplate = reactiveCustomerInteractionProducerTemplate;
        this.reactiveKafkaProducerTemplate = reactiveKafkaProducerTemplate;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
	}


	/***
	 * Publishes an AchPartnerMoneyMovementKafkaEvent to a Kafka Topic.
	 *
	 * @param achPartnerMoneyMovementKafkaEvent
	 * @param paymentRequestDataDBResponse
	 * @param correlationId
	 * @return A mono emitting a string indicating the result of the operation.
	 */
	public Mono<String> publishPaymentTransactionEventToKafka(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {

		log.debug(PaymentConstants.LOG_PREFIX + "Start of publishPaymentTransactionEventToKafka(), request: {}, paymentRequestDataDBResponse: {}", correlationId, achPartnerMoneyMovementKafkaEvent, paymentRequestDataDBResponse);
		try {
			PaymentsKafkaEvent event = PaymentKafkaProducerMapper.mapPaymentsKafkaEventFromDatabase(paymentRequestDataDBResponse, correlationId);
			event.getEventData().setCreatedBy(paymentRequestDataDBResponse.getCreatedBy());
			event.getEventData().setTransactionDate(String.valueOf(paymentRequestDataDBResponse.getCreatedTimestamp()));
			event.getEventData().setUpdatedBy(paymentRequestDataDBResponse.getUpdatedBy());
			event.getEventData().setUpdatedTimestamp(PaymentUtil.formatDate(paymentRequestDataDBResponse.getUpdatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
			event.getEventData().setCreatedTimestamp(String.valueOf(paymentRequestDataDBResponse.getCreatedTimestamp()));
			event.getEventData().setPostedDate(PaymentUtil.formatDate(PaymentUtil.parseDateTime(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getUpdatedTimestamp(),
					PaymentConstants.DATETIMEFORMAT_RESPONSE), PaymentConstants.YYYY_MM_DD));
			event.getEventData().getPaymentMetadata().setCollectionIntentId(paymentRequestDataDBResponse.getCollectionIntentId());
			event.getEventHeader().setTraceId(paymentRequestDataDBResponse.getCorrelationId());

			CustomerInteractionEvent customerInteractionEvent = CustomerInteractionProducerMapper.mapEventForPostedTransaction(achPartnerMoneyMovementKafkaEvent, paymentRequestDataDBResponse, correlationId, customerInteractionDescriptionConfig);

			return publishPaymentsKafkaEvent(event, correlationId)
					.flatMap(result -> publishCustomerInteractionKafkaEvent(customerInteractionEvent, correlationId));
		} catch (ParseException ex) {
			log.error(PaymentConstants.LOG_PREFIX + "Error while creating kafka event {}", correlationId, ex.getMessage());
			throw new PaymentException("Error while creating kafka event. Reason: " + ex.getMessage());
		}

	}

	private Mono<String> publishPaymentsKafkaEvent(PaymentsKafkaEvent event, String correlationId){
		SenderRecord<String, PaymentsKafkaEvent, Object> producerRecord = SenderRecord.create(topic, null, null, null, event, null);

		log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent to be published: {}", correlationId, event);

		reactiveKafkaProducerTemplate.send(producerRecord).doOnSuccess(result -> {
			log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent successfully published. Record Metadata: partition-{}, offset-{}, record-{}", correlationId, result.recordMetadata().partition(), result.recordMetadata().offset(), producerRecord);
		}).doOnError(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error publishing PaymentsKafkaEvent to topic-{}, reason: {}, record: {}", correlationId, topic, e.getMessage(), producerRecord);
			log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent to be published: {}", correlationId, event);
			SenderRecord<String, PaymentsKafkaEvent, Object> dlqProducerRecord = SenderRecord.create(dlqTopic, null, null, null, event, null);
			reactiveKafkaProducerTemplate.send(dlqProducerRecord).doOnSuccess(dlqResult -> {
				log.info(PaymentConstants.LOG_PREFIX + "PaymentsKafkaEvent successfully published to dlq topic. Record Metadata: partition-{}, offset-{}, record: {}", correlationId, dlqResult.recordMetadata().partition(), dlqResult.recordMetadata().offset(),
						dlqProducerRecord);
			}).doOnError(ex -> {
				log.error(PaymentConstants.LOG_PREFIX + "Error publishing PaymentsKafkaEvent to dlq topic-{}, reason: {}, record: {}", correlationId, dlqTopic, ex.getMessage(), dlqProducerRecord);
				throw new PaymentException("Error publishing PaymentsKafkaEvent to kafka topic - " + topic + ": Reason - " + e.getMessage() + "; dlq topic - " + dlqTopic + ": Reason - " + ex.getMessage());
			}).subscribe();
		}).subscribe();

		return Mono.just("SUCCESS");
	}

	private Mono<String> publishCustomerInteractionKafkaEvent(CustomerInteractionEvent event, String correlationId){
		SenderRecord<String, CustomerInteractionEvent, Object> producerRecord = SenderRecord.create(customerInteractionTopic, null, null, null, event, null);

		log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent to be published: {}", correlationId, event);

		reactiveCustomerInteractionProducerTemplate.send(producerRecord).doOnSuccess(result -> {
			log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent successfully published. Record Metadata: partition-{}, offset-{}, record-{}", correlationId, result.recordMetadata().partition(), result.recordMetadata().offset(), producerRecord);
		}).doOnError(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error publishing  CustomerInteractionEvent to topic-{}, reason: {}, record: {}", correlationId, customerInteractionTopic, e.getMessage(), producerRecord);
			log.info(PaymentConstants.LOG_PREFIX + "CustomerInteractionEvent to be published: {}", correlationId, event);
			SenderRecord<String, CustomerInteractionEvent, Object> dlqProducerRecord = SenderRecord.create(customerInteractionDlqTopic, null, null, null, event, null);
			reactiveCustomerInteractionProducerTemplate.send(dlqProducerRecord).doOnSuccess(dlqResult -> {
				log.info(PaymentConstants.LOG_PREFIX + "Event successfully published CustomerInteractionEvent to dlq topic. Record Metadata: partition-{}, offset-{}, record: {}", correlationId, dlqResult.recordMetadata().partition(), dlqResult.recordMetadata().offset(),
						dlqProducerRecord);
			}).doOnError(ex -> {
				log.error(PaymentConstants.LOG_PREFIX + "Error publishing CustomerInteractionEvent to dlq topic-{}, reason: {}, record: {}", correlationId, customerInteractionDlqTopic, ex.getMessage(), dlqProducerRecord);
				throw new PaymentException("Error publishing CustomerInteractionEvent to kafka topic - " + customerInteractionTopic + ": Reason - " + e.getMessage() + "; dlq topic - " + customerInteractionDlqTopic + ": Reason - " + ex.getMessage());
			}).subscribe();
		}).subscribe();

		return Mono.just("SUCCESS");
	}
}