package com.creditone.ucrm.payments.processor;

/**
 * Represents a processor of request.
 * This is a functional interface whose functional method is process().
 * 
 * @param <T>
 */

@FunctionalInterface
public interface Processor<T> {
    T process();
}
