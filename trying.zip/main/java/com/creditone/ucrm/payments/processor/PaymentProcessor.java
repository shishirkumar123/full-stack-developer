package com.creditone.ucrm.payments.processor;

import static org.assertj.core.api.Assertions.tuple;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClientRequestException;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.Channel;
import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentEvent;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.constant.PaymentType;
import com.creditone.ucrm.payments.dao.CustomerInteractionProducerMapper;
import com.creditone.ucrm.payments.dao.PaymentBatchActivityDAO;
import com.creditone.ucrm.payments.dao.PaymentDAO;
import com.creditone.ucrm.payments.dao.PaymentMapper;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.exception.PaymentDataUnprocessableEntityException;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
import com.creditone.ucrm.payments.service.ExternalCallService;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.achtransactionservice.model.AchTransactionRequest;
import com.ucrm.swagger.achtransactionservice.model.AchTransactionResponse;
import com.ucrm.swagger.collection.model.CollectionIntentRequest;
import com.ucrm.swagger.collection.model.CollectionIntentResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountBalanceResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsInvolvementResponse;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceRequest;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceResponse;
import com.ucrm.swagger.debittransactionservice.model.DebitTransactionRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitTransactionResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsGatewayResponse;
import com.ucrm.swagger.ewsservicepartner.model.EwsPartnerRequest;
import com.ucrm.swagger.externalaccounts.model.AccountTokenResponse;
import com.ucrm.swagger.externalaccounts.model.BankAccountResponse;
import com.ucrm.swagger.externaldebitcards.model.DebitCardInfoResponse;
import com.ucrm.swagger.externaldebitcards.model.GetDebitCardTokenResponse;
import com.ucrm.swagger.paymentrulesservice.model.EligiblePaymentAmountResponse;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckResponse;
import com.ucrm.swagger.paymentrulesservice.model.PaymentEligibilityDateResponse;
import com.ucrm.swagger.paymentrulesservice.model.RiskyPaymentRequest;
import com.ucrm.swagger.paymentrulesservice.model.RiskyPaymentResponse;
import com.ucrm.swagger.paymentservice.model.PaymentDetails;
import com.ucrm.swagger.paymentservice.model.PaymentMetadata.PaymentPurposeEnum;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest.PaymentModeEnum;
import com.ucrm.swagger.paymentservice.model.PaymentServiceResponse;
import com.ucrm.swagger.paymentservice.model.PaymentsReplayRequest;
import com.ucrm.swagger.paymentservice.model.PaymentsReplayResponse;
import com.ucrm.swagger.paymentservice.model.TransactionStatus;

import io.netty.handler.timeout.ReadTimeoutException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class PaymentProcessor {
	private static JSONParser parser = new JSONParser();
	private PaymentDAO dao;
	private PaymentBatchActivityDAO batchActivityDao;
	private PaymentCommunicationProcessor paymentCommunicationProcessor;
	private PaymentKafkaProducerProcessor kafkaProducerService;
	private ExternalCallService externalCallService;
	private PaymentRulesProcessor paymentRulesProcessor;
	private String maxRetries;
	private String skipFraudRule;
	private String collectionIntentType;
	private PaymentServiceHazelCastCacheProcessor paymentServiceHazelCastCacheProcessor;
	private BigDecimal[] validFeeAmount;
	private List<String> expressPayModeList;
	private String paymentCutoffTime;

	private CustomerInteractionProducerProcessor customerInteractionProducerProcessor;
	private CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig;

	public PaymentProcessor(PaymentDAO dao, PaymentKafkaProducerProcessor kafkaProducerService, ExternalCallService externalCallService,
			PaymentRulesProcessor paymentRulesProcessor, PaymentCommunicationProcessor paymentCommunicationProcessor, @Value(value = "${max.retries}") String maxRetries,
			@Value(value = "${skip.fraudRule}") String skipFraudRule, @Value(value = "${collection.intent.type}") String collectionIntentType,
			@Value(value = "${valid.fee.amount}") BigDecimal[] validFeeAmount, PaymentServiceHazelCastCacheProcessor paymentServiceHazelCastCacheProcessor,
			@Value("#{'${express.pay.modes}'.split('\\s*,\\s*')}") List<String> expressPayModeList, @Value("${payment.cutoff.time}") String paymentCutoffTime,
			PaymentBatchActivityDAO batchActivityDao, CustomerInteractionProducerProcessor customerInteractionProducerProcessor,
			CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		this.dao = dao;
		this.kafkaProducerService = kafkaProducerService;
		this.externalCallService = externalCallService;
		this.paymentRulesProcessor = paymentRulesProcessor;
		this.paymentCommunicationProcessor = paymentCommunicationProcessor;
		this.maxRetries = maxRetries;
		this.skipFraudRule = skipFraudRule;
		this.collectionIntentType = collectionIntentType;
		this.paymentServiceHazelCastCacheProcessor = paymentServiceHazelCastCacheProcessor;
		this.validFeeAmount = validFeeAmount;
		this.expressPayModeList = expressPayModeList;
		this.paymentCutoffTime = paymentCutoffTime;
		this.batchActivityDao = batchActivityDao;
		this.customerInteractionProducerProcessor = customerInteractionProducerProcessor;
		this.customerInteractionDescriptionConfig = customerInteractionDescriptionConfig;
	}

	/**
	 * Accepts an instance of DebitPaymentRequest from Controller, validates key
	 * parameters and routes the request to Payment-Scheduler or
	 * ACH-Transaction-Service as per provided scheduled date
	 *
	 * @param paymentServiceRequest
	 * @return Mono of DebitPaymentResponse
	 * @throws Exception
	 */

//	@Timed(value = "paymentProcessor.processAllPayments.timer")
	public Mono<PaymentServiceResponse> processAllPayments(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of processAllPayments(). request: {}", correlationId, paymentServiceRequest);
		if (!(List.of(validFeeAmount).contains(new BigDecimal(paymentServiceRequest.getFeeAmount().toString())))) {
			log.error(PaymentConstants.LOG_PREFIX + "FeeAmount is Invalid ", correlationId, paymentServiceRequest.getFeeAmount());
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_FEE_AMOUNT_IS_INVALID);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}
		UUID paymentRequestId = generatePaymentRequestId(paymentServiceRequest);// 458303a2-e36c-57d9-af88-4ec93d8e902e
		String paymentKey = paymentServiceRequest.getCustomerId() + paymentServiceRequest.getCreditAccountId() + paymentServiceRequest.getPaymentAmount();
		return checkForDuplicatePayment(correlationId, paymentRequestId, paymentKey).flatMap(isDuplicate -> {
			String cachedPaymentRequestId = paymentServiceHazelCastCacheProcessor.getDuplicatePaymentRecord(paymentKey, correlationId);
			PaymentDataTransferRequest paymentDtoRequest = PaymentMapper.mapPaymentDtoRequest(paymentServiceRequest, paymentRequestId, cachedPaymentRequestId, correlationId);
			paymentDtoRequest.setIsSchedulePayment(isSchedulePayment(paymentServiceRequest, correlationId));
			if (Boolean.TRUE.equals(isDuplicate)) {
				return processDuplicatedPaymentRequest(paymentServiceRequest, paymentDtoRequest);
			} else {
				return processNewPaymentRequest(paymentServiceRequest, paymentDtoRequest).flatMap(paymentRequestIdGenerated -> {
					return processSchedulePayment(paymentServiceRequest, correlationId, paymentRequestIdGenerated, paymentDtoRequest, paymentRequestId);
				}).onErrorResume(err -> {
					updateErrorPayment(paymentServiceRequest, paymentRequestId, PaymentStatus.ERROR.name(), correlationId).subscribe();
					log.error("Error While processing Payment " + err.getMessage());
					return Mono.error(err);
				});
			}
		});
	}

	private boolean isSchedulePayment(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		ZonedDateTime zonedDateTimePst = PaymentUtil.toZonedDateTimePST(zonedDateTime);
		String[] time = paymentCutoffTime.split(":");
		int hours = Integer.parseInt(time[0]);
		int min = Integer.parseInt(time[1]);
		LocalDate today = LocalDate.now(ZoneId.of("America/Los_Angeles"));
		LocalTime referenceTime = LocalTime.of(hours, min);
		ZonedDateTime referenceDateTime = ZonedDateTime.of(today, referenceTime, ZoneId.of("America/Los_Angeles"));
		log.info(PaymentConstants.LOG_PREFIX + "Payment date Before  {} and after converting to Zonedate {} ", correlationId, localDateTime, zonedDateTime);

		if ((zonedDateTimePst.toLocalDate().isEqual(today) && zonedDateTimePst.isAfter(referenceDateTime)) || zonedDateTimePst.toLocalDate().isAfter(today)) {
			return true;
		} else {
			return false;
		}
	}

	private Mono<PaymentServiceResponse> processSchedulePayment(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestIdGenerated, PaymentDataTransferRequest paymentDtoRequest, UUID paymentRequestId) {
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		ZonedDateTime zonedDateTimePst = PaymentUtil.toZonedDateTimePST(zonedDateTime);
		LocalDate today = LocalDate.now(ZoneId.of(PaymentConstants.AMERICA_LOS_ANGELES_ID));
		paymentDtoRequest.setSchduleTimestampPst(zonedDateTimePst);
		if (Boolean.TRUE.equals(paymentDtoRequest.getIsSchedulePayment())) {
			paymentDtoRequest.setStatus(PaymentStatus.SCHEDULE.name());
			if (zonedDateTimePst.toLocalDate().isAfter(today) && paymentServiceRequest.getPaymentMode().equals(PaymentModeEnum.EXPRESS_PAYMENT)) {
				paymentServiceRequest.setPaymentMode(PaymentModeEnum.STANDARD_PAYMENT);
				paymentDtoRequest.setPaymentMode(PaymentModeEnum.STANDARD_PAYMENT.name());
			}
			return schedulePaymentRequest(paymentRequestIdGenerated, paymentServiceRequest, paymentDtoRequest, correlationId).flatMap(response -> {
				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForInitiateAndSchedule(paymentServiceRequest, paymentDtoRequest, paymentRequestId);
				event.getEvent().getPayload()
						.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getSchedule(), paymentServiceRequest.getPaymentAmount(),paymentDtoRequest.getPaymentConfirmation(),
								PaymentUtil.formatDate(
										PaymentUtil.toZonedDateTime(PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE)),
										PaymentConstants.DATEFORMAT_DD_MM_UUUU),
								paymentDtoRequest.getExternalBankName(), paymentDtoRequest.getExternalAccountLast4()));
				CustomerInteractionProducerMapper.getScheduleCutomer360Data(paymentServiceRequest, paymentDtoRequest, zonedDateTime, zonedDateTimePst, event);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, paymentDtoRequest.getCorrelationId()).flatMap(publishResponse -> {
					return Mono.just(response);
				});
			});
		}
		paymentDtoRequest.setIsSchedulePayment(false);
		if (PaymentType.ACH.toString().equalsIgnoreCase(paymentServiceRequest.getPaymentType())
				|| PaymentType.DEBIT.toString().equalsIgnoreCase(paymentServiceRequest.getPaymentType())) {
			return processAchDebitPaymentRequest(paymentRequestIdGenerated, paymentServiceRequest, paymentDtoRequest, correlationId);
		} else {
			return logInvalidPaymentType(correlationId);
		}
	}

	private UUID generatePaymentRequestId(PaymentServiceRequest paymentServiceRequest) {
		StringBuilder paymentRequestID = new StringBuilder();
		paymentRequestID.append(paymentServiceRequest.getCustomerId()).append(paymentServiceRequest.getCreditAccountId()).append(paymentServiceRequest.getPaymentAmount())
				.append(paymentServiceRequest.getChannel())
				.append(PaymentUtil.getFormattedDate(PaymentConstants.DATEFORMAT_HH_MM, paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
		return UUIDGenerator.generateType5UUID(paymentRequestID.toString());

	}

	private Mono<Boolean> checkForDuplicatePayment(String correlationId, UUID paymentRequestId, String paymentKey) {
		if (paymentServiceHazelCastCacheProcessor.getDuplicatePaymentRecord(paymentKey, correlationId) != null) {
			return Mono.just(true);
		} else {
			paymentServiceHazelCastCacheProcessor.pushPaymentRecord(paymentKey, paymentRequestId.toString(), correlationId);
			return Mono.just(false);
		}
	}

	private Mono<PaymentServiceResponse> processDuplicatedPaymentRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dtoRequest) {
		dtoRequest.setStatus(PaymentStatus.DUPLICATE.name());
		return processNewPayment(paymentServiceRequest, dtoRequest).flatMap(paymentRequestIdGenerated -> {
			log.error(PaymentConstants.LOG_PREFIX + PaymentErrors.DUPLICATE_PAYMENT_REQUEST + dtoRequest.getCachedPaymentRequestId(), dtoRequest.getCorrelationId());
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_DUPLICATE_PAYMENT_REQUEST);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		});
	}

	private Mono<PaymentServiceResponse> logInvalidPaymentType(String correlationId) {
		log.error(PaymentConstants.LOG_PREFIX + PaymentErrors.VALIDATION_INVALID_PAYMENT_TYPE, correlationId);
		PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_TYPE_IS_INVALID);
		paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
		return Mono.error(paymentDataException);
	}

	/***
	 *
	 * @param paymentServiceRequest is required to call ther CIAM and
	 *                              CreditCardDetailsResponse api
	 * @param correlationId
	 * @return Mono of Map<String, String>, required for paymentCommunication call
	 */
	public Mono<Map<String, Object>> getCustomerNameFromCIAMAndCreditCardResponse(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of getCustomerNameFromCIAMAndCreditCardResponse(). paymentServiceRequest: {}", correlationId, paymentServiceRequest);
		String customerIdForEwsCall = (PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name().equals(paymentServiceRequest.getPaymentMode().getValue())
				&& paymentServiceRequest.getPaymentMetadata() != null && !(StringUtils.isEmpty(paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId())))
						? paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId()
						: paymentServiceRequest.getCustomerId();

		return Mono
				.zip(externalCallService.getCustomerDetailFromCIAM(paymentServiceRequest.getCustomerId(), correlationId),
						getCreditCardDetailsResponse(paymentServiceRequest.getCreditAccountId(), correlationId),
						externalCallService.getAccountsFromExternalAccountsServiceByID(customerIdForEwsCall, paymentServiceRequest.getExternalAccountId(), correlationId))
				.flatMap(tuple -> {
					EntityModelIndividualCoreIdentityResponse entityModelIndividualCoreIdentity = tuple.getT1();
					AccountDetailsResponse creditCardDetailsResponse = tuple.getT2();
					BankAccountResponse bankAccountResponse = tuple.getT3();
					Map<String, Object> mapResult = new HashMap<String, Object>();
					mapResult.put(PaymentConstants.FIRST_NAME, entityModelIndividualCoreIdentity.getFirstName());
					mapResult.put(PaymentConstants.LAST_NAME, entityModelIndividualCoreIdentity.getLastName());
					mapResult.put(PaymentConstants.CARD_TYPE,
							creditCardDetailsResponse.getDevice().getNetwork() != null ? creditCardDetailsResponse.getDevice().getNetwork() : null);
					mapResult.put(PaymentConstants.CARD_LAST4, creditCardDetailsResponse.getDevice().getDeviceLast4());
					mapResult.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, bankAccountResponse.getBankAccountLast4());
					mapResult.put(PaymentConstants.EXTERNAL_BANK_NAME, bankAccountResponse.getBankName());
					mapResult.put(PaymentConstants.EXT_ACCNT_TYPE, bankAccountResponse.getAccountType());
					mapResult.put(PaymentConstants.PLASTIC_DESIGN_CODE, creditCardDetailsResponse.getDevice().getPlasticDesignCode());
					mapResult.put(PaymentConstants.DELIQUENCY_FLAG, creditCardDetailsResponse.getDeliquencyFlag());

					mapResult.put(PaymentConstants.INVOLVEMENT_ID,
							creditCardDetailsResponse.getAccountInvolvements().stream().filter(account -> account.getAccountInvolvementType().equalsIgnoreCase("PRIMARY"))
									.map(AccountsInvolvementResponse::getInvolvementId).map(Object::toString).findFirst().orElse(null));
					mapResult.put(PaymentConstants.PRODUCT_KEY, creditCardDetailsResponse.getProductKey());

					return Mono.just(mapResult);
				}).onErrorResume(err -> {
					log.error(PaymentConstants.LOG_PREFIX + "Error from CIAM and CreditCardDetailsResponse validation exception: {}", correlationId, err.getMessage());
					if (err instanceof ServiceUnavailableException) {
						return Mono.error(err);
					}
					PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
							PaymentErrors.ERROR_PAYMENT_CANNOT_BE_PROCESSED_23);
					paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
					return Mono.error(paymentDataUnprocessableEntityException);
				});
	}

	/***
	 *
	 * @param paymentServiceRequest is required to call ther CIAM and
	 *                              CreditCardDetailsResponse api
	 * @param correlationId
	 * @return Mono of Map<String, String>, required for paymentCommunication call
	 */
	public Mono<Map<String, String>> getCustomerNameFromCIAMAndCreditCardMapResponse(PaymentServiceRequest paymentServiceRequest, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of getCustomerNameFromCIAMAndCreditCardResponse(). paymentServiceRequest: {}", correlationId, paymentServiceRequest);

		return Mono.zip(externalCallService.getCustomerDetailFromCIAM(paymentServiceRequest.getCustomerId(), correlationId),
				getCreditCardDetailsResponse(paymentServiceRequest.getCreditAccountId(), correlationId)).flatMap(tuple -> {
					EntityModelIndividualCoreIdentityResponse entityModelIndividualCoreIdentity = tuple.getT1();
					AccountDetailsResponse creditCardDetailsResponse = tuple.getT2();

					Map<String, String> mapResult = new HashMap<String, String>();
					mapResult.put(PaymentConstants.FIRST_NAME, entityModelIndividualCoreIdentity.getFirstName());
					mapResult.put(PaymentConstants.LAST_NAME, entityModelIndividualCoreIdentity.getLastName());
					mapResult.put(PaymentConstants.CARD_TYPE, creditCardDetailsResponse.getDevice().getNetwork());
					mapResult.put(PaymentConstants.CARD_LAST4, creditCardDetailsResponse.getDevice().getDeviceLast4());
					mapResult.put(PaymentConstants.PLASTICCODE, creditCardDetailsResponse.getDevice().getPlasticDesignCode());
					mapResult.put(PaymentConstants.INVOLVEMENT_ID,
							creditCardDetailsResponse.getAccountInvolvements().stream().filter(account -> account.getAccountInvolvementType().equalsIgnoreCase("PRIMARY"))
									.map(AccountsInvolvementResponse::getInvolvementId).map(Object::toString).findFirst().orElse(null));

					mapResult.put(PaymentConstants.PRODUCT_KEY, creditCardDetailsResponse.getProductKey().toString());

					return Mono.just(mapResult);
				}).onErrorResume(err -> {
					log.error(PaymentConstants.LOG_PREFIX + "Error from CIAM and CreditCardDetailsResponse validation exception: {}", correlationId, err.getMessage());
					PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
							PaymentErrors.ERROR_PAYMENT_CAN_NOT_BE_PROCESSED);
					paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
					return Mono.error(paymentDataUnprocessableEntityException);
				});
	}

	private Mono<PaymentDataTransferRequest> getCustomerNameFromCIAMAndCreditCardExternalBankResponse(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId, UUID paymentRequestId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of getCustomerNameFromCIAMAndCreditCardExternalBankResponse(). paymentServiceRequest: {}", correlationId,
				paymentServiceRequest);
		return Mono.zip(validateEligiblePaymentFlagsFromCreditCardAccountsService(paymentServiceRequest, correlationId, paymentRequestId),
				validateExternalAccountsEligiblePaymentFlags(paymentServiceRequest, correlationId, paymentRequestId),
				validateExternalAccountsSuppression(paymentServiceRequest.getCustomerId(), paymentServiceRequest.getExternalAccountId(), correlationId,
						paymentServiceRequest.getPaymentType()),
				validateEligiblePaymentDatesResponse(paymentServiceRequest, paymentDtoRequest, correlationId, false),
				validateEligiblePaymentAmountFromRules(paymentServiceRequest, paymentDtoRequest, correlationId),
				validateDebitSchedulePayment(paymentDtoRequest.getPaymentRequestId(), paymentServiceRequest, paymentDtoRequest, correlationId)).flatMap(tuple -> {
					AccountDetailsResponse creditCardDetailsResponse = tuple.getT1();
					Map<String, Object> externalAccountResponse = tuple.getT2();
					PaymentMapper.getPaymentDataMap(creditCardDetailsResponse, externalAccountResponse, paymentServiceRequest, paymentDtoRequest);
					return Mono.just(paymentDtoRequest);
				}).onErrorResume(err -> {
					log.error(PaymentConstants.LOG_PREFIX + "Error from CustomerNameFromCIAMAndCreditCardExternalBankResponse validation exception: {}", correlationId,
							err.getMessage());
					return Mono.error(err);
				});
	}

	/**
	 * Accepts an instance of DebitPaymentRequest from processDebitPayment method
	 * and orchestrates these steps 1. Add payment record to DB with status as New
	 * 2. Send payment information to Kafka with status as New 3. Fetch Bank Account
	 * from External Accounts Service 4. Send Payment data for processing to
	 * ACH/Debit Transaction Service 5. Update payment record in DB with status as
	 * Pending 6. Send payment information to Kafka with status as Pending 7. Sends
	 * a Mono of DebitPaymentResponse back to caller
	 *
	 * @param paymentRequestId
	 * @param paymentServiceRequest
	 * @return Mono of DebitPaymentResponse
	 */
	public Mono<PaymentServiceResponse> processAchDebitPaymentRequest(UUID paymentRequestId, PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of processPaymentRequest(). paymentServiceRequest: {}", correlationId, paymentServiceRequest);
		Mono<PaymentDataTransferRequest> monoValidatedOverallRules = validateOverallAchDebitRules(paymentRequestId, paymentServiceRequest, correlationId, paymentDtoRequest);
		return monoValidatedOverallRules.flatMap(paymentDtoRequestpostRules -> {
			return sendSavedAchDebitPaymentRequest(paymentDtoRequestpostRules, paymentServiceRequest, paymentRequestId, correlationId);
		});
	}

	/**
	 * Accepts an instance of DebitPaymentRequest from processDebitPayment method
	 * and orchestrates these steps 1. Add payment record to DB with status as New
	 * 2. Send payment information to Kafka with status as New 3. Fetch Bank Account
	 * from External Accounts Service 4. Send Payment data for processing to
	 * ACH/Debit Transaction Service 5. Update payment record in DB with status as
	 * Pending 6. Send payment information to Kafka with status as Pending 7. Sends
	 * a Mono of DebitPaymentResponse back to caller
	 *
	 * @param request
	 * @return Mono of DebitPaymentResponse
	 */
	private Mono<UUID> processNewPaymentRequest(PaymentServiceRequest request, PaymentDataTransferRequest dtoRequest) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of processNewPaymentRequest(). request: {}", dtoRequest.getCorrelationId(), request);
		dtoRequest.setStatus(PaymentStatus.INITIATED.name());
		dtoRequest.setFdrStatus(PaymentStatus.INITIATED.name());
		dtoRequest.setPaymentEvent(PaymentStatus.INITIATED.name());
		return processNewPayment(request, dtoRequest);
	}

	private Mono<UUID> processNewPayment(PaymentServiceRequest request, PaymentDataTransferRequest dtoRequest) {
		return saveNewPayment(request, dtoRequest);
	}

	private Mono<PaymentDataTransferRequest> validateOverallAchDebitRules(UUID paymentRequestId, PaymentServiceRequest paymentServiceRequest, String correlationId, PaymentDataTransferRequest paymentDtoRequest) {
		log.info(PaymentConstants.LOG_PREFIX + "inside validateOverallAchDebitRules(): paymentRequestId: {}, paymentServiceRequest: {} ", correlationId, paymentRequestId,
				paymentServiceRequest);
		return getCustomerNameFromCIAMAndCreditCardExternalBankResponse(paymentServiceRequest, paymentDtoRequest, correlationId, paymentRequestId).flatMap(paymentRequestDtoMap -> {
			mapResponseVerificationFeeAmount(paymentServiceRequest, paymentDtoRequest, correlationId);
			if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.ACH.name())) {
				return validateACHRulesNew(paymentServiceRequest, paymentRequestDtoMap, correlationId);
			} else {
				return validateDebitRules(paymentServiceRequest, paymentRequestDtoMap, correlationId);
			}

		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error validateOverallAchDebitRules : {}", correlationId, err.getMessage());
			return dao.updatePaymentRequestEntityStatus(PaymentStatus.ELIGIBILITY_FAILED.name(), paymentRequestId, correlationId).flatMap(uuidUpdated -> {
				return Mono.error(err);
			});
		});
	}

	private Mono<PaymentDataTransferRequest> validateEligiblePaymentDatesResponse(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest mapResult, String correlationId, boolean isSchedulePayment) {
		if (!isSchedulePayment) {
			Mono<PaymentEligibilityDateResponse> monoPaymentEligibilityDateResponse = externalCallService.getRangeAllowedPaymentDatesFromPaymentRulesService(paymentServiceRequest,
					correlationId);
			return monoPaymentEligibilityDateResponse.flatMap(paymentEligibilityDateResponse -> {
				return paymentRulesProcessor.validateEligiblePaymentDates(paymentServiceRequest, paymentEligibilityDateResponse, mapResult, correlationId);
			});
		}
		return Mono.just(mapResult);
	}

	private Mono<AccountDetailsResponse> validateEligiblePaymentFlagsFromCreditCardAccountsService(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId) {
		Mono<AccountDetailsResponse> monoCreditCardDetailsResponse = externalCallService.getCreditCardDetailsAccountsService(paymentServiceRequest.getCreditAccountId(),
				correlationId);
		return monoCreditCardDetailsResponse.flatMap(creditCardDetailsResponse -> {
			return paymentRulesProcessor.validateCreditCardAccountsEligiblePaymentFlag(paymentServiceRequest, creditCardDetailsResponse, correlationId, paymentRequestId);
		});
	}

	private Mono<PaymentDataTransferRequest> validateEligiblePaymentAmountFromRules(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest mapResult, String correlationId) {
		Mono<EligiblePaymentAmountResponse> monoEligiblePaymentAmountResponse = externalCallService.getRangeAllowedAmountFromPaymentRulesService(paymentServiceRequest,
				correlationId);
		return monoEligiblePaymentAmountResponse.flatMap(eligiblePaymentAmountResponse -> {
			return paymentRulesProcessor.validateEligiblePaymentAmount(paymentServiceRequest, mapResult, eligiblePaymentAmountResponse, correlationId);
		});
	}

	private void mapResponseVerificationFeeAmount(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId) {
		paymentDtoRequest.setFeeWaived(paymentRulesProcessor.verifyFeeAmount(paymentServiceRequest, correlationId));
		// mapValidatedEligiblePaymentAmountResponse.put(PaymentConstants.FEE_WAIVED,
		// paymentRulesProcessor.verifyFeeAmount(paymentServiceRequest, correlationId));
		if ((paymentServiceRequest.getChannel()).equalsIgnoreCase(Channel.AGENT.name())
				&& expressPayModeList.contains(paymentServiceRequest.getPaymentMode().getValue().toUpperCase())) {
			paymentDtoRequest.setExpressPayDecesion(true);
		} else if ((paymentServiceRequest.getChannel()).equalsIgnoreCase(Channel.WEB.name())
				&& PaymentModeEnum.EXPRESS_PAYMENT.name().equalsIgnoreCase(paymentServiceRequest.getPaymentMode().getValue().toUpperCase())) {
			paymentDtoRequest.setExpressPayDecesion(true);
		} else if (PaymentModeEnum.EXPRESS_PAYMENT.name().equalsIgnoreCase(paymentServiceRequest.getPaymentMode().getValue().toUpperCase())) {
			paymentDtoRequest.setExpressPayDecesion(true);
		} else {
			paymentDtoRequest.setExpressPayDecesion(false);
		}

	}

	private Mono<PaymentDataTransferRequest> validateACHRulesNew(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId) {
		String customerIdForEwsCall = (PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name().equals(paymentServiceRequest.getPaymentMode().getValue())
				&& paymentServiceRequest.getPaymentMetadata() != null && !(StringUtils.isEmpty(paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId())))
						? paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId()
						: paymentServiceRequest.getCustomerId();
		Mono<AccountTokenResponse> monoAccountTokenResponse = externalCallService.getAccountTokenFromExternalBankAccounts(customerIdForEwsCall,
				paymentServiceRequest.getExternalAccountId(), paymentServiceRequest.getChannel(), correlationId);
		return monoAccountTokenResponse.flatMap(accountTokenResponse -> {
			EwsPartnerRequest ewsPartnerRequest = PaymentMapper.mapEwsPartnerRequest(customerIdForEwsCall, accountTokenResponse, paymentServiceRequest.getChannel());
			Mono<EwsGatewayResponse> monoEwsGatewayResponse = externalCallService.callEWSServicePartnerValidation(ewsPartnerRequest, correlationId);
			paymentDtoRequest.setOneTimeAccessToken(accountTokenResponse.getMetadata().getOneTimeAccessToken().toString());
			paymentDtoRequest.setGrantAccessToken(accountTokenResponse.getMetadata().getGrantAccessToken().toString());
			paymentDtoRequest.setReceiverAccountRoutingNumber(accountTokenResponse.getRoutingNumber());
			paymentDtoRequest.setReceiverAccountType(accountTokenResponse.getAccountType());
			return monoEwsGatewayResponse.flatMap(ewsGatewayResponse -> {
				return Mono.zip(paymentRulesProcessor.validateEwsGatewayResponse(ewsGatewayResponse, paymentDtoRequest), getCreditCardData(paymentDtoRequest, correlationId))
						.flatMap(ewsCrdeditcardTuple -> {
							PaymentDataTransferRequest paymentDataDto = ewsCrdeditcardTuple.getT2();
							return validateRiskFraudPaymentRTPCalls(paymentServiceRequest, paymentDataDto, correlationId);

						});
			});
		});
	}

	private Mono<PaymentDataTransferRequest> validateRiskyPaymentCheck(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtorequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "FeeWaved {} ExpressPay {}", correlationId, paymentDtorequest.getFeeWaived(), paymentDtorequest.getExpressPayDecesion());
		if (paymentDtorequest.getExpressPayDecesion() != null && paymentDtorequest.getExpressPayDecesion()) {
			RiskyPaymentRequest riskypaymentRequest = PaymentMapper.getRiskyPaymentRequest(paymentServiceRequest, paymentDtorequest);
			Mono<RiskyPaymentResponse> monoriskyPaymentResponse = externalCallService.getRiskAssesmentPaymentRulesService(paymentServiceRequest, riskypaymentRequest,
					correlationId);
			return monoriskyPaymentResponse.flatMap(riskyPaymentResponse -> {
				if ("true".equalsIgnoreCase(riskyPaymentResponse.getRiskyPayment())) {
					CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForRiskyPaymentCheck(paymentServiceRequest, correlationId,
							paymentDtorequest.getPaymentRequestId(), customerInteractionDescriptionConfig);
					return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
						paymentDtorequest.setRiskyPayment(riskyPaymentResponse.getRiskyPayment());
						paymentDtorequest.setExpressPayCondition(riskyPaymentResponse.getExpressPayCondition());
						paymentDtorequest.setFeeAmount(BigDecimal.ZERO);
						paymentDtorequest.setExpressPayDecesion(false);
						return Mono.just(paymentDtorequest);
					});
				} else {
					paymentDtorequest.setRiskyPayment(riskyPaymentResponse.getRiskyPayment());
					paymentDtorequest.setExpressPayCondition(riskyPaymentResponse.getExpressPayCondition());
					return Mono.just(paymentDtorequest);
				}
			});
		} else {
			return Mono.just(paymentDtorequest);
		}
	}

	private Mono<PaymentDataTransferRequest> validateFraudPaymentCheck(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, String correlationId) {
		if (paymentServiceRequest.getPaymentType().equals(PaymentType.DEBIT.name()) && skipFraudRule.equalsIgnoreCase("true")) {
			paymentRequestDto.setFloatDays(Integer.valueOf(0));
			paymentRequestDto.setRiskLevel(PaymentConstants.RL00);
			return Mono.just(paymentRequestDto);
		} else {

			FraudCheckRequest fraudRulerequest = PaymentMapper.getFraudPaymentRequest(paymentServiceRequest, paymentRequestDto);
			Mono<FraudCheckResponse> monoFraudRuleResponse = externalCallService.getFraudRulesPaymentRulesService(fraudRulerequest, correlationId);
			return monoFraudRuleResponse.flatMap(fraudRuleResponse -> {
				// CustomerInteractionEvent event =
				// CustomerInteractionProducerMapper.mapEventForFailedPayment(correlationId,
				// paymentRequestDto, customerInteractionDescriptionConfig);
				// return
				// customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event,
				// correlationId).flatMap(publishResponse -> {
				paymentRequestDto.setFloatDays(fraudRuleResponse.getFloatDays());
				paymentRequestDto.setRiskLevel(fraudRuleResponse.getRiskLevel());
				return Mono.just(paymentRequestDto);
			});
			// });
		}
	}

	private Mono<PaymentDataTransferRequest> triggerRTPCall(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, String correlationId) {
		// if expressPay->true and feewaved=false
		return paymentRulesProcessor.verifyRtpCallStatus(paymentRequestDto, paymentServiceRequest, correlationId).flatMap(rtpFlag -> {
			if (Boolean.TRUE.equals(rtpFlag)) {
				log.debug(PaymentConstants.LOG_PREFIX + "Response from RTP CALL Service: {}", correlationId, rtpFlag);

				UpdateAccountBalanceRequest creditcardBalanceRequest = PaymentMapper.getCreditCardBalanceRequest(paymentServiceRequest, paymentRequestDto);
				Mono<UpdateAccountBalanceResponse> monoCardbalanceResponse = externalCallService.updateCreditBalance(paymentServiceRequest, creditcardBalanceRequest,
						correlationId);
				return monoCardbalanceResponse.flatMap(cardbalanceResponse -> {
					paymentRequestDto.setRtpStatus(cardbalanceResponse.getTransactionStatus());
					paymentRequestDto.setRtpConfirmationCode(cardbalanceResponse.getConfirmationCode());
					Mono<AccountDetailsResponse> accountDetailsRespone = externalCallService.getAccountsFromCreditCardAccountsService(paymentServiceRequest.getCreditAccountId(),
							correlationId);
					return accountDetailsRespone.flatMap(accountDetails -> {
						if (accountDetails.getExternalStatus().equals(PaymentConstants.AUTHORIZATION_PROHIBITTED)) {
							paymentRequestDto.setFeeAmount(BigDecimal.ZERO);
							paymentRequestDto.setExpressPayDecesion(false);
							// mapResult.put(PaymentConstants.FEE_AMOUNT, BigDecimal.ZERO);
							CustomerInteractionEvent eventForFeeAdjustment = CustomerInteractionProducerMapper.mapEventForFeeAdjustment(paymentServiceRequest, paymentRequestDto,
									correlationId, customerInteractionDescriptionConfig);
							return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(eventForFeeAdjustment, correlationId)
									.flatMap(publishResponseForFeeAdjustment -> {
										return Mono.just(paymentRequestDto);
									});
						} else {
							CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForCreditCardBalanceUpdate(paymentServiceRequest, paymentRequestDto,
									correlationId, cardbalanceResponse, customerInteractionDescriptionConfig);
							return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponseForFeeAdjustment -> {
								return Mono.just(paymentRequestDto);
							});
						}
					});
				});
			} else {

				return Mono.just(paymentRequestDto);
			}
		});
	}

	private Mono<Map<String, Object>> validateExternalAccountsEligiblePaymentFlags(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId) {
		Map<String, Object> response = new HashMap<String, Object>();
		if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.ACH.name())) {
			String customerIdForEwsCall = (PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name().equals(paymentServiceRequest.getPaymentMode().getValue())
					&& paymentServiceRequest.getPaymentMetadata() != null && !(StringUtils.isEmpty(paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId())))
							? paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId()
							: paymentServiceRequest.getCustomerId();
			Mono<BankAccountResponse> monoBankAccountResponse = externalCallService.getAccountsFromExternalAccountsServiceByID(customerIdForEwsCall,
					paymentServiceRequest.getExternalAccountId(), correlationId);
			return monoBankAccountResponse.flatMap(bankAccountResponse -> {
				response.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, bankAccountResponse.getBankAccountLast4());
				response.put(PaymentConstants.EXTERNAL_BANK_NAME, bankAccountResponse.getBankName());
				response.put(PaymentConstants.EXT_ACCNT_TYPE, bankAccountResponse.getAccountType());
				response.put(PaymentConstants.EXT_ACT_STATUS, bankAccountResponse.getAccountStatus());
				response.put(PaymentConstants.IS_NEW_ACNT, bankAccountResponse.getIsNewAccount());

				return paymentRulesProcessor.validateExternalAccountsEligiblePaymentFlag(paymentServiceRequest, response, bankAccountResponse, correlationId, paymentRequestId);
			});
		} else if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.DEBIT.name())) {
			return validateDebitCardEligibility(paymentServiceRequest, response, correlationId);
		}
		return Mono.just(response);
	}

	private Mono<PaymentDataTransferRequest> validateRiskFraudPaymentRTPCalls(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dataTransferDto, String correlationId) {
		return Mono.zip(validateRiskyPaymentCheck(paymentServiceRequest, dataTransferDto, correlationId),
				validateFraudPaymentCheck(paymentServiceRequest, dataTransferDto, correlationId)).flatMap(tuple -> {
					PaymentDataTransferRequest fraudRuleDto = tuple.getT2();
					return triggerRTPCall(paymentServiceRequest, fraudRuleDto, correlationId);
				});

	}

	private Mono<PaymentDataTransferRequest> validateDebitRules(PaymentServiceRequest request, PaymentDataTransferRequest mapResult, String correlationId) {
		return validateRiskFraudPaymentRTPCalls(request, mapResult, correlationId);
	}

	private Mono<Map<String, Object>> validateDebitCardEligibility(PaymentServiceRequest paymentServiceRequest, Map<String, Object> mapResult, String correlationId) {
		Mono<DebitCardInfoResponse> monoDebitCardInfoResponse = externalCallService.getAccountsFromExternalDebitAccountsServiceById(paymentServiceRequest.getCustomerId(),
				paymentServiceRequest.getExternalAccountId(), correlationId);
		return monoDebitCardInfoResponse.flatMap(debitCardInfoResponse -> {
			return paymentRulesProcessor.validateDebitCardEligibility(paymentServiceRequest, mapResult, debitCardInfoResponse, correlationId);
		});
	}

	public Mono<PaymentServiceResponse> sendSavedAchDebitPaymentRequest(PaymentDataTransferRequest paymentDtoRequest, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId) {

		return sendAchDebitPaymentRequest(paymentDtoRequest, paymentServiceRequest, paymentRequestId, correlationId).flatMap(transactionServiceResponse -> {
			log.debug(PaymentConstants.LOG_PREFIX + "Response from Transaction Service: {}", correlationId, transactionServiceResponse);

			if (PaymentErrors.ERROR_SERVICE_TIMEOUT.equalsIgnoreCase(transactionServiceResponse)) {
				PaymentServiceResponse response = new PaymentServiceResponse();
				response.setPaymentRequestId(paymentRequestId.toString());
				return Mono.just(response);
			}

			return paymentResponseAndInitiateAsync(paymentDtoRequest, paymentServiceRequest, paymentRequestId, correlationId).flatMap(paymentServiceResponse -> {
				if (PaymentServiceRequest.PaymentModeEnum.AUTO_PAYMENT.getValue().equalsIgnoreCase(paymentServiceRequest.getPaymentMode().getValue())) {
					return sendAutoPaymentNotification(paymentServiceRequest, correlationId, paymentRequestId).flatMap(paymentCommunicationResponse -> {
						log.debug(PaymentConstants.LOG_PREFIX + "Response of paymentCommunication(). response: {}", correlationId, paymentCommunicationResponse);
						return Mono.just(paymentServiceResponse);
					});
				} else {
					return Mono.just(paymentServiceResponse);
				}
			});
		}).doOnSuccess(resp -> processbatchActivityPayments(paymentServiceRequest, paymentDtoRequest, correlationId).subscribe());
	}

	public Mono<Void> processbatchActivityPayments(PaymentServiceRequest paymentServicerequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId) {
		return processPaymentBatchActivity(paymentServicerequest, paymentDtoRequest, correlationId).then();

	}

	private Mono<Void> processPaymentBatchActivity(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, String correlationId) {
		return externalCallService.getCustomerDetailFromCIAM(paymentServiceRequest.getCustomerId(), correlationId).flatMap(ciamResp -> {
			paymentRequestDto.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_PROCESSED.name());
			paymentRequestDto.setFirstName(ciamResp.getFirstName());
			paymentRequestDto.setLastName(ciamResp.getLastName());
			PaymentCommunicationRequest paymentCommunicationRequest = PaymentMapper.getPaymentCommunicationRequest(paymentServiceRequest, paymentRequestDto,
					paymentRequestDto.getPaymentRequestId());

			paymentCommunicationRequest.getPaymentCommunicationDetailsRequest().setReferenceNum(paymentRequestDto.getConfirmationCode());

			return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId).flatMap(paymentCommunicationResponse -> {
				paymentRequestDto.setCollectionIntentType(collectionIntentType);
				paymentRequestDto.setCommunicationRequestId(paymentCommunicationResponse.getCommunicationRequestId());
				if (paymentRequestDto.getCollectionIntentId() != null) {
					return updatePaymentBatchAndPublish(paymentRequestDto, paymentServiceRequest, paymentRequestDto.getPaymentRequestId(), correlationId);
				} else {
					CollectionIntentRequest collectionIntentRequest = PaymentMapper.getCollectionIntentRequest(paymentServiceRequest, paymentRequestDto,
							paymentRequestDto.getPaymentRequestId(), correlationId);
					return getCollectionIntentId(collectionIntentRequest, correlationId).flatMap(collectionIntentResponse -> {
						paymentRequestDto.setCollectionIntentId(collectionIntentResponse.getCollectionIntentId());
						paymentRequestDto.setFollowUpDate(
								collectionIntentResponse.getFollowUpDate() != null ? collectionIntentResponse.getFollowUpDate().atStartOfDay(ZoneId.systemDefault()).toInstant()
										: null);
						return updatePaymentBatchAndPublish(paymentRequestDto, paymentServiceRequest, paymentRequestDto.getPaymentRequestId(), correlationId);
					});
				}
			});
		}).then();
	}

	public Mono<CollectionIntentResponse> getCollectionIntentId(CollectionIntentRequest collectionIntentRequest, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of getCollectionIntentId(). collectionIntentRequest: {}", correlationId, collectionIntentRequest);
		return externalCallService.getCollectionIntent(collectionIntentRequest, correlationId).onErrorResume(err -> {
			return getCollectionIntentErrorResponse();
		});

	}

	private Mono<CollectionIntentResponse> getCollectionIntentErrorResponse() {
		CollectionIntentResponse collectionIntentResponse = new CollectionIntentResponse();
		collectionIntentResponse.collectionIntentId(null);
		return Mono.just(collectionIntentResponse);
	}

	private Mono<PaymentServiceResponse> paymentResponseAndInitiateAsync(PaymentDataTransferRequest paymentRequestdto, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of paymentResponse(). , paymentServiceRequest: {}, paymentRequestId: {}", correlationId, paymentServiceRequest,
				paymentRequestId);
		String confirmationCode = null;
		try {
			confirmationCode = dao.generateConfirmationCode(paymentRequestId);
		} catch (NoSuchAlgorithmException e) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CONFIRMATION_CODE);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}
		paymentRequestdto.setConfirmationCode(confirmationCode);
		paymentRequestdto.setStatus(PaymentStatus.PROCESSED.name());
		return updateAndsavePaymentbatch(paymentRequestdto, paymentServiceRequest, paymentRequestId, PaymentStatus.PROCESSED.name(), correlationId).flatMap(paymentReqId -> {
			PaymentServiceResponse response = new PaymentServiceResponse();
			return externalCallService.getAvailableCreditBalance(paymentRequestdto.getCreditAccountId(), correlationId).flatMap(creditCardAccountOverview -> {
				if (paymentServiceRequest.getPaymentMetadata().getPaymentPurpose() != null
						&& paymentServiceRequest.getPaymentMetadata().getPaymentPurpose().name().equalsIgnoreCase(PaymentPurposeEnum.OTHER.name())) {
					response.setPaymentDetails(getPaymentDetails(creditCardAccountOverview, paymentServiceRequest));
				}
				response.setPaymentRequestId(paymentRequestdto.getPaymentRequestId().toString());
				response.setPaymentConfirmation(paymentRequestdto.getConfirmationCode());
				response.setPaymentStatus(paymentRequestdto.getStatus());
				response.setAvailableCredit(creditCardAccountOverview.getAvailableCredit());

				CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForProcessedTransaction(paymentServiceRequest, paymentRequestdto, correlationId,
						paymentRequestId, customerInteractionDescriptionConfig);
				return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
					return Mono.just(response);
				});
			});
		}).onErrorResume(e -> {
			updateAndPublishPayment(paymentServiceRequest, paymentRequestId, PaymentStatus.ERROR.name(), correlationId).subscribe();

			log.error(PaymentConstants.LOG_PREFIX + "Error processPaymentRequest: {}", correlationId, e.getMessage());
			return Mono.error(e);
		});

	}

	private Mono<Boolean> updatePaymentBatchAndPublish(PaymentDataTransferRequest paymentrequestDto, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of paymentResponse().  paymentServiceRequest: {}, paymentRequestId: {}", correlationId, paymentServiceRequest,
				paymentRequestId);

		return kafkaProducerService.publishEventToKafka(paymentrequestDto, UUID.fromString(correlationId)).flatMap(paymentRequestDataDBResponse -> {
			paymentrequestDto.setIsPaymentPublished(true);
			return batchActivityDao.updateCommunicationAndCollectionIdInBatch(paymentrequestDto, correlationId).flatMap(paymentId -> {
				Mono<Boolean> monoResponseResult = dao.updateCommunicationAndCollectionId(paymentrequestDto, correlationId);
				return monoResponseResult.flatMap(responseResult -> {
					CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForCollectionIntent(paymentServiceRequest, correlationId, paymentRequestId,
							paymentrequestDto.getFollowUpDate(), customerInteractionDescriptionConfig);
					return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, correlationId).flatMap(publishResponse -> {
						log.debug(PaymentConstants.LOG_PREFIX + "End of processPaymentRequest(). responseResult: {}", correlationId, responseResult);
						return Mono.just(responseResult);
					});
				});
			}).onErrorResume(e -> {
				updateAndPublishPayment(paymentServiceRequest, paymentRequestId, PaymentStatus.ERROR.name(), correlationId).subscribe();

				log.error(PaymentConstants.LOG_PREFIX + "Error processPaymentRequest: {}", correlationId, e.getMessage());
				return Mono.error(e);
			});
		}).onErrorResume(e -> {
			updateAndPublishPayment(paymentServiceRequest, paymentRequestId, PaymentStatus.ERROR.name(), correlationId).subscribe();

			log.error(PaymentConstants.LOG_PREFIX + "Error processPaymentRequest: {}", correlationId, e.getMessage());
			return Mono.error(e);
		});
	}

	private Mono<PaymentDataTransferRequest> getCreditCardData(PaymentDataTransferRequest dataTransferDto, String correlationId) {

		log.debug(PaymentConstants.LOG_PREFIX + "start of getCreditCardData()", correlationId);
		return getPaymentServiceResponseNew(dataTransferDto, correlationId).flatMap(creditCardresponse -> {
			dataTransferDto.setCreditCardLimit(creditCardresponse.getCreditLimit());
			dataTransferDto.setCurrentBalance(creditCardresponse.getCurrentBalance());
			dataTransferDto.setStatementDate(creditCardresponse.getStatementDate() != null ? creditCardresponse.getStatementDate().toString() : null);
			dataTransferDto.setDelinquentAmount(creditCardresponse.getDelinquentAmount());
			dataTransferDto.setDaysDelinquent(creditCardresponse.getDaysDelinquent());
			dataTransferDto.setMinimumPaymentDue(creditCardresponse.getMinimumPayment());
			dataTransferDto.setPastDueAmount(creditCardresponse.getTotalPastDue());
			dataTransferDto.setDaysPastDue(creditCardresponse.getActualDaysPastDue() != null ? creditCardresponse.getActualDaysPastDue().toString() : null);
			return Mono.just(dataTransferDto);
		});
	}

	private PaymentDetails getPaymentDetails(AccountBalanceResponse creditCardAccountOverview, PaymentServiceRequest paymentServiceRequest) {
		PaymentDetails paymentDetails = new PaymentDetails();
		LocalDate paymentDate = PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		if ((creditCardAccountOverview.getMinimumPayment().compareTo(paymentServiceRequest.getPaymentAmount()) > 1)
				&& (paymentDate.isEqual(creditCardAccountOverview.getDueDate()) || paymentDate.isBefore(creditCardAccountOverview.getDueDate()))) {
			paymentDetails.setRemainingBalance(creditCardAccountOverview.getMinimumPayment().subtract(paymentServiceRequest.getPaymentAmount()));
			paymentDetails.setPaymentDueDate(creditCardAccountOverview.getDueDate().toString());
		}
		return paymentDetails;
	}

	/**
	 * Maps the payment response for the confirmation code and available card
	 * balance.
	 *
	 * @param dtoRequest
	 * @param correlationId
	 * @return
	 */
	private Mono<AccountBalanceResponse> getPaymentServiceResponseNew(PaymentDataTransferRequest dtoRequest, String correlationId) {
		return externalCallService.getAvailableCreditBalance(dtoRequest.getCreditAccountId(), correlationId).flatMap(Mono::just);
	}

	private Mono<PaymentServiceResponse> schedulePaymentRequest(UUID newpaymentRequestId, PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dtoRequest, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of scheduleDebitPaymentRequest(). request: {}", correlationId, paymentServiceRequest);
		// validation to check if the schedule date same as any block dates and
		// max schedule date
		return validateOverallAchDebitRules(newpaymentRequestId, paymentServiceRequest, correlationId, dtoRequest).flatMap(requestDto -> {
			return processValidatedEligibleScheduleDate(newpaymentRequestId, paymentServiceRequest, dtoRequest, correlationId);

		});
	}

	private Mono<PaymentServiceResponse> processValidatedEligibleScheduleDate(UUID newpaymentRequestId, PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest requestDto, String correlationId) {
		requestDto.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_SCHEDULED.name());
		PaymentCommunicationRequest paymentCommunicationRequest = PaymentMapper.getPaymentCommunicationRequest(paymentServiceRequest, requestDto, newpaymentRequestId);

		return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId).flatMap(paymentCommunicationResponse -> {
			log.debug(PaymentConstants.LOG_PREFIX + "Response of paymentCommunication(). response: {}", correlationId, paymentCommunicationResponse);
			requestDto.setCommunicationRequestId(paymentCommunicationResponse.getCommunicationRequestId());
			requestDto.setCollectionIntentType(collectionIntentType);
			CollectionIntentRequest collectionIntentRequest = PaymentMapper.getCollectionIntentRequest(paymentServiceRequest, requestDto, newpaymentRequestId, correlationId);

			return getCollectionIntentId(collectionIntentRequest, correlationId).flatMap(collectionIntentResponse -> {
				requestDto.setCollectionIntentId(collectionIntentResponse.getCollectionIntentId());
				return dao.saveSchPaymentRequestEntity(requestDto, newpaymentRequestId).flatMap(paymentRequestDataDBResponse -> {
					return kafkaProducerService.publishEventToKafka(requestDto, UUID.fromString(correlationId)).flatMap(paymentRequestIds -> {
						PaymentServiceResponse response = new PaymentServiceResponse();
						response.setPaymentStatus(paymentRequestDataDBResponse.getRequestStatus());
						response.setPaymentConfirmation(requestDto.getPaymentConfirmation());
						response.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId().toString());
						log.debug(PaymentConstants.LOG_PREFIX + "End of scheduleDebitPaymentRequest(). response: {}", correlationId, response);
						return Mono.just(response);
					});

				});
			});
		});
	}

	private Mono<Boolean> validateEligibleScheduleDate(UUID paymentRequestId, PaymentServiceRequest paymentServiceRequest, String correlationId) {
		Mono<PaymentEligibilityDateResponse> monoPaymentEligibilityDateResponse = externalCallService.getRangeAllowedPaymentDatesFromPaymentRulesService(paymentServiceRequest,
				correlationId);
		return monoPaymentEligibilityDateResponse.flatMap(paymentEligibilityDateResponse -> {
			return paymentRulesProcessor.validateEligibleScheduleDate(paymentServiceRequest, paymentEligibilityDateResponse, correlationId);
		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error validateEligibleScheduleDate : {}", correlationId, err.getMessage());
			return dao.updatePaymentRequestEntityStatus(PaymentStatus.SCHEDULE_FAILED.name(), paymentRequestId, correlationId).flatMap(uuidUpdated -> {
				return Mono.error(err);
			});
		});
	}

	private Mono<Boolean> validateDebitSchedulePayment(UUID paymentRequestId, PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, String correlationId) {
		if (paymentDtoRequest.getIsSchedulePayment()) {
			if (PaymentType.DEBIT.name().equalsIgnoreCase(paymentServiceRequest.getPaymentType()) && !Channel.AGENT.name().equals(paymentServiceRequest.getChannel())) {
				String error = PaymentErrors.ERROR_SCHEDULED_PAYMENT_FOR_DEBIT.replace("{paymentType}", paymentServiceRequest.getPaymentType());
				error = error.replace("{channel}", paymentServiceRequest.getChannel());
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				return dao.updatePaymentRequestEntity(paymentServiceRequest, PaymentStatus.SCHEDULE_FAILED.name(), paymentRequestId, correlationId).flatMap(uuidUpdated -> {
					PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CHANNEL_IS_INVALID);
					paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
					return Mono.error(paymentDataException);
				});
			}
		}
		return Mono.just(true);
	}

	/***
	 *
	 * @param creditAccountId required to get the specific CreditCardDetailsResponse
	 *                        from List
	 * @param correlationId
	 * @return Mono of CreditCardDetailsResponse
	 */
	private Mono<AccountDetailsResponse> getCreditCardDetailsResponse(String creditAccountId, String correlationId) {
		return externalCallService.getAccountsFromCreditCardAccountsService(creditAccountId, correlationId);

	}

	/**
	 * Accepts an instance of DebitPaymentRequest and paymentRequestId from
	 * processPaymentRequest method, makes a call to getExternalbankAccounts or
	 * getCustomerDebitCard to fetch the details and routes the API to ACH or Debit
	 * Transaction service to process the payment
	 *
	 * @param paymentServiceRequest
	 * @param paymentRequestId
	 * @return Mono of UUID
	 */
	private Mono<String> sendAchDebitPaymentRequest(PaymentDataTransferRequest paymentDtoRequest, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId) {
		if (PaymentType.ACH.toString().equalsIgnoreCase(paymentServiceRequest.getPaymentType())) {
			return sendACHPaymentRequest(paymentServiceRequest, paymentRequestId, correlationId, paymentDtoRequest);
		} else {
			return externalCallService.getTokenFromDebitExternalAccountsService(paymentServiceRequest.getCustomerId(), paymentServiceRequest.getExternalAccountId(), correlationId)
					.flatMap(debitCardTokenResponse -> sendDebitPaymentRequest(paymentServiceRequest, paymentRequestId, debitCardTokenResponse, correlationId));
		}
	}

	/**
	 * Accepts an instance of DebitPaymentRequest, BankAccount and paymentRequestId
	 * from sendPaymentRequest method and invokes the API from ACH Transaction
	 * Service to process the ACH payment
	 *
	 * @param paymentServiceRequest
	 * @param paymentRequestId
	 * @param correlationId
	 * @param paymentDtoRequest
	 * @return Mono of UUID
	 */
	private Mono<String> sendACHPaymentRequest(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId, PaymentDataTransferRequest paymentDtoRequest) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of sendACHPaymentRequest(). paymentServiceRequest: {}, paymentRequestId: {}", correlationId, paymentServiceRequest,
				paymentRequestId);

		AchTransactionRequest achTransactionRequest = PaymentMapper.mapAchTransactionRequest(paymentServiceRequest, paymentRequestId, paymentDtoRequest);
		Mono<AchTransactionResponse> monoAchTransactionResponse = externalCallService.callACHTransactionServicePayment(achTransactionRequest, correlationId);
		return monoAchTransactionResponse.flatMap(achTransactionResponse -> {
			return Mono.just(achTransactionResponse.getPaymentRequestId().toString());
		}).onErrorResume(err -> {
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put(PaymentConstants.THROWABLE, err);
			parameters.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
			parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestId);
			parameters.put(PaymentConstants.INPUT_REQUEST, achTransactionRequest.toString());
			parameters.put(PaymentConstants.CORRELATION_ID, correlationId);

			return manageTransactionErrorResponse(parameters);
		});
	}

	private Mono<String> manageTransactionErrorResponse(Map<String, Object> parameters) {
		Throwable err = (Throwable) parameters.get(PaymentConstants.THROWABLE);
		PaymentServiceRequest request = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		UUID paymentRequestId = (UUID) parameters.get(PaymentConstants.PAYMENT_REQUEST_ID);
		String inputRequest = (String) parameters.get(PaymentConstants.INPUT_REQUEST);
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);

		if (err instanceof WebClientRequestException) {
			if (err.getCause() instanceof ReadTimeoutException) {
				return manageErrorTransactionPaymentResponse(request, paymentRequestId, correlationId).flatMap(managedErrorTransactionPaymentResponse -> {
					log.info(PaymentConstants.LOG_PREFIX + "Updated Payment as Retryable: {}", correlationId, managedErrorTransactionPaymentResponse);
					return Mono.just(PaymentErrors.ERROR_SERVICE_TIMEOUT);
				}).onErrorResume(errManaging -> {
					String error = "Error consuming Transaction Service request: " + inputRequest + ", error: " + errManaging.getMessage();
					log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
					return Mono.error(errManaging);
				});
			}
		}

		String error = "Error consuming Transaction Service request: " + inputRequest + ", error: " + err.getMessage();
		log.error(PaymentConstants.LOG_PREFIX + error, correlationId);

		return Mono.error(err);
	}

	private Mono<Boolean> manageErrorTransactionPaymentResponse(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId) {
		return dao.existsById(paymentRequestId, correlationId).flatMap(existsPayment -> {
			if (existsPayment) {
				Mono<PaymentRequestDataDBResponse> monoPaymentRequestEntity = dao.findByPaymentRequestId(paymentRequestId, correlationId);
				return monoPaymentRequestEntity.flatMap(paymentRequestDataDBResponse -> {
					try {
						return updateRetryable(paymentRequestDataDBResponse, paymentServiceRequest, paymentRequestId, correlationId);
					} catch (ParseException e) {
						return Mono.error(new PaymentException(e.toString()));
					}
				}).onErrorResume(Mono::error);
			}

			String error = PaymentErrors.ERROR_FINDING_PAYMENT_REQUEST.replace("{paymentId}", paymentRequestId.toString());
			return Mono.error(new PaymentException(error));
		}).onErrorResume(err -> {
			String error = "Error Updating as Retryable Payment Id: " + paymentRequestId.toString() + ", error: " + err.getMessage();
			return Mono.error(new PaymentException(error));
		});
	}

	private Mono<Boolean> updateRetryable(PaymentRequestDataDBResponse paymentRequestDataDBResponse, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String correlationId)
			throws ParseException {
		parser.reset();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		Integer numberOfRetries = 0;

		if (paymentRequestData != null && paymentRequestData.get(PaymentConstants.RETRYABLE_COUNT) != null) {
			numberOfRetries = Integer.valueOf(paymentRequestData.get(PaymentConstants.RETRYABLE_COUNT).toString()) + 1;
		}

		log.info("numberOfRetries: {}, maxRetries: {}", numberOfRetries, maxRetries);

		if (numberOfRetries >= Integer.valueOf(maxRetries)) {
			updateAndPublishPayment(paymentServiceRequest, paymentRequestId, PaymentStatus.ERROR.name(), correlationId).subscribe();
			return Mono.error(new PaymentException(PaymentErrors.ERROR_EXCEEDED_RETRIES));
		}

		paymentRequestData.put(PaymentConstants.RETRYABLE_COUNT, numberOfRetries);

		Mono<PaymentRequestDataDBResponse> monoPaymentRequestEntityUpdated = dao.updatePaymentEntityStatusPaymentRequestData(paymentRequestDataDBResponse.getPaymentRequestId(),
				PaymentStatus.RETRYABLE.name(), paymentRequestData, correlationId);
		return monoPaymentRequestEntityUpdated.flatMap(paymentRequestEntityUpdated -> {
			return Mono.just(true);
		}).onErrorResume(Mono::error);
	}

	/**
	 * Accepts an instance of DebitPaymentRequest, BankAccount and paymentRequestId
	 * from sendPaymentRequest method and invokes the API from Debit Transaction
	 * Service to process the Debit payment
	 *
	 * @param paymentServiceRequest
	 * @param paymentRequestId
	 * @return Mono of UUID
	 */
	private Mono<String> sendDebitPaymentRequest(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, GetDebitCardTokenResponse getDebitCardTokenResponse, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of sendDebitPaymentRequest(). paymentServiceRequest: {}, paymentRequestId: {}, getDebitCardTokenResponse: {}", correlationId,
				paymentServiceRequest, paymentRequestId, getDebitCardTokenResponse);

		DebitTransactionRequest debitTransactionRequest = PaymentMapper.mapDebitTransactionRequest(paymentServiceRequest, paymentRequestId, getDebitCardTokenResponse);

		Mono<DebitTransactionResponse> monoDebitTransactionResponse = externalCallService.callDebitTransactionServicePayment(debitTransactionRequest, correlationId);
		return monoDebitTransactionResponse.flatMap(debitTransactionResponse -> {
			return Mono.just(debitTransactionResponse.getPaymentRequestId());
		}).onErrorResume(err -> {
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put(PaymentConstants.THROWABLE, err);
			parameters.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
			parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentRequestId);
			parameters.put(PaymentConstants.INPUT_REQUEST, debitTransactionRequest.toString());
			parameters.put(PaymentConstants.CORRELATION_ID, correlationId);

			return manageTransactionErrorResponse(parameters);
		});
	}

	private Mono<UUID> saveNewPayment(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dtoRequest) {
		return dao.savePaymentRequestEntity(paymentServiceRequest, dtoRequest).flatMap(paymentRequestId -> {
			CustomerInteractionEvent event = CustomerInteractionProducerMapper.mapEventForInitiateAndSchedule(paymentServiceRequest, dtoRequest, paymentRequestId);
			if (PaymentModeEnum.EXPRESS_PAYMENT.getValue().equalsIgnoreCase(paymentServiceRequest.getPaymentMode().getValue())) {
				event.getEvent().getPayload()
						.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getInitiateForExpress(), paymentServiceRequest.getPaymentAmount(),
								paymentServiceRequest.getFeeAmount(),
								PaymentUtil.formatDate(PaymentUtil.toZonedDateTime(LocalDateTime.now()), PaymentConstants.DATEFORMAT_DD_MM_UUUU)));
			} else {
				event.getEvent().getPayload()
						.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getInitiateForStandard(), paymentServiceRequest.getPaymentAmount(),
								PaymentUtil.formatDate(PaymentUtil.toZonedDateTime(LocalDateTime.now()), PaymentConstants.DATEFORMAT_DD_MM_UUUU)));
			}
			if (Boolean.TRUE.equals(dtoRequest.getIsSchedulePayment())) {
				event.getEvent().getPayload()
						.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getInitiateForFuture(), paymentServiceRequest.getPaymentAmount(),
								PaymentUtil.formatDate(
										PaymentUtil.toZonedDateTime(PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE)),
										PaymentConstants.DATEFORMAT_DD_MM_UUUU),
								PaymentUtil.formatDate(PaymentUtil.toZonedDateTime(LocalDateTime.now()), PaymentConstants.DATEFORMAT_DD_MM_UUUU)));
			}
			event.getEvent().getPayload().setStatus(PaymentConstants.PAYMENT_INITIATED);
			return customerInteractionProducerProcessor.publishCustomerInteractionKafkaEvent(event, dtoRequest.getCorrelationId()).map(publishResponse -> {
				return paymentRequestId;
			});
		});
	}

	private Mono<UUID> updateAndPublishPayment(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside saveAndPublishPayment(). Request: {}, paymentRequestId: {}, paymentStatus: {}", correlationId, paymentServiceRequest,
				paymentRequestId, paymentStatus);

		return dao.updatePaymentRequestEntity(paymentServiceRequest, paymentStatus, paymentRequestId, correlationId)
				.flatMap(paymentRequestIdRes -> kafkaProducerService.publishEventToKafka(paymentServiceRequest, paymentRequestIdRes, paymentStatus, correlationId, null));
	}

	private Mono<UUID> updateErrorPayment(PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside saveAndPublishPayment(). Request: {}, paymentRequestId: {}, paymentStatus: {}", correlationId, paymentServiceRequest,
				paymentRequestId, paymentStatus);

		return dao.updatePaymentRequestEntity(paymentServiceRequest, paymentStatus, paymentRequestId, correlationId);
	}

	private Mono<UUID> updateAndsavePaymentbatch(PaymentDataTransferRequest paymentRequestDto, PaymentServiceRequest paymentServiceRequest, UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside saveAndPublishPayment(). paymentServiceRequest: {}, paymentRequestId: {}, paymentStatus: {}", correlationId,
				paymentServiceRequest, paymentRequestId, paymentStatus);
		paymentRequestDto.setStatus(PaymentEvent.PROCESSED.name());
		paymentRequestDto.setPaymentEvent(PaymentEvent.PROCESSED.name());
		return dao.saveAchDebitPaymentRequest(paymentRequestDto).flatMap(paymentRequestIdRes -> batchActivityDao.saveAchDebitBatchEntity(paymentRequestDto));
	}

	public Mono<PaymentCommunicationResponse> sendAutoPaymentNotification(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside sendAutoPaymentNotification(). paymentServiceRequest: {}", correlationId, paymentServiceRequest);
		String customerId = paymentServiceRequest.getCustomerId();

		return getCustomerNameFromCIAMAndCreditCardResponse(paymentServiceRequest, correlationId).flatMap(responseFromCIAMAndCreditCard -> {
			return externalCallService.getAccountsFromExternalAccountsServiceByID(customerId, paymentServiceRequest.getExternalAccountId(), correlationId)
					.flatMap(bankAccountResponse -> {
						Map<String, Object> parameters = new HashMap<String, Object>();
						parameters.put(PaymentConstants.CARDLASTFOUR, responseFromCIAMAndCreditCard.get(PaymentConstants.CARD_LAST4));
						parameters.put(PaymentConstants.CARDTYPE, responseFromCIAMAndCreditCard.get(PaymentConstants.CARD_TYPE));
						parameters.put(PaymentConstants.FIRSTNAME, responseFromCIAMAndCreditCard.get(PaymentConstants.FIRST_NAME));
						parameters.put(PaymentConstants.LASTNAME, responseFromCIAMAndCreditCard.get(PaymentConstants.LAST_NAME));
						parameters.put(PaymentConstants.PAYMENTAMOUNT, paymentServiceRequest.getPaymentAmount());
						parameters.put(PaymentConstants.PAYMENTBANK, bankAccountResponse.getBankName());
						parameters.put(PaymentConstants.PAYMENTDATE, paymentServiceRequest.getScheduledDate());
						parameters.put(PaymentConstants.PAYMENTLAST4, bankAccountResponse.getBankAccountLast4());
						parameters.put(PaymentConstants.EMAIL_ADDRESS, responseFromCIAMAndCreditCard.get(PaymentConstants.EMAIL_ADDRESS));
						parameters.put(PaymentConstants.INVOLVEMENT_ID, responseFromCIAMAndCreditCard.get(PaymentConstants.INVOLVEMENT_ID));
						parameters.put(PaymentConstants.COMMUNICATION_INTENT, PaymentCommunicationIntent.AUTO_PAYMENT_CONFIRMATION);
						PaymentCommunicationRequest paymentCommunicationRequest = PaymentMapper.getAutoPaymentNotificationRequest(paymentServiceRequest, parameters,
								paymentRequestId);
						return paymentCommunicationProcessor.paymentCommunication(paymentCommunicationRequest, correlationId).flatMap(Mono::just);
					});
		});
	}

	public Mono<PaymentsReplayResponse> replayPayments(PaymentsReplayRequest paymentsreplayRequest, String correlationId) {
		log.debug(PaymentConstants.LOG_PREFIX + "Inside replayPayments(). paymentsreplayRequest: {}", correlationId, paymentsreplayRequest);

		return dao.findByRequestIdsIn(paymentsreplayRequest.getPaymentRequestIds().stream().map(UUID::fromString).toList(), correlationId).flatMap(paymentRequestDataDBResponse -> {
			log.debug(PaymentConstants.LOG_PREFIX + "Records from DB  paymentRequestDataDBResponse{}", correlationId, paymentRequestDataDBResponse);
			TransactionStatus transactionStatus = new TransactionStatus();
			transactionStatus.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId().toString());
			transactionStatus.setMessage(PaymentConstants.INITIATED);
			if (paymentRequestDataDBResponse.getRequestStatus().equalsIgnoreCase(PaymentStatus.TRANSACTION_ERROR.name())) {
				paymentRequestDataDBResponse.setRequestStatus(PaymentStatus.REPLAYED.name());
				return kafkaProducerService.publishReplayEventToKafka(paymentRequestDataDBResponse, correlationId).flatMap(transaction -> {
					transactionStatus.setStatus(PaymentStatus.REPLAYED.name());
					return Mono.just(transactionStatus);
				}).onErrorResume(e -> {
					log.error(PaymentConstants.LOG_PREFIX + "Error on sending event to kafka , error {}", correlationId, e.getMessage());
					transactionStatus.setStatus(PaymentConstants.FAILED);
					transactionStatus.setMessage(PaymentErrors.TRANSACTION_REPLAY_FAILED);
					return Mono.just(transactionStatus);
				});
			} else {
				transactionStatus.setStatus(paymentRequestDataDBResponse.getRequestStatus());
				return Mono.just(transactionStatus);
			}
		}).collectList().flatMap(transactionStatusList -> {
			PaymentsReplayResponse paymentsReplayResponse = new PaymentsReplayResponse();
			paymentsReplayResponse.setTransactionsStatuses(transactionStatusList);
			log.debug(PaymentConstants.LOG_PREFIX + "Inside replayPayments(). paymentsReplayResponse: {}", correlationId, paymentsReplayResponse);
			return Mono.just(paymentsReplayResponse);
		});

	}

	public Mono<Object> validateExternalAccountsSuppression(String customerId, String bankAccountId, String correlationId, String paymentType) {
		Map<String, Object> response = new HashMap<String, Object>();
		if (paymentType.equalsIgnoreCase(PaymentType.ACH.name())) {
			return externalCallService.getAccountsFromExternalAccountsSuppressions(customerId, bankAccountId, correlationId).flatMap(suppressedExtlBankAcctResponse -> {
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_EXTERNAL_ACCOUNT_INELIGIBLE);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}).onErrorResume(err -> {
				if (err instanceof PaymentDataNotFoundException) {
					return Mono.just(response);
				}
				return Mono.error(err);
			});
		}
		return Mono.just(response);
	}
}