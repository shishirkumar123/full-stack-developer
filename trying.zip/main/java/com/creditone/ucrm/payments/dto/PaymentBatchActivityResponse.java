package com.creditone.ucrm.payments.dto;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class PaymentBatchActivityResponse {
    private UUID paymentBatchId;
    private UUID paymentRequestId;
    private String paymentBatchStatus;
    private Json paymentRequestData;
    private LocalDateTime createdTimestamp;
    private String createdBy;
    private LocalDateTime updatedTimestamp;
    private String updatedBy;
}
