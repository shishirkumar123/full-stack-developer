package com.creditone.ucrm.payments.dto;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import lombok.Data;

import java.util.UUID;

@Data
public class PaymentCommunicationRequest {
    private UUID paymentRequestId;
    private PaymentCommunicationIntent communicationIntent;
    private String communicationType;
    private PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest;
}