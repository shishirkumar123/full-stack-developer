package com.creditone.ucrm.payments.dto;

import lombok.Data;

@Data
public class PaymentCommunicationResponse {
    private String communicationStatus;
    private String communicationRequestId;
}