package com.creditone.ucrm.payments.dto;

import com.ucrm.swagger.creditcardaccountservice.model.AccountSettingResponse;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;


@Getter
@Setter
@NoArgsConstructor

public class AccountSettingListResponse extends ArrayList<AccountSettingResponse> implements Serializable {

    private static final long serialVersionUID = 1L;
}
