package com.creditone.ucrm.payments.dto;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
public class PaymentRequestDataDBResponse {
    private UUID paymentRequestId;
    private UUID individualUniqueIdentifierKey;
    private ZonedDateTime paymentDate;
    private String requestStatus;
    private UUID accountKey;
    private UUID externalAccountKey;
    private String paymentType;
    private String partnerName;
    private Json paymentRequestData;
    private LocalDateTime createdTimestamp;
    private String createdBy;
    private LocalDateTime updatedTimestamp;
    private String updatedBy;
    private String correlationId;
    private String collectionIntentId;
    private String paymentConfirmation;
    private boolean isNew;
}