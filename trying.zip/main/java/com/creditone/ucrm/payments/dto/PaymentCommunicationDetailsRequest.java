package com.creditone.ucrm.payments.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
public class PaymentCommunicationDetailsRequest {
    private String firstName;
    private String lastName;
    private String cardType;
    private String cardLast4;
    private String referenceNum;
    private BigDecimal paymentAmount;
    private ZonedDateTime paymentDate;
    private String dayOfWeek;
    private String returnDate;
    private String emailAddress;
    private UUID customerId;
    private String paymentBank;
    private String paymentLast4;
    private String involvementId;
    private String plasticCode;
}