package com.creditone.ucrm.payments.dto;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;

import java.time.ZonedDateTime;
import java.util.UUID;

@Data
public class AutoPayHistoryDBResponse {
    private UUID autoPayId;
    private UUID customerId;
    private UUID creditAccountId;
    private Boolean autoPayEnabled;
    private Json autoPayHistoryData;
    private String createdBy;
    private ZonedDateTime createdTimestamp;
    private String updatedBy;
    private ZonedDateTime updatedTimestamp;

}
