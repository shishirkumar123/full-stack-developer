package com.creditone.ucrm.payments.dto;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
public class PaymentBatchDBResponse {
    private UUID batchId;
    private String batchType;
    private String status;
    private Integer processedCount;
    private Integer errorCount;
    private ZonedDateTime startTimestamp;
    private ZonedDateTime endTimestamp;
    private String createdBy;
    private ZonedDateTime createdTimestamp;
    private String updatedBy;
    private ZonedDateTime updatedTimestamp;
    private Json parameter;
}
