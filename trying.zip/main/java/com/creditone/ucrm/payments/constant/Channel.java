package com.creditone.ucrm.payments.constant;

public enum Channel {
	WEB, MOBILE,AGENT,IVR
}