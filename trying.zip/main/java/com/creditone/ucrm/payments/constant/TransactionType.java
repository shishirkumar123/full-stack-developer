package com.creditone.ucrm.payments.constant;

public enum TransactionType {
	MICRODEPOSITS, CREDITCARDPAYMENT
}