package com.creditone.ucrm.payments.constant;

public enum PaymentStatus {

	NEW("New"),INITIATED("INITIATED"),DUPLICATE("DUPLICATE"), PENDING("Pending"), SCHEDULE("Schedule"), PROCESSED("Processed"), ERROR("Error"), CANCEL("CANCEL"),
	RETURNED("Returned"), RETRYABLE("RETRYABLE"), VOID("VOID"),SCHEDULE_FAILED("SCHEDULE_FAILED"),ELIGIBILITY_FAILED("ELIGIBILITY_FAILED"),AUTOPAY_NOTIFIED("AUTOPAY_NOTIFIED"),NO_DUE("NO_DUE"),

	PAYMENT_ACCOUNT_VERIFICATION_FAILED("PAYMENT_ACCOUNT_VERIFICATION_FAILED"), AUTO_PAY_ERROR("AUTO_PAY_ERROR"),TRANSACTION_ERROR("TRANSACTION_ERROR"),FLAG("flag"),EMAIL_FLAG("emailFlag"),REPLAYED("REPLAYED")
	,REVOKED("REVOKED"),BANK_RUPT("bankrupt"), ABANDON("abandon"),CHARGE_OFF("charged off"),LOST("lost"), STOLEN("stolen"), DELETE("delete"), FALSE("false"), TRUE("true")
	,POSTED("POSTED");


	private String value;
	
	private PaymentStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}