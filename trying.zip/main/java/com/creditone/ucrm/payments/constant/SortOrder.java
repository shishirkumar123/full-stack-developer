package com.creditone.ucrm.payments.constant;

import lombok.Getter;

@Getter
public enum SortOrder {
    asc, desc;

    private SortOrder() {}
}