package com.creditone.ucrm.payments.constant;

public enum FDRStatus {

	INITIATED("INITIATED"), PENDING("PENDING"), SCHEDULE("SCHEDULE"), PROCESSED("PROCESSED"),POSTED("POSTED"),VERIFIED("VERIFIED");

	private String value;
	
	private FDRStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}