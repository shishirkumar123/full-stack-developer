package com.creditone.ucrm.payments.constant;

import lombok.Getter;

@Getter
public enum SortField {
    scheduledDate("paymentDate"), createdTimeStamp("createdTimestamp"), creditAccountId("accountKey"),
    externalAccountId("externalAccountKey"), status("requestStatus");

    private SortField(String entityField) {
        this.entityField = entityField;
    }
    private String entityField;
}