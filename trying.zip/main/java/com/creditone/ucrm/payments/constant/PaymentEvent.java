package com.creditone.ucrm.payments.constant;

public enum PaymentEvent {

	INITIATED("INITIATED"), PENDING("PENDING"), SCHEDULE("SCHEDULE"), PROCESSED("PROCESSED");

	private String value;
	
	private PaymentEvent(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}