package com.creditone.ucrm.payments.constant;

import lombok.Getter;

@Getter
public enum PaymentType {
	ACH(Partner.FISERV.name()), DEBIT(Partner.ACI.name());
	
	private String partner;
	
	private PaymentType(String partner) {
		this.partner = partner;
	}
	
}