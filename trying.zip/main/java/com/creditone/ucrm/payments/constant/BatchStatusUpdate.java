package com.creditone.ucrm.payments.constant;

public enum BatchStatusUpdate {
    IN_PROGRESS("IN_PROGRESS"),
    COMPLETED("COMPLETED"),
    PARTIALLY_COMPLETED("PARTIALLY_COMPLETED"),
    ERROR("ERROR");

    private String value;

    private BatchStatusUpdate(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
