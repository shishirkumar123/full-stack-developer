package com.creditone.ucrm.payments.constant;

public class PaymentErrors {
	
	public static final String VALIDATION_NOT_NULL = " cannot be null";
	public static final String VALIDATION_MISSING = " is missing";
	public static final String VALIDATION_UUID = " must be a UUID";
	public static final String VALIDATION_INVALID = " is Invalid";
	public static final String VALIDATION_UTC_DATE_INVALID = " is Invalid. Date must be in UTC format uuuu-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String VALIDATION_DATE_YYYY_MM_DD_INVALID = " is Invalid. Date must be in YYYY-MM-DD";
	public static final String VALIDATION_END_DATE_WITHOUT_START_DATE = " is invalid. End Date without a valid Start date";
	public static final String VALIDATION_END_DATE_LESS_THAN_START_DATE = " is invalid. End Date should be greater than Start date";
	public static final String VALIDATION_END_DATE_LESS_THAN_CURRENT_DATE = " is invalid. End Date should be greater than Current date";
	public static final String VALIDATION_AMOUNT_NEGATIVE = " is Invalid. Cannot be negative";
	public static final String VALIDATION_INVALID_PAYMENT_DATE = "Invalid Payment Date";
	public static final String VALIDATION_INVALID_PAYMENT_TYPE = "Invalid Payment Type";
	public static final String VALIDATION_INVALID_PAYMENT_MODE_FOR_PAYMENT_TYPE = " paymentMode is Invalid for the provided paymentType";
	public static final String VALIDATION_INVALID_BATCH_PROCESS_TYPE = " batchProcessType is Invalid for the provided batch-process";
	public static final String VALIDATION_INVALID_EXTERNAL_ACCOUNT_ID = "No details available for the provided externalAccountId";
	public static final String VALIDATION_INVALID_AMOUNT_PRECISION = " is Invalid. Amounts can have a decimal precision of 2 digits";
	public static final String VALIDATION_PAYMENT_AMOUNT_REQUIRED = " is required when PaymentPurpose is OTHER.";
	public static final String VALIDATION_ENUM_INPUT_VALUE = "{value} is not a valid input for {requiredType}";
	public static final String VALIDATION_NUMBER_OF_TOKENS = " Incorrect number of tokens in dateSpan, it has {numberOfTokens}, and expected 2";
	public static final String VALIDATION_NUMERIC = " Incorrect numeric value in dateSpan, it has {value}";
	public static final String VALIDATION_INCORRECT_UNIT = " Incorrect unit in dateSpan, it has {unit}, and expected days";
	public static final String ERROR_MISSING_ENTITY = "Payment Request not available in Database";
	public static final String ERROR_NO_PAYMENT_DATA_AVAILABLE = "No payment request available for the provided input";
	public static final String ERROR_PAYMENT_NOT_IN_SCHEDULE = "Payment Request Id provided is not in schedule state";
	public static final String ERROR_PAYMENT_NOT_IN_PROCESSED_OR_PENDING = "Payment Request Id provided is not in Processed or Pending state";
	public static final String ERROR_DEBIT_TRANSACTION_VOID_FAILURE = "Debit Transaction service failed to void Payment Request Id {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_ID_NOT_FOUND = "The paymentId is not present in the ACH Error Event";
	public static final String ERROR_ACH_ERROR_TRANSACTION_TYPE_NOT_FOUND = "Transaction Type is Empty for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_CUSTOMER_ID_NOT_FOUND = "The customerId is not present for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_STATUS_NOT_FOUND = "Status is Empty for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_STATUS_INVALID = "Status {status} is not in valid Status list for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_DATE_NOT_FOUND = "Payment Date is Empty for ACH Error Event with paymentId " + "{paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_DATE_INVALID = "Payment Date is Invalid for ACH Error Event with paymentId " + "{paymentId}";
	public static final String ERROR_ACH_ERROR_RETURN_DATE_NOT_FOUND = "Return Date is Empty for ACH Error Event with paymentId " + "{paymentId}";
	public static final String ERROR_ACH_ERROR_RETURN_DATE_INVALID = "Return Date is Invalid for ACH Error Event with paymentId " + "{paymentId}";
	public static final String WARNING_ACH_ERROR_IGNORED_MESSAGE_BECAUSE_TRANSACTION_TYPE = "Ignored message because it is transaction type {transactionType} for " +
																							"ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_NOT_ONE_RECORD_DATABASE_FOUND = "One record with paymentId {paymentId} was expected and not found in database, " +
																				"they were found {numberOfRecords} records";
	public static final String ERROR_ACH_ERROR_INDIVIDUAL_UNIQUE_IDENTIFIER_NOT_FOUND_DATABASE = "Individual Unique Identifier from database record is empty with paymentId " +
																								"{paymentId}";
	public static final String ERROR_ACH_ERROR_ACCOUNT_KEY_NOT_FOUND_DATABASE = "Account Key from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_EXTERNAL_ACCOUNT_KEY_NOT_FOUND_DATABASE = "External Account Key from database record is empty with paymentId " +
																						"{paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_TYPE_NOT_FOUND_DATABASE = "Payment Type from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_TYPE_IN_DATABASE_INVALID = "Payment Type from database {paymentType} is not in valid Payment Type list for ACH Error " +
																				"Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_DATE_NOT_FOUND_DATABASE = "Payment Date from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_STATUS_NOT_FOUND_DATABASE = "Status from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_STATUS_IN_DATABASE_INVALID = "Status from database {status} is not in valid Status list for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_CREATED_BY_NOT_FOUND_DATABASE = "Created By from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_REQUEST_DATA_NOT_FOUND_DATABASE = "Payment Request Data from database record is null with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_FEE_AMOUNT_NOT_FOUND_DATABASE = "Fee Amount from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_FEE_AMOUNT_IN_DATABASE_INVALID = "Fee Amount from database {feeAmount} is not a valid value " +
																				"for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_RETRY_EXCEEDED = "Retry Count from database {retryCount} is not a valid value " +
			"for Error Event with paymentId {paymentId}";

	public static final String ERROR_ACH_ERROR_PAYMENT_AMOUNT_NOT_FOUND_DATABASE = "Payment Amount from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_AMOUNT_IN_DATABASE_INVALID = "Payment Amount from database {paymentAmount} is not a valid value " +
																					"for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_CHANNEL_NOT_FOUND_DATABASE = "Channel from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_CHANNEL_IN_DATABASE_INVALID = "Channel from database {channel} is not a valid value for ACH Error Event with paymentId " +
																			"{paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_MODE_NOT_FOUND_DATABASE = "Payment Mode from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_MODE_IN_DATABASE_INVALID = "Payment Mode from database {paymentMode} is not a valid value for ACH Error Event with paymentId " + "{paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_METADATA_NOT_FOUND_DATABASE = "Payment Metadata from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_METADATA_JSON_ARRAY = "Payment Metadata from database record is not a json array with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_METADATA_EMPTY = "Payment Metadata from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_NOTES_NOT_FOUND_DATABASE = "Notes from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_DATE_NOT_FOUND_DATABASE = "Date from Payment Metadata from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_PURPOSE_NOT_FOUND_DATABASE = "Payment Purpose from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_PAYMENT_PURPOSE_IN_DATABASE_INVALID = "Payment Purpose from database {paymentPurpose} is not a valid value for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_CREDIT_LAST4_NOT_FOUND_DATABASE = "Credit Last4 from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_ERROR_EXTERNAL_LAST4_NOT_FOUND_DATABASE = "External Last4 from database record is empty with paymentId {paymentId}";
	public static final String ERROR_ACH_INFO_RECORD_PROCESSED = "Record with paymentId {paymentId} processed";
	public static final String ERROR_ACH_ERROR_PAYMENT_METADATA_ON_RECORD_HAS_OUTDATED_FORMAT = "Payment Metadata from database has outdated format for for ACH Error Event with paymentId {paymentId}";
	public static final String ERROR_FINDING_PAYMENT_REQUEST = "Payment Id {paymentId} Not Found";
	public static final String ERROR_ELIGIBLE_PAYMENT_DATE_EMPTY_DATES_RESPONSE = "payment validation failed cannot accept new payments";
	public static final String ERROR_ELIGIBLE_PAYMENT_DATE = "Error in Scheduled Date {scheduledDate}, it is not between the range of NextEligiblePaymentDate {nextEligiblePaymentDate} and LastEligiblePaymentDate {lastEligiblePaymentDate}";
	public static final String ERROR_ELIGIBLE_PAYMENT_DATE_BLOCKED_DATE = "Error in Scheduled Date {scheduledDate}, it is the same as a blockedDate {blockedDate}";
	public static final String ERROR_SCHEDULED_PAYMENT_DATE_BLOCKED_DATE = "Error in Scheduled Date {scheduledDate}, it is the same as a blockedDate";
	public static final String ERROR_CREDITCARD_ACCOUNT_NOT_FOUND_IN_CREDITCARD_ACCOUNTS_LIST = "Credit Card Account Not Found in Credit Card List Account, customerId: {customerId}, creditCardAccount: {creditCardAccount}";
	public static final String ERROR_CREDITCARD_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT = "Credit Card Account Not Eligible for Payment, customerId: {customerId}, creditCardAccount: {creditCardAccount}";
	public static final String ERROR_CREDITCARD_ACCOUNT_NOT_ELIGIBLE_FOR_EXPRESS_PAYMENT = "Credit Card Account Not Eligible for Express Payment, customerId: {customerId}, creditCardAccount: {creditCardAccount}";
	public static final String ERROR_ELIGIBLE_AMOUNT = "Error in Payment Amount {paymentAmount}, it is not between the range of MinPaymentAmount {minPaymentAmount} and MaxPaymentAmount {maxPaymentAmount}";
	public static final String ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NULL = "Null response received from EWS for customerId: {customerId}, externalAccountId: {externalAccountId}";
    public static final String ERROR_EWS_SERVICE_VALIDATION_RESPONSE_NOT_VALID_STATUS = "EWS Validation Status {status} Account Not Status Approve or Inconclusive for customerId: {customerId}, externalAccountId: {externalAccountId}";
	public static final String ERROR_EXTERNAL_ACCOUNT_NOT_FOUND_IN_EXTERNAL_ACCOUNTS_LIST = "External Account Not Found in External List Account, customerId: {customerId}, externalAccount: {externalAccount}";
	public static final String ERROR_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT = "External Account Not Eligible for Payment, customerId: {customerId}, externalAccount: {externalAccount}";
	public static final String ERROR_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_EXPRESS_PAYMENT = "External Account Not Eligible for Express Payment, customerId: {customerId}, externalAccount: {externalAccount}";
	public static final String ERROR_DEBIT_EXTERNAL_ACCOUNT_NOT_FOUND_IN_DEBIT_ACCOUNTS_LIST = "Debit External Account Not Found in Debit List Account, customerId: {customerId}, externalAccount: {externalAccount}";
	public static final String ERROR_DEBIT_EXTERNAL_ACCOUNT_NOT_ELIGIBLE_FOR_PAYMENT = "Debit External Account Not Eligible for Payment, customerId: {customerId}, externalAccount: {externalAccount}";
	public static final String ERROR_COMMUNICATION_INTENT_PAYMENT_RETURNED_WITHOUT_PROVIDED_COMMUNICATION_DETAILS = "Communication Intent Payment Returned not allowed to be sent without Communication Details Provided";
	public static final String ERROR_DATABASE_RECORD_PAYMENT_CONFIRMATION_NULL = "Customer {customerId} has Payment Confirmation null";
	public static final String ERROR_DATABASE_RECORD_PAYMENT_AMOUNT_NULL = "Customer {customerId} has Payment Amount null";
	public static final String ERROR_DATABASE_RECORD_PAYMENT_DATE_NULL = "Customer {customerId} has Payment Date null";
	public static final String ERROR_CIAM_FIRST_NAME_LAST_NAME_NULL = "Customer {customerId} has FirstName or LastName null";
	public static final String ERROR_CONSUMING_CREDITCARD_ACCOUNTS_SERVICE_CREDITCARD_ACCOUNTS = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: {creditAccountId}, error: {errorMessage}";
	public static final String ERROR_CONSUMING_CREDITCARD_ACCOUNTS_SERVICE_CREDITCARD_ACCOUNT = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: {creditAccountId}, error: {errorMessage}";
	public static final String ERROR_CREDITCARD_ACCOUNT_EMAIL_ADDRESS_NULL = "Credit Account {creditCardAccount} has EmailAddress null, customerId: {customerId}";
	public static final String ERROR_CREDITCARD_ACCOUNT_CARD_LAST4_NULL = "Credit Account {creditCardAccount} has CardLast4 null, customerId: {customerId}";
	public static final String ERROR_CREDITCARD_ACCOUNT_CARD_TYPE_NULL = "Credit Account {creditCardAccount} has CardType null, customerId: {customerId}";
	public static final String ERROR_MAP_COMMUNICATION_TYPE_NOT_FOUND = "Map Communication Type Not Found for customerId: {customerId}, communicationIntent: {communicationIntent}";
	public static final String ERROR_EXCEEDED_RETRIES = "Error Processing Payment, Exceeded Retries";
	public static final String ERROR_CONFIRMATION_CODE = "Error in generating confirmation code";
	public static final String NO_PAYMENT_DATA_REQUEST_FOUND = "No payment request was found due to invalid data";
	public static final String ERROR_PAGE_NUMBER_PROVIDED_BUT_NOT_PAGE_SIZE = "pageSize is mandatory if page is provided";
	public static final String INVALID_EXTERNAL_ACCOUNT_ID = "invalid external account id";
	public static final String INVALID_CREDIT_ACCOUNT_ID = "invalid credit account id";
	public static final String INVALID_CUSTOMER_ID = "invalid customer id";
    public static final String ERROR_PAYMENT_CANNOT_BE_SCHEDULED = "payment cannot be scheduled";
	public static final String ERROR_PAYMENT_CANNOT_BE_PROCESSED = "payment cannot be processed";
	public static final String ERROR_SCHEDULED_PAYMENT_FOR_DEBIT = "Payment Cannot be scheduled for payment Type : {paymentType} with channel : {channel} ";
	public static final String RESOURCE_NOT_FOUND = "Resource not Found";
	public static final String JSON_ERROR_FROM_AUTO_PAY_DATA = "Error converting object to JSON string response Auto Pay Data field. Reason: ";
	public static final String JSON_ERROR_FROM_PAYMENT_REQUEST_DATA = "Error converting object to JSON string response Payment Request Data field. Reason: ";
	public static final String AUTOPAY_PROCESS_ERROR = "AutoPay cannot be processed.";
	public static final String ERROR_SERVICE_TIMEOUT="Transaction Timeout";
    public static final String INVALID_PAYMENT_PURPOSE ="Invalid Payment Purpose" ;
	public static final String ERROR_GETTING_FINAL_TOTAL_PAYMENT = "Error Getting Final Total Payment";
	public static final String ERROR_OTHER_AMOUNT_LESS_OR_EQUALS_ZERO = "Other Amount can not be less or equals to Zero";
	public static final String ERROR_AUTOPAY_NOTIFIED_RULES_VALIDATION = "Error in AutoPay Notified Rules Validation";
	public static final String AUTOPAY_ALREADY_ENROLLED = "Autopay already enrolled";
	public static final String AUTOPAY_IS_NOT_ENROLLED = "Autopay is not enrolled";
	public static final String AUTOPAY_ENROLLED_CREDIT_CARD_VALIDATION_ERROR = "Error validating CreditCard while enrolling in Autopay.";
	public static final String AUTOPAY_VALIDATION_FAILED = "Autopay validation failed. Reason: ";
	public static final String EITHER_NEWCONFIGURATION_OR_CANCELCURRENTMONTH_REQUIRED = "Either newCongifuration or cancelCurrentMonth is required";
	public static final String PAYMENT_ALREADY_SCHEDULED = "Payment is already scheduled for the current month";
	public static final String ERROR_CONSUMING_CREDITCARD_ACCOUNTS_SERVICE_FOR_CREDITCARD_ACCOUNT = "Error in Getting Accounts from CreditCardAccountService, creditAccountId: ";
	public static final String CREDIT_CARD_VALIDATION_ERROR = "Error Validating CreditCard. Error: {errorMessage}";
		
	public static final String JSON_ERROR_FROM_AUTO_PAY_OFF_CONFLICT = "Autopay already cancelled for the current month";

	public static final String PAYMENT_IS_NOT_SCHEDULED = "Payment is not scheduled";
    
	public static final String ERROR_AUTOPAY_IS_NOT_SCHEDULE = "Autopay is not scheduled";

	public static final String PREVIOUS_VERSION_NOT_AVAILABLE = "Previous version not available";

	public static final String ERROR_NOT_CREDIT_CARD_ACCOUNT_FOUND = "Received Empty Response from Credit Account Service";
	public static final String AUTOPAY_HISTORY_UPDATE_FAILED =" autoPayHistory Not Found. Update Failed.";

	public static final String AUTO_PAY_HISTORY_RECORD_NOT_FOUND = "Record Not Found !! in autoPayHistory for customerId: {} and creditAccountId: {}";
	public static final String AUTO_PAY_RECORD_NOT_FOUND = "Record Not Found !! in autoPay";
	public static final String TRANSACTION_REPLAY_FAILED = "Transaction replay failed due to validation Error";
	public static final String DUPLICATE_PAYMENT_REQUEST = "Duplicate payment request has been detected for the same amount with original paymentRequestId : ";
	public static final String ACCOUNT_NOT_IN_SUPPRESSLIST = "ExternalAccount is not in SuppressList";
	public static final String INVALID_FEE_AMOUNT = "Invalid FeeAmount";
	public static final String EXTERNAL_ACCOUNT_ID_SUPPRESSION = "External account id is in supressionList";
	public static final String ERROR_INVALID_MONEY_MOVEMENT_EVENT = "Invalid ACH Money Movement Kafka Event";
	public static final String ERROR_TRANSACTION_ID_NOT_FOUND_MONEY_MOVEMENT_EVENT = "Transaction id not found in Money Movement Kafka Event";
	public static final String ERROR_PAYMENT_REQUEST_ID_NOT_FOUND_MONEY_MOVEMENT_EVENT = "Payment request id not found in Money Movement Kafka Event";
	public static final String ERROR_STATUS_NOT_FOUND_MONEY_MOVEMENT_EVENT ="Status not found in Money Movement Kafka Event" ;
	public static final String ERROR_UPDATED_TIMESTAMP_NOT_FOUND_MONEY_MOVEMENT_EVENT = "Updated Timestamp not found in Money Movement Kafka Event";

	public static final String ERROR_PAYMENT_NOT_FOUND_MONEY_MOVEMENT_EVENT = "Payment not found in Money Movement Kafka Event";
	public static final String NO_RECORDS_ERROR = "No Records Found";
	public static final String ERROR_CANCEL_PAYMENT_IS_INVALID = "23: Microdeposit already Initiated";
	public static final String ERROR_CUSTOMER_IS_INVALID = "01: customerId is not valid";
	public static final String ERROR_SCHEDULE_PAYMENT_IS_INVALID = "01: scheduledDate is not valid";
	public static final String ERROR_CREDIT_ACCOUNT_IS_INVALID = "01: creditAccountId is not valid";
	public static final String ERROR_EXTERNAL_ACCOUNT_IS_INVALID = "01: externalAccountId is not valid";
	public static final String ERROR_AGENT_IS_INVALID = "01: agentId is not valid";
	public static final String ERROR_PAYMENT_AMOUNT_IS_INVALID = "01: paymentAmount is not valid";
	public static final String ERROR_FEE_AMOUNT_IS_INVALID = "01: feeAmount is not valid";
	public static final String ERROR_PAYMENT_TYPE_IS_INVALID = "01: paymentType is not valid";
	public static final String ERROR_PAYMENT_METADATA_IS_INVALID = "01: paymentMetadata is not valid";
	public static final String ERROR_PAYMENT_PURPOSE_IS_INVALID = "01: paymentPurpose is not valid";
	public static final String ERROR_CHANNEL_IS_INVALID = "01: Channel is not valid";
	public static final String ERROR_PAYMENT_MODE_IS_INVALID = "01: paymentMode is not valid";
	public static final String ERROR_BATCH_TYPE_IS_INVALID = "01: batchProcessType is not valid";
	public static final String ERROR_PAYMENT_STATUS_IS_INVALID = "01: paymentStatus is not valid";
	public static final String ERROR_IS_AUTOPAY_IS_INVALID = "01: isAutoPay is not valid";
	public static final String ERROR_PAYMENT_REQUEST_ID_IS_INVALID = "01: paymentRequestId is not valid";
	public static final String ERROR_NO_RECORD_FOUND = "01: No Record found";
	public static final String ERROR_START_DATE_IS_INVALID = "01: startDate is not valid";
	public static final String ERROR_END_DATE_IS_INVALID = "01:endDate is not valid";
	public static final String ERROR_START_DATE_END_DATE_IS_INVALID = "01:startDate & endDate is not valid";
	public static final String ERROR_END_DATE_IS_INVALID_03 = "03:endDate is not valid";
	public static final String ERROR_SORT_IS_INVALID = "01: sort is not valid";
	public static final String ERROR_SORT_FIELD_IS_INVALID = "01: sortField is not valid";
	public static final String ERROR_PAGE_IS_INVALID = "01: page is not valid";
	public static final String ERROR_PAGE_SIZE_IS_INVALID = "01: pageSize is not valid";
	public static final String ERROR_BATCH_PROCESS_ID_INVALID = "01:batchProcessId is not valid";
	public static final String ERROR_PAGE_SIZE_IS_MISSING = "03: pageSize is missing";
	public static final String ERROR_NO_RECORD_FOUND_CREDIT_ACCOUNT_ID = "04: No Records found for creditAccountId";
	public static final String ERROR_NO_RECORD_FOUND_AUTOPAY = "04: No Record Found for AutoPay";
	public static final String ERROR_PARSING_JSON = "05: Data Parsing Error";
	public static final String ERROR_DUPLICATE_PAYMENT_REQUEST = "26: Duplicate Payment request";
	public static final String ERROR_CREDITCARD_ACCOUNT_INELIGIBLE = "21: accountId ineligible for payment";
	public static final String ERROR_CREDITCARD_ACCOUNT_EXPRESS_PAY_INELIGIBLE = "21: credit account ineligible for payment";
	public static final String ERROR_EXTERNAL_ACCOUNT_INELIGIBLE = "21: externalAccount ineligible for payment";
	public static final String ERROR_PAYMENT_CANNOT_BE_PROCESSED_23 = "23: Payment Cannot be processed";
	public static final String ERROR_PAYMENT_RULES_PAYMENT_DATE = "27: Payment Validation Failed";
	public static final String ERROR_PAYMENT_RULES_PAYMENT_DATE_VALIDATION = "27: Payment Validation for Date failed";
	public static final String ERROR_PAYMENT_RULES_PAYMENT_AMOUNT = "28: Payment Amount Validation Failed";
	public static final String ERROR_EWS_VALIDATION = "29: External Account Validation Failed";
	public static final String ERROR_EXTERNAL_ACCOUNT_INVALID = "01: external account id is not valid";
	public static final String ERROR_PAYMENT_CAN_NOT_BE_PROCESSED = "02: payment cannot be processed";
	public static final String ERROR_EWS_UNAVAILABLE_RESPONSE = "02: EWS Partner Service is unavailable. Please try again later";
	public static final String ERROR_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE = "02: Accounts Service is unavailable. Please try again later";
	public static final String ERROR_RULES_SERVICE_UNAVAILABLE_RESPONSE = "02: Payment Rules Service is unavailable. Please try again later";
	public static final String ERROR_CIAM_UNAVAILABLE_RESPONSE = "02: CIAM Service is unavailable. Please try again later";
	public static final String ERROR_EXTERNAL_ACCOUNTS_SERVICE_UNAVAILABLE_RESPONSE = "02: External Account Service is unavailable. Please try again later";
	public static final String ERROR_COMMUNICATION_HUB_UNAVAILABLE_RESPONSE = "02: Communication Hub Service is unavailable. Please try again later";
	public static final String ERROR_DEBIT_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE = "02: Debit Transaction Service is unavailable. Please try again later";
	public static final String ERROR_ACH_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE = "02: ACH Transaction Service is unavailable. Please try again later";
	public static final String ERROR_PAYMENT_DATE_ELIGIBILITY = "21: payment date eligibility failed";
	public static final String ERROR_AUTOPAY_VALIDATION = "30: auto pay validation failed";
	public static final String ERROR_AUTOPAY_CANNOT_BE_PROCESSED = "31: auto pay cannot be processed";
	public static final String ERROR_AUTOPAY_CANNOT_BE_PROCESSED_32 = "32: auto pay cannot be processed";
	public static final String ERROR_PAYMENT_REQUEST_INVALID_CANCELLATION = "33: Payment Request id invalid for cancellation";
	public static final String ERROR_PAYMENT_BATCH_PROCESS = "33:Payment batch process failed";
	public static final String ERROR_AUTOPAY_CANNOT_BE_UNENROLLED = "34:Auto pay cannot be unenrolled";
	public static final String ERROR_ACCOUNT_INELIGIBLE_FOR_AUTOPLAY = "35:Account ineligible for auto pay enrollment";
	public static final String ERROR_FTMS_TRANSACTION_SERVICE_UNAVAILABLE_RESPONSE = "36: FTMS Transaction Service is unavailable. Please try again later";
	public static final String ERROR_FTMS_TRANSACTION_SERVICE_POSTED_RESPONSE = "37: Payment cannot be void";
	public static final String ERROR_PAYMENTS = "Error in reading paymentMetadata data from payment request data jsonb value in mapDataDBResponseToPaymentUpdatesKakfaEvent method";

	private PaymentErrors() {}

}