package com.creditone.ucrm.payments.constant;

public enum TransactionDirection {
	CREDIT, DEBIT, PAYMENT
}