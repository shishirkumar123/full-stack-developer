package com.creditone.ucrm.payments.constant;

public enum Partner {
	FISERV, ACI
}