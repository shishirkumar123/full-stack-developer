package com.creditone.ucrm.payments.constant;

public enum LineOfBusiness {
	CREDITCARD, DIGITALBANK
}