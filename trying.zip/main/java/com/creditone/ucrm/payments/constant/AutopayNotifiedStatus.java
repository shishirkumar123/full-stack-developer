package com.creditone.ucrm.payments.constant;

public enum AutopayNotifiedStatus {
    VALID("VALID"), INVALID_NOTIFICATION("INVALID_NOTIFICATION"), INVALID_NO_NOTIFICATION("INVALID_NO_NOTIFICATION"), PROCESSED("PROCESSED"), ERROR("ERROR");
    private String value;

    private AutopayNotifiedStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}