package com.creditone.ucrm.payments.config;

import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.FinTransPaymentSrvTransStatusKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.PaymentsErrorKafkaEvent;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.reactive.ReactiveKafkaConsumerTemplate;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import reactor.kafka.receiver.ReceiverOptions;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaConsumerConfiguration {

	@Bean(name = "reactiveKafkaConsumerTemplate")
    public ReactiveKafkaConsumerTemplate<String, PaymentsErrorKafkaEvent> reactiveKafkaConsumerTemplate(KafkaPropertiesConfig properties) {
        Map<String, Object> props = new HashMap<>();
        KafkaPropertiesConfig.Consumer consumerProperties = properties.getConsumer();
        KafkaPropertiesConfig.Ssl sslProperties = properties.getSsl();

        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumerProperties.getBootstrapAddress());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerProperties.getGroup_id());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumerProperties.getAuto_offset_reset());
        props.put(JsonDeserializer.TRUSTED_PACKAGES, consumerProperties.getJson_trusted_packages());
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, consumerProperties.getJson_use_type_headers());
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, consumerProperties.getJson_value_default_type());

        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, consumerProperties.getSecurity_protocol());
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslProperties.getTruststore_location());
        props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, sslProperties.getEndpoint_identification_algorithm());

        if (Boolean.FALSE.equals(sslProperties.getIs_msk())) {
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslProperties.getTruststore_password());
        }

        props.put(SaslConfigs.SASL_MECHANISM, sslProperties.getSasl_mechanism());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format("%s required username=\"%s\" " + "password=\"%s\";", sslProperties.getSasl_jaas_login_module(), consumerProperties.getSasl_username(), consumerProperties.getSasl_password()));

        ReceiverOptions<String, PaymentsErrorKafkaEvent> basicReceiverOptions = ReceiverOptions.create(props);
        basicReceiverOptions = basicReceiverOptions.subscription(Collections.singletonList(consumerProperties.getTopic()));

        return new ReactiveKafkaConsumerTemplate<String, PaymentsErrorKafkaEvent>(basicReceiverOptions);
    }
    
    @Bean(name = "reactiveKafkaFinTransactionConsumerTemplate")
    public ReactiveKafkaConsumerTemplate<String, FinTransPaymentSrvTransStatusKafkaEvent> reactiveKafkaFinTransactionConsumerTemplateFinTransaction(KafkaPropertiesConfig properties) {
        Map<String, Object> props = new HashMap<>();
        KafkaPropertiesConfig.Consumer consumer = properties.getFinTransactionConsumer();
        KafkaPropertiesConfig.Ssl sslProperties = properties.getSsl();

        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumer.getBootstrapAddress());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, consumer.getGroup_id());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumer.getAuto_offset_reset());
        props.put(JsonDeserializer.TRUSTED_PACKAGES, consumer.getJson_trusted_packages());
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, consumer.getJson_use_type_headers());
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, consumer.getJson_value_default_type());

        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, consumer.getSecurity_protocol());
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslProperties.getTruststore_location());
        props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, sslProperties.getEndpoint_identification_algorithm());
        if (Boolean.FALSE.equals(sslProperties.getIs_msk())) {
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslProperties.getTruststore_password());
        }
        props.put(SaslConfigs.SASL_MECHANISM, sslProperties.getSasl_mechanism());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format("%s required username=\"%s\" " + "password=\"%s\";", sslProperties.getSasl_jaas_login_module(), consumer.getSasl_username(), consumer.getSasl_password()));

         ReceiverOptions<String, FinTransPaymentSrvTransStatusKafkaEvent> basicReceiverOptions = ReceiverOptions.create(props);
        basicReceiverOptions = basicReceiverOptions.subscription(Collections.singletonList(consumer.getTopic()));

         return new ReactiveKafkaConsumerTemplate<String, FinTransPaymentSrvTransStatusKafkaEvent>(basicReceiverOptions);
    }

    @Bean(name = "reactiveKafkaPaymentTransactionConsumerTemplate")
    public ReactiveKafkaConsumerTemplate<String, AchPartnerMoneyMovementKafkaEvent> reactiveKafkaPaymentTransactionConsumerTemplate(KafkaPropertiesConfig properties) {
        Map<String, Object> props = new HashMap<>();
        KafkaPropertiesConfig.Consumer consumer = properties.getPaymentTransactionConsumer();
        KafkaPropertiesConfig.Ssl sslProperties = properties.getSsl();

        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumer.getBootstrapAddress());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, consumer.getGroup_id());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumer.getAuto_offset_reset());
        props.put(JsonDeserializer.TRUSTED_PACKAGES, consumer.getJson_trusted_packages());
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, consumer.getJson_use_type_headers());
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, consumer.getJson_value_default_type());

        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, consumer.getSecurity_protocol());
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslProperties.getTruststore_location());
        props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, sslProperties.getEndpoint_identification_algorithm());
        if (Boolean.FALSE.equals(sslProperties.getIs_msk())) {
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslProperties.getTruststore_password());
        }
        props.put(SaslConfigs.SASL_MECHANISM, sslProperties.getSasl_mechanism());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format("%s required username=\"%s\" " + "password=\"%s\";", sslProperties.getSasl_jaas_login_module(), consumer.getSasl_username(), consumer.getSasl_password()));

         ReceiverOptions<String, AchPartnerMoneyMovementKafkaEvent> basicReceiverOptions = ReceiverOptions.create(props);
        basicReceiverOptions = basicReceiverOptions.subscription(Collections.singletonList(consumer.getTopic()));

         return new ReactiveKafkaConsumerTemplate<String, AchPartnerMoneyMovementKafkaEvent>(basicReceiverOptions);
    }
}