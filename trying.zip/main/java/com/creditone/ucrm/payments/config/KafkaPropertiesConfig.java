package com.creditone.ucrm.payments.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka")
@Data
public class KafkaPropertiesConfig {
    private Producer producer;
    private Consumer consumer;
    private Consumer paymentTransactionConsumer;
    private Consumer finTransactionConsumer;
    private Ssl ssl;

    @Data
    public static class Producer {
        private String topic;
        private String security_protocol;
        private String compression_type_config;
        private String bootstrapAddress;
        private int delivery_timeout_ms;
        private boolean idempotence_config;
        private int batch_size_config;
        private int linger_ms_config;
        private int retries_config;
        private int max_inflight_req_per_conn;
        private int retries_backoff_ms_config;
        private int max_block_ms;
        private int request_timeout_ms;
        private int buffer_memory_config;
        private String sasl_username;
        private String sasl_password;
        private String sasl_customer_interaction_username;
        private String sasl_customer_interaction_password;
    }

    @Data
    public static class Consumer {
        private String topic;
        private String security_protocol;
        private String group_id;
        private String bootstrapAddress;
        private String auto_offset_reset;
        private String json_trusted_packages;
        private String json_use_type_headers;
        private String json_value_default_type;
        private String sasl_username;
        private String sasl_password;
      }

    @Data
    public static class Ssl {
        private String truststore_location;
        private String truststore_password;
        private String endpoint_identification_algorithm;
        private String sasl_mechanism;
        private String sasl_jaas_login_module;
        private Boolean is_msk;
    }
}