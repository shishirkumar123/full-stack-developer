package com.creditone.ucrm.payments.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "customer.interaction")
@Data
public class CustomerInteractionDescriptionConfig {

    private CustomerInteractionDescription description;

    @Data
    public static class CustomerInteractionDescription {
        private String initiateForExpress;
        private String initiateForStandard;
        private String initiateForFuture;
        private String schedule;
        private String paymentEligibilityFailed;
        private String cancel;
        private String riskyPayment;
        private String expressPayment;
        private String processedPaymentForExpress;
        private String processedPaymentForStandard;
        private String postedPayment;
        private String voidPayment;
        private String paymentBalancePosted;
        private String returnPayment;
        private String failedPayment;
        private String feeAdjustment;
        private String collectionIntent;
        private String paymentBalanceVerified;
    }
}