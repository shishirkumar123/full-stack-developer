package com.creditone.ucrm.payments.config;

import java.util.HashMap;
import java.util.Map;

import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.creditone.ucrm.payments.events.kafka.PaymentsKafkaEvent;

import reactor.kafka.sender.SenderOptions;

@Configuration
@EnableTransactionManagement
public class KafkaProducerConfiguration {
	/**
	 * Method for Kafkaproducer config
	 * 
	 * @return Map<String, Object>
	 */
	private Map<String, Object> producerConfigs(KafkaPropertiesConfig properties, String username, String password) {
		KafkaPropertiesConfig.Producer producerProperties = properties.getProducer();
		KafkaPropertiesConfig.Ssl sslProperties = properties.getSsl();

		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, producerProperties.getBootstrapAddress());
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

		props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, producerProperties.getDelivery_timeout_ms());
		props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, producerProperties.getCompression_type_config());
		props.put(ProducerConfig.BATCH_SIZE_CONFIG, producerProperties.getBatch_size_config());
		props.put(ProducerConfig.LINGER_MS_CONFIG, producerProperties.getLinger_ms_config());
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, producerProperties.getBuffer_memory_config());
		props.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, producerProperties.getMax_block_ms());
		props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, producerProperties.getRetries_backoff_ms_config());

		props.put(ProducerConfig.RETRIES_CONFIG, producerProperties.getRetries_config());
		props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, producerProperties.getRetries_backoff_ms_config());
		props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, producerProperties.isIdempotence_config());
		props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, producerProperties.getMax_inflight_req_per_conn());
//		props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, transactionalIdConfig);

		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				org.springframework.kafka.support.serializer.JsonSerializer.class);
		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, producerProperties.getSecurity_protocol());

		fillSSLPropoperties(props, sslProperties, username, password);

		return props;
	}

	private void fillSSLPropoperties(Map<String, Object> props, KafkaPropertiesConfig.Ssl sslProperties, String username, String password) {
		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslProperties.getTruststore_location());
		props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, sslProperties.getEndpoint_identification_algorithm());

		if (Boolean.FALSE.equals(sslProperties.getIs_msk())) {
			props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslProperties.getTruststore_password());
		}

		props.put(SaslConfigs.SASL_MECHANISM, sslProperties.getSasl_mechanism());
		props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format("%s required username=\"%s\" " + "password=\"%s\";", sslProperties.getSasl_jaas_login_module(), username, password));
	}
	
	/**
	 * Creates kafka producer template instance
	 * 
	 * @param properties
	 * @return ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent>
	 */
	@Bean(name = "reactiveKafkaProducerTemplate")
	public ReactiveKafkaProducerTemplate<String, PaymentsKafkaEvent> reactiveKafkaProducerTemplate(KafkaPropertiesConfig properties) {
		SenderOptions<String, PaymentsKafkaEvent> senderOptions = SenderOptions.create(producerConfigs(properties, properties.getProducer().getSasl_username(),
				properties.getProducer().getSasl_password()));
		senderOptions.maxInFlight(4096);

        return new ReactiveKafkaProducerTemplate<>(senderOptions);
    }

	/**
	 * Creates kafka producer template instance
	 *
	 * @param properties
	 * @return ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent>
	 */
	@Bean(name = "reactiveCustomerInteractionProducerTemplate")
	public ReactiveKafkaProducerTemplate<String, CustomerInteractionEvent> reactiveCustomerInteractionProducerTemplate(KafkaPropertiesConfig properties) {
		SenderOptions<String, CustomerInteractionEvent> senderOptions = SenderOptions.create(producerConfigs(properties, properties.getProducer().getSasl_customer_interaction_username(),
				properties.getProducer().getSasl_customer_interaction_password()));
		senderOptions.maxInFlight(4096);

		return new ReactiveKafkaProducerTemplate<>(senderOptions);
	}
}