package com.creditone.ucrm.payments.config;

import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;

@Configuration
public class R2DBCEntityTemplatetConfiguration {
    private String url;

    public R2DBCEntityTemplatetConfiguration(@Value(value = "${database.r2dbc.url}") String url) {
        this.url = url;
    }

    @Bean("connectionFactory")
    public ConnectionFactory connectionFactory() {
        ConnectionFactory connectionFactory = ConnectionFactories.get(url);
        return connectionFactory;
    }
    @Bean
    public R2dbcEntityTemplate r2dbcEntityTemplate (@Autowired @Qualifier("connectionFactory") ConnectionFactory connectionFactory) {
        return new R2dbcEntityTemplate(connectionFactory);
    }

}