package com.creditone.ucrm.payments.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
//import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "rulesEntityManagerFactory", basePackages = {
        "com.creditone.ucrm.payments.rules.repository" })
//@RefreshScope
public class RulesDBConfiguration {
    private String ddlAuto;
    private String formatSQL;
    private String dialect;
    private String defaultSchema;

    public RulesDBConfiguration(@Value(value = "${spring.jpa.hibernate.ddl-auto}") String ddlAuto,
                                @Value(value = "${spring.jpa.properties.hibernate.format_sql}") String formatSQL,
                                @Value(value = "${spring.jpa.properties.hibernate.dialect}") String dialect,
                                @Value(value = "${spring.jpa.properties.hibernate.default_schema}") String defaultSchema
                                      ) {
        this.ddlAuto = ddlAuto;
        this.formatSQL = formatSQL;
        this.dialect = dialect;
        this.defaultSchema = defaultSchema;
    }

    //@RefreshScope
    @Bean(name = "rulesDataSourceProperties")
    @ConfigurationProperties("spring.datasource")
    public DataSourceProperties rulesDataSourceProperties() {
        return new DataSourceProperties();
    }

    //@RefreshScope
    @Bean(name = "rulesDataSource")
    public DataSource rulesDataSource(
            @Qualifier("rulesDataSourceProperties") DataSourceProperties rulesDataSourceProperties) {
        return rulesDataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }

    //@RefreshScope
    @Bean(name = "rulesEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean primaryEntityManagerFactory(
            EntityManagerFactoryBuilder rulesEntityManagerFactoryBuilder,
            @Qualifier("rulesDataSource") DataSource rulesDataSource) {

        Map<String, String> rulesJpaProperties = new HashMap<>();
        rulesJpaProperties.put("hibernate.dialect", dialect);
        rulesJpaProperties.put("hibernate.default_schema", defaultSchema);
        rulesJpaProperties.put("hibernate.ddl-auto", ddlAuto);
        rulesJpaProperties.put("hibernate.format_sql", formatSQL);

        return rulesEntityManagerFactoryBuilder.dataSource(rulesDataSource)
                .packages("com.creditone.ucrm.payments.rules.entity").persistenceUnit("rulesDataSource")
                .properties(rulesJpaProperties).build();
    }
}