package com.creditone.ucrm.payments.config;

import com.creditone.ucrm.payments.rules.dao.EWSRulesDAO;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import java.io.IOException;

@Slf4j
//@RefreshScope
@Configuration
public class DroolsConfiguration {
	private static final KieServices kieServices = KieServices.Factory.get();
	private String accountStatusRulesDRL;
	private String accountstatusName;
	private String rtpCallRulesDrl;
	private String rtpCallRuleName;
	private EWSRulesDAO rulesDAO;

	public DroolsConfiguration(@Value(value = "${rules.accountstatus.path}") String accountStatusRulesDRL,
		@Value(value = "${rules.accountstatus.name}") String accountstatusName,
		@Value(value = "${rules.rtpCall.name}") String rtpCallRuleName,
		@Value(value = "${rules.rtpCallDrl.path}") String rtpCallRulesDrl, EWSRulesDAO rulesDAO) {
        this.accountStatusRulesDRL = accountStatusRulesDRL;
        this.rulesDAO = rulesDAO;
        this.accountstatusName=accountstatusName;
        this.rtpCallRulesDrl=rtpCallRulesDrl;
        this.rtpCallRuleName=rtpCallRuleName;
        
    }

	// @RefreshScope
	@Lazy
	@Bean
	@Qualifier("accountStatusKieContainer")
	public KieContainer accountStatusKieContainer() {
		KieFileSystem kieFileSystem = kieServices.newKieFileSystem();

		writeRules(accountstatusName, accountStatusRulesDRL, kieFileSystem);

		kieServices.newKieBuilder(kieFileSystem).buildAll();
		return kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
	}

	@Lazy
	@Bean
	@Qualifier("rtpCallKieContainer")
	public KieContainer rtpCallKieContainer() {
		KieFileSystem kieFileSystem = kieServices.newKieFileSystem();

		writeRules(rtpCallRuleName, rtpCallRulesDrl, kieFileSystem);

		kieServices.newKieBuilder(kieFileSystem).buildAll();
		return kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
	}

	private void writeRules(String ruleSet, String rulePath, KieFileSystem kieFileSystem) {
		try {
			kieFileSystem.write(rulePath, rulesDAO.loadRules(ruleSet));
		} catch (IOException e) {
			log.error("Failed. Reason: {}", e.getMessage());
		}
	}

}