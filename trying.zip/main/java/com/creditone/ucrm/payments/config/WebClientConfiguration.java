package com.creditone.ucrm.payments.config;
import com.creditone.ucrm.payments.exception.PaymentException;
import com.creditone.ucrm.payments.exception.ServiceUnavailableException;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.util.retry.Retry;

import javax.net.ssl.SSLException;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Configuration
public class WebClientConfiguration {

    private Integer maxConnections;
    private Integer retryAttempts;
    private Integer retryDurationInSeconds;
    private Integer maxInMemorySize;
    private Integer maxConnectionPool;
    private Integer maxIdleTimeSeconds;
    private Integer maxLifeTimeSeconds;
    private Integer evictInBackgroundSeconds;
    private Integer connectionTimeOutMillis;
    private Integer responseTimeOutMillis;
    private Integer readTimeOutMillis;
    private Integer writeTimeOutMillis;

    public WebClientConfiguration(@Value(value = "${config.http.max.connections}") Integer maxConnections,
                                  @Value(value = "${config.http.retry.count}") Integer retryAttempts,
                                  @Value(value = "${config.http.retry.duration.seconds}") Integer retryDurationInSeconds,
                                  @Value(value = "${config.http.max.inmemory.size}") Integer maxInMemorySize,
                                  @Value(value = "${config.http.max.connection.pool}") Integer maxConnectionPool,
                                  @Value(value = "${config.http.max.idle.time.seconds}") Integer maxIdleTimeSeconds,
                                  @Value(value = "${config.http.max.life.time.seconds}") Integer maxLifeTimeSeconds,
                                  @Value(value = "${config.http.max.evictinbackground.seconds}") Integer evictInBackgroundSeconds,
                                  @Value(value = "${config.http.max.connection.timeout.millis}") Integer connectionTimeOutMillis,
                                  @Value(value = "${config.http.max.response.timeout.millis}") Integer responseTimeOutMillis,
                                  @Value(value = "${config.http.max.read.timeout.millis}") Integer readTimeOutMillis,
                                  @Value(value = "${config.http.max.write.timeout.millis}") Integer writeTimeOutMillis) {
        this.maxConnections = maxConnections;
        this.retryAttempts = retryAttempts;
        this.retryDurationInSeconds = retryDurationInSeconds;
        this.maxInMemorySize = maxInMemorySize;
        this.maxConnectionPool = maxConnectionPool;
        this.maxIdleTimeSeconds = maxIdleTimeSeconds;
        this.maxLifeTimeSeconds = maxLifeTimeSeconds;
        this.evictInBackgroundSeconds = evictInBackgroundSeconds;
        this.connectionTimeOutMillis = connectionTimeOutMillis;
        this.responseTimeOutMillis = responseTimeOutMillis;
        this.readTimeOutMillis = readTimeOutMillis;
        this.writeTimeOutMillis = writeTimeOutMillis;
    }

    @Bean("paymentsObjectMapper")
    public ObjectMapper paymentsObjectMapper(Jackson2ObjectMapperBuilder mapperBuilder) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.findAndRegisterModules();
        return objectMapper;
    }

    @Bean("paymentsWebClient")
    @DependsOn("paymentsObjectMapper")
    public WebClient paymentsWebClient(@Autowired @Qualifier("paymentsObjectMapper") ObjectMapper objectMapper) {
        ConnectionProvider provider = ConnectionProvider.builder("custom").maxConnections(maxConnections)
                .maxIdleTime(Duration.ofSeconds(maxIdleTimeSeconds)).maxLifeTime(Duration.ofSeconds(maxLifeTimeSeconds)).pendingAcquireMaxCount(maxConnectionPool)
                .evictInBackground(Duration.ofSeconds(evictInBackgroundSeconds)).build();

        HttpClient httpClient = HttpClient.create(provider).secure(t -> {
                    try {
                        t.sslContext(SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build());
                    } catch (SSLException e) {
                        throw new PaymentException(e.getMessage());
                    }
                }).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeOutMillis).responseTimeout(Duration.ofMillis(responseTimeOutMillis))
                .doOnConnected(conn -> conn.addHandlerFirst(new ReadTimeoutHandler(readTimeOutMillis, TimeUnit.MILLISECONDS))
                        .addHandlerLast(new WriteTimeoutHandler(writeTimeOutMillis, TimeUnit.MILLISECONDS)));

        final ExchangeStrategies exchangeStrategies = ExchangeStrategies.builder().codecs(clientCodecConfigurer -> {
            clientCodecConfigurer.defaultCodecs()
                    .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper, MediaType.APPLICATION_JSON));
            clientCodecConfigurer.defaultCodecs()
                    .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper, MediaType.APPLICATION_JSON));
        }).build();

        return WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient))
                .filter(buildRetryExchangeFilterFunction()).exchangeStrategies(exchangeStrategies)
                .defaultHeaders(httpHeaders -> {
                    httpHeaders.set("Content-Type", "application/json");
                }).build();
    }

    private ExchangeFilterFunction buildRetryExchangeFilterFunction() {
        return (request, next) -> next.exchange(request)
                .retryWhen(Retry.backoff(retryAttempts, Duration.ofSeconds(retryDurationInSeconds))
                        .filter(HttpTimeoutException.class::isInstance)
                        .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                            throw new ServiceUnavailableException("Failed to process after max retries");
                        }));
    }

}