package com.creditone.ucrm.payments.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.r2dbc.convert.R2dbcCustomConversions;
import org.springframework.data.r2dbc.dialect.PostgresDialect;

import com.creditone.microservice.type.JSONObjectToJsonConverter;
import com.creditone.microservice.type.JsonToJSONObjectConverter;

@Configuration
public class JSONObjectConverterConfiguration {
	
	@Bean
	public R2dbcCustomConversions jsonObjectConversions() {
		List<Converter<?, ?>> converters = new ArrayList<>();
		converters.add(new JsonToJSONObjectConverter());
		converters.add(new JSONObjectToJsonConverter());
		
		return R2dbcCustomConversions.of(PostgresDialect.INSTANCE, converters);
	}

}