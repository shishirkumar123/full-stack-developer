package com.creditone.ucrm.payments.dao;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ucrm.swagger.paymentservice.model.*;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.AutoPayDBResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.AutoPayEntity;
import com.creditone.ucrm.payments.model.AutoPayHistoryEntity;
import com.creditone.ucrm.payments.util.PaymentUtil;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class AutoPayMapper {
	public static AutoPayDBResponse fromAutoPayEntityToAutoPayDBResponse(AutoPayEntity autoPayEntity) {
		AutoPayDBResponse autoPayDBResponse = new AutoPayDBResponse();
		autoPayDBResponse.setAutoPayId(autoPayEntity.getAutoPayId());
		autoPayDBResponse.setCustomerId(autoPayEntity.getCustomerId());
		autoPayDBResponse.setCreditAccountId(autoPayEntity.getCreditAccountId());
		autoPayDBResponse.setPaymentDay(autoPayEntity.getAutoPaymentDay());
		autoPayDBResponse.setAutoPayData(autoPayEntity.getAutoPayData());
		autoPayDBResponse.setCreatedBy(autoPayEntity.getCreatedBy());
		autoPayDBResponse.setCreatedTimestamp(autoPayEntity.getCreatedTimestamp());
		autoPayDBResponse.setUpdatedBy(autoPayEntity.getUpdatedBy());
		autoPayDBResponse.setUpdatedTimestamp(autoPayEntity.getUpdatedTimestamp());
		return autoPayDBResponse;
	}

	public static AutoPayEntity mappingFromAutoPayDBResponseToAutoPayEntity(AutoPayDBResponse autoPayDBResponse) {
		AutoPayEntity autoPayEntity = new AutoPayEntity();
		autoPayEntity.setAutoPayId(autoPayDBResponse.getAutoPayId());
		autoPayEntity.setCustomerId(autoPayDBResponse.getCustomerId());
		autoPayEntity.setCreditAccountId(autoPayDBResponse.getCreditAccountId());
		autoPayEntity.setAutoPaymentDay(autoPayDBResponse.getPaymentDay());
		autoPayEntity.setAutoPayData(autoPayDBResponse.getAutoPayData());
		autoPayEntity.setCreatedBy(autoPayDBResponse.getCreatedBy());
		autoPayEntity.setCreatedTimestamp(autoPayDBResponse.getCreatedTimestamp());
		autoPayEntity.setUpdatedBy(autoPayDBResponse.getUpdatedBy());
		autoPayEntity.setUpdatedTimestamp(PaymentUtil.utcNow());
		return autoPayEntity;
	}

	public static AutoPayEntity mapAutoPayEntity(Map<String, Object> parameters) {
		UUID customerId = UUID.fromString((String) parameters.get(PaymentConstants.CUSTOMER_ID));
		UUID creditAccountId = UUID.fromString((String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID));
		int dueInDays = (int) parameters.get(PaymentConstants.JSON_PROPERTY_DUE_IN_DAYS);
		AutoPayRequest request = (AutoPayRequest) parameters.get(PaymentConstants.AUTO_PAY_REQUEST);
		UUID autoPayId = (UUID) parameters.get(PaymentConstants.AUTO_PAY_ID);
		AutoPayEntity autoPayEntity1 = new AutoPayEntity();
		autoPayEntity1.setAutoPayId(autoPayId);
		autoPayEntity1.setCustomerId(customerId);
		autoPayEntity1.setCreditAccountId(creditAccountId);
		JSONObject data = getJsonObject(parameters);
		autoPayEntity1.setAutoPayData(Json.of(data.toJSONString()));
		autoPayEntity1.setCreatedBy(request.getAgentId());
		autoPayEntity1.setCreatedTimestamp(PaymentUtil.utcNow());
		autoPayEntity1.setUpdatedBy(request.getAgentId());
		autoPayEntity1.setUpdatedTimestamp(PaymentUtil.utcNow());
		autoPayEntity1.setAutoPaymentDay(dueInDays);
		return autoPayEntity1;
	}

	public static AutoPayResponse maptoEnableAutoPayResponse(AutoPayRequest request, Map<String, Object> parameters) {
		AutoPayResponse autoPayResponse = new AutoPayResponse();
		autoPayResponse.externalAccountId(request.getExternalAccountId());
		autoPayResponse.externalAccountBankName((String) parameters.get(PaymentConstants.EXTERNAL_BANK_NAME));
		autoPayResponse.externalAccountLast4((String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		autoPayResponse.paymentPurpose(
				AutoPayResponse.PaymentPurposeEnum.valueOf(String.valueOf(request.getPaymentPurpose())));
		autoPayResponse.paymentAmount(request.getPaymentAmount() != null ? request.getPaymentAmount() :BigDecimal.ZERO);
		
		autoPayResponse.firstAutoPayDate((String) parameters.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		autoPayResponse.setCommunicationRequestId((String) parameters.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
		
		autoPayResponse.channel(request.getChannel());
		autoPayResponse.agentId(request.getAgentId());
		return autoPayResponse;
	}

	public static JSONObject getJsonObject(Map<String, Object> parameters) {
		AutoPayRequest request = (AutoPayRequest) parameters.get(PaymentConstants.AUTO_PAY_REQUEST);
		JSONObject data = new JSONObject();
		data.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, request.getExternalAccountId());
		data.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, parameters.get(PaymentConstants.CARD_LAST4));
		data.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		data.put(PaymentConstants.EXTERNAL_BANK_NAME, parameters.get(PaymentConstants.EXTERNAL_BANK_NAME));
		data.put(PaymentConstants.PAYMENT_AMOUNT, request.getPaymentAmount() != null ? request.getPaymentAmount() : 0);
		data.put(PaymentConstants.PAYMENT_PURPOSE, String.valueOf(request.getPaymentPurpose()));
		data.put(PaymentConstants.FIRST_AUTO_PAY_DATE, parameters.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		data.put(PaymentConstants.AGENT_ID, request.getAgentId());
		data.put(PaymentConstants.CHANNEL, request.getChannel());
		return data;
	}

	public static AutoPayConfiguration mappingFromAutoPayDBResponseToAutoConfiguration(AutoPayDBResponse autoPayDBResponse, String correlationId) {
		if (autoPayDBResponse == null) {
			return null;
		}

		AutoPayConfiguration autoPayConfiguration = new AutoPayConfiguration();
		autoPayConfiguration.setAutoPayId(autoPayDBResponse.getAutoPayId().toString());
		if (autoPayDBResponse.getCreatedTimestamp() != null) {
			autoPayConfiguration.setAutoPayEventDate(PaymentUtil.formatDate(autoPayDBResponse.getUpdatedTimestamp(), PaymentConstants.YYYY_MM_DD));
		}
		autoPayConfiguration.setAutoPaymentDay(autoPayDBResponse.getPaymentDay());

		fillParametersAutoPayConfiguration(autoPayDBResponse, autoPayConfiguration, correlationId);

		return autoPayConfiguration;
	}

	private static void fillParametersAutoPayConfiguration(AutoPayDBResponse autoPayDBResponse, AutoPayConfiguration autoPayConfiguration, String correlationId) {
		JSONParser parser = new JSONParser();

		JSONObject dataParams = null;
		if (autoPayDBResponse.getAutoPayData() != null) {
			try {
				dataParams = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
			}
			catch (ParseException e) {
				String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				throw paymentDataException;
			}
			String externalAccountId = (dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_ID) != null) ? dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_ID).toString() : null;
			autoPayConfiguration.setExternalAccountId(externalAccountId);

			String externalAccountLast4 = (dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4) != null) ? dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4).toString() : null;
			autoPayConfiguration.setExternalAccountLast4(externalAccountLast4);

			String externalBankName = (dataParams.get(PaymentConstants.EXTERNAL_BANK_NAME) != null) ? dataParams.get(PaymentConstants.EXTERNAL_BANK_NAME).toString() : null;
			autoPayConfiguration.setExternalBankName(externalBankName);

			String paymentPurpose = (dataParams.get(PaymentConstants.PAYMENT_PURPOSE) != null) ? dataParams.get(PaymentConstants.PAYMENT_PURPOSE).toString() : null;
			autoPayConfiguration.setPaymentPurpose(paymentPurpose);

			Double paymentAmount = (dataParams.get(PaymentConstants.PAYMENT_AMOUNT) != null) ? Double.valueOf(dataParams.get(PaymentConstants.PAYMENT_AMOUNT).toString()) : null;
			autoPayConfiguration.setPaymentAmount(paymentAmount);
		}
	}

	 public static AutoPayHistoryEntity getAutoPayHistoryEntity(AutoPayEntity savedEntity, String communicationRequestId, String correlationId) {
	        AutoPayHistoryEntity historyEntity = new AutoPayHistoryEntity();
	        historyEntity.setNew(true);
	        historyEntity.setAutoPayId(savedEntity.getAutoPayId());
	        historyEntity.setCustomerId(savedEntity.getCustomerId());
	        historyEntity.setCreditAccountId(savedEntity.getCreditAccountId());

	        Json autoPayHistoryData = getAutoPayHistoryData(communicationRequestId, savedEntity, correlationId);
	        historyEntity.setAutoPayHistoryData(autoPayHistoryData);

	        historyEntity.setCreatedBy(savedEntity.getCreatedBy());
	        historyEntity.setCreatedTimestamp(savedEntity.getCreatedTimestamp());
	        historyEntity.setUpdatedBy(savedEntity.getUpdatedBy());
	        historyEntity.setAutoPayEnabled(true);
	        historyEntity.setUpdatedTimestamp(savedEntity.getUpdatedTimestamp());
	        return historyEntity;
	}

	public static Json getAutoPayHistoryData(String communicationRequestId, AutoPayEntity autoPayEntity, String correlationId) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode autoPayHistoryNode = mapper.createObjectNode();
		ArrayNode autoPayHistoryArray = mapper.createArrayNode();
		ObjectNode historyData = mapper.createObjectNode();
		Json autoPayData = autoPayEntity.getAutoPayData();

		try {
			JsonNode autoPayDataNode = mapper.readTree(autoPayData.asArray());
			fillHistoryDataForGetAutoPayHistoryEntity(communicationRequestId, autoPayEntity, historyData, autoPayDataNode);

			autoPayHistoryArray.add(historyData);
			autoPayHistoryNode.set(PaymentConstants.AUTO_PAY_HISTORY, autoPayHistoryArray);
		}
		catch (IOException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}

		return Json.of(autoPayHistoryNode.toString());
	}

	private static void fillHistoryDataForGetAutoPayHistoryEntity(String communicationRequestId, AutoPayEntity autoPayEntity, ObjectNode historyData, JsonNode autoPayDataNode) {
		historyData.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, autoPayDataNode.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
		historyData.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, autoPayDataNode.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		historyData.put(PaymentConstants.EXTERNAL_BANK_NAME, autoPayDataNode.get(PaymentConstants.EXTERNAL_BANK_NAME));
		historyData.put(PaymentConstants.PAYMENT_PURPOSE, autoPayDataNode.get(PaymentConstants.PAYMENT_PURPOSE));
		historyData.put(PaymentConstants.PAYMENT_AMOUNT, autoPayDataNode.get(PaymentConstants.PAYMENT_AMOUNT));
		historyData.put(PaymentConstants.AUTO_PAY_EVENT_DATE, autoPayEntity.getCreatedTimestamp().format(DateTimeFormatter.ofPattern(PaymentConstants.DATEFORMAT)));
		historyData.put(PaymentConstants.FIRST_AUTO_PAY_DATE, autoPayDataNode.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		historyData.put(PaymentConstants.AUTO_PAY_EVENT_STATUS, PaymentConstants.ENABLED);
		historyData.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);
		historyData.put(PaymentConstants.CHANNEL, autoPayDataNode.get(PaymentConstants.CHANNEL));
		historyData.put(PaymentConstants.AGENT_ID, autoPayDataNode.get(PaymentConstants.AGENT_ID));
	}

	public static AutoPayHistoryEntity getAutoPayHistoryEntity(AutoPayDBResponse autoPayDBResponse, String communicationRequestId, String correlationId) {
		AutoPayHistoryEntity historyEntity = new AutoPayHistoryEntity();
		historyEntity.setNew(true);
		historyEntity.setAutoPayId(autoPayDBResponse.getAutoPayId());
		historyEntity.setCustomerId(autoPayDBResponse.getCustomerId());
		historyEntity.setCreditAccountId(autoPayDBResponse.getCreditAccountId());

		Json autoPayHistoryData = getAutoPayHistoryData(communicationRequestId, autoPayDBResponse, correlationId);
		historyEntity.setAutoPayHistoryData(autoPayHistoryData);

		historyEntity.setCreatedBy(autoPayDBResponse.getCreatedBy());
		historyEntity.setCreatedTimestamp(autoPayDBResponse.getCreatedTimestamp());
		historyEntity.setUpdatedBy(autoPayDBResponse.getUpdatedBy());
		historyEntity.setAutoPayEnabled(true);
		historyEntity.setUpdatedTimestamp(PaymentUtil.utcNow());
		return historyEntity;
	}

	public static Json getAutoPayHistoryData(String communicationRequestId, AutoPayDBResponse autoPayDBResponse, String correlationId) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode autoPayHistoryNode = mapper.createObjectNode();
		ArrayNode autoPayHistoryArray = mapper.createArrayNode();
		ObjectNode historyData = mapper.createObjectNode();
		Json autoPayData = autoPayDBResponse.getAutoPayData();

		try {
			JsonNode autoPayDataNode = mapper.readTree(autoPayData.asArray());
			fillHistoryDataForGetAutoPayHistoryData(communicationRequestId, autoPayDBResponse, historyData, autoPayDataNode);

			autoPayHistoryArray.add(historyData);
			autoPayHistoryNode.set(PaymentConstants.AUTO_PAY_HISTORY, autoPayHistoryArray);
		}
		catch (IOException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		return Json.of(autoPayHistoryNode.toString());
	}

	private static void fillHistoryDataForGetAutoPayHistoryData(String communicationRequestId, AutoPayDBResponse autoPayDBResponse, ObjectNode historyData, JsonNode autoPayDataNode) {
		historyData.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, autoPayDataNode.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
		historyData.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, autoPayDataNode.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		historyData.put(PaymentConstants.EXTERNAL_BANK_NAME, autoPayDataNode.get(PaymentConstants.EXTERNAL_BANK_NAME));
		historyData.put(PaymentConstants.PAYMENT_PURPOSE, autoPayDataNode.get(PaymentConstants.PAYMENT_PURPOSE));
		historyData.put(PaymentConstants.PAYMENT_AMOUNT, autoPayDataNode.get(PaymentConstants.PAYMENT_AMOUNT));
		historyData.put(PaymentConstants.AUTO_PAY_EVENT_DATE, autoPayDBResponse.getCreatedTimestamp().format(DateTimeFormatter.ofPattern(PaymentConstants.DATEFORMAT)));
		historyData.put(PaymentConstants.FIRST_AUTO_PAY_DATE, autoPayDataNode.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		historyData.put(PaymentConstants.AUTO_PAY_EVENT_STATUS, PaymentConstants.ENABLED);
		historyData.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);
		historyData.put(PaymentConstants.CHANNEL, autoPayDataNode.get(PaymentConstants.CHANNEL));
		historyData.put(PaymentConstants.AGENT_ID, autoPayDataNode.get(PaymentConstants.AGENT_ID));
		historyData.put(PaymentConstants.VERSION, PaymentConstants.ONE);
	}

	public static JSONObject getUpdateJsonObject(Map<String, Object> parameters, Json autoPayData, String correlationId) {
		UpdateAutoPayRequest request = (UpdateAutoPayRequest) parameters.get(PaymentConstants.UPDATE_AUTO_PAY_REQUEST);
		JSONParser parser = new JSONParser();
		JSONObject dataParams = null;
		JSONObject data = new JSONObject();
		String firstAutoPayDate = null;
		BigDecimal paymentAmount =PaymentMapper.convertObjectToBigDecimal((Object)parameters.get(PaymentConstants.PAYMENT_AMOUNT));
		if (autoPayData != null) {
			try {
				dataParams = (JSONObject) parser.parse(autoPayData.asString());
			}
			catch (ParseException e) {
				String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				throw paymentDataException;
			}
			firstAutoPayDate = (dataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE) != null) ? dataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE).toString() : null;
			paymentAmount = PaymentMapper.convertObjectToBigDecimal((Object)dataParams.get(PaymentConstants.PAYMENT_AMOUNT));
		}
		if(request.getPaymentAmount()==null){
			parameters.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount);
		}

		data.put(PaymentConstants.EXTERNAL_ACCOUNT_ID,request.getExternalAccountId());
		data.put(PaymentConstants.PAYMENT_AMOUNT, (request.getPaymentAmount()!=null)?request.getPaymentAmount():paymentAmount);
		data.put(PaymentConstants.PAYMENT_PURPOSE,String.valueOf(request.getPaymentPurpose()));
		data.put(PaymentConstants.FIRST_AUTO_PAY_DATE, firstAutoPayDate);
		data.put(PaymentConstants.AGENT_ID, request.getAgentId());
		data.put(PaymentConstants.CHANNEL, request.getChannel());
		data.put(PaymentConstants.AUTO_PAY_OFF, dataParams.get(PaymentConstants.AUTO_PAY_OFF));

		data.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		data.put(PaymentConstants.EXTERNAL_BANK_NAME, parameters.get(PaymentConstants.EXTERNAL_BANK_NAME));

		return data;
	}

	public static PaymentCommunicationDetailsRequest getAutoPayCommunicationDetailsRequest(Map<String, Object> parameters) {
		Map<String, String> responseFromCIAMAndCreditCard = (Map<String, String>) parameters.get(PaymentConstants.RESPONSE_FROM_CIAM_AND_CREDITCARD);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal((Object) parameters.get(PaymentConstants.PAYMENT_AMOUNT));
		String customerId = (String) parameters.get(PaymentConstants.CUSTOMER_ID);
		String paymentBank = (String) parameters.get(PaymentConstants.EXTERNAL_BANK_NAME);
		String paymentLast4 = (String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
		String paymentDate = (String) parameters.get(PaymentConstants.PAYMENTDATE);

		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setFirstName(responseFromCIAMAndCreditCard.get("firstName"));
		paymentCommunicationDetailsRequest.setLastName(responseFromCIAMAndCreditCard.get("lastName"));
		paymentCommunicationDetailsRequest.setCardType(responseFromCIAMAndCreditCard.get("cardType"));
		paymentCommunicationDetailsRequest.setCardLast4(responseFromCIAMAndCreditCard.get("cardLast4"));
		paymentCommunicationDetailsRequest.setPaymentBank(paymentBank);
		paymentCommunicationDetailsRequest.setPaymentAmount(paymentAmount);
		paymentCommunicationDetailsRequest.setPaymentLast4(paymentLast4);

		paymentCommunicationDetailsRequest.setEmailAddress(responseFromCIAMAndCreditCard.get("emailAddress"));
		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(customerId));

		String dayOfWeek = PaymentUtil.getCurrentDayOfWeek();
		paymentCommunicationDetailsRequest.setDayOfWeek(dayOfWeek);

		paymentCommunicationDetailsRequest.setPaymentDate(PaymentUtil.getZonedDateTime(paymentDate));

		LocalDateTime localDateTime = LocalDateTime.now();
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		String returnDate = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATEFORMAT_MM_DD_UUUU);
		paymentCommunicationDetailsRequest.setReturnDate(returnDate);
		return paymentCommunicationDetailsRequest;
	}

	public static PaymentCommunicationDetailsRequest getNotifyAutoPayCommunicationDetailsRequest(Map<String, Object> parameters) {
		String firstName = (String) parameters.get(PaymentConstants.FIRST_NAME);
		String lastName = (String)parameters.get(PaymentConstants.LAST_NAME);
		String cardType = (String)parameters.get(PaymentConstants.CARD_TYPE);
		String cardLast4 = (String)parameters.get(PaymentConstants.CARD_LAST4);
		String paymentLast4 = (String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
		String paymentBank = (String) parameters.get(PaymentConstants.EXTERNAL_BANK_NAME);
		String involvementId = (String)parameters.get(PaymentConstants.INVOLVEMENT_ID);

		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest)parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);

		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setFirstName(firstName);
		paymentCommunicationDetailsRequest.setLastName(lastName);
		paymentCommunicationDetailsRequest.setCardType(cardType);
		paymentCommunicationDetailsRequest.setCardLast4(cardLast4);
		paymentCommunicationDetailsRequest.setPaymentLast4(paymentLast4);
		paymentCommunicationDetailsRequest.setPaymentAmount(paymentServiceRequest.getPaymentAmount());

		String scheduledDate = paymentServiceRequest.getScheduledDate();
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(scheduledDate, PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);

		paymentCommunicationDetailsRequest.setPaymentDate(zonedDateTime);
		paymentCommunicationDetailsRequest.setPaymentBank(paymentBank);

		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(paymentServiceRequest.getCustomerId()));
		paymentCommunicationDetailsRequest.setInvolvementId(involvementId);

		return paymentCommunicationDetailsRequest;
	}

	public static JSONObject getUpdatedAutoPayData(Json autoPayData, String agentId, String cancelCurrentMonth, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject dataParams = null;
		JSONObject data = new JSONObject();

		if (autoPayData != null) {
			try {
				dataParams = (JSONObject) parser.parse(autoPayData.asString());
			}
			catch (ParseException e) {
				String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
				log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				throw paymentDataException;
			}

			data.put(PaymentConstants.AGENT_ID, dataParams.get(PaymentConstants.AGENT_ID));
			data.put(PaymentConstants.CHANNEL, dataParams.get(PaymentConstants.CHANNEL));
			data.put(PaymentConstants.PAYMENT_AMOUNT, dataParams.get(PaymentConstants.PAYMENT_AMOUNT));
			data.put(PaymentConstants.PAYMENT_PURPOSE, dataParams.get(PaymentConstants.PAYMENT_PURPOSE));
			data.put(PaymentConstants.EXTERNAL_BANK_NAME, dataParams.get(PaymentConstants.EXTERNAL_BANK_NAME));
			data.put(PaymentConstants.FIRST_AUTO_PAY_DATE, dataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
			data.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
			data.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, dataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));

			setDataForAutoPayOff(agentId, cancelCurrentMonth, dataParams, data);
		}
		return data;
	}

	private static void setDataForAutoPayOff(String agentId, String cancelCurrentMonth, JSONObject dataParams, JSONObject data) {
		JSONObject autoPayOffData = new JSONObject();
		if (dataParams.get(PaymentConstants.AUTO_PAY_OFF) != null) {
			JSONArray existingAutoPayOff = (JSONArray) dataParams.get(PaymentConstants.AUTO_PAY_OFF);
			autoPayOffData.put(PaymentConstants.CANCELLATION_MONTH, cancelCurrentMonth);
			autoPayOffData.put(PaymentConstants.AGENT_ID, agentId);
			existingAutoPayOff.add(autoPayOffData);
			data.put(PaymentConstants.AUTO_PAY_OFF, existingAutoPayOff);
		} else {
			JSONArray autoPayOff = new JSONArray();
			autoPayOffData.put(PaymentConstants.CANCELLATION_MONTH, cancelCurrentMonth);
			autoPayOffData.put(PaymentConstants.AGENT_ID, agentId);
			autoPayOff.add(autoPayOffData);
			data.put(PaymentConstants.AUTO_PAY_OFF, autoPayOff);
		}
	}

	public static AutoPayResponse mapToAutoPayResponseFromUpdateAutoPayResponse(Map<String, Object> parameters) {

		UpdateAutoPayRequest updateAutoPayRequest = (UpdateAutoPayRequest)parameters.get(PaymentConstants.UPDATE_AUTO_PAY_REQUEST);

		AutoPayResponse autoPayResponse = new AutoPayResponse();
		if(updateAutoPayRequest!=null){
			autoPayResponse.externalAccountId(updateAutoPayRequest.getExternalAccountId());
			autoPayResponse.channel(updateAutoPayRequest.getChannel());
			autoPayResponse.agentId(updateAutoPayRequest.getAgentId());
		}

		if(parameters.get(PaymentConstants.PAYMENT_PURPOSE) != null) {
			autoPayResponse.paymentPurpose(AutoPayResponse.PaymentPurposeEnum.valueOf(String.valueOf(parameters.get(PaymentConstants.PAYMENT_PURPOSE))));
		}
		autoPayResponse.paymentAmount((BigDecimal)parameters.get(PaymentConstants.PAYMENT_AMOUNT));
		autoPayResponse.externalAccountBankName((String) parameters.get(PaymentConstants.EXTERNAL_BANK_NAME));
		autoPayResponse.externalAccountLast4((String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));


		return autoPayResponse;
	}
}