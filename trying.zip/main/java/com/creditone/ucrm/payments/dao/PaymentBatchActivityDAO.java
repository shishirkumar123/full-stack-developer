package com.creditone.ucrm.payments.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.creditone.ucrm.payments.dto.PaymentBatchActivityResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.PaymentBatchActivityEntity;
import com.creditone.ucrm.payments.repository.PaymentBatchActivityRepository;
import com.creditone.ucrm.payments.util.PaymentUtil;

import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class PaymentBatchActivityDAO {
	private PaymentBatchActivityRepository paymentBatchActivityRepository;

	public PaymentBatchActivityDAO(PaymentBatchActivityRepository paymentBatchRepository) {
		this.paymentBatchActivityRepository = paymentBatchRepository;
	}

	public Mono<UUID> saveAchDebitBatchEntity(PaymentDataTransferRequest paymentrequestDto) {
		// String correlationId = (String)
		// parametersSaveAchDebitPaymentRequestEntity.get(PaymentConstants.CORRELATION_ID);
		// log.info(PaymentConstants.LOG_PREFIX + "Start of savePaymentRequestEntity().
		// parametersSaveAchDebitPaymentRequestEntity: {}", correlationId,
		// parametersSaveAchDebitPaymentRequestEntity);
		StringBuilder paymentBatchID = new StringBuilder();
		paymentBatchID.append(paymentrequestDto.getPaymentRequestId()).append(PaymentUtil.utcNow().toString());
		JSONObject data = getDataJSONObjectPaymentBatchActivity(paymentrequestDto);
		PaymentBatchActivityEntity batchEntity = new PaymentBatchActivityEntity();
		batchEntity.setCreatedTimestamp(LocalDateTime.now());
		batchEntity.setCreatedBy(paymentrequestDto.getAgentId());
		batchEntity.setUpdatedTimestamp(LocalDateTime.now());
		batchEntity.setUpdatedBy(paymentrequestDto.getAgentId());
		batchEntity.setPaymentBatchId(UUIDGenerator.generateType5UUID(paymentBatchID.toString()));
		batchEntity.setPaymentRequestData(Json.of(data.toJSONString()));
		batchEntity.setPaymentBatchStatus(PaymentConstants.STATUS_PENDING);
		batchEntity.setPaymentRequestId(paymentrequestDto.getPaymentRequestId());
		batchEntity.setNew(true);

		UUID paymentRequestId = paymentrequestDto.getPaymentRequestId();
		return paymentBatchActivityRepository.save(batchEntity).doOnSuccess(entity1 -> {
			log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", paymentrequestDto.getCorrelationId(), entity1);
		}).onErrorReturn(ClassCastException.class, batchEntity).map(PaymentBatchActivityEntity::getPaymentBatchId);

	}

	public Mono<UUID> updateCommunicationAndCollectionIdInBatch(PaymentDataTransferRequest paymentDataDto, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateRequestStatus(), ", correlationId);
		return paymentBatchActivityRepository.findByPaymentRequestId(paymentDataDto.getPaymentRequestId()).flatMap(paymentRequestEntity -> {
			return updateEntity(paymentRequestEntity, paymentDataDto, correlationId);
		});
	}

	private Mono<UUID> updateEntity(PaymentBatchActivityEntity paymentRequestEntity, PaymentDataTransferRequest paymentDataDto, String correlationId) {
		paymentRequestEntity.setPaymentRequestData(Json.of(getDataJSONObjectPaymentBatchActivityUpdate(paymentRequestEntity, paymentDataDto).toString()));
		paymentRequestEntity.setPaymentBatchStatus(paymentDataDto.getIsBatchComplete()?PaymentConstants.STATUS_COMPLETE:PaymentConstants.STATUS_PENDING);
		paymentRequestEntity.setNew(false);
		return paymentBatchActivityRepository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
			log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
		}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentBatchActivityEntity::getPaymentBatchId);

	}

	private JSONObject communicationTask(PaymentDataTransferRequest paymentDataDto) {
		JSONObject json = new JSONObject();
		json.put(PaymentConstants.TASK_TYPE, PaymentConstants.TASK_TYPE_COMMUN);
		if (paymentDataDto.getCommunicationRequestId() != null) {
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.SUCCESS);
		} else {
			paymentDataDto.setIsBatchComplete(false);
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.FAILED);
		}
		JSONObject detailsJson = new JSONObject();
		detailsJson.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentDataDto.getCommunicationRequestId());
		detailsJson.put(PaymentConstants.TASK_TIMESTAMP, PaymentUtil.utcNow().toString());
		json.put(PaymentConstants.TASK_DETAILS, detailsJson);
		return json;
	}

	private Object collectionTask(PaymentDataTransferRequest paymentDataDto) {
		JSONObject json = new JSONObject();
		json.put(PaymentConstants.TASK_TYPE, PaymentConstants.TASK_TYPE_COLLEC);
		if (paymentDataDto.getCollectionIntentId() != null) {
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.SUCCESS);
		} else {
			paymentDataDto.setIsBatchComplete(false);
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.FAILED);
		}
		JSONObject detailsJson = new JSONObject();
		detailsJson.put(PaymentConstants.COLLECTION_INTENT_ID, paymentDataDto.getCollectionIntentId());
		detailsJson.put(PaymentConstants.TASK_TIMESTAMP, PaymentUtil.utcNow().toString());
		json.put(PaymentConstants.TASK_DETAILS, detailsJson);
		return json;
	}

	private Object kafkaTask(PaymentDataTransferRequest paymentDataDto) {
		JSONObject json = new JSONObject();
		json.put(PaymentConstants.TASK_TYPE, PaymentConstants.TASK_TYPE_KAFKA);
		if (paymentDataDto.getIsPaymentPublished()) {
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.SUCCESS);
		} else {
			paymentDataDto.setIsBatchComplete(false);
			json.put(PaymentConstants.TASK_STATUS, PaymentConstants.FAILED);
		}
		JSONObject detailsJson = new JSONObject();
		detailsJson.put(PaymentConstants.TASK_TIMESTAMP, PaymentUtil.utcNow().toString());
		json.put(PaymentConstants.TASK_DETAILS, detailsJson);
		return json;
	}

	private JSONObject getDataJSONObjectPaymentBatchActivity(PaymentDataTransferRequest paymentRequestDto) {
		JSONObject data = new JSONObject();
		JSONObject asyncyJsonObj = new JSONObject();
		Map<String, Object> dataParams = new HashMap<String, Object>();
		JSONArray taskArray = new JSONArray();
		JSONObject taskJsonObj = new JSONObject();
		taskArray.add(taskJsonObj);
		dataParams.put(PaymentConstants.ASYNC_JOBS, asyncyJsonObj);
		asyncyJsonObj.put(PaymentConstants.TASKS, taskArray);
		data.putAll(dataParams);

		return data;
	}

	private JSONObject getDataJSONObjectPaymentBatchActivityUpdate(PaymentBatchActivityEntity paymentRequestEntity, PaymentDataTransferRequest paymentRequestDto) {
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = null;
		try {
			paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity + ", error: " + e.toString(),
					paymentRequestDto.getCorrelationId());
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		if (paymentRequestData != null) {
			Map<String, Object> dataParams = new HashMap<String, Object>();

			JSONObject asyncJobJson = (JSONObject) paymentRequestData.get(PaymentConstants.ASYNC_JOBS);
			if (asyncJobJson != null) {
				JSONArray taskArray = (JSONArray) paymentRequestData.get(PaymentConstants.TASKS);
				if (taskArray == null) {
					taskArray = new JSONArray();
				}
				taskArray.add(communicationTask(paymentRequestDto));
				taskArray.add(collectionTask(paymentRequestDto));
				taskArray.add(kafkaTask(paymentRequestDto));
				asyncJobJson.put(PaymentConstants.TASKS, taskArray);
		
				paymentRequestData.put(PaymentConstants.ASYNC_JOBS, asyncJobJson);
			}
		}

		return paymentRequestData;
	}

	public Flux<PaymentBatchActivityResponse> findByPaymentBatchStatusAndCreatedTimestamp(String paymentBatchStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByPaymentBatchStatus(), paymentStatus: {}", correlationId, paymentBatchStatus);
		return paymentBatchActivityRepository.findByPaymentBatchStatus(paymentBatchStatus)
				.flatMap(paymentBatchActivityEntity -> {
					if(checkCreatedTimestampIsCurrentDate(paymentBatchActivityEntity.getCreatedTimestamp())) {
						PaymentBatchActivityResponse paymentBatchActivityResponse = PaymentBatchMapper.mapFromPaymentBatchActivityEntityToPaymentBatchActivityResponse(paymentBatchActivityEntity);
						return Mono.just(paymentBatchActivityResponse);
					}else{
						return Mono.empty();
					}
				});
	}

	private boolean checkCreatedTimestampIsCurrentDate(LocalDateTime createdTimestamp) {
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(createdTimestamp);
		ZonedDateTime zonedDateTimePst = PaymentUtil.toZonedDateTimePST(zonedDateTime);
		LocalDate today = PaymentUtil.toZonedDateTimePST(PaymentUtil.toZonedDateTime(LocalDateTime.now())).toLocalDate();

		return today.equals(zonedDateTimePst.toLocalDate());
	}

	public Mono<UUID> updateReprocessStatus(UUID paymentRequestId, String status, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateReprocessStatus() ", correlationId);
		return paymentBatchActivityRepository.findByPaymentRequestId(paymentRequestId).flatMap(paymentRequestEntity ->{
				return updatePaymentBatchActivityEntityStatus(paymentRequestEntity, status, correlationId);
		});
	}

	private Mono<UUID> updatePaymentBatchActivityEntityStatus(PaymentBatchActivityEntity paymentRequestEntity, String status, String correlationId) {
		paymentRequestEntity.setPaymentBatchStatus(status);
		paymentRequestEntity.setNew(false);
		return paymentBatchActivityRepository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
			log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
		}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentBatchActivityEntity::getPaymentBatchId);
	}

	public Mono<UUID> updateReprocessStatusAndCount(PaymentDataTransferRequest paymentDataDto, String taskType, String communicationRequestId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateReprocessStatusAndCount() ", correlationId);
		return paymentBatchActivityRepository.findByPaymentRequestId(paymentDataDto.getPaymentRequestId()).flatMap(paymentRequestEntity -> {
			return updatePaymentBatchActivityEntity(paymentRequestEntity, taskType, communicationRequestId, correlationId);
		});
	}

	private Mono<UUID> updatePaymentBatchActivityEntity(PaymentBatchActivityEntity paymentRequestEntity, String taskType, String communicationRequestId, String correlationId) {
		JSONObject dataJsonObject = null;
		try{
			dataJsonObject = getDataJSONObjectPaymentBatchActivityUpdateByTasksType(paymentRequestEntity, taskType, communicationRequestId, correlationId);
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity + ", error: " + e.toString(),
					correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		paymentRequestEntity.setPaymentRequestData(Json.of(dataJsonObject.toString()));
		paymentRequestEntity.setNew(false);
		return paymentBatchActivityRepository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
			log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
		}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentBatchActivityEntity::getPaymentBatchId);
	}


	public Mono<UUID> updateReprocessStatusAndCountForFailure(PaymentDataTransferRequest paymentDataDto, Integer maxReprocessRetries, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateReprocessStatusAndCountForFailure() ", correlationId);
		return paymentBatchActivityRepository.findByPaymentRequestId(paymentDataDto.getPaymentRequestId()).flatMap(paymentRequestEntity -> {
			JSONObject dataJsonObject = null;
			try{
				dataJsonObject =  getDataJSONObjectPaymentBatchActivityUpdateByTasksTypeForFailure(paymentRequestEntity, correlationId);
			} catch (ParseException e) {
				log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity + ", error: " + e.toString(),
						correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				throw paymentDataException;
			}
			JSONObject asyncJobs = (JSONObject) dataJsonObject.get(PaymentConstants.ASYNC_JOBS);
			Long count = (Long) asyncJobs.get(PaymentConstants.BATCH_REPROCESS_COUNT);
			paymentRequestEntity.setPaymentRequestData(Json.of(dataJsonObject.toString()));
			if(maxReprocessRetries !=null && Long.valueOf(maxReprocessRetries)==count){
				paymentRequestEntity.setPaymentBatchStatus(PaymentConstants.REPROCESS_FAILED);
			}
			paymentRequestEntity.setNew(false);
			return paymentBatchActivityRepository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated For Failure: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentBatchActivityEntity::getPaymentBatchId);
		});
	}

	private JSONObject getDataJSONObjectPaymentBatchActivityUpdateByTasksType(PaymentBatchActivityEntity paymentRequestEntity, String taskType, String communicationRequestId, String correlationId) throws ParseException{
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
		if (paymentRequestData != null) {

			JSONObject asyncJobJson = (JSONObject) paymentRequestData.get(PaymentConstants.ASYNC_JOBS);
			if (asyncJobJson != null) {
				if(taskType!=null) {
					JSONArray taskArray = (JSONArray) asyncJobJson.get(PaymentConstants.TASKS);
					if (taskArray == null) {
						taskArray = new JSONArray();
					}
					for (int i = 0; i < taskArray.size(); i++) {
						JSONObject element = (JSONObject)taskArray.get(i);
						String task_type = (String) element.get(PaymentConstants.TASK_TYPE);
						setTaskStatus(taskType, task_type, communicationRequestId, element);
					}
					asyncJobJson.put(PaymentConstants.TASKS, taskArray);
				}
				asyncJobJson.put(PaymentConstants.STATUS, PaymentConstants.STATUS_COMPLETE);

				paymentRequestData.put(PaymentConstants.ASYNC_JOBS, asyncJobJson);
			}
		}

		return paymentRequestData;
	}

	private JSONObject getDataJSONObjectPaymentBatchActivityUpdateByTasksTypeForFailure(PaymentBatchActivityEntity paymentRequestEntity, String correlationId) throws ParseException{
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
		if (paymentRequestData != null) {

			JSONObject asyncJobJson = (JSONObject) paymentRequestData.get(PaymentConstants.ASYNC_JOBS);
			if (asyncJobJson != null) {
				if(asyncJobJson.get("batchProcessCount")!=null){
					asyncJobJson.remove("batchProcessCount");
				}
				if(asyncJobJson.get(PaymentConstants.BATCH_REPROCESS_COUNT)==null){
					Long initialCount = 1L;
					asyncJobJson.put(PaymentConstants.BATCH_REPROCESS_COUNT, initialCount);
				}else{
					Long batchProcessCount = (Long) asyncJobJson.get(PaymentConstants.BATCH_REPROCESS_COUNT);
					asyncJobJson.put(PaymentConstants.BATCH_REPROCESS_COUNT, batchProcessCount+1);
				}
				asyncJobJson.put(PaymentConstants.STATUS, PaymentConstants.STATUS_COMPLETE);

				paymentRequestData.put(PaymentConstants.ASYNC_JOBS, asyncJobJson);
			}
		}

		return paymentRequestData;
	}

	private static void setTaskStatus(String taskType, String task_type, String communicationRequestId, JSONObject element) {
		if (taskType.equalsIgnoreCase(task_type)) {
			element.put(PaymentConstants.TASK_STATUS, PaymentConstants.SUCCESS);
			if(task_type.equalsIgnoreCase(PaymentConstants.COMMUNICATION)){
				if(element.get(PaymentConstants.TASK_DETAILS)!=null){
					JSONObject detailsJson = (JSONObject) element.get(PaymentConstants.TASK_DETAILS);
					detailsJson.put(PaymentConstants.COMMUNICATION_REQUEST_ID,communicationRequestId);
				}
			}
		}
	}
}
