package com.creditone.ucrm.payments.dao;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.AutoPayDBResponse;
import com.creditone.ucrm.payments.dto.AutoPayHistoryDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.AutoPayHistoryEntity;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.AutoPayConfigurationHistory;
import com.ucrm.swagger.paymentservice.model.AutoPayDetails;
import com.ucrm.swagger.paymentservice.model.UpdateAutoPayRequest;

import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AutoPayHistoryMapper {

	public static AutoPayHistoryDBResponse mappingFromAutoPayHistoryEntityToAutoPayHistoryDBResponse(AutoPayHistoryEntity autoPayHistoryEntity) {
		AutoPayHistoryDBResponse autoPayHistoryDBResponse = new AutoPayHistoryDBResponse();
		autoPayHistoryDBResponse.setAutoPayId(autoPayHistoryEntity.getAutoPayId());
		autoPayHistoryDBResponse.setCustomerId(autoPayHistoryEntity.getCustomerId());
		autoPayHistoryDBResponse.setCreditAccountId(autoPayHistoryEntity.getCreditAccountId());
		autoPayHistoryDBResponse.setAutoPayEnabled(autoPayHistoryEntity.getAutoPayEnabled());
		autoPayHistoryDBResponse.setAutoPayHistoryData(autoPayHistoryEntity.getAutoPayHistoryData());
		autoPayHistoryDBResponse.setCreatedBy(autoPayHistoryEntity.getCreatedBy());
		autoPayHistoryDBResponse.setCreatedTimestamp(autoPayHistoryEntity.getCreatedTimestamp());
		autoPayHistoryDBResponse.setUpdatedBy(autoPayHistoryEntity.getUpdatedBy());
		autoPayHistoryDBResponse.setUpdatedTimestamp(autoPayHistoryEntity.getUpdatedTimestamp());
		return autoPayHistoryDBResponse;
	}

	public static AutoPayConfigurationHistory mappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(AutoPayHistoryDBResponse autoPayHistoryDBResponse, String correlationId) {
		if (autoPayHistoryDBResponse == null) {
			return null;
		}

		AutoPayConfigurationHistory autoPayConfigurationHistory = new AutoPayConfigurationHistory();
		autoPayConfigurationHistory.setAutoPayId(autoPayHistoryDBResponse.getAutoPayId().toString());
		autoPayConfigurationHistory.setAutoPayEnabled(autoPayHistoryDBResponse.getAutoPayEnabled());

		JSONObject dataParams = null;
		if (autoPayHistoryDBResponse.getAutoPayHistoryData() != null) {
			dataParams = getJSONObjectForMappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(autoPayHistoryDBResponse, correlationId);

			List<AutoPayDetails> history = new ArrayList<>();
			autoPayConfigurationHistory.setAutoPayHistory(history);

			List<AutoPayDetails> autoPayHistoryDetails = autoPayConfigurationHistory.getAutoPayHistory();
			List<JSONObject> autoPayHistory = ((List<JSONObject>) dataParams.get(PaymentConstants.AUTO_PAY_HISTORY));
			for (JSONObject jsonObject : autoPayHistory) {
				AutoPayDetails autoPayDetails = getAutoPayDetailsForMappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(jsonObject);
				autoPayHistoryDetails.add(autoPayDetails);
			}
			autoPayConfigurationHistory.setAutoPayHistory(autoPayHistoryDetails);
		}
		return autoPayConfigurationHistory;
	}

	private static JSONObject getJSONObjectForMappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(AutoPayHistoryDBResponse autoPayHistoryDBResponse, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject dataParams = null;

		try {
			dataParams = (JSONObject) parser.parse(autoPayHistoryDBResponse.getAutoPayHistoryData().asString());
		} catch (ParseException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA.replace("{errorMessage}", e.toString());
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}

		return dataParams;
	}

	private static AutoPayDetails getAutoPayDetailsForMappingFromAutoPayHistoryDBResponseToAutoConfigurationHistory(JSONObject jsonObject) {
		AutoPayDetails autoPayDetails = new AutoPayDetails();

		autoPayDetails.setExternalAccountId(jsonObject.get(PaymentConstants.EXTERNAL_ACCOUNT_ID) != null ? jsonObject.get(PaymentConstants.EXTERNAL_ACCOUNT_ID).toString() : null);
		autoPayDetails.setPaymentPurpose(jsonObject.get(PaymentConstants.PAYMENT_PURPOSE) != null ? jsonObject.get(PaymentConstants.PAYMENT_PURPOSE).toString() : null);
		autoPayDetails.setAutoPayEventDate(jsonObject.get(PaymentConstants.AUTO_PAY_EVENT_DATE) != null ? jsonObject.get(PaymentConstants.AUTO_PAY_EVENT_DATE).toString() : null);
		autoPayDetails
				.setAutoPayEventStatus(jsonObject.get(PaymentConstants.AUTO_PAY_EVENT_STATUS) != null ? jsonObject.get(PaymentConstants.AUTO_PAY_EVENT_STATUS).toString() : null);
		autoPayDetails.setChannel(jsonObject.get(PaymentConstants.CHANNEL) != null ? jsonObject.get(PaymentConstants.CHANNEL).toString() : null);
		autoPayDetails.setAgentId(jsonObject.get(PaymentConstants.AGENT_ID) != null ? jsonObject.get(PaymentConstants.AGENT_ID).toString() : null);
		autoPayDetails.setExternalBankName(jsonObject.get(PaymentConstants.EXTERNAL_BANK_NAME) != null ? jsonObject.get(PaymentConstants.EXTERNAL_BANK_NAME).toString() : null);
		autoPayDetails.setExternalAccountLast4(
				jsonObject.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4) != null ? jsonObject.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4).toString() : null);

		return autoPayDetails;
	}

	public static AutoPayHistoryEntity mappingFromAutoPayHistoryDBResponseToAutoPayHistoryEntity(AutoPayHistoryDBResponse autoPayHistoryDBResponse, boolean autoPayEnabledStatus) {
		AutoPayHistoryEntity autoPayHistoryEntity = new AutoPayHistoryEntity();

		autoPayHistoryEntity.setAutoPayHistoryData(autoPayHistoryDBResponse.getAutoPayHistoryData());
		autoPayHistoryEntity.setAutoPayId(autoPayHistoryDBResponse.getAutoPayId());
		autoPayHistoryEntity.setCustomerId(autoPayHistoryDBResponse.getCustomerId());
		autoPayHistoryEntity.setCreditAccountId(autoPayHistoryDBResponse.getCreditAccountId());
		autoPayHistoryEntity.setAutoPayEnabled(autoPayEnabledStatus);
		autoPayHistoryEntity.setCreatedBy(autoPayHistoryDBResponse.getCreatedBy());
		autoPayHistoryEntity.setUpdatedBy(autoPayHistoryDBResponse.getUpdatedBy());
		autoPayHistoryEntity.setUpdatedTimestamp(autoPayHistoryDBResponse.getUpdatedTimestamp());
		autoPayHistoryEntity.setCreatedTimestamp(autoPayHistoryDBResponse.getCreatedTimestamp());
		autoPayHistoryEntity.setIntentCode(autoPayHistoryEntity.getIntentCode());
		autoPayHistoryEntity.setNew(false);

		return autoPayHistoryEntity;
	}

	/***
	 * This method is to map the
	 * mappingFromAutoPayHistoryDBResponseToSaveAutoPayHistoryEntity when the update
	 * operation fails in order to perform save operation of autoPayHistory record.
	 * 
	 * @param autoPayHistoryDBResponse
	 * @param autoPayEnabledStatus
	 * @return
	 */
	public static AutoPayHistoryEntity mappingFromAutoPayHistoryDBResponseToSaveAutoPayHistoryEntity(AutoPayHistoryDBResponse autoPayHistoryDBResponse, boolean autoPayEnabledStatus) {
		AutoPayHistoryEntity autoPayHistoryEntity = new AutoPayHistoryEntity();
		autoPayHistoryEntity.setAutoPayHistoryData(autoPayHistoryDBResponse.getAutoPayHistoryData());
		autoPayHistoryEntity.setAutoPayId(autoPayHistoryDBResponse.getAutoPayId());
		autoPayHistoryEntity.setCustomerId(autoPayHistoryDBResponse.getCustomerId());
		autoPayHistoryEntity.setCreditAccountId(autoPayHistoryDBResponse.getCreditAccountId());
		autoPayHistoryEntity.setAutoPayEnabled(autoPayEnabledStatus);
		autoPayHistoryEntity.setCreatedBy(autoPayHistoryDBResponse.getCreatedBy());
		autoPayHistoryEntity.setUpdatedBy(autoPayHistoryDBResponse.getUpdatedBy());
		autoPayHistoryEntity.setUpdatedTimestamp(autoPayHistoryDBResponse.getUpdatedTimestamp());
		autoPayHistoryEntity.setCreatedTimestamp(autoPayHistoryDBResponse.getCreatedTimestamp());
		autoPayHistoryEntity.setIntentCode(autoPayHistoryEntity.getIntentCode());
		autoPayHistoryEntity.setNew(true);
		return autoPayHistoryEntity;
	}

	public static JSONObject mappingFromAutoPayDBResponseToJSON(JSONObject autoPayDataParams, AutoPayDBResponse autoPayDBResponse, String communicationRequestId, String status) {
		JSONObject jsonResult = new JSONObject();
		ZonedDateTime zonedDateTime = PaymentUtil.utcNow();
		String date = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATEFORMAT);

		jsonResult.put(PaymentConstants.AUTO_PAY_EVENT_DATE, date);
		jsonResult.put(PaymentConstants.AUTO_PAY_EVENT_STATUS, status);
		jsonResult.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);

		if (autoPayDBResponse.getPaymentDay() != null) {
			jsonResult.put(PaymentConstants.AUTO_PAYMENT_DAY, autoPayDBResponse.getPaymentDay());
		}

		fillOptionalJSONObjectParamsForMappingFromAutoPayDBResponseToJSON(autoPayDataParams, jsonResult);

		return jsonResult;
	}

	private static void fillOptionalJSONObjectParamsForMappingFromAutoPayDBResponseToJSON(JSONObject autoPayDataParams, JSONObject jsonResult) {
		if (autoPayDataParams.containsKey(PaymentConstants.AGENT_ID)) {
			jsonResult.put(PaymentConstants.AGENT_ID, autoPayDataParams.get(PaymentConstants.AGENT_ID));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.CHANNEL)) {
			jsonResult.put(PaymentConstants.CHANNEL, autoPayDataParams.get(PaymentConstants.CHANNEL));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.PAYMENT_AMOUNT)) {
			jsonResult.put(PaymentConstants.PAYMENT_AMOUNT, autoPayDataParams.get(PaymentConstants.PAYMENT_AMOUNT));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.PAYMENT_PURPOSE)) {
			jsonResult.put(PaymentConstants.PAYMENT_PURPOSE, autoPayDataParams.get(PaymentConstants.PAYMENT_PURPOSE));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.EXTERNAL_BANK_NAME)) {
			jsonResult.put(PaymentConstants.EXTERNAL_BANK_NAME, autoPayDataParams.get(PaymentConstants.EXTERNAL_BANK_NAME));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.FIRST_AUTO_PAY_DATE)) {
			jsonResult.put(PaymentConstants.FIRST_AUTO_PAY_DATE, autoPayDataParams.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.EXTERNAL_ACCOUNT_ID)) {
			jsonResult.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, autoPayDataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
		}

		if (autoPayDataParams.containsKey(PaymentConstants.EXTERNAL_ACCOUNT_LAST4)) {
			jsonResult.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, autoPayDataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		}
	}

	/***
	 * This method is to get the Json Object for new record from existing
	 * autoPayHistoryData record
	 * 
	 * @param autoPayHistoryDataRecord is for existing autoPayHistoryData record
	 * @param maxVersion               is for maximum version of the
	 *                                 autoPayHistoryData
	 * @return JSONObject for new autoPayHistoryDataRecord with status DISABLED
	 */
	public static JSONObject mapAutopayDisableEntry(JSONObject autoPayHistoryDataRecord, Long maxVersion) {
		JSONObject jsonResult = new JSONObject();

		jsonResult.put(PaymentConstants.AGENT_ID, autoPayHistoryDataRecord.get(PaymentConstants.AGENT_ID));
		jsonResult.put(PaymentConstants.CHANNEL, autoPayHistoryDataRecord.get(PaymentConstants.CHANNEL));
		jsonResult.put(PaymentConstants.PAYMENT_AMOUNT, autoPayHistoryDataRecord.get(PaymentConstants.PAYMENT_AMOUNT));
		jsonResult.put(PaymentConstants.PAYMENT_PURPOSE, autoPayHistoryDataRecord.get(PaymentConstants.PAYMENT_PURPOSE));
		jsonResult.put(PaymentConstants.AUTO_PAY_EVENT_DATE, autoPayHistoryDataRecord.get(PaymentConstants.AUTO_PAY_EVENT_DATE));
		jsonResult.put(PaymentConstants.EXTERNAL_BANK_NAME, autoPayHistoryDataRecord.get(PaymentConstants.EXTERNAL_BANK_NAME));
		jsonResult.put(PaymentConstants.FIRST_AUTO_PAY_DATE, autoPayHistoryDataRecord.get(PaymentConstants.FIRST_AUTO_PAY_DATE));
		jsonResult.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, autoPayHistoryDataRecord.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
		jsonResult.put(PaymentConstants.AUTO_PAY_EVENT_STATUS, PaymentConstants.DISABLED);
		jsonResult.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, autoPayHistoryDataRecord.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		jsonResult.put(PaymentConstants.COMMUNICATION_REQUEST_ID, autoPayHistoryDataRecord.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
		jsonResult.put(PaymentConstants.VERSION, maxVersion);

		return jsonResult;
	}

	/***
	 * This method is to create the mapping from request to autoPayHistoryData in
	 * cases where the autopayHistory record is not available for update AutoPay
	 * operation.
	 * 
	 * @param updateAutoPayRequest is the data for the autopayHistoryData column
	 * @return Json of the autoPayHistoryData with available feilds.
	 */
	public static Json mappingFromUpdateAutoPayRequestToAutoPayHistoryData(UpdateAutoPayRequest updateAutoPayRequest) {
		if (updateAutoPayRequest == null) {
			return null;
		}
		JSONObject data = new JSONObject();
		data.put(PaymentConstants.AGENT_ID, updateAutoPayRequest.getAgentId());
		data.put(PaymentConstants.CHANNEL, updateAutoPayRequest.getChannel());
		data.put(PaymentConstants.VERSION, 1);
		data.put(PaymentConstants.PAYMENT_AMOUNT, updateAutoPayRequest.getPaymentAmount());
		data.put(PaymentConstants.PAYMENT_PURPOSE, String.valueOf(updateAutoPayRequest.getPaymentPurpose()));
		data.put(PaymentConstants.AUTO_PAY_EVENT_DATE, null);
		data.put(PaymentConstants.EXTERNAL_BANK_NAME, null);
		data.put(PaymentConstants.FIRST_AUTO_PAY_DATE, null);
		data.put(PaymentConstants.EXTERNAL_ACCOUNT_ID, updateAutoPayRequest.getExternalAccountId());
		data.put(PaymentConstants.AUTO_PAY_EVENT_STATUS, null);
		data.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, null);
		data.put(PaymentConstants.COMMUNICATION_REQUEST_ID, null);
		List<JSONObject> autoPayHistory = new ArrayList<>();
		autoPayHistory.add(data);

		JSONObject result = new JSONObject();
		result.put(PaymentConstants.AUTO_PAY_HISTORY, autoPayHistory);

		return Json.of(result.toString());
	}
}