package com.creditone.ucrm.payments.dao;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.constant.FDRStatus;
import com.creditone.ucrm.payments.constant.LineOfBusiness;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentEvent;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.constant.TransactionDirection;
import com.creditone.ucrm.payments.constant.TransactionType;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.exception.*;
import com.creditone.ucrm.payments.model.PaymentRequestEntity;
import com.creditone.ucrm.payments.repository.PaymentBatchActivityRepository;
import com.creditone.ucrm.payments.repository.PaymentRequestRepository;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest;
import com.ucrm.swagger.paymentservice.model.PaymentRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.relational.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class PaymentDAO {

	private PaymentRequestRepository repository;
	private PaymentBatchActivityRepository paymentBatchAcivityRepository;

	private R2dbcEntityTemplate r2dbcEntityTemplate;
	private String confirmationNumberLength;
	private String paymentZoneId;
	private String configuredFeeAmount;

	public PaymentDAO(PaymentRequestRepository repository, R2dbcEntityTemplate r2dbcEntityTemplate, @Value(value = "${confirmation.length}") String confirmationNumberLength,
			@Value(value = "${fee.amount}") String configuredFeeAmount, @Value(value = "${payment.zoneId}") String paymentZoneId) {
		this.repository = repository;
		this.r2dbcEntityTemplate = r2dbcEntityTemplate;
		this.confirmationNumberLength = confirmationNumberLength;
		this.configuredFeeAmount = configuredFeeAmount;
		this.paymentZoneId = paymentZoneId;
	}

	public Mono<UUID> updatePaymentRequestEntity(PaymentServiceRequest request, String paymentStatus, UUID paymentRequestId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentRequestEntity(). request: {}, paymentStatus: {}, paymentRequestId: {}", correlationId, request, paymentStatus,
				paymentRequestId);
		return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(entity -> {
			entity.setUpdatedTimestamp(LocalDateTime.now());
			entity.setUpdatedBy(request.getAgentId());
			entity.setRequestStatus(paymentStatus);
			entity.setNew(false);
			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", correlationId, entity);
			return repository.save(entity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, entity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	public Mono<UUID> updatePaymentRequestEntityStatus(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapStatusPayment, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentRequestEntity(). paymentRequestDataDBResponse: {}, mapStatusPayment: {}", correlationId,
				paymentRequestDataDBResponse, mapStatusPayment);
		UUID paymentRequestId = paymentRequestDataDBResponse.getPaymentRequestId();
		String agentId = paymentRequestDataDBResponse.getCreatedBy();
		String paymentStatus = mapStatusPayment.get(PaymentConstants.STATUS).toString();
		JSONObject data = new JSONObject();
		Map<String, Object> dataParams = PaymentMapper.getDataParamsFromPaymentRequestDataDBResponse(paymentRequestDataDBResponse, mapStatusPayment, correlationId);
		String confirmationCode = null;
		try {
			confirmationCode = generateConfirmationCode(paymentRequestId);
		} catch (NoSuchAlgorithmException e) {
			return Mono.error(new PaymentDataException(PaymentErrors.ERROR_CONFIRMATION_CODE));
		}
		dataParams.put(PaymentConstants.PAYMENT_CONFIRMATION, confirmationCode);
		dataParams.put(PaymentConstants.COLLECTION_INTENT_ID, mapStatusPayment.get(PaymentConstants.COLLECTION_INTENT_ID));
		data.putAll(dataParams);
		return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(paymentRequestEntity -> {
			setEntityForUpdatePaymentRequestEntityStatus(paymentRequestEntity, agentId, paymentStatus, data);
			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", correlationId, paymentRequestEntity);
			return repository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	private void setEntityForUpdatePaymentRequestEntityStatus(PaymentRequestEntity paymentRequestEntity, String agentId, String paymentStatus, JSONObject data) {
		paymentRequestEntity.setUpdatedTimestamp(LocalDateTime.now());
		paymentRequestEntity.setUpdatedBy(agentId);
		paymentRequestEntity.setRequestStatus(paymentStatus);
		if (data != null) {
			paymentRequestEntity.setPaymentRequestData(Json.of(data.toJSONString()));
		}
		paymentRequestEntity.setNew(false);
	}

	public Mono<PaymentRequestDataDBResponse> saveSchPaymentRequestEntity(PaymentDataTransferRequest paymentrequestDto, UUID paymentRequestId) {
		String correlationId = paymentrequestDto.getCorrelationId();
		log.info(PaymentConstants.LOG_PREFIX + "Start of savePaymentRequestEntity(). parameters: {}, paymentRequestId: {}", correlationId, paymentrequestDto, paymentRequestId);
		Mono<JSONObject> monoData = getDataJSONObjectForSaveSchPaymentRequestEntity(paymentrequestDto, paymentRequestId);
		return monoData.flatMap(data -> {
			return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(paymentRequestEntity -> {
				log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", correlationId, paymentRequestEntity);

				setEntityForSaveSchPaymentRequestEntity(paymentrequestDto, data, paymentRequestEntity);
				paymentrequestDto.setCreatedTimestamp(paymentRequestEntity.getCreatedTimestamp());
				paymentrequestDto.setUpdatedTimestamp(paymentRequestEntity.getUpdatedTimestamp());
				paymentrequestDto.setCreatedBy(paymentRequestEntity.getCreatedBy());
				paymentrequestDto.setUpdatedBy(paymentRequestEntity.getUpdatedBy());
				return repository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
					log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
				}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(entity -> mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
			});
		});
	}

	private void setEntityForSaveSchPaymentRequestEntity(PaymentDataTransferRequest paymentrequestDto, JSONObject data, PaymentRequestEntity paymentRequestEntity) {

		PaymentMapper.mapPaymentRequestSchEntity(paymentrequestDto, paymentRequestEntity);
		if (data != null) {
			paymentRequestEntity.setPaymentRequestData(Json.of(data.toJSONString()));
		}
		paymentRequestEntity.setNew(false);
	}

	private Mono<JSONObject> getDataJSONObjectForSaveSchPaymentRequestEntity(PaymentDataTransferRequest paymentrequestDto, UUID paymentRequestId) {
		paymentrequestDto.setPaymentEvent(PaymentEvent.SCHEDULE.name());
		paymentrequestDto.setFdrStatus(FDRStatus.SCHEDULE.name());
		paymentrequestDto.setPaymentRequestId(paymentRequestId);
		JSONObject data = new JSONObject();
		Map<String, Object> dataParams = PaymentMapper.getDataParamsFromPaymentServiceSchRequest(paymentrequestDto, configuredFeeAmount);
		String confirmationCode = null;
		try {
			confirmationCode = generateConfirmationCode(paymentRequestId);
		} catch (NoSuchAlgorithmException e) {
			return Mono.error(new PaymentDataException(PaymentErrors.ERROR_CONFIRMATION_CODE));
		}
		dataParams.put(PaymentConstants.PAYMENT_CONFIRMATION, confirmationCode);
		paymentrequestDto.setPaymentConfirmation(confirmationCode);
		paymentrequestDto.setConfirmationCode(confirmationCode);
		data.putAll(dataParams);

		return Mono.just(data);
	}

	public Mono<UUID> saveAchDebitPaymentRequestEntity(Map<String, Object> parametersSaveAchDebitPaymentRequestEntity, Map<String, Object> resultMap) {
		String correlationId = (String) parametersSaveAchDebitPaymentRequestEntity.get(PaymentConstants.CORRELATION_ID);
		log.info(PaymentConstants.LOG_PREFIX + "Start of savePaymentRequestEntity(). parametersSaveAchDebitPaymentRequestEntity: {}", correlationId,
				parametersSaveAchDebitPaymentRequestEntity);

		UUID paymentRequestId = (UUID) parametersSaveAchDebitPaymentRequestEntity.get(PaymentConstants.PAYMENT_REQUEST_ID);

		return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(paymentRequestEntity -> {
			setEntityForSaveAchDebitPaymentRequestEntity(parametersSaveAchDebitPaymentRequestEntity, paymentRequestEntity, correlationId);

			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", correlationId, paymentRequestEntity);
			resultMap.put(PaymentConstants.CREATED_DATE, PaymentUtil.formatDate(paymentRequestEntity.getCreatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
			resultMap.put(PaymentConstants.FEE_WAIVER_AMOUNT, parametersSaveAchDebitPaymentRequestEntity.get(PaymentConstants.FEE_WAIVER_AMOUNT));
			return repository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	public Mono<UUID> saveAchDebitPaymentRequest(PaymentDataTransferRequest paymentrequestDto) {
		// String correlationId = (String)
		// parametersSaveAchDebitPaymentRequestEntity.get(PaymentConstants.CORRELATION_ID);
		// log.info(PaymentConstants.LOG_PREFIX + "Start of savePaymentRequestEntity().
		// parametersSaveAchDebitPaymentRequestEntity: {}", correlationId,
		// parametersSaveAchDebitPaymentRequestEntity);

		UUID paymentRequestId = paymentrequestDto.getPaymentRequestId();
		return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(paymentRequestEntity -> {
			setEntityForSaveAchDebitPaymentRequest(paymentrequestDto, paymentRequestEntity, paymentrequestDto.getCorrelationId());

			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", paymentrequestDto.getCorrelationId(), paymentRequestEntity);
			return repository.save(paymentRequestEntity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", paymentrequestDto.getCorrelationId(), entity1);
			}).onErrorReturn(ClassCastException.class, paymentRequestEntity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	private JSONObject getDataJSONObjectForSaveAchDebitPaymentRequestEntity(Map<String, Object> enitityParameters, String correlationId) {
		Map<String, Object> mapResult = (Map<String, Object>) enitityParameters.get(PaymentConstants.MAP_RESULT);
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) enitityParameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		PaymentRequestEntity paymentRequestEntity = (PaymentRequestEntity) enitityParameters.get(PaymentConstants.PAYMENT_REQUEST_ENTITY);

		String externalAccountLast4 = (String) mapResult.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);// add
		String creditAccountLast4 = (String) mapResult.get(PaymentConstants.CARD_LAST4);// add
		String communicationID = (String) mapResult.get(PaymentConstants.COMMUNICATION_REQUEST_ID);
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = null;
		try {
			paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		enitityParameters.put(PaymentConstants.FEE_WAIVER_AMOUNT, paymentRequestData.get(PaymentConstants.FEE_WAIVER_AMOUNT));
		Map<String, Object> parameterMethod = new HashMap<String, Object>();
		parameterMethod.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
		parameterMethod.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, externalAccountLast4);
		parameterMethod.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, creditAccountLast4);
		parameterMethod.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationID);
		parameterMethod.put(PaymentConstants.STATUS, mapResult.get(PaymentConstants.STATUS));
		parameterMethod.put(PaymentConstants.FDR_STATUS, FDRStatus.PENDING.name());
		parameterMethod.put(PaymentConstants.PAYMENT_EVENT, PaymentEvent.PROCESSED.name());
		parameterMethod.put(PaymentConstants.AGENT_ID, paymentServiceRequest.getAgentId());
		parameterMethod.put(PaymentConstants.COLLECTION_INTENT_ID, mapResult.get(PaymentConstants.COLLECTION_INTENT_ID));
		parameterMethod.put(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER, mapResult.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER));
		parameterMethod.put(PaymentConstants.MAP_RESULT, mapResult);
		parameterMethod.put(PaymentConstants.CORRELATION_ID, enitityParameters.get(PaymentConstants.CORRELATION_ID));

		parameterMethod.put(PaymentConstants.PAYMENT_REQUEST_DATA_JSON, paymentRequestData);

		Map<String, Object> dataParams = PaymentMapper.getDataParamsFromPaymentServiceRequestUpdated(parameterMethod);
		dataParams.put(PaymentConstants.EXPRESS_PAY_CONDITION, mapResult.get(PaymentConstants.EXPRESS_PAY_CONDITION));
		dataParams.put(PaymentConstants.PAYMENT_CONFIRMATION, mapResult.get(PaymentConstants.PAYMENT_CONFIRMATION));
		paymentRequestData.putAll(dataParams);

		return paymentRequestData;
	}

	private JSONObject getDataJSONObjectForSaveAchDebitPaymentRequestProcessed(PaymentDataTransferRequest paymentRequestDto, PaymentRequestEntity paymentRequestEntity, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = null;
		try {
			paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		paymentRequestDto.setCreatedTimestamp(paymentRequestEntity.getCreatedTimestamp());
		paymentRequestDto.setUpdatedTimestamp(paymentRequestEntity.getUpdatedTimestamp());
		paymentRequestDto.setCreatedBy(paymentRequestEntity.getCreatedBy());
		paymentRequestDto.setUpdatedBy(paymentRequestEntity.getUpdatedBy());
		Map<String, Object> dataParams = new HashMap<String, Object>();
		dataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		dataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		dataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		dataParams.put(PaymentConstants.PAYMENT_AMOUNT, paymentRequestDto.getPaymentAmount());
		dataParams.put(PaymentConstants.FEE_AMOUNT, paymentRequestDto.getFeeAmount());
		dataParams.put(PaymentConstants.CHANNEL, paymentRequestDto.getChannel());
		dataParams.put(PaymentConstants.PAYMENT_MODE, paymentRequestDto.getPaymentMode());
		dataParams.put(PaymentConstants.FDR_STATUS, paymentRequestDto.getFdrStatus());
		dataParams.put(PaymentConstants.COLLECTION_INTENT_ID, paymentRequestDto.getCollectionIntentId());
		dataParams.put(PaymentConstants.CORRELATION_ID, paymentRequestDto.getCorrelationId());
		dataParams.put(PaymentConstants.EXPRESS_PAY_DECISION, paymentRequestDto.getExpressPayDecesion());
		PaymentMapper.addDataParamMetadataProcessed(paymentRequestDto, dataParams, paymentRequestData);
		dataParams.put(PaymentConstants.EXPRESS_PAY_CONDITION, paymentRequestDto.getExpressPayCondition());
		dataParams.put(PaymentConstants.PAYMENT_CONFIRMATION, paymentRequestDto.getConfirmationCode());
		dataParams.put(PaymentConstants.INVOLVEMENT_ID, paymentRequestDto.getInvolvementId());
		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, paymentRequestDto.getExternalBankName());
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, paymentRequestDto.getExternalAccountLast4());
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, paymentRequestDto.getPaymentPurpose());
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, paymentRequestDto.getCreditAccountLast4());
		dataParams.put(PaymentConstants.PAST_DUE_AMOUNT, paymentRequestDto.getPastDueAmount());
		dataParams.put(PaymentConstants.DEBIT_LAST4, paymentRequestDto.getDebitLast4());
		dataParams.put(PaymentConstants.STATEMENT_DATE, String.valueOf(paymentRequestDto.getStatementDate()));
		dataParams.put(PaymentConstants.MINIMUM_PAYMENT, String.valueOf(paymentRequestDto.getMinimumPaymentDue()));
		dataParams.put(PaymentConstants.DELINQUENT_AMOUNT, String.valueOf(paymentRequestDto.getDelinquentAmount()));
		dataParams.put(PaymentConstants.DAYS_DELINQUENT, String.valueOf(paymentRequestDto.getDaysDelinquent()));

		paymentRequestData.putAll(dataParams);

		return paymentRequestData;
	}

	private void setEntityForSaveAchDebitPaymentRequestEntity(Map<String, Object> parametersSaveAchDebitPaymentRequestEntity, PaymentRequestEntity paymentRequestEntity, String correlationId) {
		parametersSaveAchDebitPaymentRequestEntity.put(PaymentConstants.PAYMENT_REQUEST_ENTITY, paymentRequestEntity);
		JSONObject data = getDataJSONObjectForSaveAchDebitPaymentRequestEntity(parametersSaveAchDebitPaymentRequestEntity, correlationId);
		PaymentMapper.mapPaymentRequestEntity(parametersSaveAchDebitPaymentRequestEntity);
		if (data != null) {
			paymentRequestEntity.setPaymentRequestData(Json.of(data.toJSONString()));
		}
		paymentRequestEntity.setNew(false);
	}

	private void setEntityForSaveAchDebitPaymentRequest(PaymentDataTransferRequest paymentRequestDto, PaymentRequestEntity paymentRequestEntity, String correlationId) {
		JSONObject data = getDataJSONObjectForSaveAchDebitPaymentRequestProcessed(paymentRequestDto, paymentRequestEntity, correlationId);
		paymentRequestEntity.setRequestStatus(paymentRequestDto.getStatus());
		// PaymentMapper.mapPaymentRequestEntity(parametersSaveAchDebitPaymentRequestEntity);
		if (data != null) {
			paymentRequestEntity.setPaymentRequestData(Json.of(data.toJSONString()));
		}
		paymentRequestEntity.setNew(false);
	}

	public Mono<UUID> savePaymentRequestEntity(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dtoRequest) {
		PaymentRequestEntity entity = PaymentMapper.mapNewPaymentRequestEntity(paymentServiceRequest, dtoRequest);
		JSONObject data = new JSONObject();
		String name = paymentServiceRequest.getCustomerId() + paymentServiceRequest.getCreditAccountId() + paymentServiceRequest.getPaymentAmount()
				+ paymentServiceRequest.getChannel() + paymentServiceRequest.getPaymentAmount() + System.nanoTime();
		UUID paymentRequestId = dtoRequest.getStatus().equalsIgnoreCase(PaymentStatus.DUPLICATE.name()) ? UUIDGenerator.generateType5UUID(name) : dtoRequest.getPaymentRequestId();
		Map<String, Object> dataParams = PaymentMapper.getJsonDataFromPaymentServiceRequest(dtoRequest, configuredFeeAmount);
		dataParams.put(PaymentConstants.CARD_TYPE, dtoRequest.getCardType());
		dataParams.put(PaymentConstants.CARD_LAST4, dtoRequest.getCreditAccountLast4());
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, dtoRequest.getExternalAccountLast4());
		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, dtoRequest.getExternalBankName());
		dataParams.put(PaymentConstants.EXT_ACCNT_TYPE, dtoRequest.getExternalAccountType());
		dataParams.put(PaymentConstants.CORRELATION_ID, dtoRequest.getCorrelationId());
		data.putAll(dataParams);

		return saveEntity(entity, data, paymentRequestId, dtoRequest.getCorrelationId());

	}

	private Mono<UUID> saveEntity(PaymentRequestEntity entity, JSONObject data, UUID paymentRequestId, String correlationId) {
		entity.setPaymentRequestData(Json.of(data.toJSONString()));
		entity.setPaymentRequestId(paymentRequestId);
		entity.setNew(true);
		log.info(PaymentConstants.LOG_PREFIX + "Entity to Add: {}", correlationId, entity);

		return repository.findById(paymentRequestId).flatMap(existingEntity -> {
			return Mono.error(new PaymentConflictException(PaymentErrors.DUPLICATE_PAYMENT_REQUEST + paymentRequestId));
		}).switchIfEmpty(repository.save(entity)).flatMap(savedEntity -> {
			return Mono.just(entity.getPaymentRequestId());
		}).onErrorResume(err -> {
			log.error(PaymentConstants.LOG_PREFIX + err.getMessage(), correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_DUPLICATE_PAYMENT_REQUEST);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		});
	}

	public String generateConfirmationCode(UUID paymentRequestId) throws NoSuchAlgorithmException {

		// Use SHA-256 hashing algorithm on the paymentRequestId
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashedBytes = digest.digest(paymentRequestId.toString().getBytes());
		// Convert the hashed bytes to a hex string
		StringBuilder hexString = new StringBuilder();
		for (byte b : hashedBytes) {
			String hex = Integer.toHexString(0xFF & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		Integer part1 = Integer.valueOf(confirmationNumberLength) / 2;
		Integer part2 = Integer.valueOf(confirmationNumberLength) - part1;
		// Extract the first 3 characters as alphabetic
		String alphaPart = hexString.toString().replaceAll("[^b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]", "").substring(0, part1);
		// Extract the next 3 characters as numeric
		String numericPart = hexString.toString().replaceAll("[^0-9]", "").substring(0, part2);
		// Combine both parts to create the 6-digit alphanumeric code
		return alphaPart + numericPart;
	}

	/**
	 * Jira Link: https://creditonebank.atlassian.net/browse/CRM-220 Accepts an
	 * instance of CancelACHPaymentRequest, payment status and paymentRequestId from
	 * service, returns paymentRequestId
	 *
	 * @param paymentRequestId
	 * @param cancelACHPaymentRequest
	 * @throws PaymentDataNotFoundException
	 */

	public Mono<PaymentRequestDataDBResponse> cancelScheduledPaymentRequest(UUID paymentRequestId, CancelACHPaymentRequest cancelACHPaymentRequest, String correlationId)
			throws PaymentDataNotFoundException {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of DAO cancelScheduledPaymentRequest(). paymentRequestId: {}, cancelACHPaymentRequest: {}", correlationId, paymentRequestId,
				cancelACHPaymentRequest);

		Mono<PaymentRequestEntity> monoPaymentRequestData = repository.findById(paymentRequestId);
		return monoPaymentRequestData.hasElement().flatMap(hasElement -> {
			if (!hasElement) {
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				return Mono.error(paymentDataNotFoundException);
			}
			return monoPaymentRequestData.flatMap(paymentRequestEntity -> {
				if (paymentRequestEntity.getRequestStatus().equalsIgnoreCase(PaymentStatus.SCHEDULE.name())) {
					paymentRequestEntity.setRequestStatus(cancelACHPaymentRequest.getPaymentStatus());
					paymentRequestEntity.setUpdatedBy(cancelACHPaymentRequest.getAgentId());
					paymentRequestEntity.setNew(false);
					log.info(PaymentConstants.LOG_PREFIX + "Request to Update Entity(). paymentRequestEntity: {}", correlationId, paymentRequestEntity);

					return repository.save(paymentRequestEntity).flatMap(entity1 -> {
						log.info(PaymentConstants.LOG_PREFIX + "Entity cancelScheduledPaymentRequest Updated: {}", correlationId, entity1);
						PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
						return Mono.just(paymentRequestDataDBResponse);
					}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId));
				}
				PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(
						PaymentErrors.ERROR_PAYMENT_REQUEST_INVALID_CANCELLATION);
				paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
				return Mono.error(paymentDataUnprocessableEntityException);
			});
		});
	}

	public Mono<PaymentRequestDataDBResponse> cancelScheduledAutoPayRequest(CancelACHPaymentRequest cancelACHPaymentRequest, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId)
			throws PaymentDataNotFoundException {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of DAO cancelScheduledAutoPayRequest(). cancelACHPaymentRequest: {}, paymentRequestDataDBResponse: {}", correlationId,
				cancelACHPaymentRequest, paymentRequestDataDBResponse);

		PaymentRequestEntity entity = PaymentCancellationMapper.mapFromPaymentRequestDTOToPaymentRequestEntity(paymentRequestDataDBResponse);
		if (entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.SCHEDULE.name())) {
			entity.setRequestStatus(cancelACHPaymentRequest.getPaymentStatus());
			entity.setUpdatedBy(cancelACHPaymentRequest.getAgentId());
			entity.setNew(false);
			log.info(PaymentConstants.LOG_PREFIX + "Request to Update Entity(). entity: {}", correlationId, entity);

			return repository.save(entity).flatMap(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity cancelScheduledAutoPayRequest Updated: {}", correlationId, entity1);
				PaymentRequestDataDBResponse paymentRequestDataDBResponseUpdated = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
				return Mono.just(paymentRequestDataDBResponseUpdated);
			}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
		}
		PaymentDataUnprocessableEntityException paymentDataUnprocessableEntityException = new PaymentDataUnprocessableEntityException(PaymentErrors.ERROR_NO_RECORD_FOUND);
		paymentDataUnprocessableEntityException.setHttpStatusCode(HttpStatus.UNPROCESSABLE_ENTITY);
		return Mono.error(paymentDataUnprocessableEntityException);
	}

	public Mono<PaymentRequestDataDBResponse> getProcessedOrPendingPaymentRequest(UUID paymentRequestId, CancelACHPaymentRequest cancelACHPaymentRequest, String correlationId)
			throws PaymentDataNotFoundException {
		log.debug(PaymentConstants.LOG_PREFIX + "Start of DAO getProcessedOrPendingPaymentRequest(). request: {}, paymentRequestId: {}", correlationId, cancelACHPaymentRequest,
				paymentRequestId);
		log.info(
				PaymentConstants.LOG_PREFIX
						+ "Request to findByPaymentRequestIdAndPaymentDateGreaterThanAndPaymentDateLessThan. paymentRequestId: {}, startPaymentDate {}, endPaymentDate{}",
				correlationId, paymentRequestId, ZonedDateTime.now().minusDays(1), ZonedDateTime.now().plusDays(1));
		Mono<PaymentRequestEntity> monoPaymentRequestEntity = repository.findByPaymentRequestIdAndPaymentDateGreaterThanAndPaymentDateLessThan(paymentRequestId,
				ZonedDateTime.now().minusDays(1), ZonedDateTime.now().plusDays(1));
		return monoPaymentRequestEntity.hasElement().flatMap(hasElement -> {
			if (hasElement) {
				return monoPaymentRequestEntity.flatMap(entity -> {
					log.info(PaymentConstants.LOG_PREFIX + "response to findByPaymentRequestIdAndPaymentDateGreaterThanAndPaymentDateLessThan(). response: {}", correlationId,
							entity);
					if (entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.PROCESSED.name()) || entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.PENDING.name())
							|| entity.getRequestStatus().equalsIgnoreCase(PaymentStatus.VOID.name())) {
						PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId);
						return Mono.just(paymentRequestDataDBResponse);
					}

					log.error(PaymentConstants.LOG_PREFIX + "Error in getProcessedOrPendingPaymentRequest(). error: {}", correlationId,
							PaymentErrors.ERROR_PAYMENT_NOT_IN_PROCESSED_OR_PENDING);
					PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
					paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
					return Mono.error(paymentDataNotFoundException);
				});
			}

			return logPaymentDataNotFound(correlationId);
		});
	}

	public Mono<Boolean> existsById(UUID paymentId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of existsById(), paymentId: {}", correlationId, paymentId);
		Mono<Boolean> monoResult = repository.existsById(paymentId);
		return monoResult.flatMap(exists -> {
			log.info(PaymentConstants.LOG_PREFIX + "existsById() response: {}", correlationId, exists);
			return Mono.just(exists);
		});
	}

	private Mono<PaymentRequestDataDBResponse> logPaymentDataNotFound(String correlationId) {
		log.error(PaymentConstants.LOG_PREFIX + "Error in getProcessedOrPendingPaymentRequest(). error: {}", correlationId, PaymentErrors.ERROR_NO_PAYMENT_DATA_AVAILABLE);
		PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
		paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
		return Mono.error(paymentDataNotFoundException);
	}

	public Mono<PaymentRequestDataDBResponse> updatePaymentEntityStatusPaymentRequestData(UUID paymentRequestId, String status, JSONObject paymentRequestData, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentEntityStatusPaymentRequestData(). paymentRequestId: {}, status: {}, paymentRequestData: {}", correlationId,
				paymentRequestId, status, paymentRequestData);

		return repository.findById(paymentRequestId).flatMap(entity -> {
			entity.setRequestStatus(status);
			entity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			entity.setNew(false);
			return repository.save(entity).flatMap(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
				return Mono.just(paymentRequestDataDBResponse);
			}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
		});
	}

	public Mono<PaymentRequestDataDBResponse> updatePaymentEntityPaymentRequestData(UUID paymentRequestId, JSONObject paymentRequestData, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentEntityStatusPaymentRequestData(). paymentRequestId: {}, status: {}, paymentRequestData: {}", correlationId,
				paymentRequestId, paymentRequestData);

		return repository.findById(paymentRequestId).flatMap(entity -> {
			entity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			entity.setNew(false);
			entity.setUpdatedTimestamp(LocalDateTime.now());
			return repository.save(entity).flatMap(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
				return Mono.just(paymentRequestDataDBResponse);
			}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
		});
	}

	public Mono<PaymentRequestDataDBResponse> updatePaymentEntityStatus(Map<String, Object> parameters) {
		UUID paymentRequestId = (UUID) parameters.get(PaymentConstants.PAYMENT_REQUEST_ID);
		String status = (String) parameters.get(PaymentConstants.STATUS);
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);
		String updatedBy = (String) parameters.get(PaymentConstants.UPDATED_BY);
		LocalDateTime updatedTimeStamp = (LocalDateTime) parameters.get(PaymentConstants.UPDATED_TIMESTAMP);

		JSONObject paymentRequestData = getPaymentRequestData(parameters);

		log.info(
				PaymentConstants.LOG_PREFIX + "Start of updatePaymentEntityStatus(). paymentRequestId: {}, status: {}, updatedBy: {}, updatedTimeStamp: {}, paymentRequestData: {}",
				correlationId, paymentRequestId, status, updatedBy, updatedTimeStamp, paymentRequestData);

		return repository.findById(paymentRequestId).flatMap(entity -> {
			entity.setRequestStatus(status);
			entity.setNew(false);
			entity.setUpdatedBy(updatedBy);
			entity.setUpdatedTimestamp(updatedTimeStamp);
			if (paymentRequestData != null) {
				entity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			}

			return repository.save(entity).flatMap(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
				return Mono.just(paymentRequestDataDBResponse);
			}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
		});
	}

	public Mono<PaymentRequestDataDBResponse> updatePaymentEntityFdrStatus(Map<String, Object> parameters) {
		UUID paymentRequestId = (UUID) parameters.get(PaymentConstants.PAYMENT_REQUEST_ID);
		String fdrStatus = (String) parameters.get(PaymentConstants.FDR_STATUS);
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);
		String updatedBy = (String) parameters.get(PaymentConstants.UPDATED_BY);
		LocalDateTime updatedTimeStamp = (LocalDateTime) parameters.get(PaymentConstants.UPDATED_TIMESTAMP);

		JSONObject paymentRequestData = getPaymentRequestData(parameters);

		log.info(
				PaymentConstants.LOG_PREFIX
						+ "Start of updatePaymentEntityStatus(). paymentRequestId: {}, Fdrstatus: {}, updatedBy: {}, updatedTimeStamp: {}, paymentRequestData: {}",
				correlationId, paymentRequestId, fdrStatus, updatedBy, updatedTimeStamp, paymentRequestData);

		return repository.findById(paymentRequestId).flatMap(entity -> {
			entity.setNew(false);
			entity.setUpdatedBy(updatedBy);
			entity.setUpdatedTimestamp(updatedTimeStamp);
			if (paymentRequestData != null) {
				entity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			}

			return repository.save(entity).flatMap(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(entity1, correlationId);
				return Mono.just(paymentRequestDataDBResponse);
			}).onErrorReturn(ClassCastException.class, mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId));
		});
	}

	private JSONObject getPaymentRequestData(Map<String, Object> parameters) {
		JSONObject paymentRequestData;
		if (parameters.get(PaymentConstants.PAYMENT_METADATA) != null) {
			paymentRequestData = (JSONObject) parameters.get(PaymentConstants.PAYMENT_METADATA);
		} else {
			paymentRequestData = null;
		}

		return paymentRequestData;
	}

	public Mono<PaymentRequestDataDBResponse> findByPaymentRequestId(UUID paymentRequestId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByPaymentRequestId(), paymentRequestId: {}", correlationId, paymentRequestId);

		Mono<PaymentRequestEntity> monoResult = repository.findByPaymentRequestId(paymentRequestId);
		return monoResult.flatMap(paymentRequestEntity -> {
			PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
			log.info(PaymentConstants.LOG_PREFIX + "findByPaymentRequestId() response: {}", correlationId, paymentRequestEntity);
			return Mono.just(paymentRequestDataDBResponse);
		});
	}

	public Mono<PaymentRequestDataDBResponse> findByPaymentRequestIdAndRequestStatus(UUID paymentRequestId, String requestStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByPaymentRequestIdAndRequestStatus(), paymentRequestId: {}, requestStatus: {}", correlationId, paymentRequestId, requestStatus);

		Mono<PaymentRequestEntity> monoResult = repository.findByPaymentRequestIdAndRequestStatus(paymentRequestId, requestStatus);
		return monoResult.flatMap(paymentRequestEntity -> {
			PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
			log.info(PaymentConstants.LOG_PREFIX + "findByPaymentRequestIdAndRequestStatus() response: {}", correlationId, paymentRequestEntity);
			return Mono.just(paymentRequestDataDBResponse);
		});
	}

	public Mono<PaymentRequestDataDBResponse> findByPaymentRequestIdAndAccountKey(UUID paymentRequestId, UUID accountKey, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByPaymentRequestId(), paymentRequestId: {}", correlationId, paymentRequestId);

		Mono<PaymentRequestEntity> monoResult = repository.findByPaymentRequestIdAndAccountKey(paymentRequestId, accountKey);
		return monoResult.flatMap(paymentRequestEntity -> {
			PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
			log.info(PaymentConstants.LOG_PREFIX + "findByPaymentRequestId() response: {}", correlationId, paymentRequestEntity);
			return Mono.just(paymentRequestDataDBResponse);
		});
	}

	public Flux<PaymentRequestDataDBResponse> findByRequestStatusInAndPaymentDateLessThan(List<String> listStatus, ZonedDateTime localDateTime, String correlationId) {
		return repository.findByRequestStatusInAndPaymentDateLessThan(listStatus, localDateTime).map(entity -> {
			return mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId);
		});
	}
	public Flux<PaymentRequestDataDBResponse> findByRequestStatusInAndPaymentDateLessThanAndCreatedBy(List<String> listStatus, ZonedDateTime localDateTime, String createdBy,String correlationId) {
		return repository.findByRequestStatusInAndPaymentDateLessThanAndCreatedByNot(listStatus, localDateTime,createdBy).map(entity -> {
			return mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId);
		});
	}

	public PaymentRequest getPaymentRequest(PaymentRequestEntity entity) throws ParseException {
		return PaymentMapper.fromPaymentRequestEntityToPaymentRequest(entity);
	}

	private PaymentRequest prepareHistoryResponse(PaymentRequestEntity entity, String correlationId) {
		PaymentRequest paymentRequest = new PaymentRequest();
		try {
			paymentRequest = getPaymentRequest(entity);
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error Parsing JSON, reason: {}", correlationId, e.toString());
			return paymentRequest;
		}
		return paymentRequest;
	}

	public Flux<PaymentRequest> findByQuery(Query query, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByQuery(), query criterias: {}, sorting: {}", correlationId, query.getCriteria().toString(),
				query.getSort().toString());

		return r2dbcEntityTemplate.select(query, PaymentRequestEntity.class).map(entity -> prepareHistoryResponse(entity, correlationId));
	}

	public Mono<Long> countByQuery(Query query, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of countByQuery(), query criterias: {}, sorting: {}", correlationId, query.getCriteria().toString(),
				query.getSort().toString());

		Mono<Long> monoResult = r2dbcEntityTemplate.select(query, PaymentRequestEntity.class).count();
		return monoResult.flatMap(result -> {
			log.info(PaymentConstants.LOG_PREFIX + "Result of countByQuery(), result: {}", correlationId, result);
			return Mono.just(result);
		});
	}

	public PaymentRequestDataDBResponse mapFromPaymentRequestEntityToPaymentRequestDTO(PaymentRequestEntity paymentRequestEntity, String correlationId) {
		PaymentRequestDataDBResponse paymentRequestDataDBResponse = new PaymentRequestDataDBResponse();
		paymentRequestDataDBResponse.setPaymentRequestId(paymentRequestEntity.getPaymentRequestId());
		paymentRequestDataDBResponse.setIndividualUniqueIdentifierKey(paymentRequestEntity.getIndividualUniqueIdentifierKey());
		paymentRequestDataDBResponse.setPaymentDate(paymentRequestEntity.getPaymentDate());
		paymentRequestDataDBResponse.setRequestStatus(paymentRequestEntity.getRequestStatus());
		paymentRequestDataDBResponse.setAccountKey(paymentRequestEntity.getAccountKey());
		paymentRequestDataDBResponse.setExternalAccountKey(paymentRequestEntity.getExternalAccountKey());
		paymentRequestDataDBResponse.setPaymentType(paymentRequestEntity.getPaymentType());
		paymentRequestDataDBResponse.setPartnerName(paymentRequestEntity.getPartnerName());
		paymentRequestDataDBResponse.setPaymentRequestData(paymentRequestEntity.getPaymentRequestData());
		paymentRequestDataDBResponse.setCreatedTimestamp(paymentRequestEntity.getCreatedTimestamp());
		paymentRequestDataDBResponse.setCreatedBy(paymentRequestEntity.getCreatedBy());
		paymentRequestDataDBResponse.setUpdatedTimestamp(paymentRequestEntity.getUpdatedTimestamp());
		paymentRequestDataDBResponse.setUpdatedBy(paymentRequestEntity.getUpdatedBy());
		paymentRequestDataDBResponse.setNew(paymentRequestEntity.isNew());
		paymentRequestDataDBResponse
				.setCorrelationId(PaymentUtil.getValueFromJsonObject(paymentRequestEntity.getPaymentRequestData(), PaymentConstants.CORRELATION_ID, correlationId));
		paymentRequestDataDBResponse
				.setCollectionIntentId(PaymentUtil.getValueFromJsonObject(paymentRequestEntity.getPaymentRequestData(), PaymentConstants.COLLECTION_INTENT_ID, correlationId));
		paymentRequestDataDBResponse
				.setPaymentConfirmation(PaymentUtil.getValueFromJsonObject(paymentRequestEntity.getPaymentRequestData(), PaymentConstants.PAYMENT_CONFIRMATION, correlationId));
		return paymentRequestDataDBResponse;
	}

	public Mono<UUID> updatePaymentRequestEntityStatus(String paymentStatus, UUID paymentRequestId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentRequestEntity().  paymentStatus: {}, paymentRequestId: {}", correlationId, paymentStatus, paymentRequestId);
		return repository.findById(paymentRequestId).switchIfEmpty(Mono.just(new PaymentRequestEntity())).flatMap(entity -> {
			entity.setUpdatedTimestamp(LocalDateTime.now());
			entity.setRequestStatus(paymentStatus);
			entity.setNew(false);
			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Update: {}", correlationId, entity);
			return repository.save(entity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, entity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	public Flux<PaymentRequestDataDBResponse> findPaymentsBetweenDates(Map<String, Object> paymentDates, List<String> status, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findPaymentsBetweenDates(), paymentDates: {}, status: {}", correlationId, paymentDates, status);
		ZonedDateTime lastStatementDate = (ZonedDateTime) paymentDates.getOrDefault(PaymentConstants.LAST_STATEMENT_DATE, ZonedDateTime.now());
		ZonedDateTime currentDate = (ZonedDateTime) paymentDates.getOrDefault(PaymentConstants.CURRENT_DATE, ZonedDateTime.now(ZoneId.of(paymentZoneId)));
		UUID accountKey = (UUID) paymentDates.get(PaymentConstants.ACCOUNT_KEY);
		UUID individualUniqueIdentifierKey = (UUID) paymentDates.get(PaymentConstants.INDIVIDUAL_UNIQUE_IDENTIFIER_KEY);
		Flux<PaymentRequestEntity> existingPaymentsToProcess = repository.findExistingPaymentsToProcess(accountKey, individualUniqueIdentifierKey, status,
				lastStatementDate.toLocalDateTime(), currentDate.toLocalDateTime());
		return existingPaymentsToProcess.map(paymentRequestEntity -> {
			return mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
		}).onErrorResume(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error in findPaymentsBetweenDates, error: {}", correlationId, e.getMessage());
			return Flux.error(new PaymentException(e.getMessage()));
		});
	}

	public Flux<PaymentRequestDataDBResponse> findAutoPayPaymentsToNotified(List<String> status, ZonedDateTime paymentDateStart, ZonedDateTime paymentDateEnd, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByRequestStatusInAndPaymentDateBetween(), status: {},Start{} endTime: {}", correlationId, status, paymentDateStart,
				paymentDateEnd);
		Flux<PaymentRequestEntity> existingPaymentsToProcess = repository.findByRequestStatusInAndPaymentDateGreaterThanAndPaymentDateLessThan(status, paymentDateStart,
				paymentDateEnd);
		return existingPaymentsToProcess.map(paymentRequestEntity -> {
			return mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
		}).onErrorResume(e -> {
			log.error(PaymentConstants.LOG_PREFIX + "Error in findAutoPayDatesTOSchedule, error: {}", correlationId, e.getMessage());
			return Flux.error(new PaymentException(e.getMessage()));
		});
	}

	public Mono<UUID> saveNotifiedPayment(Map<String, Object> parameters) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		String paymentStatus = (String) parameters.get(PaymentConstants.STATUS);
		String externalAccountLast4 = (String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
		String creditAccountLast4 = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_LAST4);

		if (parameters.get(PaymentConstants.CREDIT_ACCOUNT_LAST4) != null) {
			creditAccountLast4 = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_LAST4);
		}
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);

		log.info(PaymentConstants.LOG_PREFIX + "Start of saveNotifiedPayment(). request: {}, paymentStatus: {}, externalAccountLast4: {}, creditAccountLast4: {}", correlationId,
				paymentServiceRequest, paymentStatus, externalAccountLast4, creditAccountLast4);
		UUID uuidCustomerId = UUID.fromString(paymentServiceRequest.getCustomerId());
		UUID uuidExternalAccountId = UUID.fromString(paymentServiceRequest.getExternalAccountId());
		PaymentRequestEntity entity = PaymentMapper.mapPaymentRequestEntity(paymentServiceRequest, paymentStatus, uuidCustomerId, uuidExternalAccountId);
		String name = uuidCustomerId.toString() + uuidExternalAccountId.toString() + System.nanoTime();
		UUID paymentRequestId = UUIDGenerator.generateType5UUID(name);
		Mono<JSONObject> monoData = getJSONObjectDataForSaveNotifiedPayment(parameters, paymentRequestId);
		return monoData.flatMap(data -> {
			entity.setPaymentRequestData(Json.of(data.toJSONString()));
			entity.setPaymentRequestId(paymentRequestId);
			entity.setNew(true);

			log.debug(PaymentConstants.LOG_PREFIX + "Entity to Add: {}", correlationId, entity);

			return repository.save(entity).doOnSuccess(entity1 -> {
				log.info(PaymentConstants.LOG_PREFIX + "Entity Saved: {}", correlationId, entity1);
			}).onErrorReturn(ClassCastException.class, entity).map(PaymentRequestEntity::getPaymentRequestId);
		});
	}

	public Mono<UUID> updateNotifiedPayment(UUID paymentRequestId, String paymentStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateNotifiedPayment(). paymentRequestId: {}, paymentStatus: {}", correlationId, paymentRequestId, paymentStatus);
		Mono<PaymentRequestEntity> monoPaymentRequestEntity = repository.findByPaymentRequestId(paymentRequestId);

		return monoPaymentRequestEntity.hasElement().flatMap(hasElement -> {
			if (!hasElement) {
				log.error(PaymentConstants.LOG_PREFIX + "Not Record Found with paymentRequestId: {}", correlationId, paymentRequestId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CUSTOMER_IS_INVALID);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}

			return monoPaymentRequestEntity.flatMap(paymentRequestEntity -> {
				paymentRequestEntity.setRequestStatus(paymentStatus);
				return repository.save(paymentRequestEntity).flatMap(paymentRequestEntityUpdated -> {
					log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, paymentRequestEntityUpdated);
					return Mono.just(paymentRequestEntityUpdated.getPaymentRequestId());
				});
			});
		});

	}

	private Mono<JSONObject> getJSONObjectDataForSaveNotifiedPayment(Map<String, Object> parameters, UUID paymentRequestId) {
		JSONObject data = new JSONObject();
		Map<String, Object> dataParams = PaymentMapper.getDataParamsFromPaymentServiceRequest(parameters, configuredFeeAmount);
		String confirmationCode = null;
		try {
			confirmationCode = generateConfirmationCode(paymentRequestId);
		} catch (NoSuchAlgorithmException e) {
			return Mono.error(new PaymentDataException(PaymentErrors.ERROR_CONFIRMATION_CODE));
		}
		dataParams.put(PaymentConstants.PAYMENT_CONFIRMATION, confirmationCode);
		data.putAll(dataParams);
		return Mono.just(data);
	}

	public Flux<PaymentRequestDataDBResponse> findByRequestIdsIn(List<UUID> paymentRequestIds, String correlationId) {
		return repository.findByPaymentRequestIdIn(paymentRequestIds).map(entity -> {
			return mapFromPaymentRequestEntityToPaymentRequestDTO(entity, correlationId);
		});
	}

	public Mono<PaymentRequestDataDBResponse> updatePaymentRequestStatus(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent, PaymentCommunicationResponse paymentCommunicationResponse, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updatePaymentRequestStatus(), paymentCommunicationResponse: {}, achPartnerMoneyMovementKafkaEvent: {}", correlationId,
				paymentCommunicationResponse, achPartnerMoneyMovementKafkaEvent);
		UUID paymentRequestId = UUID.fromString(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId());
		return repository.findByPaymentRequestId(paymentRequestId).flatMap(entity -> {
			return updateRequestStatus(entity, achPartnerMoneyMovementKafkaEvent, paymentCommunicationResponse, correlationId).flatMap(paymentRequestEntity -> {
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
				log.info(PaymentConstants.LOG_PREFIX + "updatePaymentRequestStatus() response: {}", correlationId, paymentRequestDataDBResponse);
				return Mono.just(paymentRequestDataDBResponse);
			});
		});
	}
	/*
	 * for (int i = 0; i < paymentMetadata.size(); i++) { JSONObject
	 * processedJson=(JSONObject) paymentMetadata.get(i); String
	 * paymentStatus=(String) processedJson.get(PaymentConstants.PAYMENT_EVENT); if(
	 * paymentStatus.equalsIgnoreCase("PROCESSED")) {
	 * processedJson.put(achPartnerMoneyMovementKafkaEvent, paymentStatus) } //
	 * items[i] = new Application(res.getJSONObject(i)); }
	 */

	public Mono<Boolean> updateCommunicationAndCollectionId(PaymentDataTransferRequest paymentDataDto, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateRequestStatus(), ", correlationId);
		return repository.findByPaymentRequestId(paymentDataDto.getPaymentRequestId()).flatMap(paymentRequestEntity -> {
			JSONParser parser = new JSONParser();
			JSONObject paymentRequestData = null;
			try {
				paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
			} catch (ParseException e) {
				log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity + ", error: " + e.toString(), correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}

			if (paymentRequestData != null) {
				JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
				for (int i = 0; i < paymentMetadata.size(); i++) {
					JSONObject processedJson = (JSONObject) paymentMetadata.get(i);
					String paymentStatus = (String) processedJson.get(PaymentConstants.PAYMENT_EVENT);
					if (PaymentStatus.PROCESSED.getValue().equalsIgnoreCase(paymentStatus)) {
						processedJson.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentDataDto.getCommunicationRequestId());
					}
				}
				paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
				paymentRequestData.put(PaymentConstants.COLLECTION_INTENT_ID, paymentDataDto.getCollectionIntentId());
				paymentRequestEntity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			}
			paymentRequestEntity.setNew(false);
			return repository.save(paymentRequestEntity).flatMap(paymentRequestEntityUpdated -> {
				PaymentRequestDataDBResponse paymentRequestDataDBResponse = mapFromPaymentRequestEntityToPaymentRequestDTO(paymentRequestEntity, correlationId);
				log.info(PaymentConstants.LOG_PREFIX + "updatePaymentRequestStatus() response: {}", correlationId, paymentRequestDataDBResponse);
				return Mono.just(true);
			});
		});
	}

	private Mono<PaymentRequestEntity> updateRequestStatus(PaymentRequestEntity paymentRequestEntity, AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent, PaymentCommunicationResponse paymentCommunicationResponse, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateRequestStatus(), achPartnerMoneyMovementKafkaEvent: {}, paymentCommunicationResponse: {}", correlationId,
				achPartnerMoneyMovementKafkaEvent, paymentCommunicationResponse);
		if (PaymentStatus.PROCESSED.getValue().equalsIgnoreCase(paymentRequestEntity.getRequestStatus())) {
			paymentRequestEntity.setRequestStatus(PaymentStatus.POSTED.getValue());
			paymentRequestEntity.getPaymentRequestData();
			JSONParser parser = new JSONParser();
			JSONObject paymentRequestData = null;
			try {
				paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());
			} catch (ParseException e) {
				log.error(PaymentConstants.LOG_PREFIX + "Error While parsing paymentRequestData" + paymentRequestEntity + ", error: " + e.toString(), correlationId);
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				return Mono.error(paymentDataException);
			}
			if (paymentRequestData != null) {
				paymentRequestData.put(PaymentConstants.POSTED_DATE, PaymentUtil.formatDate(
						PaymentUtil.parseDate(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getUpdatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE),
						PaymentConstants.YYYY_MM_DD));

				JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);

				JSONObject noteJSONObject = new JSONObject();
				ZonedDateTime zonedDateTime = PaymentUtil.utcNow();
				String date = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATETIMEFORMAT_RESPONSE);
				noteJSONObject.put(PaymentConstants.DATE, date);
				noteJSONObject.put(PaymentConstants.NOTES, PaymentConstants.NOTES_FOR_PAYMENT_POSTED);
				noteJSONObject.put(PaymentConstants.PAYMENT_EVENT, PaymentStatus.POSTED.getValue());
				noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentCommunicationResponse.getCommunicationRequestId());
				paymentMetadata.add(noteJSONObject);
				paymentRequestData.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);

				paymentRequestEntity.setPaymentRequestData(Json.of(paymentRequestData.toJSONString()));
			}
		}

		return repository.save(paymentRequestEntity).flatMap(paymentRequestEntityUpdated -> {
			log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, paymentRequestEntityUpdated);
			return Mono.just(paymentRequestEntityUpdated);
		});
	}
}