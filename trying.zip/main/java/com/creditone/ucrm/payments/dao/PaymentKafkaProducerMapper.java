package com.creditone.ucrm.payments.dao;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.drools.util.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;

import com.creditone.ucrm.payments.constant.FDRStatus;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEventMetaData;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEventPayload;
import com.creditone.ucrm.payments.events.kafka.KafkaEventHeader;
import com.creditone.ucrm.payments.events.kafka.PaymentRequestEventData;
import com.creditone.ucrm.payments.events.kafka.PaymentRequestEventMetadata;
import com.creditone.ucrm.payments.events.kafka.PaymentsKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;

public class PaymentKafkaProducerMapper {
	static DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US);

	public static PaymentsKafkaEvent mapPaymentsKafkaEventFromPaymentServiceRequest(Map<String, Object> parameters) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		UUID paymentRequestId = (UUID) parameters.get(PaymentConstants.PAYMENT_REQUEST_ID);
		String status = (String) parameters.get(PaymentConstants.STATUS);
		Map<String, Object> resultMap = (Map<String, Object>) parameters.get(PaymentConstants.MAP_RESULT);
		String correlationId = (String) parameters.get(PaymentConstants.CORRELATION_ID);
		PaymentRequestEventData eventData = getPaymentRequestEventData(paymentServiceRequest, paymentRequestId, status, resultMap);
		KafkaEventHeader eventHeader = new KafkaEventHeader();
		eventHeader.setEventCreatedTimestamp(LocalDateTime.now());
		eventHeader.setEventSource(PaymentConstants.PAYMENT_SERVICE);
		eventHeader.setTraceId(correlationId);
		PaymentsKafkaEvent event = new PaymentsKafkaEvent();
		event.setEventHeader(eventHeader);
		event.setEventData(eventData);
		return event;
	}

	public static PaymentsKafkaEvent mapPaymentsKafkaEventFromPaymentServiceDto(PaymentDataTransferRequest paymentRequestDto) {
		PaymentRequestEventData eventData = getPaymentRequestEventData(paymentRequestDto);
		KafkaEventHeader eventHeader = new KafkaEventHeader();
		eventHeader.setEventCreatedTimestamp(LocalDateTime.now());
		eventHeader.setEventSource(PaymentConstants.PAYMENT_SERVICE);
		eventHeader.setTraceId(paymentRequestDto.getCorrelationId());
		PaymentsKafkaEvent event = new PaymentsKafkaEvent();
		event.setEventHeader(eventHeader);
		event.setEventData(eventData);
		return event;
	}

	public static PaymentRequestEventData getPaymentRequestEventData(PaymentDataTransferRequest paymentRequestDto) {
		PaymentRequestEventData eventData = new PaymentRequestEventData();
		eventData.setPaymentRequestId(paymentRequestDto.getPaymentRequestId());
		eventData.setCustomerId(UUID.fromString(paymentRequestDto.getCustomerId()));
		eventData.setCreditAccountId(UUID.fromString(paymentRequestDto.getCreditAccountId()));
		eventData.setExternalAccountId(UUID.fromString(paymentRequestDto.getExternalAccountId()));
		eventData.setPaymentType(paymentRequestDto.getPaymentType());
		eventData.setPaymentMode(paymentRequestDto.getPaymentMode());
		eventData.setFeeAmount(
				Boolean.TRUE.equals(paymentRequestDto.getExpressPayDecesion()) ? PaymentMapper.convertObjectToBigDecimal(paymentRequestDto.getFeeAmount()) : BigDecimal.ZERO);
		eventData.setPaymentAmount(paymentRequestDto.getPaymentAmount());
		eventData.setScheduledDate(paymentRequestDto.getScheduledDate());
		eventData.setChannel(paymentRequestDto.getChannel());
		eventData.setAgentId(paymentRequestDto.getAgentId());
		getJsonData(paymentRequestDto, eventData);
		PaymentRequestEventMetadata paymentRequestEventMetadata = new PaymentRequestEventMetadata();
		eventData.setExpresspayCondition(paymentRequestDto.getExpressPayCondition());
		PaymentKafkaProducerMetaDataMapper.getPaymentMetaData(paymentRequestDto, paymentRequestEventMetadata);
		eventData.setPaymentMetadata(paymentRequestEventMetadata);

		return eventData;
	}

	private static void getJsonData(PaymentDataTransferRequest paymentRequestDto, PaymentRequestEventData eventData) {
		eventData.setFdrStatus(paymentRequestDto.getFdrStatus());
		eventData.setStatus(paymentRequestDto.getStatus());
		eventData.setFeeWaiverAmount(PaymentMapper.convertObjectToBigDecimal(paymentRequestDto.getFeeWaiverAmount()) != null
				? PaymentMapper.convertObjectToBigDecimal(paymentRequestDto.getFeeWaiverAmount()).toString()
				: null);
		eventData.setFeeWaived(paymentRequestDto.getFeeWaived() != null ? paymentRequestDto.getFeeWaived().toString() : null);
		eventData.setRiskyPayment(paymentRequestDto.getRiskyPayment() != null ? paymentRequestDto.getRiskyPayment().toString() : null);
		eventData.setRiskLevel(paymentRequestDto.getRiskLevel() != null ? paymentRequestDto.getRiskLevel().toString() : null);
		eventData.setFloatDays(paymentRequestDto.getFloatDays() != null ? (Integer) paymentRequestDto.getFloatDays() : null);
		eventData.setExpressPayDecision(paymentRequestDto.getExpressPayDecesion() != null ? paymentRequestDto.getExpressPayDecesion().toString() : null);
		eventData.setExpresspayCondition(paymentRequestDto.getExpressPayCondition());
		eventData.setTransactionDate(PaymentUtil.formatDate(paymentRequestDto.getCreatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
		eventData.setCreatedTimestamp(PaymentUtil.formatDate(paymentRequestDto.getCreatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
		eventData.setExpresspayCondition(paymentRequestDto.getExpressPayCondition());
		eventData.setUpdatedBy(paymentRequestDto.getUpdatedBy());
		eventData.setCreatedBy(paymentRequestDto.getCreatedBy());
		eventData.setUpdatedTimestamp(PaymentUtil.formatDate(paymentRequestDto.getUpdatedTimestamp(), PaymentConstants.DATETIMEFORMAT_RESPONSE));
		eventData.setPaymentConfirmation(paymentRequestDto.getConfirmationCode() != null ? paymentRequestDto.getConfirmationCode().toString() : null);
		eventData.setAccountType(paymentRequestDto.getExternalAccountType());
	}

	private static PaymentRequestEventData getPaymentRequestEventData(PaymentServiceRequest request, UUID paymentRequestId, String status, Map<String, Object> resultMap) {
		PaymentRequestEventData eventData = new PaymentRequestEventData();
		eventData.setPaymentRequestId(paymentRequestId);
		eventData.setCustomerId(UUID.fromString(request.getCustomerId()));
		eventData.setCreditAccountId(UUID.fromString(request.getCreditAccountId()));
		eventData.setExternalAccountId(UUID.fromString(request.getExternalAccountId()));
		eventData.setPaymentType(request.getPaymentType());
		eventData.setPaymentMode(request.getPaymentMode().name());
		eventData.setFeeAmount(PaymentMapper.convertObjectToBigDecimal(resultMap.get(PaymentConstants.FEE_AMOUNT)));
		eventData.setPaymentAmount(request.getPaymentAmount());
		eventData.setScheduledDate(request.getScheduledDate());
		eventData.setChannel(request.getChannel());
		eventData.setAgentId(request.getAgentId());
		eventData.setFdrStatus((status != null && status.equalsIgnoreCase(PaymentStatus.PROCESSED.name())) ? FDRStatus.PENDING.name() : status);
		eventData.setStatus(status);
		eventData.setFeeWaiverAmount(PaymentMapper.convertObjectToBigDecimal(resultMap.get(PaymentConstants.FEE_WAIVER_AMOUNT)) != null
				? PaymentMapper.convertObjectToBigDecimal(resultMap.get(PaymentConstants.FEE_WAIVER_AMOUNT)).toString()
				: null);
		getEventDataFromMap(resultMap, eventData);
		PaymentRequestEventMetadata paymentRequestEventMetadata = new PaymentRequestEventMetadata();
		PaymentKafkaProducerMetaDataMapper.getEventMetaData(request, resultMap, paymentRequestEventMetadata);
		eventData.setPaymentMetadata(paymentRequestEventMetadata);

		return eventData;
	}

	private static void getEventDataFromMap(Map<String, Object> resultMap, PaymentRequestEventData eventData) {
		eventData.setFeeWaived(resultMap.get(PaymentConstants.FEE_WAIVED) != null ? resultMap.get(PaymentConstants.FEE_WAIVED).toString() : null);
		eventData.setRiskyPayment(resultMap.get(PaymentConstants.RISKY_PAYMENT) != null ? resultMap.get(PaymentConstants.RISKY_PAYMENT).toString() : null);
		eventData.setRiskLevel(resultMap.get(PaymentConstants.RISK_LEVEL) != null ? resultMap.get(PaymentConstants.RISK_LEVEL).toString() : null);
		eventData.setFloatDays(resultMap.get(PaymentConstants.FLOAT_DAYS) != null ? (Integer) resultMap.get(PaymentConstants.FLOAT_DAYS) : null);
		eventData.setExpressPayDecision(resultMap.get(PaymentConstants.EXPRESS_PAY) != null ? resultMap.get(PaymentConstants.EXPRESS_PAY).toString() : null);
		eventData.setTransactionDate((String) resultMap.get(PaymentConstants.CREATED_DATE));
		eventData.setPaymentConfirmation(resultMap.get(PaymentConstants.PAYMENT_CONFIRMATION) != null ? resultMap.get(PaymentConstants.PAYMENT_CONFIRMATION).toString() : null);
	}

	public static PaymentsKafkaEvent mapPaymentsKafkaEventFromDatabase(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) throws ParseException {
		PaymentRequestEventData eventData = new PaymentRequestEventData();
		eventData.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId());
		eventData.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
		eventData.setCreditAccountId(paymentRequestDataDBResponse.getAccountKey());
		eventData.setExternalAccountId(paymentRequestDataDBResponse.getExternalAccountKey());
		eventData.setPaymentType(paymentRequestDataDBResponse.getPaymentType());

		DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US);
		String formattedString = paymentRequestDataDBResponse.getPaymentDate().format(CUSTOM_FORMATTER);
		eventData.setScheduledDate(formattedString);
		eventData.setUpdatedTimestamp(paymentRequestDataDBResponse.getUpdatedTimestamp().format(CUSTOM_FORMATTER));
		eventData.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		eventData.setStatus(paymentRequestDataDBResponse.getRequestStatus());
		eventData.setPaymentConfirmation(paymentRequestDataDBResponse.getPaymentConfirmation());
		eventData.setCreatedTimestamp(paymentRequestDataDBResponse.getCreatedTimestamp().format(CUSTOM_FORMATTER));
		editJson(eventData, paymentRequestDataDBResponse);

		KafkaEventHeader eventHeader = new KafkaEventHeader();
		eventHeader.setEventCreatedTimestamp(LocalDateTime.now());
		eventHeader.setEventSource(PaymentConstants.PAYMENT_SERVICE);
		eventHeader.setTraceId(correlationId);

		PaymentsKafkaEvent event = new PaymentsKafkaEvent();
		event.setEventHeader(eventHeader);
		event.setEventData(eventData);

		return event;
	}

	public static PaymentsKafkaEvent mapFdrPaymentsKafkaEventFromDatabase(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) throws ParseException {
		PaymentRequestEventData eventData = new PaymentRequestEventData();
		eventData.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId());
		eventData.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
		eventData.setCreditAccountId(paymentRequestDataDBResponse.getAccountKey());
		eventData.setExternalAccountId(paymentRequestDataDBResponse.getExternalAccountKey());
		eventData.setPaymentType(paymentRequestDataDBResponse.getPaymentType());

		DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US);
		String formattedString = paymentRequestDataDBResponse.getPaymentDate().format(CUSTOM_FORMATTER);
		eventData.setScheduledDate(formattedString);

		eventData.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		eventData.setStatus(paymentRequestDataDBResponse.getRequestStatus());
		eventData.setPaymentConfirmation(paymentRequestDataDBResponse.getPaymentConfirmation());
		eventData.setUpdatedTimestamp(paymentRequestDataDBResponse.getUpdatedTimestamp().format(CUSTOM_FORMATTER));
		editJsonForFdr(eventData, paymentRequestDataDBResponse);

		KafkaEventHeader eventHeader = new KafkaEventHeader();
		eventHeader.setEventCreatedTimestamp(LocalDateTime.now());
		eventHeader.setEventSource(PaymentConstants.PAYMENT_SERVICE);
		eventHeader.setTraceId(correlationId);

		PaymentsKafkaEvent event = new PaymentsKafkaEvent();
		event.setEventHeader(eventHeader);
		event.setEventData(eventData);

		return event;
	}

	public static void editJson(PaymentRequestEventData eventData, PaymentRequestDataDBResponse paymentRequestDataDBResponse) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());

		String paymentMode = (String) paymentRequestData.get(PaymentConstants.PAYMENT_MODE);
		eventData.setPaymentMode(paymentMode);

		eventData.setFeeAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.FEE_AMOUNT)));

		eventData.setPaymentAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT)));

		String channel = (String) paymentRequestData.get(PaymentConstants.CHANNEL);
		eventData.setChannel(channel);
		eventData.setExpressPayDecision(String.valueOf(paymentRequestData.get(PaymentConstants.EXPRESS_PAY_DECISION)));
		eventData.setFdrStatus(String.valueOf(paymentRequestData.get(PaymentConstants.FDR_STATUS)));
		PaymentRequestEventMetadata paymentRequestEventMetadata = new PaymentRequestEventMetadata();
		List<JSONObject> listPaymentRequestData = (List<JSONObject>) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		if (listPaymentRequestData != null) {
			PaymentKafkaProducerMetaDataMapper.setFdrMetaData(eventData, paymentRequestEventMetadata, listPaymentRequestData);
		}
		eventData.setPaymentMetadata(paymentRequestEventMetadata);
	}

	public static void editJsonForFdr(PaymentRequestEventData eventData, PaymentRequestDataDBResponse paymentRequestDataDBResponse) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		String paymentMode = (String) paymentRequestData.get(PaymentConstants.PAYMENT_MODE);
		eventData.setPaymentMode(paymentMode);

		eventData.setFeeAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.FEE_AMOUNT)));

		eventData.setPaymentAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT)));

		String channel = (String) paymentRequestData.get(PaymentConstants.CHANNEL);
		eventData.setChannel(channel);

		eventData.setPaymentMode((String) paymentRequestData.get(PaymentConstants.PAYMENT_MODE));
		eventData.setFdrStatus(paymentRequestData.get(PaymentConstants.FDR_STATUS) != null ? (String) paymentRequestData.get(PaymentConstants.FDR_STATUS) : null);
		eventData.setFdrPostedDate(paymentRequestData.get(PaymentConstants.FDR_POSTED_DATE) != null ? (String) paymentRequestData.get(PaymentConstants.FDR_POSTED_DATE) : null);
		eventData.setPaymentConfirmation(
				paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION) != null ? (String) paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION) : null);
		eventData.setFdrVerifiedDate(
				paymentRequestData.get(PaymentConstants.FDR_VERIFIED_DATE) != null ? (String) paymentRequestData.get(PaymentConstants.FDR_VERIFIED_DATE) : null);
		eventData.setExpressPayDecision(
				paymentRequestData.get(PaymentConstants.EXPRESS_PAY_DECISION) != null ? String.valueOf(paymentRequestData.get(PaymentConstants.EXPRESS_PAY_DECISION)) : null);
		eventData.setFeeWaived(paymentRequestData.get(PaymentConstants.FEE_WAIVED) != null ? (String) paymentRequestData.get(PaymentConstants.FEE_WAIVED) : null);
		eventData.setRiskyPayment(paymentRequestData.get(PaymentConstants.RISKY_PAYMENT) != null ? (String) paymentRequestData.get(PaymentConstants.RISKY_PAYMENT) : null);
		eventData.setFloatDays(paymentRequestData.get(PaymentConstants.FLOAT_DAYS) != null ? (Integer) paymentRequestData.get(PaymentConstants.FLOAT_DAYS) : null);
		eventData.setUpdatedTimestamp(
				paymentRequestDataDBResponse.getUpdatedTimestamp() != null ? paymentRequestDataDBResponse.getUpdatedTimestamp().format(CUSTOM_FORMATTER) : null);
		PaymentRequestEventMetadata paymentRequestEventMetadata = new PaymentRequestEventMetadata();

		List<JSONObject> listPaymentRequestData = (List<JSONObject>) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		if (listPaymentRequestData != null) {
			PaymentKafkaProducerMetaDataMapper.setFdrMetaData(eventData, paymentRequestEventMetadata, listPaymentRequestData);
		}

	}

	public static CustomerInteractionEvent mapCustomerInteractionKafkaEventFromDatabase(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();

		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);

		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = new CustomerInteractionKafkaEventMetaData();
		customerInteractionKafkaEventMetaData.setChannelCode(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.VOICE : PaymentConstants.USER);
		customerInteractionKafkaEventMetaData.setDeviceType(getDeviceType(channel));
		customerInteractionKafkaEventMetaData.setActorType(getActorType(channel));
		customerInteractionKafkaEventMetaData.setApplicationType(PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setIntentGroup(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME : PaymentConstants.PAYMENT);
		customerInteractionKafkaEventMetaData.setEventTime(PaymentUtil.utcNow());
		customerInteractionKafkaEventMetaData.setActivityId(String
				.valueOf(UUID.nameUUIDFromBytes(("payment-Service-api" + "creditcardfinancials" + paymentRequestDataDBResponse.getCreatedTimestamp().toString()).getBytes())));
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setEventSourceId(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId());
		customerInteractionKafkaEventMetaData.setCorrelationId(paymentRequestDataDBResponse.getCorrelationId());

		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setDescription("Payment Posted Successfully");
		customerInteractionKafkaEventPayload.setAmount(PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId)));
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setStatus(PaymentStatus.POSTED.getValue());
		customerInteractionKafkaEventPayload.setServiceActivityId(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId());
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString());

		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	private static String getActorType(String channel) {
		if (PaymentConstants.AGENT.equalsIgnoreCase(channel)) {
			return PaymentConstants.AGENT;
		} else if (PaymentConstants.WEB.equalsIgnoreCase(channel) || PaymentConstants.MOBILE.equalsIgnoreCase(channel)) {
			return PaymentConstants.CUSTOMER;
		} else {
			return PaymentConstants.BOT;
		}
	}

	private static String getDeviceType(String channel) {
		if (PaymentConstants.AGENT.equalsIgnoreCase(channel)) {
			return PaymentConstants.PHYSICAL;
		} else if (PaymentConstants.WEB.equalsIgnoreCase(channel)) {
			return PaymentConstants.WEB;
		} else if (PaymentConstants.MOBILE.equalsIgnoreCase(channel)) {
			return PaymentConstants.MOBILE;
		} else {
			return null;
		}
	}

	public static PaymentsKafkaEvent mapDataDBResponseToPaymentsKakfaEvent(PaymentRequestDataDBResponse paymentRequestDataDBResponse, CancelACHPaymentRequest cancelACHPaymentRequest, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject dataParams = null;
		String paymentPurpose = StringUtils.EMPTY;
		String agentId = cancelACHPaymentRequest.getAgentId();
		Map<String,Object> argsMap = new HashMap<String,Object>();
		String metaDataStatus=cancelACHPaymentRequest.getPaymentStatus().equalsIgnoreCase(PaymentStatus.VOID.name())?PaymentStatus.PROCESSED.name():PaymentStatus.SCHEDULE.name();
		try {
			dataParams = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
			} catch (ParseException e) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		try {
					List<JSONObject> paymentMetadataNodeList = (List<JSONObject>) dataParams.get(PaymentConstants.PAYMENT_METADATA);
					if (paymentMetadataNodeList != null  && paymentMetadataNodeList.size() > 0) {
						for (Map<String, Object> note  : paymentMetadataNodeList) {
							if (note.get(PaymentConstants.PAYMENT_EVENT) != null
									&& metaDataStatus.equalsIgnoreCase(String.valueOf(note.get(PaymentConstants.PAYMENT_EVENT)))) {
								paymentPurpose = String.valueOf(note.get(PaymentConstants.PAYMENT_PURPOSE));
								argsMap.put(PaymentConstants.RISK_LEVEL,
										note.get(PaymentConstants.RISK_LEVEL) != null ? String.valueOf(note.get(PaymentConstants.RISK_LEVEL)) : "");
								argsMap.put(PaymentConstants.CARD_TYPE, note.get(PaymentConstants.CARD_TYPE) != null ? String.valueOf(note.get(PaymentConstants.CARD_TYPE)) : "");
								argsMap.put(PaymentConstants.COMMUNICATION_REQUEST_ID,
										note.get(PaymentConstants.COMMUNICATION_REQUEST_ID) != null ? String.valueOf(note.get(PaymentConstants.COMMUNICATION_REQUEST_ID)) : "");
							}
						}
									
			}
		} catch (Exception e) {
			// log.error(PaymentConstants.LOG_PREFIX + e, correlationId);
		}
		getDataMap(paymentRequestDataDBResponse, dataParams, paymentPurpose, agentId, argsMap);
		PaymentsKafkaEvent paymentsKafkaEvent = returnPaymentsKafaEvent(paymentRequestDataDBResponse, argsMap, correlationId);
		return paymentsKafkaEvent;
	}

	private static void getDataMap(PaymentRequestDataDBResponse paymentRequestDataDBResponse, JSONObject dataParams, String paymentPurpose, String agentId, Map<String, Object> argsMap) {
		String requestStatus = paymentRequestDataDBResponse.getRequestStatus() != null ? paymentRequestDataDBResponse.getRequestStatus() : "";
		Object feeAmount = dataParams.get(PaymentConstants.FEE_AMOUNT) != null ? (Object) dataParams.get(PaymentConstants.FEE_AMOUNT) : "";
		Object paymentAmount = dataParams.get(PaymentConstants.PAYMENT_AMOUNT) != null ? (Object) dataParams.get(PaymentConstants.PAYMENT_AMOUNT) : "";
		String channel = dataParams.get(PaymentConstants.CHANNEL) != null ? (String) dataParams.get(PaymentConstants.CHANNEL) : "";
		String paymentConfirmation = dataParams.get(PaymentConstants.PAYMENT_CONFIRMATION) != null ? (String) dataParams.get(PaymentConstants.PAYMENT_CONFIRMATION) : "";
		String expressPayDecision = dataParams.get(PaymentConstants.EXPRESS_PAY_DECISION) != null ? String.valueOf(dataParams.get(PaymentConstants.EXPRESS_PAY_DECISION)) : "false";
		argsMap.put(PaymentConstants.FEE_AMOUNT, feeAmount);
		argsMap.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount);
		argsMap.put(PaymentConstants.CHANNEL, channel);
		argsMap.put(PaymentConstants.PAYMENT_CONFIRMATION, paymentConfirmation);
		argsMap.put(PaymentConstants.PAYMENT_PURPOSE, paymentPurpose);
		argsMap.put(PaymentConstants.REQUEST_STATUS, requestStatus);
		argsMap.put(PaymentConstants.AGENT_ID, agentId);
		argsMap.put(PaymentConstants.PAYMENT_MODE, dataParams.get(PaymentConstants.PAYMENT_MODE));
		argsMap.put(PaymentConstants.EXPRESS_PAY_DECISION, expressPayDecision);
		argsMap.put(PaymentConstants.PAYMENT_MODE, dataParams.get(PaymentConstants.PAYMENT_MODE));
		
	}

	public static PaymentsKafkaEvent returnPaymentsKafaEvent(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map argsMap, String correlationId) {
		PaymentsKafkaEvent paymentsKafkaEvent = new PaymentsKafkaEvent();
		KafkaEventHeader kafkaEventHeader = new KafkaEventHeader();
		kafkaEventHeader.setTraceId(correlationId);
		kafkaEventHeader.setEventCreatedTimestamp(LocalDateTime.now());
		kafkaEventHeader.setEventSource(PaymentConstants.PAYMENT_SERVICE);
		paymentsKafkaEvent.setEventHeader(kafkaEventHeader);
		PaymentRequestEventData paymentRequestEventData = new PaymentRequestEventData();
		getCancelEventData(paymentRequestDataDBResponse, argsMap, paymentRequestEventData);
		String agentId = (String) argsMap.get(PaymentConstants.AGENT_ID);
		String paymentPurpose = (String) argsMap.get(PaymentConstants.PAYMENT_PURPOSE);
		String requestStatus = (String) argsMap.get(PaymentConstants.REQUEST_STATUS);

		PaymentRequestEventMetadata paymentUpdatesEventMetadata = getPaymentUpdatesEventMetadata(agentId, paymentPurpose, requestStatus);
		paymentUpdatesEventMetadata.setCommunicationRequestId((String) argsMap.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
		paymentRequestEventData.setPaymentMetadata(paymentUpdatesEventMetadata);
		paymentRequestEventData.setRiskLevel(String.valueOf(argsMap.get(PaymentConstants.RISK_LEVEL)));
		paymentUpdatesEventMetadata.setCreditAccountType(String.valueOf(argsMap.get(PaymentConstants.CARD_TYPE)));
		paymentsKafkaEvent.setEventData(paymentRequestEventData);
		return paymentsKafkaEvent;
	}

	private static void getCancelEventData(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map argsMap, PaymentRequestEventData paymentRequestEventData) {
		paymentRequestEventData.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId());
		paymentRequestEventData.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
		paymentRequestEventData.setCreditAccountId(UUID.fromString(paymentRequestDataDBResponse.getAccountKey().toString()));
		paymentRequestEventData.setExternalAccountId(UUID.fromString(paymentRequestDataDBResponse.getExternalAccountKey().toString()));
		paymentRequestEventData.setPaymentType(paymentRequestDataDBResponse.getPaymentType());
		paymentRequestEventData.setPaymentMode((String) argsMap.get(PaymentConstants.PAYMENT_MODE));
		paymentRequestEventData.setFeeAmount(PaymentMapper.convertObjectToBigDecimal((Object) argsMap.get(PaymentConstants.FEE_AMOUNT)));
		paymentRequestEventData.setPaymentAmount(PaymentMapper.convertObjectToBigDecimal((Object) argsMap.get(PaymentConstants.PAYMENT_AMOUNT)));
		paymentRequestEventData.setScheduledDate(ZonedDateTime.now().format(DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE)));
		DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US);
		paymentRequestEventData.setTransactionDate(String.valueOf(paymentRequestDataDBResponse.getPaymentDate()));
		paymentRequestEventData.setCreatedTimestamp(
				paymentRequestDataDBResponse.getCreatedTimestamp() != null ? paymentRequestDataDBResponse.getCreatedTimestamp().format(CUSTOM_FORMATTER) : null);
		paymentRequestEventData.setCreatedBy(paymentRequestDataDBResponse.getCreatedBy());
		paymentRequestEventData.setUpdatedTimestamp(
				paymentRequestDataDBResponse.getUpdatedTimestamp() != null ? paymentRequestDataDBResponse.getUpdatedTimestamp().format(CUSTOM_FORMATTER) : null);
		paymentRequestEventData.setUpdatedBy(paymentRequestDataDBResponse.getUpdatedBy());
		paymentRequestEventData.setChannel((String) argsMap.get(PaymentConstants.CHANNEL));
		paymentRequestEventData.setAgentId((String) argsMap.get(PaymentConstants.AGENT_ID));
		paymentRequestEventData.setStatus(paymentRequestDataDBResponse.getRequestStatus());
		paymentRequestEventData.setFdrStatus(paymentRequestDataDBResponse.getRequestStatus());
		paymentRequestEventData.setPaymentConfirmation((String) argsMap.get(PaymentConstants.PAYMENT_CONFIRMATION));
		paymentRequestEventData.setExpressPayDecision(String.valueOf(argsMap.get(PaymentConstants.EXPRESS_PAY_DECISION)));
	}

	private static PaymentRequestEventMetadata getPaymentUpdatesEventMetadata(String agentId, String paymentPurpose, String requestStatus) {
		PaymentRequestEventMetadata paymentUpdatesEventMetadata = new PaymentRequestEventMetadata();
		paymentUpdatesEventMetadata.setAgentId(agentId);
		paymentUpdatesEventMetadata.setPaymentEvent(requestStatus);
		paymentUpdatesEventMetadata.setPaymentPurpose(paymentPurpose);

		if (requestStatus.equalsIgnoreCase(PaymentStatus.VOID.name()))
			paymentUpdatesEventMetadata.setNotes(PaymentConstants.PAYMENT_VOID_BY_USER);
		else {
			paymentUpdatesEventMetadata.setNotes(PaymentConstants.PAYMENT_CANCELLED_BY_USER);
		}
		return paymentUpdatesEventMetadata;
	}
}