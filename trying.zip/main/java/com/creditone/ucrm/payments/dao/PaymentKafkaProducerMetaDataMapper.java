package com.creditone.ucrm.payments.dao;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.events.kafka.PaymentRequestEventData;
import com.creditone.ucrm.payments.events.kafka.PaymentRequestEventMetadata;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;

public class PaymentKafkaProducerMetaDataMapper {
	
	public static void setFdrMetaData(PaymentRequestEventData eventData, PaymentRequestEventMetadata paymentRequestEventMetadata, List<JSONObject> listPaymentRequestData) {
		for (Map<String, Object> note : listPaymentRequestData) {
			if (note.get(PaymentConstants.PAYMENT_EVENT) != null && PaymentStatus.PROCESSED.name().equalsIgnoreCase((String) note.get(PaymentConstants.PAYMENT_EVENT))) {
				String notes = (String) note.get(PaymentConstants.NOTES);
				paymentRequestEventMetadata.setNotes(notes);
				String creditAccountLast4 = (String) note.get(PaymentConstants.CREDIT_ACCOUNT_LAST4);
				paymentRequestEventMetadata.setCreditAccountLast4(creditAccountLast4);
				String externalAccountLast4 = (String) note.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
				paymentRequestEventMetadata.setExternalAccountLast4(externalAccountLast4);
				paymentRequestEventMetadata.setExternalAccountLast4(externalAccountLast4);
				String paymentPurpose = (String) note.get(PaymentConstants.PAYMENT_PURPOSE);
				paymentRequestEventMetadata.setPaymentPurpose(paymentPurpose);

				String bankName = (String) note.get(PaymentConstants.EXTERNAL_BANK_NAME);
				paymentRequestEventMetadata.setBankName(bankName);
				String creditAccountSystemNumber = (String) note.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER);
				paymentRequestEventMetadata.setCreditAccountSystemNumber(creditAccountSystemNumber);
				String delinquentAmount = (String) note.get(PaymentConstants.DELINQUENT_AMOUNT);
				paymentRequestEventMetadata.setDelinquentAmount(delinquentAmount);
				String daysDelinquent = (String) note.get(PaymentConstants.DAYS_DELINQUENT);
				paymentRequestEventMetadata.setDaysDelinquent(daysDelinquent);
				String paymentEvent = (String) note.get(PaymentConstants.PAYMENT_EVENT);
				paymentRequestEventMetadata.setPaymentEvent(paymentEvent);
				String agentId = (String) note.get(PaymentConstants.AGENT_ID);
				paymentRequestEventMetadata.setAgentId(agentId);
				paymentRequestEventMetadata.setCommunicationRequestId(String.valueOf(PaymentConstants.COMMUNICATION_REQUEST_ID));
				paymentRequestEventMetadata.setCollectionIntentId(String.valueOf(PaymentConstants.COLLECTION_INTENT_ID));
				paymentRequestEventMetadata.setCreditAccountType(String.valueOf(note.get(PaymentConstants.CARD_TYPE)));
				eventData.setRiskLevel(String.valueOf(note.get(PaymentConstants.RISK_LEVEL)));
				eventData.setPaymentMetadata(paymentRequestEventMetadata);
			}

		}
	}
	
	public static void getPaymentMetaData(PaymentDataTransferRequest paymentRequestDto, PaymentRequestEventMetadata paymentRequestEventMetadata) {
		paymentRequestEventMetadata.setNotes(paymentRequestDto.getNotes());
		paymentRequestEventMetadata.setPaymentPurpose(paymentRequestDto.getPaymentPurpose());
		paymentRequestEventMetadata.setCreditAccountType(paymentRequestDto.getCardType() != null ? paymentRequestDto.getCardType().toString() : null);
		paymentRequestEventMetadata.setCreditAccountLast4(paymentRequestDto.getCreditAccountLast4() != null ? paymentRequestDto.getCreditAccountLast4().toString() : null);
		paymentRequestEventMetadata
				.setCreditAccountSystemNumber(paymentRequestDto.getCreditAccountSystemNumber() != null ? paymentRequestDto.getCreditAccountSystemNumber().toString() : null);
		paymentRequestEventMetadata.setExternalAccountLast4(paymentRequestDto.getExternalAccountLast4() != null ? paymentRequestDto.getExternalAccountLast4().toString() : null);
		paymentRequestEventMetadata.setStatementDate(paymentRequestDto.getStatementDate() != null ? paymentRequestDto.getStatementDate().toString() : null);
		paymentRequestEventMetadata.setMinimumPaymentDue(paymentRequestDto.getMinimumPaymentDue() != null ? paymentRequestDto.getMinimumPaymentDue().toString() : null);
		paymentRequestEventMetadata.setDelinquentAmount(paymentRequestDto.getDelinquentAmount() != null ? paymentRequestDto.getDelinquentAmount().toString() : null);
		paymentRequestEventMetadata.setDaysDelinquent(paymentRequestDto.getDaysDelinquent() != null ? paymentRequestDto.getDaysDelinquent().toString() : null);
		paymentRequestEventMetadata.setAgentId(paymentRequestDto.getAgentId());
		paymentRequestEventMetadata.setPaymentEvent(paymentRequestDto.getPaymentEvent() != null ? paymentRequestDto.getPaymentEvent().toString() : null);
		paymentRequestEventMetadata.setBankName(paymentRequestDto.getExternalBankName() != null ? paymentRequestDto.getExternalBankName().toString() : null);
		paymentRequestEventMetadata.setProductKey(paymentRequestDto.getProductKey() != null ? paymentRequestDto.getProductKey().toString() : null);
		paymentRequestEventMetadata.setThirdPartyCustomerId(paymentRequestDto.getThirdPartyCustomerId());
		paymentRequestEventMetadata.setCollectionIntentId(paymentRequestDto.getCollectionIntentId() != null ? paymentRequestDto.getCollectionIntentId().toString() : null);
		paymentRequestEventMetadata.setCommunicationRequestId(paymentRequestDto.getCommunicationRequestId());
	}
	public static void getEventMetaData(PaymentServiceRequest request, Map<String, Object> resultMap, PaymentRequestEventMetadata paymentRequestEventMetadata) {
		paymentRequestEventMetadata.setNotes(request.getPaymentMetadata().getNotes());
		paymentRequestEventMetadata.setPaymentPurpose(request.getPaymentMetadata().getPaymentPurpose().name());
		paymentRequestEventMetadata.setCreditAccountType(resultMap.get(PaymentConstants.CARD_TYPE) != null ? resultMap.get(PaymentConstants.CARD_TYPE).toString() : null);
		paymentRequestEventMetadata.setCreditAccountLast4(resultMap.get(PaymentConstants.CARD_LAST4) != null ? resultMap.get(PaymentConstants.CARD_LAST4).toString() : null);
		paymentRequestEventMetadata.setCreditAccountSystemNumber(
				resultMap.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER) != null ? resultMap.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER).toString() : null);
		paymentRequestEventMetadata
				.setExternalAccountLast4(resultMap.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4) != null ? resultMap.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4).toString() : null);
		paymentRequestEventMetadata.setStatementDate(resultMap.get(PaymentConstants.STATEMENT_DATE) != null ? resultMap.get(PaymentConstants.STATEMENT_DATE).toString() : null);
		paymentRequestEventMetadata
				.setMinimumPaymentDue(resultMap.get(PaymentConstants.MINIMUM_PAYMENT) != null ? resultMap.get(PaymentConstants.MINIMUM_PAYMENT).toString() : null);
		paymentRequestEventMetadata
				.setDelinquentAmount(resultMap.get(PaymentConstants.DELINQUENT_AMOUNT) != null ? resultMap.get(PaymentConstants.DELINQUENT_AMOUNT).toString() : null);
		paymentRequestEventMetadata.setDaysDelinquent(resultMap.get(PaymentConstants.DAYS_DELINQUENT) != null ? resultMap.get(PaymentConstants.DAYS_DELINQUENT).toString() : null);
		paymentRequestEventMetadata.setAgentId(request.getAgentId());
		paymentRequestEventMetadata.setPaymentEvent(resultMap.get(PaymentConstants.PAYMENT_EVENT) != null ? resultMap.get(PaymentConstants.PAYMENT_EVENT).toString() : null);
		paymentRequestEventMetadata.setBankName(resultMap.get(PaymentConstants.EXTERNAL_BANK_NAME) != null ? resultMap.get(PaymentConstants.EXTERNAL_BANK_NAME).toString() : null);
		paymentRequestEventMetadata.setProductKey(resultMap.get(PaymentConstants.PRODUCT_KEY) != null ? resultMap.get(PaymentConstants.PRODUCT_KEY).toString() : null);
		paymentRequestEventMetadata.setThirdPartyCustomerId(request.getPaymentMetadata().getThirdPartyCustomerId());
		paymentRequestEventMetadata
				.setCollectionIntentId(resultMap.get(PaymentConstants.COLLECTION_INTENT_ID) != null ? resultMap.get(PaymentConstants.COLLECTION_INTENT_ID).toString() : null);
	}
}