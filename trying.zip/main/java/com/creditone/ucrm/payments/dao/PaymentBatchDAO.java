package com.creditone.ucrm.payments.dao;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.PaymentBatchDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.model.PaymentBatchEntity;
import com.creditone.ucrm.payments.repository.PaymentBatchRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class PaymentBatchDAO {
    private PaymentBatchRepository paymentBatchRepository;

    private R2dbcEntityTemplate r2dbcEntityTemplate;

    public PaymentBatchDAO(PaymentBatchRepository paymentBatchRepository, R2dbcEntityTemplate r2dbcEntityTemplate) {
        this.paymentBatchRepository = paymentBatchRepository;
        this.r2dbcEntityTemplate = r2dbcEntityTemplate;
    }
    public Mono<PaymentBatchDBResponse> saveOrUpdatePaymentBatchEntity(Map<String,Object> parameters, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of saveOrUpdatePaymentBatchEntity: parameters: {}", correlationId, parameters);
        Mono<PaymentBatchEntity> monoPaymentBatchEntity = paymentBatchRepository.findByBatchId((UUID) parameters.get(PaymentConstants.BATCH_ID));
        return monoPaymentBatchEntity.hasElement().flatMap(hasElement->{
            if(hasElement){
                return monoPaymentBatchEntity.flatMap(paymentBatchEntity -> PaymentBatchMapper.mapUpdatedPaymentBatchEntity(paymentBatchEntity, parameters));
            }
            else {
                PaymentBatchEntity paymentBatchEntity = PaymentBatchMapper.mapToPaymentBatchEntity(parameters);
                paymentBatchEntity.setNew(true);
                return Mono.just(paymentBatchEntity);
            }
        }).flatMap(paymentBatchEntity -> paymentBatchRepository.save(paymentBatchEntity)
                .onErrorReturn(ClassCastException.class,paymentBatchEntity))
                .flatMap(paymentBatchEntityUpdated -> {
                    PaymentBatchDBResponse paymentBatchDBResponse = PaymentBatchMapper.fromPaymentBatchEntityToPaymentBatchDBResponse(paymentBatchEntityUpdated);
                    log.info(PaymentConstants.LOG_PREFIX + "End of saveOrUpdatePaymentBatchEntity: paymentBatchDBResponse: {}", correlationId, paymentBatchDBResponse);
                    return Mono.just(paymentBatchDBResponse);
                });
    }

    public Mono<PaymentBatchDBResponse> findByBatchId(UUID batchId, String correlationId) {
        log.info(PaymentConstants.LOG_PREFIX + "Start of findByBatchId: batchId: {}", correlationId, batchId);
        Mono<PaymentBatchEntity> monoPaymentBatchEntity = paymentBatchRepository.findByBatchId(batchId);
        return monoPaymentBatchEntity.hasElement().flatMap(hasElement -> {
            if(!hasElement) {
                log.error(PaymentConstants.LOG_PREFIX + "Batch Not Found with batchId: {}", correlationId, batchId);
                PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_BATCH_PROCESS_ID_INVALID);
                paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
                return Mono.error(paymentDataNotFoundException);
            }

            return monoPaymentBatchEntity.flatMap(paymentBatchEntity -> {
                PaymentBatchDBResponse paymentBatchDBResponse = PaymentBatchMapper.fromPaymentBatchEntityToPaymentBatchDBResponse(paymentBatchEntity);
                log.info(PaymentConstants.LOG_PREFIX + "End of findByBatchId: paymentBatchDBResponse: {}", correlationId, paymentBatchDBResponse);
                return Mono.just(paymentBatchDBResponse);
            });
        });
    }
}