package com.creditone.ucrm.payments.dao;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.AutoPayDBResponse;
import com.creditone.ucrm.payments.dto.AutoPayHistoryDBResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.exception.PaymentConflictException;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.AutoPayHistoryEntity;
import com.creditone.ucrm.payments.repository.AutoPayHistoryRepository;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.creditone.ucrm.payments.model.AutoPayEntity;
import com.creditone.ucrm.payments.repository.AutoPayRepository;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
public class AutoPayDAO {
	private AutoPayRepository autoPayRepository;

	private AutoPayHistoryRepository autoPayHistoryRepository;

	private R2dbcEntityTemplate r2dbcEntityTemplate;

	public AutoPayDAO(AutoPayRepository autoPayRepository, R2dbcEntityTemplate r2dbcEntityTemplate, AutoPayHistoryRepository autoPayHistoryRepository) {
		this.autoPayRepository = autoPayRepository;
		this.r2dbcEntityTemplate = r2dbcEntityTemplate;
		this.autoPayHistoryRepository = autoPayHistoryRepository;
	}

	public Mono<AutoPayDBResponse> saveOrUpdateAutoPayEntity(Map<String, Object> parameters, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of saveOrUpdateAutoPayEntity: parameters: {}", correlationId, parameters);

		String customerID = (String) parameters.get(PaymentConstants.CUSTOMER_ID);
		String creditAccountId = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);

		Mono<AutoPayEntity> monoAutoPayEntity = autoPayRepository.findTopByCustomerIdAndCreditAccountIdOrderByUpdatedTimestampDesc(UUID.fromString(customerID), UUID.fromString(creditAccountId));
		return monoAutoPayEntity.hasElement().flatMap(hasElement -> {
			if(Boolean.TRUE.equals(hasElement)) {
				return Mono.error(new PaymentConflictException(PaymentErrors.AUTOPAY_ALREADY_ENROLLED));
			}
			else {
				AutoPayEntity autoPayEntity = AutoPayMapper.mapAutoPayEntity(parameters);
				autoPayEntity.setAutoPayId(getAutoPayId(String.valueOf(customerID), String.valueOf(creditAccountId)));
				autoPayEntity.setNew(true);
				return Mono.just(autoPayEntity);
			}
		}).flatMap(autoPayEntity -> {
			return autoPayRepository.save(autoPayEntity)
					.onErrorReturn(ClassCastException.class, autoPayEntity);
		}).flatMap(autoPayEntityUpdated -> {
			AutoPayDBResponse autoPayDBResponse = AutoPayMapper.fromAutoPayEntityToAutoPayDBResponse(autoPayEntityUpdated);
			log.info(PaymentConstants.LOG_PREFIX + "End of saveOrUpdateAutoPayEntity: autoPayDBResponse: {}", correlationId, autoPayDBResponse);
			return Mono.just(autoPayDBResponse);
		});
	}

	public Mono<AutoPayHistoryDBResponse> saveOrUpdateAutoPayHistoryEntity(Map<String, Object> parameters, AutoPayDBResponse autoPayDBResponse, PaymentCommunicationResponse paymentCommunicationResponse, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of saveOrUpdateAutoPayHistoryEntity: parameters: {}, paymentCommunicationResponse {}", correlationId, parameters, paymentCommunicationResponse);

		String customerID = (String) parameters.get(PaymentConstants.CUSTOMER_ID);
		String creditAccountId = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_ID);
		Mono<AutoPayHistoryEntity> monoAutoPayHistoryEntity = autoPayHistoryRepository.findTopByCustomerIdAndCreditAccountIdOrderByUpdatedTimestampDesc(UUID.fromString(customerID), UUID.fromString(creditAccountId));
		return monoAutoPayHistoryEntity.hasElement().flatMap(hasElement -> {
			if(Boolean.TRUE.equals(hasElement)) {
				return monoAutoPayHistoryEntity.flatMap(autoPayHistoryEntity -> {
					return getUpdatedEntity(autoPayHistoryEntity, autoPayDBResponse, paymentCommunicationResponse.getCommunicationRequestId(), PaymentConstants.ENABLED, correlationId);
				});
			}

			AutoPayHistoryEntity autoPayHistoryEntity = AutoPayMapper.getAutoPayHistoryEntity(autoPayDBResponse, paymentCommunicationResponse.getCommunicationRequestId(), correlationId);
			
			parameters.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentCommunicationResponse.getCommunicationRequestId());
			
			return Mono.just(autoPayHistoryEntity);
		}).flatMap(autoPayHistoryEntity -> {
			autoPayHistoryEntity.setAutoPayEnabled(true);
			return autoPayHistoryRepository.save(autoPayHistoryEntity).onErrorReturn(ClassCastException.class, autoPayHistoryEntity);
		}).flatMap(autoPayHistoryEntityUpdated -> {
			AutoPayHistoryDBResponse autoPayHistoryDBResponse = AutoPayHistoryMapper.mappingFromAutoPayHistoryEntityToAutoPayHistoryDBResponse(autoPayHistoryEntityUpdated);
			log.info(PaymentConstants.LOG_PREFIX + "End of saveOrUpdateAutoPayHistoryEntity: autoPayHistoryDBResponse: {}", correlationId, autoPayHistoryDBResponse);
			return Mono.just(autoPayHistoryDBResponse);
		});
	}

	public static UUID getAutoPayId(String customerId, String creditAccountId) {
		String value = (customerId + creditAccountId);
		UUID autoPayId  = UUIDGenerator.generateType5UUID(value);
		return autoPayId;
	}

	private static Mono<AutoPayHistoryEntity> getUpdatedEntity(AutoPayHistoryEntity autoPayHistoryEntity, AutoPayDBResponse autoPayDBResponse, String communicationRequestId, String status, String correlationId) {
		JSONParser parser = new JSONParser();
		JSONObject autoPayHistoryData = null;
		JSONObject autoPayDataParams = null;

		try {
			autoPayHistoryData = (JSONObject) parser.parse(autoPayHistoryEntity.getAutoPayHistoryData().asString());
			autoPayDataParams = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());
		}
		catch (ParseException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			return Mono.error(paymentDataException);
		}

		JSONObject autoPayDBResponseJson = AutoPayHistoryMapper.mappingFromAutoPayDBResponseToJSON(autoPayDataParams, autoPayDBResponse, communicationRequestId,status);
		fillAutoPayHistoryForGetUpdatedEntityForSaveOrUpdateAutoPayHistoryEntity(autoPayHistoryData, autoPayDBResponseJson);

		autoPayHistoryEntity.setAutoPayHistoryData(Json.of(autoPayHistoryData.toJSONString()));
		autoPayHistoryEntity.setUpdatedBy(autoPayDBResponse.getUpdatedBy());
		autoPayHistoryEntity.setUpdatedTimestamp(PaymentUtil.utcNow());
		autoPayHistoryEntity.setNew(false);

		return Mono.just(autoPayHistoryEntity);
	}

	private static void fillAutoPayHistoryForGetUpdatedEntityForSaveOrUpdateAutoPayHistoryEntity(JSONObject autoPayHistoryData, JSONObject autoPayDBResponseJson) {
		if(autoPayHistoryData != null && autoPayHistoryData.get(PaymentConstants.AUTO_PAY_HISTORY) != null) {
			List<JSONObject> autoPayHistoryList = (List<JSONObject>) autoPayHistoryData.get(PaymentConstants.AUTO_PAY_HISTORY);

			//updating version in autoPayHistoryData
			if(!autoPayHistoryList.isEmpty()) {
                JSONObject maxVersionObj = autoPayHistoryList.stream().max(Comparator.comparing(a -> Long.parseLong(a.getOrDefault(PaymentConstants.VERSION, "0").toString()))).orElse(null);
                if(maxVersionObj!=null) {
                    Long maxVersion = (Long) maxVersionObj.get(PaymentConstants.VERSION);
                    autoPayDBResponseJson.put(PaymentConstants.VERSION, maxVersion + 1);
                }
			}

			autoPayHistoryList.add(autoPayDBResponseJson);
		}
	}

	public Mono<AutoPayDBResponse> findByCustomerIdAndCreditAccountId(UUID customerId, UUID creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of existsByCustomerIdAndCreditAccountId(), customerId: {}, creditAccountId: {}", correlationId, customerId, creditAccountId);
		Mono<AutoPayEntity> monoAutoPayEntity = autoPayRepository.findTopByCustomerIdAndCreditAccountIdOrderByUpdatedTimestampDesc(customerId, creditAccountId);
		return monoAutoPayEntity.hasElement().flatMap(hasElement -> {
			if(!hasElement) {
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_CUSTOMER_IS_INVALID);
				paymentDataException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				return Mono.error(paymentDataException);
			}

			return monoAutoPayEntity.flatMap(autoPayEntity ->  {
				log.info(PaymentConstants.LOG_PREFIX + "findByCustomerIdAndCreditAccountId() response: {}", correlationId, autoPayEntity);
				return Mono.just(AutoPayMapper.fromAutoPayEntityToAutoPayDBResponse(autoPayEntity));
			});
		});
	}

	public Mono<Boolean> disableAutoPay(AutoPayDBResponse autoPayDBResponse, UUID customerId, UUID creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of disableAutoPay(), autoPayDBResponse: {}, customerId: {}, creditAccountId: {}", correlationId, autoPayDBResponse, customerId, creditAccountId);
		return autoPayRepository.deleteByAutoPayId(autoPayDBResponse.getAutoPayId())
				.doOnSuccess(aVoid -> log.info(PaymentConstants.LOG_PREFIX + "AutoPay entry deleted successfully", correlationId)).thenReturn(true);
	}

	public Mono<AutoPayHistoryDBResponse> findByCustomerIdAndCreditAccountIdHistory(UUID customerId, UUID creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByCustomerIdAndCreditAccountId(), customerId: {}, creditAccountId: {}", correlationId, customerId, creditAccountId);
		return autoPayHistoryRepository.findTopByCustomerIdAndCreditAccountIdOrderByUpdatedTimestampDesc(customerId, creditAccountId)
				.flatMap(autoPayHistoryEntity -> {
					log.info(PaymentConstants.LOG_PREFIX + "findByCustomerIdAndCreditAccountId() response: {}", correlationId, autoPayHistoryEntity);
					return Mono.just(AutoPayHistoryMapper.mappingFromAutoPayHistoryEntityToAutoPayHistoryDBResponse(autoPayHistoryEntity));
				});
	}

	public Mono<AutoPayHistoryDBResponse> updateAutoPayHistory(AutoPayHistoryDBResponse autoPayHistoryDBResponse, String communicationRequestId, boolean autoPayEnabledStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of updateAutoPayHistory(), autoPayHistoryDBResponse: {}, communicationRequestId: {}, autoPayEnabledStatus: {}", correlationId, communicationRequestId);

		AutoPayHistoryEntity autoPayHistoryEntity = AutoPayHistoryMapper.mappingFromAutoPayHistoryDBResponseToAutoPayHistoryEntity(autoPayHistoryDBResponse, autoPayEnabledStatus);
		log.info(PaymentConstants.LOG_PREFIX + "AutoPayHistory Updated Entity : {}", correlationId, autoPayHistoryEntity);
		return autoPayHistoryRepository.save(autoPayHistoryEntity)
				.flatMap(updatedEntity -> {
					log.info(PaymentConstants.LOG_PREFIX + "Entity Updated: {}", correlationId, updatedEntity);
					AutoPayHistoryDBResponse updatedAutoPayHistoryDBResponse = AutoPayHistoryMapper.mappingFromAutoPayHistoryEntityToAutoPayHistoryDBResponse(updatedEntity);
					return Mono.just(updatedAutoPayHistoryDBResponse);
				});
	}

	public Mono<AutoPayDBResponse> updateAutoPayConfiguration(AutoPayDBResponse autoPayDBResponse, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "updateAutoPayConfiguration: autoPayDBResponse: {}", correlationId, autoPayDBResponse);

		AutoPayEntity autoPayEntity = AutoPayMapper.mappingFromAutoPayDBResponseToAutoPayEntity(autoPayDBResponse);
		autoPayEntity.setNew(false);

		return autoPayRepository.save(autoPayEntity)
				.onErrorReturn(ClassCastException.class,autoPayEntity)
				.flatMap(entity -> {
					AutoPayMapper.fromAutoPayEntityToAutoPayDBResponse(entity);
					log.info(PaymentConstants.LOG_PREFIX + "Response from updateAutoPayConfiguration: {}", correlationId, entity);
					return Mono.just(autoPayDBResponse);
				});
	}

	public Flux<AutoPayDBResponse> findByAutoPaymentDay(List<UUID> creditAccountIDs,Integer autoPaymentDay, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of findByAutoPaymentDay: autoPaymentDay: {}", correlationId, autoPaymentDay);

		return autoPayRepository.findByAutoPaymentDayAndCreditAccountIdNotIn(autoPaymentDay,creditAccountIDs).map(autoPayEntity -> {
			return AutoPayMapper.fromAutoPayEntityToAutoPayDBResponse(autoPayEntity);
		});
	}

	/***
	 * This method is invoked if update autoPayHistory fails
	 * @param autoPayHistoryDBResponse
	 * @param communicationRequestId
	 * @param autoPayEnabledStatus
	 * @param correlationId
	 * @return
	 */
	public Mono<AutoPayHistoryDBResponse> saveAutoPayHistory(AutoPayHistoryDBResponse autoPayHistoryDBResponse, String communicationRequestId, boolean autoPayEnabledStatus, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of saveAutoPayHistory(), autoPayHistoryDBResponse: {}, communicationRequestId: {}, autoPayEnabledStatus: {}", correlationId, communicationRequestId);
		AutoPayHistoryEntity autoPayHistoryEntity = AutoPayHistoryMapper.mappingFromAutoPayHistoryDBResponseToSaveAutoPayHistoryEntity(autoPayHistoryDBResponse, autoPayEnabledStatus);
		log.info(PaymentConstants.LOG_PREFIX + "AutoPayHistory Save Entity : {}", correlationId, autoPayHistoryEntity);
		return autoPayHistoryRepository.save(autoPayHistoryEntity)
									   .flatMap(updatedEntity -> {
										   log.info(PaymentConstants.LOG_PREFIX + "Entity Saved: {}", correlationId, updatedEntity);
										   AutoPayHistoryDBResponse updatedAutoPayHistoryDBResponse = AutoPayHistoryMapper.mappingFromAutoPayHistoryEntityToAutoPayHistoryDBResponse(updatedEntity);
										   return Mono.just(updatedAutoPayHistoryDBResponse);
									   });
	}

	public Mono<Boolean> deleteByCustomerIdAndCreditAccountId(UUID customerId, UUID creditAccountId, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + "Start of deleteByCustomerIdAndCreditAccountId(), customerId: {}, creditAccountId: {}", correlationId, customerId, creditAccountId);
		return autoPayRepository.deleteByCustomerIdAndCreditAccountId(customerId, creditAccountId)
				.doOnSuccess(aVoid -> log.info(PaymentConstants.LOG_PREFIX + "AutoPay entry deleted successfully", correlationId)).thenReturn(true);
	}
}