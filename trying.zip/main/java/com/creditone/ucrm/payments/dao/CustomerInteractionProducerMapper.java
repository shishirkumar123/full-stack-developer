package com.creditone.ucrm.payments.dao;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.UUID;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.creditone.ucrm.payments.config.CustomerInteractionDescriptionConfig;
import com.creditone.ucrm.payments.constant.Customer360IntentStatus;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.dto.PaymentCommunicationResponse;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEvent;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEventMetaData;
import com.creditone.ucrm.payments.events.kafka.CustomerInteractionKafkaEventPayload;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceResponse;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomerInteractionProducerMapper {

	public static CustomerInteractionEvent mapEventForInitiateAndSchedule(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest dtoRequest, UUID paymentRequestId) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = paymentServiceRequest.getChannel();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = new CustomerInteractionKafkaEventMetaData();
		customerInteractionKafkaEventMetaData.setChannelCode(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.VOICE : PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setDeviceType(getDeviceType(channel));
		customerInteractionKafkaEventMetaData.setActorType(getActorType(channel));
		customerInteractionKafkaEventMetaData.setApplicationType(PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setIntentGroup(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue().equalsIgnoreCase(paymentServiceRequest.getPaymentMode().getValue())
						? PaymentConstants.EXPRESS_PAY_NAME
						: PaymentConstants.STANDARD_PAYMENT));
		customerInteractionKafkaEventMetaData.setEventTime(PaymentUtil.utcNow());
		customerInteractionKafkaEventMetaData.setActivityId(String
				.valueOf(UUID.nameUUIDFromBytes((PaymentConstants.PAYMENT_SERVICE_API + PaymentConstants.CREDITCARD_FINALCIALS + LocalDateTime.now().toString()).getBytes())));
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setEventSourceId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventMetaData.setCorrelationId(dtoRequest.getCorrelationId());
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}
	public static void  getScheduleCutomer360Data(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDtoRequest, ZonedDateTime zonedDateTime, ZonedDateTime zonedDateTimePst, CustomerInteractionEvent event) {
		event.getEvent().getPayload().setStatus(PaymentConstants.PAYMENT_SCHEDULED);
		event.getEvent().getMetadata().setChannelCode(PaymentConstants.BACKEND);
		event.getEvent().getMetadata().setApplicationType(PaymentConstants.BATCH);
		event.getEvent().getMetadata().setActorType(PaymentConstants.BOT);
		event.getEvent().getMetadata().setDeviceType(PaymentConstants.SERVER);
		event.getEvent().getPayload().setFollowupDate(zonedDateTime != null ? zonedDateTimePst.toInstant() : null);
	}
	private static String getActorType(String channel) {
		if (PaymentConstants.AGENT.equalsIgnoreCase(channel)) {
			return PaymentConstants.AGENT;
		} else if (PaymentConstants.WEB.equalsIgnoreCase(channel) || PaymentConstants.MOBILE.equalsIgnoreCase(channel)) {
			return PaymentConstants.CUSTOMER;
		} else {
			return PaymentConstants.BOT;
		}
	}

	private static String getDeviceType(String channel) {
		if (PaymentConstants.AGENT.equalsIgnoreCase(channel)) {
			return PaymentConstants.PHYSICAL;
		} else if (PaymentConstants.WEB.equalsIgnoreCase(channel)) {
			return PaymentConstants.WEB;
		} else if (PaymentConstants.MOBILE.equalsIgnoreCase(channel)) {
			return PaymentConstants.MOBILE;
		} else {
			return null;
		}
	}

	public static CustomerInteractionEvent mapEventForCancellation(PaymentRequestDataDBResponse paymentRequestDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = getValueFromPaymentRequestData(paymentRequestDBResponse, correlationId, PaymentConstants.CHANNEL);
		String correlationIdFromDB = getValueFromPaymentRequestData(paymentRequestDBResponse, correlationId, PaymentConstants.CORRELATION_ID);
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = new CustomerInteractionKafkaEventMetaData();
		customerInteractionKafkaEventMetaData.setChannelCode(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.VOICE : PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setDeviceType(getDeviceType(channel));
		customerInteractionKafkaEventMetaData.setActorType(getActorType(channel));
		customerInteractionKafkaEventMetaData.setApplicationType(PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setIntentGroup(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		customerInteractionKafkaEventMetaData.setEventTime(PaymentUtil.utcNow());
		customerInteractionKafkaEventMetaData.setActivityId(String
				.valueOf(UUID.nameUUIDFromBytes((PaymentConstants.PAYMENT_SERVICE_API + PaymentConstants.CREDITCARD_FINALCIALS + LocalDateTime.now().toString()).getBytes())));
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setEventSourceId(String.valueOf(paymentRequestDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationIdFromDB != null ? correlationIdFromDB : correlationId);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(String.valueOf(paymentRequestDBResponse.getAccountKey()));
		customerInteractionKafkaEventPayload.setAmount(new BigDecimal(getValueFromPaymentRequestData(paymentRequestDBResponse, correlationId, PaymentConstants.PAYMENT_AMOUNT)));
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getCancel(),
				getValueFromPaymentRequestData(paymentRequestDBResponse, correlationId, PaymentConstants.EXTERNAL_BANK_NAME),
				getValueFromPaymentRequestData(paymentRequestDBResponse, correlationId, PaymentConstants.EXTERNAL_ACCOUNT_LAST4)));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_CANCELLED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	private static String getValueFromPaymentRequestData(PaymentRequestDataDBResponse paymentRequestDBResponse, String correlationId, String key) {
		JSONParser jsonParser = new JSONParser();
		JSONObject feeData = null;
		try {
			String jsonString = paymentRequestDBResponse.getPaymentRequestData().asString();
			feeData = (JSONObject) jsonParser.parse(jsonString);
			return String.valueOf(feeData.get(key));
		} catch (ParseException e) {
			log.error(PaymentConstants.LOG_PREFIX + "Error Parsing JSON, error {}", correlationId, e.toString());
		}
		return null;
	}

	public static CustomerInteractionEvent mapEventForEligibilityFailed(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId, String failedProcess, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId, paymentRequestId,
				paymentServiceRequest.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getPaymentEligibilityFailed(), failedProcess));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_ELIGIBILITY_FAILED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForRiskyPaymentCheck(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId, paymentRequestId,
				paymentServiceRequest.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENT_RULES);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEventPayload.setDescription(customerInteractionDescriptionConfig.getDescription().getRiskyPayment());
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.EXPRESSPAY_DISABLED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForFailedPayment(String correlationId, PaymentDataTransferRequest paymentRequestDto, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDto.getPaymentRequestId(), paymentRequestDto.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDto.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentRequestDto.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDto.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDto.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentRequestDto.getCustomerId());
		customerInteractionKafkaEventPayload
				.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getFailedPayment(), paymentRequestDto.getPaymentAmount()));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_FAILED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForCreditCardBalanceUpdate(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, String correlationId, UpdateAccountBalanceResponse cardbalanceResponse, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDto.getPaymentRequestId(), paymentRequestDto.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.CREDIT_CARD_ACCOUNTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		customerInteractionKafkaEventMetaData.setIntentGroup(PaymentConstants.ACCOUNTS);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.ACCOUNTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDto.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.CREDIT_CARD_ACCOUNTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getExpressPayment(),
				paymentServiceRequest.getPaymentAmount(), cardbalanceResponse.getConfirmationCode()));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.EXPRESS_PAYMENT.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForProcessedTransaction(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestdto, String correlationId, UUID paymentRequestId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId, paymentRequestId,
				paymentRequestdto.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		if (Boolean.TRUE.equals(paymentRequestdto.getExpressPayDecesion())) {
			customerInteractionKafkaEventPayload
					.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getProcessedPaymentForExpress(), paymentServiceRequest.getPaymentAmount(),
							paymentRequestdto.getConfirmationCode(), paymentRequestdto.getExternalBankName(), paymentRequestdto.getExternalAccountLast4()));
		} else {
			customerInteractionKafkaEventPayload
					.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getProcessedPaymentForStandard(), paymentServiceRequest.getPaymentAmount(),
							paymentRequestdto.getConfirmationCode(), paymentRequestdto.getExternalBankName(), paymentRequestdto.getExternalAccountLast4()));
		}
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_PROCESSED.name());
		customerInteractionKafkaEventPayload.setFollowupDate(paymentRequestdto.getFollowUpDate());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}
	private static CustomerInteractionKafkaEventMetaData getCustomerInteractionKafkaEventMetaData(String correlationId, UUID paymentRequestId, String channel) {
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = new CustomerInteractionKafkaEventMetaData();
		customerInteractionKafkaEventMetaData.setChannelCode(PaymentConstants.BACKEND);
		customerInteractionKafkaEventMetaData.setDeviceType(PaymentConstants.SERVER);
		customerInteractionKafkaEventMetaData.setActorType(PaymentConstants.BOT);
		customerInteractionKafkaEventMetaData.setApplicationType(PaymentConstants.BATCH);
		customerInteractionKafkaEventMetaData.setIntentGroup(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setEventTime(PaymentUtil.utcNow());
		customerInteractionKafkaEventMetaData.setActivityId(String
				.valueOf(UUID.nameUUIDFromBytes((PaymentConstants.PAYMENT_SERVICE_API + PaymentConstants.CREDITCARD_FINALCIALS + LocalDateTime.now().toString()).getBytes())));
		customerInteractionKafkaEventMetaData.setEventSourceId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationId);
		return customerInteractionKafkaEventMetaData;
	}

	public static CustomerInteractionEvent mapEventForPostedTransaction(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);
		String correlationFromDB = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CORRELATION_ID, correlationId);
		String bankName = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_BANK_NAME, correlationId);
		String externalAccountLast4 = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_ACCOUNT_LAST4,
				correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId));
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				UUID.fromString(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId()), channel);
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationFromDB != null ? correlationFromDB : correlationId);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue()
						.equalsIgnoreCase(PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_MODE, correlationId))
								? PaymentConstants.EXPRESS_PAY_NAME
								: PaymentConstants.STANDARD_PAYMENT));
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setAmount(paymentAmount);
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload
				.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getPostedPayment(), paymentAmount, bankName, externalAccountLast4));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_POSTED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForVoidPayment(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId));
		String bankName = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_BANK_NAME, correlationId);
		String bankAccountLast4 = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_ACCOUNT_LAST4, correlationId);
		String correlationIdFromDB = getValueFromPaymentRequestData(paymentRequestDataDBResponse, correlationId, PaymentConstants.CORRELATION_ID);
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDataDBResponse.getPaymentRequestId(), channel);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue()
						.equalsIgnoreCase(PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_MODE, correlationId))
								? PaymentConstants.EXPRESS_PAY_NAME
								: PaymentConstants.STANDARD_PAYMENT));
		customerInteractionKafkaEventMetaData.setChannelCode(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.VOICE : PaymentConstants.WEB);
		customerInteractionKafkaEventMetaData.setDeviceType(getDeviceType(channel));
		customerInteractionKafkaEventMetaData.setActorType(getActorType(channel));
		customerInteractionKafkaEventMetaData.setApplicationType(PaymentConstants.WEB);
	
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationIdFromDB != null ? correlationIdFromDB : correlationId);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setAmount(paymentAmount);
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDataDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getVoidPayment(), paymentAmount,
				PaymentUtil.formatDate(paymentRequestDataDBResponse.getPaymentDate(), PaymentConstants.DATEFORMAT_DD_MM_UUUU), bankName, bankAccountLast4));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_VOID.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForFDRStatusUpdate(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);
		String correlationFromDB = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CORRELATION_ID, correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId));
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDataDBResponse.getPaymentRequestId(), channel);
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue()
						.equalsIgnoreCase(PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_MODE, correlationId))
								? PaymentConstants.EXPRESS_PAY_NAME
								: PaymentConstants.STANDARD_PAYMENT));
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationFromDB != null ? correlationFromDB : correlationId);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setAmount(paymentAmount);
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDataDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getPaymentBalancePosted(), paymentAmount));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_BALANCE_POSTED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForReturnPayment(PaymentCommunicationResponse paymentCommunicationResponse, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);
		String correlationFromDB = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CORRELATION_ID, correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId));
		String bankName = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_BANK_NAME, correlationId);
		String bankLast4 = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.EXTERNAL_ACCOUNT_LAST4, correlationId);
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDataDBResponse.getPaymentRequestId(), channel);
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue()
						.equalsIgnoreCase(PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_MODE, correlationId))
								? PaymentConstants.EXPRESS_PAY_NAME
								: PaymentConstants.STANDARD_PAYMENT));
		customerInteractionKafkaEventMetaData.setCorrelationId(correlationFromDB != null ? correlationFromDB : correlationId);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setAmount(paymentAmount);
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDataDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getReturnPayment(), paymentAmount,
				paymentCommunicationResponse.getCommunicationRequestId(), bankName, bankLast4));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_RETURNED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForCollectionIntent(PaymentServiceRequest paymentServiceRequest, String correlationId, UUID paymentRequestId, Instant followUpDate, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId, paymentRequestId,
				paymentServiceRequest.getChannel());
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENT_RULES);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestId));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.COLLECTIONS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEventPayload
				.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getCollectionIntent(), paymentServiceRequest.getPaymentAmount()));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.COLLECTIONS_INTENT.name());
		customerInteractionKafkaEventPayload.setFollowupDate(followUpDate);
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForPaymentBalanceVerified(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		String channel = PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.CHANNEL, correlationId);
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal(
				PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_AMOUNT, correlationId));
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDataDBResponse.getPaymentRequestId(), channel);
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.AGENT.equalsIgnoreCase(channel) ? PaymentConstants.EXPRESS_PAY_NAME
				: (PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.getValue()
						.equalsIgnoreCase(PaymentUtil.getValueFromJsonObject(paymentRequestDataDBResponse.getPaymentRequestData(), PaymentConstants.PAYMENT_MODE, correlationId))
								? PaymentConstants.EXPRESS_PAY_NAME
								: PaymentConstants.STANDARD_PAYMENT));

		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		customerInteractionKafkaEventPayload.setAmount(paymentAmount);
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDataDBResponse.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentRequestDataDBResponse.getCreatedBy());
		customerInteractionKafkaEventPayload.setCustomerId(String.valueOf(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey()));
		customerInteractionKafkaEventPayload.setDescription(String.format(customerInteractionDescriptionConfig.getDescription().getPaymentBalanceVerified(), paymentAmount));
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.PAYMENT_BALANCE_VERIFIED.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;
	}

	public static CustomerInteractionEvent mapEventForFeeAdjustment(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestDto, String correlationId, CustomerInteractionDescriptionConfig customerInteractionDescriptionConfig) {
		CustomerInteractionEvent event = new CustomerInteractionEvent();
		CustomerInteractionKafkaEvent customerInteractionKafkaEvent = new CustomerInteractionKafkaEvent();
		CustomerInteractionKafkaEventMetaData customerInteractionKafkaEventMetaData = getCustomerInteractionKafkaEventMetaData(correlationId,
				paymentRequestDto.getPaymentRequestId(), paymentRequestDto.getChannel());
		customerInteractionKafkaEventMetaData.setEventSource(PaymentConstants.PAYMENT_RULES);
		customerInteractionKafkaEventMetaData.setIntentName(PaymentConstants.EXPRESS_PAY_NAME);
		CustomerInteractionKafkaEventPayload customerInteractionKafkaEventPayload = new CustomerInteractionKafkaEventPayload();
		customerInteractionKafkaEventPayload.setBusinessArea(PaymentConstants.CREDIT_CARDS);
		customerInteractionKafkaEventPayload.setAccountId(paymentServiceRequest.getCreditAccountId());
		customerInteractionKafkaEventPayload.setAmount(paymentServiceRequest.getPaymentAmount());
		customerInteractionKafkaEventPayload.setServiceCode(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setServiceActivityId(String.valueOf(paymentRequestDto.getPaymentRequestId()));
		customerInteractionKafkaEventPayload.setDomain(PaymentConstants.PAYMENTS);
		customerInteractionKafkaEventPayload.setAgentId(paymentServiceRequest.getAgentId());
		customerInteractionKafkaEventPayload.setCustomerId(paymentServiceRequest.getCustomerId());
		customerInteractionKafkaEventPayload.setDescription(customerInteractionDescriptionConfig.getDescription().getFeeAdjustment());
		customerInteractionKafkaEventPayload.setStatus(Customer360IntentStatus.FEE_ADJUSTMENT.name());
		customerInteractionKafkaEvent.setMetadata(customerInteractionKafkaEventMetaData);
		customerInteractionKafkaEvent.setPayload(customerInteractionKafkaEventPayload);
		event.setEvent(customerInteractionKafkaEvent);
		return event;

	}
}
