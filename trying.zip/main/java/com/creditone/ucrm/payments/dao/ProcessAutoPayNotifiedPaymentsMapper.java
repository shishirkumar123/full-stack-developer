package com.creditone.ucrm.payments.dao;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.ucrm.swagger.paymentservice.model.BatchProcessResponse;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ProcessAutoPayNotifiedPaymentsMapper {
    public static BatchProcessResponse mapBatchProcessResponseFromMapToProcessAutoPayNotifiedPayments(Map<String, Object> parameters) {
        UUID batchId = (UUID) parameters.get(PaymentConstants.BATCH_ID);
        BatchProcessResponse batchProcessResponse = new BatchProcessResponse();
        batchProcessResponse.setBatchId(String.valueOf(batchId));
        return batchProcessResponse;
    }

    public static void mapParameterForSaveOrUpdatePaymentBatchEntity(Map<String, Object> parametersMethod, List<UUID> listRecordsProcessed, List<UUID> listRecordsError) {
        parametersMethod.put(PaymentConstants.PROCESS_COUNT, listRecordsProcessed.size());
        parametersMethod.put(PaymentConstants.ERROR_COUNT, listRecordsError.size());
        parametersMethod.put(PaymentConstants.END_TIME, ZonedDateTime.now());
        parametersMethod.put(PaymentConstants.STATUS, PaymentBatchMapper.getBatchProcessingStatus(listRecordsProcessed.size(),listRecordsError.size()));
        parametersMethod.put(PaymentConstants.PAYMENT_REQUEST_ID, listRecordsProcessed);
    }
}