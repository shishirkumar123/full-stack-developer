package com.creditone.ucrm.payments.dao;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.communicationhuapiservice.model.ContactAttributes;
import com.ucrm.swagger.communicationhuapiservice.model.EnterpriseCommunicationrequest;
import com.ucrm.swagger.communicationhuapiservice.model.SubscriberAttributes;
import com.ucrm.swagger.communicationhuapiservice.model.To;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsInvolvementResponse;

public class PaymentCommunicationMapper {
	public static PaymentCommunicationDetailsRequest mapPaymentCommunicationDetailsRequestFromDatabase(Map<String, Object> parametersValidation) {
		Map<String, Object> parametersDatabase = (Map<String, Object>) parametersValidation.get(PaymentConstants.PARAMETERS_DATABASE);
		PaymentCommunicationIntent paymentCommunicationIntent = (PaymentCommunicationIntent) parametersValidation.get(PaymentConstants.PAYMENT_COMMUNICATION_INTENT);
		EntityModelIndividualCoreIdentityResponse entityModelIndividualCoreIdentityResponse = (EntityModelIndividualCoreIdentityResponse) parametersValidation
				.get(PaymentConstants.ENTITY_MODEL_INDIVIDUAL_CORE_IDENTITY);
		AccountDetailsResponse creditCardDetailsResponse = (AccountDetailsResponse) parametersValidation.get(PaymentConstants.CREDITCARD_DETAILS_RESPONSE);
		String customerId = (String) parametersValidation.get(PaymentConstants.CUSTOMER_ID_PARAM);

		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setFirstName(entityModelIndividualCoreIdentityResponse.getFirstName());
		paymentCommunicationDetailsRequest.setLastName(entityModelIndividualCoreIdentityResponse.getLastName());

		paymentCommunicationDetailsRequest.setCardLast4(creditCardDetailsResponse.getDevice().getDeviceLast4());
		paymentCommunicationDetailsRequest.setCardType(creditCardDetailsResponse.getDevice().getNetwork());
		paymentCommunicationDetailsRequest
				.setInvolvementId(creditCardDetailsResponse.getAccountInvolvements().stream().filter(account -> account.getAccountInvolvementType().equals("PRIMARY"))
						.map(AccountsInvolvementResponse::getInvolvementId).map(id -> id.toString()).findFirst().orElse(null));
		// paymentCommunicationDetailsRequest.setEmailAddress(creditCardDetailsResponse.getContactDetails().getEmail().getEmailData().getEmailAddress());

		String dayOfWeek = PaymentUtil.getCurrentDayOfWeek();
		paymentCommunicationDetailsRequest.setDayOfWeek(dayOfWeek);

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_PROCESSED)) {
			paymentCommunicationDetailsRequest.setReferenceNum((String) parametersDatabase.get(PaymentConstants.REFERENCENUM));
		}

		paymentCommunicationDetailsRequest.setPaymentAmount(PaymentMapper.convertObjectToBigDecimal((Object) parametersDatabase.get(PaymentConstants.PAYMENTAMOUNT)));
		paymentCommunicationDetailsRequest.setPaymentDate((ZonedDateTime) parametersDatabase.get(PaymentConstants.PAYMENTDATE));

		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(customerId));

		return paymentCommunicationDetailsRequest;
	}

	public static Map<String, Object> mapCommunicationValues(PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, PaymentCommunicationIntent paymentCommunicationIntent) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put(PaymentConstants.CARDLASTFOUR, paymentCommunicationDetailsRequest.getCardLast4());
		parameters.put(PaymentConstants.CARDTYPE, paymentCommunicationDetailsRequest.getCardType());
		parameters.put(PaymentConstants.FIRSTNAME, paymentCommunicationDetailsRequest.getFirstName());
		parameters.put(PaymentConstants.LASTNAME, paymentCommunicationDetailsRequest.getLastName());
		parameters.put(PaymentConstants.FULLNAME, paymentCommunicationDetailsRequest.getFirstName() + " " + paymentCommunicationDetailsRequest.getLastName());
		parameters.put(PaymentConstants.PAYMENTAMOUNT, paymentCommunicationDetailsRequest.getPaymentAmount());
		parameters.put(PaymentConstants.TRANSACTIONAMOUNT, paymentCommunicationDetailsRequest.getPaymentAmount());
		parameters.put(PaymentConstants.DAYOFWEEK, paymentCommunicationDetailsRequest.getDayOfWeek());

		fillOptionalAndConditionalMapCommunicationValues(paymentCommunicationDetailsRequest, paymentCommunicationIntent, parameters);

		return parameters;
	}

	private static void fillOptionalAndConditionalMapCommunicationValues(PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, PaymentCommunicationIntent paymentCommunicationIntent, Map<String, Object> parameters) {
		if (paymentCommunicationDetailsRequest.getReferenceNum() != null) {
			parameters.put(PaymentConstants.REFERENCENUM, paymentCommunicationDetailsRequest.getReferenceNum());
		}

		if (paymentCommunicationDetailsRequest.getPaymentDate() != null) {
			String dateFormatted = PaymentUtil.formatDate(paymentCommunicationDetailsRequest.getPaymentDate(), PaymentConstants.DATEFORMAT_MM_DD_UUUU);
			parameters.put(PaymentConstants.PAYMENTDATE, dateFormatted);
			parameters.put(PaymentConstants.POSTDATE, dateFormatted);
		}

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_PROCESSED) || paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_SCHEDULED)
				|| paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_POSTED)) {
			ZonedDateTime dateNow = PaymentUtil.utcNow();
			String dateFormatted = PaymentUtil.formatDate(dateNow, PaymentConstants.DATEFORMAT_MM_DD_UUUU);
			parameters.put(PaymentConstants.SENDDATE, dateFormatted);
		} else if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_RETURNED)) {
			parameters.put(PaymentConstants.SENDDATE, paymentCommunicationDetailsRequest.getReturnDate());
		}

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.CANCEL_SINGLE_INSTANCE_AUTO_PAYMENT)) {
			String nextPaymentDate = PaymentUtil.formatDate(paymentCommunicationDetailsRequest.getPaymentDate().plusMonths(1), PaymentConstants.DATEFORMAT_MM_DD_UUUU);
			parameters.put(PaymentConstants.NEXTPAYMENTDATE, nextPaymentDate);
		}

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.AUTO_PAY_ENROLL_MINIMUM_DUE)
				|| paymentCommunicationIntent.equals(PaymentCommunicationIntent.AUTO_PAY_ENROLL_STATEMENT_BALANCE)
				|| paymentCommunicationIntent.equals(PaymentCommunicationIntent.AUTO_PAY_ENROLL_STATEMENT_OTHER)
				|| paymentCommunicationIntent.equals(PaymentCommunicationIntent.AUTO_PAYMENT_CONFIRMATION)
				|| paymentCommunicationIntent.equals(PaymentCommunicationIntent.NOTIFY_AUTO_PAY)) {
			parameters.put(PaymentConstants.PAYMENTBANK, paymentCommunicationDetailsRequest.getPaymentBank());
			parameters.put(PaymentConstants.PAYMENTLAST4, paymentCommunicationDetailsRequest.getPaymentLast4());
		}

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.AUTO_PAY_ENROLL_STATEMENT_OTHER)) {
			parameters.put(PaymentConstants.OTHERAMOUNT, paymentCommunicationDetailsRequest.getPaymentAmount());
		}

		if (paymentCommunicationIntent.equals(PaymentCommunicationIntent.CANCEL_PAYMENT)) {
			parameters.put(PaymentConstants.PLASTICCODE, paymentCommunicationDetailsRequest.getPlasticCode());
		}
	}

	public static EnterpriseCommunicationrequest mapEnterpriseCommunicationrequest(String address, String subscriberKey, String messageData) {
		EnterpriseCommunicationrequest enterpriseCommunicationrequest = new EnterpriseCommunicationrequest();
		To to = new To();
		to.setAddress(address);
		to.subscriberKey(subscriberKey);
		ContactAttributes contactAttributes = new ContactAttributes();
		SubscriberAttributes subscriberAttributes = new SubscriberAttributes();
		subscriberAttributes.setMessageData(messageData);
		contactAttributes.setSubscriberAttributes(subscriberAttributes);
		to.setContactAttributes(contactAttributes);

		enterpriseCommunicationrequest.setTo(to);

		return enterpriseCommunicationrequest;
	}
}