package com.creditone.ucrm.payments.dao;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;

import java.util.UUID;

public class PaymentKafkaConsumerMapper {
    public static PaymentCommunicationRequest mapPaymentCommunicationRequestForKafkaConsumer(UUID paymentRequestId) {
        PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
        paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_RETURNED);
        paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
        paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);

        return paymentCommunicationRequest;
    }

    public static PaymentCommunicationRequest mapPaymentCommunicationRequestForPosted(UUID paymentRequestId) {
        PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
        paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_POSTED);
        paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
        paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);

        return paymentCommunicationRequest;
    }
}