package com.creditone.ucrm.payments.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;

import com.creditone.ucrm.payments.constant.LineOfBusiness;
import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.constant.PaymentType;
import com.creditone.ucrm.payments.constant.TransactionDirection;
import com.creditone.ucrm.payments.constant.TransactionType;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dto.PaymentCommunicationRequest;
import com.creditone.ucrm.payments.dto.PaymentDataTransferRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.PaymentRequestEntity;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.achtransactionservice.model.AchTransactionRequest;
import com.ucrm.swagger.achtransactionservice.model.MetaData;
import com.ucrm.swagger.collection.model.CollectionIntentRequest;
import com.ucrm.swagger.collection.model.CollectionIntentRequest.CollectionIntentsTypeEnum;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;
import com.ucrm.swagger.creditcardaccountservice.model.AccountsInvolvementResponse;
import com.ucrm.swagger.creditcardaccountservice.model.ChannelTypeRequest;
import com.ucrm.swagger.creditcardaccountservice.model.TransactionMediumRequest;
import com.ucrm.swagger.creditcardaccountservice.model.UpdateAccountBalanceRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitTransactionRequest;
import com.ucrm.swagger.ewsservicepartner.model.EwsPartnerRequest;
import com.ucrm.swagger.ewsservicepartner.model.EwsPartnerRequestMetaData;
import com.ucrm.swagger.externalaccounts.model.AccountTokenResponse;
import com.ucrm.swagger.externaldebitcards.model.GetDebitCardTokenResponse;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest.ChannelEnum;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest.IntentEnum;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequest.PaymentTypeEnum;
import com.ucrm.swagger.paymentrulesservice.model.FraudCheckRequestExternalAccountVerfication;
import com.ucrm.swagger.paymentrulesservice.model.RiskyPaymentRequest;
import com.ucrm.swagger.paymentservice.model.PaymentRequest;
import com.ucrm.swagger.paymentservice.model.PaymentRequestPaymentMetadataInner;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest.PaymentModeEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PaymentMapper {
	public static PaymentRequest fromPaymentRequestEntityToPaymentRequest(PaymentRequestEntity paymentRequestEntity) throws ParseException {
		// Removed validation to close story, we will relay on input validations
		// for new input payment data, and will need stories for mapping
		// existing values in database or make new functionalities backward
		// compatible with old data
		// PaymentRecordDatabaseValidator.validatePaymentRecordVerificationData(paymentRequestEntity,
		// PaymentConstants.PAYMENT_HISTORY_ORIGIN);
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestEntity.getPaymentRequestData().asString());

		String paymentMode = (String) paymentRequestData.get(PaymentConstants.PAYMENT_MODE);
		Object feeAmount = (Object) paymentRequestData.get(PaymentConstants.FEE_AMOUNT);
		Object paymentAmount = (Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT);
		String dataFormatted = paymentRequestEntity.getPaymentDate().format(DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US));
		String channel = (String) paymentRequestData.get(PaymentConstants.CHANNEL);
		String fdrStatus = (String) paymentRequestData.get(PaymentConstants.FDR_STATUS);
		String fdrPostedDate = (String) paymentRequestData.get(PaymentConstants.FDR_POSTED_DATE);
		String cretedDate = paymentRequestEntity.getCreatedTimestamp().format(DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US));
		Object feeWaiverAmount = (Object) paymentRequestData.get(PaymentConstants.FEE_WAIVER_AMOUNT);
		Boolean feeWaived = (Boolean) paymentRequestData.get(PaymentConstants.FEE_WAVED);
		Boolean expressPayDecesion = Boolean.valueOf(String.valueOf(paymentRequestData.get(PaymentConstants.EXPRESS_PAY_DECISION)));
		String collectionIntentId = (String) paymentRequestData.get(PaymentConstants.COLLECTION_INTENT_ID);
		String paymentConfirmation = (String) paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION);
		String correlationId = (String) paymentRequestData.get(PaymentConstants.CORRELATION_ID);
		String transactionDate = (String) paymentRequestData.get(PaymentConstants.TRANSACTION_DATE);
		String postedDate = (String) paymentRequestData.get(PaymentConstants.POSTED_DATE);

		String autoFeeAdjusted = (String) paymentRequestData.get(PaymentConstants.AUTOFEE_ADJUSTED);
		String updatedDate = paymentRequestEntity.getUpdatedTimestamp().format(DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE, Locale.US));

		PaymentRequest paymentRequest = new PaymentRequest();
		paymentRequest.setPaymentMode(paymentMode);
		paymentRequest.setFeeAmount(convertObjectToBigDecimal(feeAmount));
		paymentRequest.setPaymentAmount(convertObjectToBigDecimal(paymentAmount));
		paymentRequest.setScheduledDate(dataFormatted);
		paymentRequest.setCreateDate(cretedDate);
		paymentRequest.setChannel(channel);
		paymentRequest.setFdrStatus(fdrStatus);
		paymentRequest.setFdrPostedDate(fdrPostedDate);
		paymentRequest.setCancellationEligible((paymentRequestEntity.getRequestStatus().equalsIgnoreCase(PaymentStatus.PROCESSED.name())
				|| paymentRequestEntity.getRequestStatus().equalsIgnoreCase(PaymentStatus.SCHEDULE.name())));
		// added feeWaiverAmount,feeWaived,expressPayDecesion,
		// paymentConfirmation,collectionIntentId fields as part of SSPP-8296
		paymentRequest.setFeeWaiverAmount(convertObjectToBigDecimal(feeWaiverAmount));
		paymentRequest.setFeeWaived(feeWaived);
		paymentRequest.setExpressPayDecision(expressPayDecesion);
		paymentRequest.setPaymentConfirmation(paymentConfirmation);
		paymentRequest.setCollectionIntentId(collectionIntentId);
		if (!ObjectUtils.isEmpty(correlationId))
			paymentRequest.setCorrelationId(correlationId);
		if (!ObjectUtils.isEmpty(transactionDate))
			paymentRequest.setTransactionDate(transactionDate);
		if (!ObjectUtils.isEmpty(postedDate))
			paymentRequest.setPostedDate(postedDate);
		if (!ObjectUtils.isEmpty(autoFeeAdjusted)) {
			if (autoFeeAdjusted.equalsIgnoreCase("true")) {
				paymentRequest.setAutoFeeAdjusted(true);
			} else {
				paymentRequest.setAutoFeeAdjusted(false);
			}
		}
		if (!ObjectUtils.isEmpty(updatedDate))
			paymentRequest.setUpdatedDate(updatedDate);
		List<PaymentRequestPaymentMetadataInner> paymentMetaData = new ArrayList<>();

		if (paymentRequestData.get(PaymentConstants.PAYMENT_METADATA) instanceof List) {
			addPaymentMetadataFromList(paymentRequestData, paymentMetaData);
		} else if (paymentRequestData.get(PaymentConstants.PAYMENT_METADATA) instanceof JSONObject) {
			addPaymentMetadataFromJSONObject(paymentRequestData, paymentMetaData);
		}

		if (!ObjectUtils.isEmpty((String) paymentRequestData.get(PaymentConstants.CREDIT_ACCOUNT_LAST4)))
			paymentRequest.setCreditAccountLast4((String) paymentRequestData.get(PaymentConstants.CREDIT_ACCOUNT_LAST4));
		if (!ObjectUtils.isEmpty((String) paymentRequestData.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4)))
			paymentRequest.setExternalAccountLast4((String) paymentRequestData.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		paymentRequest.setPaymentReturnCode((String) paymentRequestData.get(PaymentConstants.PAYMENT_RETURN_CODE));
		paymentRequest.setPaymentReturnDate(((String) paymentRequestData.get(PaymentConstants.PAYMENT_RETURN_DATE)));
		paymentRequest.setExternalBankName((String) paymentRequestData.get(PaymentConstants.EXTERNAL_BANK_NAME));
		paymentRequest.setPastDueAmount(PaymentMapper.convertObjectToBigDecimal(paymentRequestData.get(PaymentConstants.PAST_DUE_AMOUNT)));
		if (paymentRequestData.get(PaymentConstants.PAYMENT_PURPOSE) != null) {
			paymentRequest.setPaymentPurpose(PaymentRequest.PaymentPurposeEnum.valueOf((String) paymentRequestData.get(PaymentConstants.PAYMENT_PURPOSE)));
		}
		paymentRequest.setStatementDate((String) paymentRequestData.get(PaymentConstants.STATEMENT_DATE_REQ));
		String minimumPayment = (String) paymentRequestData.get(PaymentConstants.MINIMUM_PAYMENT_DUE);
		paymentRequest.setMinimumPaymentDue(convertStringToBigDecimal(minimumPayment));
		String delinquentAmount = (String) paymentRequestData.get(PaymentConstants.DELINQUENT_AMOUNT);
		paymentRequest.setDelinquentAmount(convertStringToBigDecimal(delinquentAmount));
		String delinquentDays = (String) paymentRequestData.get(PaymentConstants.DAYS_DELINQUENT);
		paymentRequest.setDaysDelinquent(convertStringToBigDecimal(delinquentDays));
		if (paymentRequestData.get(PaymentConstants.DEBIT_LAST4) != null) {
			paymentRequest.setDebitLast4((String) paymentRequestData.get(PaymentConstants.DEBIT_LAST4));
		}

		paymentRequest.setPaymentMetadata(paymentMetaData);

		fillPaymentRequest(paymentRequest, paymentRequestEntity);

		return paymentRequest;
	}

	private static void addPaymentMetadataFromList(JSONObject paymentRequestData, List<PaymentRequestPaymentMetadataInner> paymentMetaData) {
		PaymentRequestPaymentMetadataInner paymentRequestPaymentMetadataInner = null;

		List<JSONObject> listPaymentRequestData = (List<JSONObject>) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		if (listPaymentRequestData != null) {
			for (Map<String, Object> paramsPaymentMetaData : listPaymentRequestData) {
				paymentRequestPaymentMetadataInner = new PaymentRequestPaymentMetadataInner();
				paymentRequestPaymentMetadataInner.setNotes((String) paramsPaymentMetaData.get(PaymentConstants.NOTES));
				paymentRequestPaymentMetadataInner.setDate((String) paramsPaymentMetaData.get(PaymentConstants.DATE));
				paymentRequestPaymentMetadataInner.setCommunicationRequestId((String) paramsPaymentMetaData.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
				Integer floatdays;
				if (paramsPaymentMetaData.get(PaymentConstants.FLOAT_DAYS) instanceof Long) {
					Long floatLong = (Long) paramsPaymentMetaData.get(PaymentConstants.FLOAT_DAYS);
					floatdays = Integer.valueOf(floatLong.toString());
				} else {
					floatdays = (Integer) paramsPaymentMetaData.get(PaymentConstants.FLOAT_DAYS);
				}
				paymentRequestPaymentMetadataInner.setFloatDays(floatdays);
				paymentRequestPaymentMetadataInner.setRiskLevel((String) paramsPaymentMetaData.get(PaymentConstants.RISK_LEVEL));
				if (!ObjectUtils.isEmpty((String) paramsPaymentMetaData.get(PaymentConstants.EXT_ACCNT_TYPE)))
					paymentRequestPaymentMetadataInner.setExternalAccountType((String) paramsPaymentMetaData.get(PaymentConstants.EXT_ACCNT_TYPE));
				mapAdditionalMetadataForPaymentHistory(paramsPaymentMetaData, paymentRequestPaymentMetadataInner);
				editParamsMetadata(paramsPaymentMetaData, paymentRequestPaymentMetadataInner);
				paymentMetaData.add(paymentRequestPaymentMetadataInner);
			}
		}
	}

	/***
	 * This method maps additional parameters for paymentMetadata response from
	 * payment history, called from
	 * PaymentMapper.fromPaymentRequestEntityToPaymentRequest
	 *
	 * @param paramsPaymentMetaData
	 * @param paymentRequestPaymentMetadataInner
	 */
	private static void mapAdditionalMetadataForPaymentHistory(Map<String, Object> paramsPaymentMetaData, PaymentRequestPaymentMetadataInner paymentRequestPaymentMetadataInner) {
		paymentRequestPaymentMetadataInner.setAgentId((String) paramsPaymentMetaData.get(PaymentConstants.AGENT_ID));
		paymentRequestPaymentMetadataInner.setPaymentEvent((String) paramsPaymentMetaData.get(PaymentConstants.PAYMENT_EVENT));
		paymentRequestPaymentMetadataInner
				.setCreditAccountSystemNumber(PaymentMapper.convertObjectToBigDecimal((String) paramsPaymentMetaData.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER)));
		paymentRequestPaymentMetadataInner.setThirdPartyCustomerId((String) paramsPaymentMetaData.get(PaymentConstants.THIRD_PARTY_CUSTOMER_ID));
	}

	private static void editParamsMetadata(Map<String, Object> paramsPaymentMetaData, PaymentRequestPaymentMetadataInner paymentRequestPaymentMetadataInner) {
		if (paramsPaymentMetaData.get(PaymentConstants.FULL_NAME) != null) {
			paymentRequestPaymentMetadataInner.setFullName((String) paramsPaymentMetaData.get(PaymentConstants.FULL_NAME));
		}
		if (paramsPaymentMetaData.get(PaymentConstants.DEBIT_EXPIRATION) != null) {
			paymentRequestPaymentMetadataInner.setDebitExpiration((String) paramsPaymentMetaData.get(PaymentConstants.DEBIT_EXPIRATION));
		}
		if (paramsPaymentMetaData.get(PaymentConstants.ADDRESS) != null) {
			paymentRequestPaymentMetadataInner.setAddress((String) paramsPaymentMetaData.get(PaymentConstants.ADDRESS));
		}
	}

	private static void addPaymentMetadataFromJSONObject(JSONObject paymentRequestData, List<PaymentRequestPaymentMetadataInner> paymentMetaData) {
		JSONObject paymentRequestDataJSONObject = (JSONObject) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		PaymentRequestPaymentMetadataInner paymentRequestPaymentMetadataInner = new PaymentRequestPaymentMetadataInner();
		if (paymentRequestDataJSONObject.get(PaymentConstants.NOTES) instanceof JSONArray) {
			JSONArray jsonArrayNotes = (JSONArray) paymentRequestDataJSONObject.get(PaymentConstants.NOTES);
			if (jsonArrayNotes.size() > 0) {
				JSONObject noteOne = (JSONObject) jsonArrayNotes.get(0);
				if (noteOne.get(PaymentConstants.DESCRIPTION) != null) {
					paymentRequestPaymentMetadataInner.setNotes((String) noteOne.get(PaymentConstants.DESCRIPTION));
				}
				if (noteOne.get(PaymentConstants.DATE) != null) {
					paymentRequestPaymentMetadataInner.setDate((String) noteOne.get(PaymentConstants.DATE));
				}
				paymentRequestPaymentMetadataInner.setCommunicationRequestId((String) noteOne.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
				Integer floatdays;
				if (noteOne.get(PaymentConstants.FLOAT_DAYS) instanceof Long) {
					Long floatLong = (Long) noteOne.get(PaymentConstants.FLOAT_DAYS);
					floatdays = Integer.valueOf(floatLong.toString());
				} else {
					floatdays = (Integer) noteOne.get(PaymentConstants.FLOAT_DAYS);
				}
				paymentRequestPaymentMetadataInner.setFloatDays(floatdays);
				paymentRequestPaymentMetadataInner.setRiskLevel((String) noteOne.get(PaymentConstants.RISK_LEVEL));
				if (!ObjectUtils.isEmpty((String) noteOne.get(PaymentConstants.EXT_ACCNT_TYPE)))
					paymentRequestPaymentMetadataInner.setExternalAccountType((String) noteOne.get(PaymentConstants.EXT_ACCNT_TYPE));

				mapAdditionalMetadataForPaymentHistoryForJSONObject(paymentRequestPaymentMetadataInner, noteOne);
			}
		}
		paymentMetaData.add(paymentRequestPaymentMetadataInner);
	}

	/***
	 * This method maps additional parameters for paymentMetadata response from
	 * payment history, called from
	 * PaymentMapper.fromPaymentRequestEntityToPaymentRequest For Json Object
	 *
	 * @param noteOne
	 * @param paymentRequestPaymentMetadataInner
	 */
	private static void mapAdditionalMetadataForPaymentHistoryForJSONObject(PaymentRequestPaymentMetadataInner paymentRequestPaymentMetadataInner, JSONObject noteOne) {
		paymentRequestPaymentMetadataInner.setAgentId((String) noteOne.get(PaymentConstants.AGENT_ID));
		paymentRequestPaymentMetadataInner.setPaymentEvent((String) noteOne.get(PaymentConstants.PAYMENT_EVENT));
		paymentRequestPaymentMetadataInner
				.setCreditAccountSystemNumber(PaymentMapper.convertObjectToBigDecimal((String) noteOne.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER)));
		paymentRequestPaymentMetadataInner.setThirdPartyCustomerId((String) noteOne.get(PaymentConstants.THIRD_PARTY_CUSTOMER_ID));
	}

	public static BigDecimal convertStringToBigDecimal(String inputValue) {
		if (inputValue != null) {
			BigDecimal bigDecimalvalue = new BigDecimal(inputValue);
			return bigDecimalvalue;
		} else
			return null;
	}

	public static BigDecimal convertObjectToBigDecimal(Object inputValue) {
		if (inputValue != null) {
			BigDecimal bigDecimalvalue = null;

			if (inputValue instanceof Long long1) {
				bigDecimalvalue = BigDecimal.valueOf(long1);
			} else if (inputValue instanceof Double double1) {
				bigDecimalvalue = BigDecimal.valueOf(double1);
			} else if (inputValue instanceof String string) {
				bigDecimalvalue = new BigDecimal(string);
			} else if (inputValue instanceof BigDecimal decimal) {
				bigDecimalvalue = decimal;
			}
			return bigDecimalvalue;
		} else
			return null;
	}

	private static void fillPaymentRequest(PaymentRequest paymentRequest, PaymentRequestEntity paymentRequestEntity) {
		paymentRequest.setPaymentRequestId(paymentRequestEntity.getPaymentRequestId().toString());
		paymentRequest.setCreditAccountId(paymentRequestEntity.getAccountKey().toString());
		paymentRequest.setExternalAccountId(paymentRequestEntity.getExternalAccountKey().toString());
		paymentRequest.setPaymentType(paymentRequestEntity.getPaymentType());
		paymentRequest.setAgentId(paymentRequestEntity.getCreatedBy());
		paymentRequest.setStatus(paymentRequestEntity.getRequestStatus());
	}

	public static EwsPartnerRequest mapEwsPartnerRequest(String customerId, AccountTokenResponse accountTokenResponse, String channel) {
		EwsPartnerRequest ewsPartnerRequest = new EwsPartnerRequest();
		EwsPartnerRequestMetaData ewsPartnerRequestMetaData = new EwsPartnerRequestMetaData();

		ewsPartnerRequest.setCustomerId(customerId);
		ewsPartnerRequestMetaData.setOneTimeAccessToken(accountTokenResponse.getMetadata().getOneTimeAccessToken().toString());
		ewsPartnerRequestMetaData.setGrantAccessToken(accountTokenResponse.getMetadata().getGrantAccessToken().toString());
		ewsPartnerRequest.setMetaData(ewsPartnerRequestMetaData);
		ewsPartnerRequest.setRoutingNumber(accountTokenResponse.getRoutingNumber());
		ewsPartnerRequest.setAccountType(accountTokenResponse.getAccountType());
		ewsPartnerRequest.setAmount(0);
		ewsPartnerRequest.setChannel(channel);

		return ewsPartnerRequest;
	}

	public static PaymentRequestEntity mapNewPaymentRequestEntity(PaymentServiceRequest request, PaymentDataTransferRequest requestDto) {
		PaymentRequestEntity entity = new PaymentRequestEntity();
		entity.setIndividualUniqueIdentifierKey(UUID.fromString(request.getCustomerId()));
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(request.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		entity.setPaymentDate(zonedDateTime);
		entity.setRequestStatus(requestDto.getStatus());
		entity.setAccountKey(UUID.fromString(request.getCreditAccountId()));
		entity.setExternalAccountKey(UUID.fromString(request.getExternalAccountId()));
		entity.setPaymentType(request.getPaymentType());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(request.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		entity.setPartnerName(partner);
		entity.setCreatedTimestamp(LocalDateTime.now());
		entity.setCreatedBy(request.getAgentId());
		entity.setUpdatedTimestamp(LocalDateTime.now());
		entity.setUpdatedBy(request.getAgentId());

		return entity;
	}

	public static PaymentRequestEntity mapPaymentRequestEntity(PaymentServiceRequest request, String paymentStatus, UUID uuidCustomerId, UUID uuidExternalAccountId) {
		PaymentRequestEntity entity = new PaymentRequestEntity();
		entity.setIndividualUniqueIdentifierKey(uuidCustomerId);
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(request.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		entity.setPaymentDate(zonedDateTime);
		entity.setRequestStatus(paymentStatus);
		entity.setAccountKey(UUID.fromString(request.getCreditAccountId()));
		entity.setExternalAccountKey(uuidExternalAccountId);
		entity.setPaymentType(request.getPaymentType());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(request.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		entity.setPartnerName(partner);
		entity.setCreatedTimestamp(LocalDateTime.now());
		entity.setCreatedBy(request.getAgentId());
		entity.setUpdatedTimestamp(LocalDateTime.now());
		entity.setUpdatedBy(request.getAgentId());

		return entity;
	}

	public static PaymentDataTransferRequest mapPaymentDtoRequest(PaymentServiceRequest request, UUID paymentRequestId, String cachedpaymentReqId, String correlationId) {
		PaymentDataTransferRequest dtoRequest = new PaymentDataTransferRequest();
		dtoRequest.setCustomerId(request.getCustomerId());
		dtoRequest.setStatus(PaymentStatus.INITIATED.name());
		dtoRequest.setCorrelationId(correlationId);
		dtoRequest.setPaymentRequestId(paymentRequestId);
		dtoRequest.setCachedPaymentRequestId(cachedpaymentReqId);
		dtoRequest.setExternalAccountId(request.getExternalAccountId());
		dtoRequest.setCreditAccountId(request.getCreditAccountId());
		dtoRequest.setScheduledDate(request.getScheduledDate());
		dtoRequest.setAgentId(request.getAgentId());
		dtoRequest.setChannel(request.getChannel());
		dtoRequest.setFeeAmount(request.getFeeAmount());
		dtoRequest.setNotes(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getNotes() : null);
		dtoRequest.setAddress(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getAddress() : null);
		dtoRequest.setFullName(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getFullName() : null);
		dtoRequest.setThirdPartyCustomerId(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getThirdPartyCustomerId() : null);
		dtoRequest.setPaymentType(request.getPaymentType());
		dtoRequest.setPaymentAmount(request.getPaymentAmount());
		dtoRequest.setPaymentPurpose(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getPaymentPurpose().name() : null);
		dtoRequest.setPaymentMode(request.getPaymentMode().name());
		dtoRequest.setDebitExpiration(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getDebitExpiration() : null);
		dtoRequest.setDebitLast4(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getDebitLast4() : null);
		return dtoRequest;
	}

	public static PaymentRequestEntity mapPaymentRequestEntity(Map<String, Object> parametersMethod) {
		PaymentRequestEntity entity = (PaymentRequestEntity) parametersMethod.get(PaymentConstants.PAYMENT_REQUEST_ENTITY);
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parametersMethod.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		String paymentStatus = (String) parametersMethod.get(PaymentConstants.STATUS);
		UUID uuidCustomerId = UUID.fromString(paymentServiceRequest.getCustomerId());
		UUID uuidExternalAccountId = UUID.fromString(paymentServiceRequest.getExternalAccountId());
		entity.setIndividualUniqueIdentifierKey(uuidCustomerId);
		if (paymentServiceRequest.getScheduledDate() != null) {
			LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
			ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
			entity.setPaymentDate(zonedDateTime);
		}
		entity.setRequestStatus(paymentStatus);
		entity.setAccountKey(UUID.fromString(paymentServiceRequest.getCreditAccountId()));
		entity.setExternalAccountKey(uuidExternalAccountId);
		entity.setPaymentType(paymentServiceRequest.getPaymentType());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(paymentServiceRequest.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		entity.setPartnerName(partner);
		entity.setCreatedTimestamp(LocalDateTime.now());
		entity.setCreatedBy(paymentServiceRequest.getAgentId());
		entity.setUpdatedTimestamp(LocalDateTime.now());
		entity.setUpdatedBy(paymentServiceRequest.getAgentId());

		return entity;
	}

	public static PaymentRequestEntity mapPaymentRequestSchEntity(PaymentDataTransferRequest paymentrequestDto, PaymentRequestEntity entity) {
		UUID uuidCustomerId = UUID.fromString(paymentrequestDto.getCustomerId());
		UUID uuidExternalAccountId = UUID.fromString(paymentrequestDto.getExternalAccountId());
		entity.setIndividualUniqueIdentifierKey(uuidCustomerId);
		if (paymentrequestDto.getScheduledDate() != null) {
			LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentrequestDto.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
			ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
			entity.setPaymentDate(zonedDateTime);
		}
		entity.setRequestStatus(paymentrequestDto.getStatus());
		entity.setAccountKey(UUID.fromString(paymentrequestDto.getCreditAccountId()));
		entity.setExternalAccountKey(uuidExternalAccountId);
		entity.setPaymentType(paymentrequestDto.getPaymentType());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(paymentrequestDto.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		entity.setPartnerName(partner);
		entity.setCreatedTimestamp(LocalDateTime.now());
		entity.setCreatedBy(paymentrequestDto.getAgentId());
		entity.setUpdatedTimestamp(LocalDateTime.now());
		entity.setUpdatedBy(paymentrequestDto.getAgentId());

		return entity;
	}

	public static Map<String, Object> getDataParamsFromPaymentServiceRequest(Map<String, Object> parameters, String configuredFeeAmount) {

		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameters.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		String externalAccountLast4 = (String) parameters.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
		String creditAccountLast4 = null;
		if (parameters.get(PaymentConstants.CREDIT_ACCOUNT_LAST4) != null) {
			creditAccountLast4 = (String) parameters.get(PaymentConstants.CREDIT_ACCOUNT_LAST4);
		}
		String communicationID = null;
		if (parameters.get(PaymentConstants.COMMUNICATION_REQUEST_ID) != null) {
			communicationID = (String) parameters.get(PaymentConstants.COMMUNICATION_REQUEST_ID);
		}

		Map<String, Object> dataParams = new HashMap<String, Object>();
		dataParams.put(PaymentConstants.PAYMENT_REQUESTID,
				parameters.get(PaymentConstants.PAYMENT_REQUESTID) != null ? parameters.get(PaymentConstants.PAYMENT_REQUESTID).toString() : null);
		dataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		dataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		dataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		dataParams.put(PaymentConstants.PAYMENT_AMOUNT, paymentServiceRequest.getPaymentAmount());
		dataParams.put(PaymentConstants.FEE_AMOUNT, paymentServiceRequest.getFeeAmount());
		dataParams.put(PaymentConstants.CHANNEL, paymentServiceRequest.getChannel());
		dataParams.put(PaymentConstants.FDR_STATUS, parameters.get(PaymentConstants.FDR_STATUS));
		dataParams.put(PaymentConstants.TRANSACTION_DATE, DateTimeFormatter.ISO_INSTANT.format(PaymentUtil.utcNow()));

		BigDecimal feeAmnt = new BigDecimal(configuredFeeAmount);
		if (paymentServiceRequest.getFeeAmount() != null && paymentServiceRequest.getFeeAmount().doubleValue() > 0) {
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, feeAmnt.subtract(paymentServiceRequest.getFeeAmount()));
		} else {
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, BigDecimal.ZERO);
		}
		dataParams.put(PaymentConstants.PAYMENT_MODE, paymentServiceRequest.getPaymentMode().name());

		Map<String, Object> parameterMethod = new HashMap<>();
		parameterMethod.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
		parameterMethod.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, externalAccountLast4);
		parameterMethod.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, creditAccountLast4);
		parameterMethod.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationID);
		parameterMethod.put(PaymentConstants.DATA_PARAMS, dataParams);
		parameterMethod.put(PaymentConstants.AGENT_ID, paymentServiceRequest.getAgentId());
		parameterMethod.put(PaymentConstants.EXTERNAL_BANK_NAME, parameters.get(PaymentConstants.EXTERNAL_BANK_NAME));
		parameterMethod.put(PaymentConstants.PAYMENT_EVENT, parameters.get(PaymentConstants.PAYMENT_EVENT));
		addDataParamMetadata(parameterMethod);
		return dataParams;
	}

	public static Map<String, Object> getJsonDataFromPaymentServiceRequest(PaymentDataTransferRequest requestDto, String configuredFeeAmount) {

		Map<String, Object> dataParams = new HashMap<String, Object>();
		dataParams.put(PaymentConstants.PAYMENT_REQUESTID, requestDto.getPaymentRequestId().toString());
		dataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		dataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		dataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		dataParams.put(PaymentConstants.PAYMENT_AMOUNT, requestDto.getPaymentAmount());
		dataParams.put(PaymentConstants.FEE_AMOUNT, requestDto.getFeeAmount());
		dataParams.put(PaymentConstants.CHANNEL, requestDto.getChannel());
		dataParams.put(PaymentConstants.FDR_STATUS, requestDto.getFdrStatus());
		dataParams.put(PaymentConstants.TRANSACTION_DATE, DateTimeFormatter.ISO_INSTANT.format(PaymentUtil.utcNow()));

		BigDecimal feeAmnt = new BigDecimal(configuredFeeAmount);
		if (requestDto.getFeeAmount() != null && requestDto.getFeeAmount().doubleValue() > 0) {
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, feeAmnt.subtract(requestDto.getFeeAmount()));
		} else {
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, BigDecimal.ZERO);
		}
		dataParams.put(PaymentConstants.PAYMENT_MODE, requestDto.getPaymentMode());
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, requestDto.getCreditAccountLast4() != null ? requestDto.getCreditAccountLast4().toString() : "");
		dataParams.put(PaymentConstants.DEBIT_LAST4, requestDto.getDebitLast4());
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, requestDto.getPaymentPurpose());
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, requestDto.getPaymentPurpose());
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, requestDto.getExternalAccountLast4() != null ? requestDto.getExternalAccountLast4().toString() : "");
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, requestDto.getCreditAccountLast4() != null ? requestDto.getCreditAccountLast4().toString() : "");
		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, requestDto.getExternalBankName());
		if (requestDto.getDebitLast4() != null) {
			dataParams.put(PaymentConstants.DEBIT_LAST4, requestDto.getDebitLast4());
		}
		addJsonMetadata(requestDto, dataParams);

		return dataParams;
	}

	public static Map<String, Object> getDataParamsFromPaymentServiceSchRequest(PaymentDataTransferRequest dataTransferDto, String configuredFeeAmount) {
		Map<String, Object> dataParams = new HashMap<String, Object>();
		dataParams.put(PaymentConstants.PAYMENT_REQUESTID, dataTransferDto.getPaymentRequestId().toString());
		dataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		dataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		dataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		dataParams.put(PaymentConstants.PAYMENT_AMOUNT, dataTransferDto.getPaymentAmount());
		dataParams.put(PaymentConstants.CHANNEL, dataTransferDto.getChannel());
		dataParams.put(PaymentConstants.FDR_STATUS, dataTransferDto.getFdrStatus());
		dataParams.put(PaymentConstants.TRANSACTION_DATE, DateTimeFormatter.ISO_INSTANT.format(PaymentUtil.utcNow()));
		dataParams.put(PaymentConstants.CORRELATION_ID, dataTransferDto.getCorrelationId());
		dataParams.put(PaymentConstants.COLLECTION_INTENT_ID, dataTransferDto.getCollectionIntentId());
		dataParams.put(PaymentConstants.INVOLVEMENT_ID, dataTransferDto.getInvolvementId());
		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, dataTransferDto.getExternalBankName());
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, dataTransferDto.getExternalAccountLast4());

		BigDecimal feeAmnt = new BigDecimal(configuredFeeAmount);
		if (dataTransferDto.getFeeAmount() != null && dataTransferDto.getFeeAmount().doubleValue() > 0) {
			dataParams.put(PaymentConstants.AUTOFEE_ADJUSTED, "true");
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, BigDecimal.ZERO);
			dataParams.put(PaymentConstants.FEE_AMOUNT, BigDecimal.ZERO);
		} else {
			dataParams.put(PaymentConstants.AUTOFEE_ADJUSTED, "false");
			dataParams.put(PaymentConstants.FEE_WAIVER_AMOUNT, BigDecimal.ZERO);
			dataParams.put(PaymentConstants.FEE_AMOUNT, dataTransferDto.getFeeAmount());
		}
		dataParams.put(PaymentConstants.PAYMENT_MODE, dataTransferDto.getPaymentMode());
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, dataTransferDto.getPaymentPurpose());
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, dataTransferDto.getCreditAccountLast4());
		dataParams.put(PaymentConstants.DEBIT_LAST4, dataTransferDto.getDebitLast4());
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, dataTransferDto.getPaymentPurpose());
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, dataTransferDto.getExternalAccountLast4() != null ? dataTransferDto.getExternalAccountLast4().toString() : "");
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, dataTransferDto.getCreditAccountLast4() != null ? dataTransferDto.getCreditAccountLast4().toString() : "");
		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, dataTransferDto.getExternalBankName());
		if (dataTransferDto.getDebitLast4() != null) {
			dataParams.put(PaymentConstants.DEBIT_LAST4, dataTransferDto.getDebitLast4());
		}
		dataParams.put(PaymentConstants.PAST_DUE_AMOUNT, dataTransferDto.getPastDueAmount());
		dataParams.put(PaymentConstants.DEBIT_LAST4, dataTransferDto.getDebitLast4());
		dataParams.put(PaymentConstants.STATEMENT_DATE, String.valueOf(dataTransferDto.getStatementDate()));
		dataParams.put(PaymentConstants.MINIMUM_PAYMENT, String.valueOf(dataTransferDto.getMinimumPaymentDue()));
		dataParams.put(PaymentConstants.DELINQUENT_AMOUNT, String.valueOf(dataTransferDto.getDelinquentAmount()));
		dataParams.put(PaymentConstants.DAYS_DELINQUENT, String.valueOf(dataTransferDto.getDaysDelinquent()));

		addJsonMetadata(dataTransferDto, dataParams);

		return dataParams;
	}

	/***
	 *
	 * @param paymentRequestDataDBResponse
	 * @param mapStatusPayment
	 * @return autoPayDataParams caller:
	 *         PaymentDAO.updatePaymentRequestEntityStatus()
	 */
	public static Map<String, Object> getDataParamsFromPaymentRequestDataDBResponse(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> mapStatusPayment, String correlationId) {
		JSONObject result;
		String jsonString = paymentRequestDataDBResponse.getPaymentRequestData().asString();
		BigDecimal paymentAmount = PaymentMapper.convertObjectToBigDecimal((Object) mapStatusPayment.get(PaymentConstants.PAYMENT_AMOUNT));
		JSONParser parser = new JSONParser();
		try {
			result = (JSONObject) parser.parse(jsonString);
		} catch (ParseException e) {
			String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
		JSONObject autoPayDataParams = result;
		String channel = (String) autoPayDataParams.get(PaymentConstants.CHANNEL);
		String paymentMode = autoPayDataParams.get(PaymentConstants.PAYMENT_MODE).toString();
		JSONArray paymentMetadataArray = (JSONArray) autoPayDataParams.get(PaymentConstants.PAYMENT_METADATA);

		fillMetadataGetDataParamsFromPaymentRequestDataDBResponse(paymentMetadataArray, mapStatusPayment);

		autoPayDataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4,
				autoPayDataParams.containsKey(PaymentConstants.EXTERNAL_ACCOUNT_LAST4) ? String.valueOf(autoPayDataParams.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4).toString())
						: " ");
		autoPayDataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4,
				autoPayDataParams.containsKey(PaymentConstants.CREDIT_ACCOUNT_LAST4) ? String.valueOf(autoPayDataParams.get(PaymentConstants.CREDIT_ACCOUNT_LAST4).toString())
						: " ");
		autoPayDataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, String.valueOf(mapStatusPayment.get(PaymentConstants.EXTERNAL_BANK_NAME)));
		autoPayDataParams.put(PaymentConstants.PAYMENT_PURPOSE,
				autoPayDataParams.containsKey(PaymentConstants.PAYMENT_PURPOSE) ? String.valueOf(autoPayDataParams.get(PaymentConstants.PAYMENT_PURPOSE).toString()) : " ");
		autoPayDataParams.put(PaymentConstants.PAYMENT_METADATA, paymentMetadataArray);
		autoPayDataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		autoPayDataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		autoPayDataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		autoPayDataParams.put(PaymentConstants.PAYMENT_AMOUNT, paymentAmount != null ? paymentAmount : result.get(PaymentConstants.PAYMENT_AMOUNT));
		autoPayDataParams.put(PaymentConstants.FEE_AMOUNT, PaymentMapper.convertObjectToBigDecimal((Object) autoPayDataParams.get(PaymentConstants.FEE_AMOUNT)));
		autoPayDataParams.put(PaymentConstants.CHANNEL, channel);
		autoPayDataParams.put(PaymentConstants.PAYMENT_MODE, paymentMode);

		return autoPayDataParams;
	}

	private static void fillMetadataGetDataParamsFromPaymentRequestDataDBResponse(JSONArray paymentMetadataArray, Map<String, Object> mapStatusPayment) {
		JSONObject paymentMetadata = paymentMetadataArray.size() > 0 ? (JSONObject) paymentMetadataArray.get(0) : new JSONObject();
		String agentId = paymentMetadata.containsKey(PaymentConstants.AGENT_ID) ? String.valueOf(paymentMetadata.get(PaymentConstants.AGENT_ID).toString()) : " ";
		String date = paymentMetadata.containsKey(PaymentConstants.DATE) ? String.valueOf(paymentMetadata.get(PaymentConstants.DATE).toString()) : " ";
		String notes = paymentMetadata.containsKey(PaymentConstants.NOTES) ? String.valueOf(paymentMetadata.get(PaymentConstants.NOTES).toString()) : " ";
		String communicationRequestId = (paymentMetadata.containsKey(PaymentConstants.COMMUNICATION_REQUEST_ID)
				&& paymentMetadata.get(PaymentConstants.COMMUNICATION_REQUEST_ID) != null)
						? String.valueOf(paymentMetadata.get(PaymentConstants.COMMUNICATION_REQUEST_ID).toString())
						: " ";

		paymentMetadata.put(PaymentConstants.DATE, date);
		paymentMetadata.put(PaymentConstants.NOTES, notes);
		paymentMetadata.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);
		paymentMetadata.put(PaymentConstants.PAYMENT_EVENT, PaymentConstants.AUTOPAY_NOTIFIED);

		JSONObject paymentMetaDataSchedule = new JSONObject();
		String cardType = (String) mapStatusPayment.get(PaymentConstants.CARD_TYPE);
		String externalAccountType = (String) mapStatusPayment.get(PaymentConstants.EXT_ACCNT_TYPE);
		String plasticDesignCode = (String) mapStatusPayment.get(PaymentConstants.PLASTIC_DESIGN_CODE);
		String deliquencyFlag = (String) mapStatusPayment.get(PaymentConstants.DELIQUENCY_FLAG);
		String scheduleDate = PaymentUtil.formatDate(PaymentUtil.utcNow(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		paymentMetaDataSchedule.put(PaymentConstants.NOTES, notes);
		paymentMetaDataSchedule.put(PaymentConstants.DATE, scheduleDate);
		paymentMetaDataSchedule.put(PaymentConstants.AGENT_ID, agentId);
		paymentMetaDataSchedule.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationRequestId);
		paymentMetaDataSchedule.put(PaymentConstants.PAYMENT_EVENT, PaymentConstants.SCHEDULE);
		paymentMetaDataSchedule.put(PaymentConstants.CARD_TYPE, cardType);
		paymentMetaDataSchedule.put(PaymentConstants.EXT_ACCNT_TYPE, externalAccountType);
		paymentMetaDataSchedule.put(PaymentConstants.PLASTIC_DESIGN_CODE, plasticDesignCode);
		paymentMetaDataSchedule.put(PaymentConstants.DELIQUENCY_FLAG, deliquencyFlag);
		paymentMetadataArray.add(paymentMetaDataSchedule);

	}

	/***
	 * @param parameterMethod
	 * @return dataParams caller: PaymentDao.saveAchDebitPaymentRequestEntity()
	 */
	public static Map<String, Object> getDataParamsFromPaymentServiceRequestUpdated(Map<String, Object> parameterMethod) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameterMethod.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		Map<String, Object> resultMap = (Map<String, Object>) parameterMethod.get(PaymentConstants.MAP_RESULT);

		Map<String, Object> dataParams = new HashMap<String, Object>();
		dataParams.put(PaymentConstants.LINE_OF_BUSINESS, LineOfBusiness.CREDITCARD.name());
		dataParams.put(PaymentConstants.TRANSACTION_TYPE, TransactionType.CREDITCARDPAYMENT.name());
		dataParams.put(PaymentConstants.TRANSACTION_DIRECTION, TransactionDirection.PAYMENT.name());
		dataParams.put(PaymentConstants.PAYMENT_AMOUNT, paymentServiceRequest.getPaymentAmount());
		dataParams.put(PaymentConstants.FEE_AMOUNT, paymentServiceRequest.getFeeAmount());
		dataParams.put(PaymentConstants.CHANNEL, paymentServiceRequest.getChannel());
		dataParams.put(PaymentConstants.PAYMENT_MODE, paymentServiceRequest.getPaymentMode().name());
		dataParams.put(PaymentConstants.FDR_STATUS, parameterMethod.get(PaymentConstants.FDR_STATUS));
		dataParams.put(PaymentConstants.COLLECTION_INTENT_ID, parameterMethod.get(PaymentConstants.COLLECTION_INTENT_ID));
		dataParams.put(PaymentConstants.CORRELATION_ID, parameterMethod.get(PaymentConstants.CORRELATION_ID));
		dataParams.put(PaymentConstants.EXPRESS_PAY_CONDITION, resultMap.get(PaymentConstants.EXPRESS_PAY_CONDITION));

		parameterMethod.put(PaymentConstants.DATA_PARAMS, dataParams);

		addDataParamMetadataUpdated(parameterMethod);

		return dataParams;
	}

	private static void addDataParamMetadata(Map<String, Object> parameterMethod) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameterMethod.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		Map<String, Object> dataParams = (Map<String, Object>) parameterMethod.get(PaymentConstants.DATA_PARAMS);
		JSONArray paymentMetadata = new JSONArray();
		JSONObject noteJSONObject = new JSONObject();
		String date = PaymentUtil.formatDate(PaymentUtil.utcNow(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		noteJSONObject.put(PaymentConstants.NOTES, paymentServiceRequest.getPaymentMetadata().getNotes());
		noteJSONObject.put(PaymentConstants.DATE, date);
		noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, (String) parameterMethod.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
		noteJSONObject.put(PaymentConstants.PAYMENT_EVENT, (String) parameterMethod.get(PaymentConstants.PAYMENT_EVENT));
		noteJSONObject.put(PaymentConstants.AGENT_ID, (String) parameterMethod.get(PaymentConstants.AGENT_ID));

		dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, (String) parameterMethod.get(PaymentConstants.EXTERNAL_BANK_NAME));
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, (String) parameterMethod.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, (String) parameterMethod.get(PaymentConstants.CREDIT_ACCOUNT_LAST4));
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, paymentServiceRequest.getPaymentMetadata().getPaymentPurpose().name());
		if (paymentServiceRequest.getPaymentMetadata().getDebitLast4() != null) {
			dataParams.put(PaymentConstants.DEBIT_LAST4, paymentServiceRequest.getPaymentMetadata().getDebitLast4());
		}

		fillOptionalDataParamMetadata(paymentServiceRequest, noteJSONObject);

		paymentMetadata.add(noteJSONObject);

		dataParams.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
	}

	@SuppressWarnings("unchecked")
	private static void addJsonMetadata(PaymentDataTransferRequest requestDto, Map<String, Object> dataParams) {
		JSONArray paymentMetadata = new JSONArray();
		JSONObject noteJSONObject = new JSONObject();
		String date = PaymentUtil.formatDate(PaymentUtil.utcNow(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		noteJSONObject.put(PaymentConstants.NOTES, requestDto.getNotes());
		noteJSONObject.put(PaymentConstants.DATE, date);

		noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, requestDto.getCommunicationRequestId() != null ? requestDto.getCommunicationRequestId().toString() : "");
		noteJSONObject.put(PaymentConstants.PAYMENT_EVENT, requestDto.getPaymentEvent());
		noteJSONObject.put(PaymentConstants.AGENT_ID, requestDto.getAgentId());
		noteJSONObject.put(PaymentConstants.EXT_ACCNT_TYPE, requestDto.getExternalAccountType());
		noteJSONObject.put(PaymentConstants.CARD_TYPE, requestDto.getCardType());// todo
		noteJSONObject.put(PaymentConstants.PLASTIC_DESIGN_CODE, requestDto.getPlasticDesignCode());
		noteJSONObject.put(PaymentConstants.DELIQUENCY_FLAG, requestDto.getDelequencyFlag());

		fillOptionalJsonParamMetadata(requestDto, noteJSONObject);

		paymentMetadata.add(noteJSONObject);

		dataParams.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
	}

	private static void fillOptionalDataParamMetadata(PaymentServiceRequest paymentServiceRequest, JSONObject noteJSONObject) {
		if (paymentServiceRequest.getPaymentMetadata().getAddress() != null) {
			noteJSONObject.put(PaymentConstants.ADDRESS, paymentServiceRequest.getPaymentMetadata().getAddress());
		}

		if (paymentServiceRequest.getPaymentMetadata().getDebitExpiration() != null) {
			noteJSONObject.put(PaymentConstants.DEBIT_EXPIRATION, paymentServiceRequest.getPaymentMetadata().getDebitExpiration());
		}

		if (paymentServiceRequest.getPaymentMetadata().getFullName() != null) {
			noteJSONObject.put(PaymentConstants.FULL_NAME, paymentServiceRequest.getPaymentMetadata().getFullName());
		}
	}

	private static void fillOptionalJsonParamMetadata(PaymentDataTransferRequest paymentServiceRequest, JSONObject noteJSONObject) {
		if (paymentServiceRequest.getAddress() != null) {
			noteJSONObject.put(PaymentConstants.ADDRESS, paymentServiceRequest.getAddress());
		}

		if (paymentServiceRequest.getDebitExpiration() != null) {
			noteJSONObject.put(PaymentConstants.DEBIT_EXPIRATION, paymentServiceRequest.getDebitExpiration());
		}

		if (paymentServiceRequest.getFullName() != null) {
			noteJSONObject.put(PaymentConstants.FULL_NAME, paymentServiceRequest.getFullName());
		}
	}

	private static void addDataParamMetadataUpdated(Map<String, Object> parameterMethod) {
		PaymentServiceRequest paymentServiceRequest = (PaymentServiceRequest) parameterMethod.get(PaymentConstants.PAYMENT_SERVICE_REQUEST);
		String externalAccountLast4 = (String) parameterMethod.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4);
		String creditAccountLast4 = (String) parameterMethod.get(PaymentConstants.CREDIT_ACCOUNT_LAST4);
		String communicationID = (String) parameterMethod.get(PaymentConstants.COMMUNICATION_REQUEST_ID);
		Map<String, Object> resultMap = (Map<String, Object>) parameterMethod.get(PaymentConstants.MAP_RESULT);
		Map<String, Object> dataParams = (Map<String, Object>) parameterMethod.get(PaymentConstants.DATA_PARAMS);
		JSONObject paymentRequestDataJson = (JSONObject) parameterMethod.get(PaymentConstants.PAYMENT_REQUEST_DATA_JSON);
		JSONObject noteJSONObject = new JSONObject();
		JSONArray paymentMetadata = (JSONArray) paymentRequestDataJson.get(PaymentConstants.PAYMENT_METADATA);

		String date = PaymentUtil.formatDate(PaymentUtil.utcNow(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		noteJSONObject.put(PaymentConstants.NOTES, paymentServiceRequest.getPaymentMetadata().getNotes());
		noteJSONObject.put(PaymentConstants.DATE, date);
		noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationID);
		noteJSONObject.put(PaymentConstants.AGENT_ID, parameterMethod.get(PaymentConstants.AGENT_ID));
		noteJSONObject.put(PaymentConstants.PAYMENT_EVENT, parameterMethod.get(PaymentConstants.PAYMENT_EVENT));
		noteJSONObject.put(PaymentConstants.RTP_STATUS, resultMap.get(PaymentConstants.RTP_STATUS));
		noteJSONObject.put(PaymentConstants.RTP_CONFIRMATION_CODE, resultMap.get(PaymentConstants.RTP_CONFIRMATION_CODE));
		noteJSONObject.put(PaymentConstants.THIRD_PARTY_CUSTOMER_ID, paymentServiceRequest.getPaymentMetadata().getThirdPartyCustomerId());
		noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, communicationID);
		noteJSONObject.put(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER, parameterMethod.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER));
		noteJSONObject.put(PaymentConstants.EXT_ACCNT_TYPE, resultMap.get(PaymentConstants.EXT_ACCNT_TYPE));
		noteJSONObject.put(PaymentConstants.PLASTIC_DESIGN_CODE, resultMap.get(PaymentConstants.PLASTIC_DESIGN_CODE));
		noteJSONObject.put(PaymentConstants.DELIQUENCY_FLAG, resultMap.get(PaymentConstants.DELIQUENCY_FLAG));

		dataParams.put(PaymentConstants.PAST_DUE_AMOUNT, resultMap.get(PaymentConstants.PAST_DUE_AMOUNT));
		dataParams.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, externalAccountLast4);
		dataParams.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, creditAccountLast4);
		dataParams.put(PaymentConstants.PAYMENT_PURPOSE, paymentServiceRequest.getPaymentMetadata().getPaymentPurpose().name());

		addOptionalParamMetadataUpdated(paymentServiceRequest, noteJSONObject, resultMap);
		if (resultMap.get(PaymentConstants.EXTERNAL_BANK_NAME) != null) {
			dataParams.put(PaymentConstants.EXTERNAL_BANK_NAME, resultMap.get(PaymentConstants.EXTERNAL_BANK_NAME));
		}
		if (paymentServiceRequest.getPaymentMetadata().getDebitLast4() != null) {
			dataParams.put(PaymentConstants.DEBIT_LAST4, paymentServiceRequest.getPaymentMetadata().getDebitLast4());
		}
		if (resultMap.get(PaymentConstants.STATEMENT_DATE) != null) {
			dataParams.put(PaymentConstants.STATEMENT_DATE, resultMap.get(PaymentConstants.STATEMENT_DATE).toString());
		}
		if (resultMap.get(PaymentConstants.MINIMUM_PAYMENT) != null) {
			dataParams.put(PaymentConstants.MINIMUM_PAYMENT, resultMap.get(PaymentConstants.MINIMUM_PAYMENT).toString());
		}
		if (resultMap.get(PaymentConstants.DELINQUENT_AMOUNT) != null) {
			dataParams.put(PaymentConstants.DELINQUENT_AMOUNT, resultMap.get(PaymentConstants.DELINQUENT_AMOUNT).toString());
		}
		if (resultMap.get(PaymentConstants.DAYS_DELINQUENT) != null) {
			dataParams.put(PaymentConstants.DAYS_DELINQUENT, resultMap.get(PaymentConstants.DAYS_DELINQUENT).toString());
		}
		paymentMetadata.add(noteJSONObject);

		dataParams.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
	}

	private static void addOptionalParamMetadataUpdated(PaymentServiceRequest paymentServiceRequest, JSONObject noteJSONObject, Map<String, Object> resultMap) {
		if (paymentServiceRequest.getPaymentMetadata().getAddress() != null) {
			noteJSONObject.put(PaymentConstants.ADDRESS, paymentServiceRequest.getPaymentMetadata().getAddress());
		}
		if (resultMap.get(PaymentConstants.CARD_TYPE) != null) {
			noteJSONObject.put(PaymentConstants.CARD_TYPE, resultMap.get(PaymentConstants.CARD_TYPE));
		}
		if (paymentServiceRequest.getPaymentMetadata().getDebitExpiration() != null) {
			noteJSONObject.put(PaymentConstants.DEBIT_EXPIRATION, paymentServiceRequest.getPaymentMetadata().getDebitExpiration());
		}

		if (paymentServiceRequest.getPaymentMetadata().getFullName() != null) {
			noteJSONObject.put(PaymentConstants.FULL_NAME, paymentServiceRequest.getPaymentMetadata().getFullName());
		}

		addOptionalRiskExpressPayParamMetadataUpdated(noteJSONObject, resultMap);
	}

	public static void addDataParamMetadataProcessed(PaymentDataTransferRequest paymentRequestDto, Map<String, Object> dataParams, JSONObject paymentRequestDataJson) {
		JSONObject noteJSONObject = new JSONObject();
		JSONArray paymentMetadata = (JSONArray) paymentRequestDataJson.get(PaymentConstants.PAYMENT_METADATA);

		String date = PaymentUtil.formatDate(PaymentUtil.utcNow(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		noteJSONObject.put(PaymentConstants.NOTES, paymentRequestDto.getNotes());
		noteJSONObject.put(PaymentConstants.DATE, date);
		noteJSONObject.put(PaymentConstants.COMMUNICATION_REQUEST_ID, paymentRequestDto.getCommunicationRequestId());
		noteJSONObject.put(PaymentConstants.AGENT_ID, paymentRequestDto.getAgentId());
		noteJSONObject.put(PaymentConstants.PAYMENT_EVENT, paymentRequestDto.getPaymentEvent());
		noteJSONObject.put(PaymentConstants.RTP_STATUS, paymentRequestDto.getRtpStatus());
		noteJSONObject.put(PaymentConstants.RTP_CONFIRMATION_CODE, paymentRequestDto.getRtpConfirmationCode());
		noteJSONObject.put(PaymentConstants.THIRD_PARTY_CUSTOMER_ID, paymentRequestDto.getThirdPartyCustomerId());
		noteJSONObject.put(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER, paymentRequestDto.getCreditAccountSystemNumber());
		noteJSONObject.put(PaymentConstants.EXT_ACCNT_TYPE, paymentRequestDto.getExternalAccountType());
		noteJSONObject.put(PaymentConstants.PLASTIC_DESIGN_CODE, paymentRequestDto.getPlasticDesignCode());
		noteJSONObject.put(PaymentConstants.DELIQUENCY_FLAG, paymentRequestDto.getDelequencyFlag());
		noteJSONObject.put(PaymentConstants.DAYS_PASY_DUE, paymentRequestDto.getDaysPastDue());
		noteJSONObject.put(PaymentConstants.INVOLVEMENT_ID, paymentRequestDto.getInvolvementId());
		noteJSONObject.put(PaymentConstants.PRODUCT_KEY, paymentRequestDto.getProductKey());

		addOptionalParamMetadataProcessed(paymentRequestDto, noteJSONObject);

		paymentMetadata.add(noteJSONObject);

		dataParams.put(PaymentConstants.PAYMENT_METADATA, paymentMetadata);
	}

	private static void addOptionalParamMetadataProcessed(PaymentDataTransferRequest paymentRequestDto, JSONObject noteJSONObject) {
		if (paymentRequestDto.getAddress() != null) {
			noteJSONObject.put(PaymentConstants.ADDRESS, paymentRequestDto.getAddress());
		}
		if (paymentRequestDto.getCardType() != null) {
			noteJSONObject.put(PaymentConstants.CARD_TYPE, paymentRequestDto.getCardType());
		}
		if (paymentRequestDto.getDebitExpiration() != null) {
			noteJSONObject.put(PaymentConstants.DEBIT_EXPIRATION, paymentRequestDto.getDebitExpiration());
		}

		if (paymentRequestDto.getFullName() != null) {
			noteJSONObject.put(PaymentConstants.FULL_NAME, paymentRequestDto.getFullName());
		}

		addOptionalRiskExpressPayParamMetadataProcessed(noteJSONObject, paymentRequestDto);
	}

	private static void addOptionalRiskExpressPayParamMetadataUpdated(JSONObject noteJSONObject, Map<String, Object> resultMap) {
		if (resultMap.get(PaymentConstants.FEE_WAIVED) != null) {
			noteJSONObject.put(PaymentConstants.FEE_WAIVED, resultMap.get(PaymentConstants.FEE_WAIVED).toString());
		}

		if (resultMap.get(PaymentConstants.RISKY_PAYMENT) != null) {
			noteJSONObject.put(PaymentConstants.RISKY_PAYMENT, resultMap.get(PaymentConstants.RISKY_PAYMENT).toString());
		}

		if (resultMap.get(PaymentConstants.RISK_LEVEL) != null) {
			noteJSONObject.put(PaymentConstants.RISK_LEVEL, (String) resultMap.get(PaymentConstants.RISK_LEVEL));
		}

		if (resultMap.get(PaymentConstants.FLOAT_DAYS) != null) {
			noteJSONObject.put(PaymentConstants.FLOAT_DAYS, (Integer) resultMap.get(PaymentConstants.FLOAT_DAYS));
		}

		if (resultMap.get(PaymentConstants.EXPRESS_PAY) != null) {
			noteJSONObject.put(PaymentConstants.EXPRESS_PAY, resultMap.get(PaymentConstants.EXPRESS_PAY).toString());
		}
	}

	private static void addOptionalRiskExpressPayParamMetadataProcessed(JSONObject noteJSONObject, PaymentDataTransferRequest paymentRequestdto) {
		if (paymentRequestdto.getFeeWaived() != null) {
			noteJSONObject.put(PaymentConstants.FEE_WAIVED, paymentRequestdto.getFeeWaived().toString());
		}

		if (paymentRequestdto.getRiskyPayment() != null) {
			noteJSONObject.put(PaymentConstants.RISKY_PAYMENT, paymentRequestdto.getRiskyPayment().toString());
		}

		if (paymentRequestdto.getRiskLevel() != null) {
			noteJSONObject.put(PaymentConstants.RISK_LEVEL, (String) paymentRequestdto.getRiskLevel());
		}

		if (paymentRequestdto.getFloatDays() != null) {
			noteJSONObject.put(PaymentConstants.FLOAT_DAYS, (Integer) paymentRequestdto.getFloatDays());
		}

		if (paymentRequestdto.getExpressPayDecesion() != null) {
			noteJSONObject.put(PaymentConstants.EXPRESS_PAY, paymentRequestdto.getExpressPayDecesion().toString());
		}
	}

	public static AchTransactionRequest mapAchTransactionRequest(PaymentServiceRequest request, UUID paymentRequestId, PaymentDataTransferRequest paymentRequestDto) {
		AchTransactionRequest achTransactionRequest = new AchTransactionRequest();
		achTransactionRequest.setChannel(request.getChannel());
		BigDecimal feeAmount = PaymentMapper.convertObjectToBigDecimal(paymentRequestDto.getFeeAmount());
		BigDecimal finalAmount = request.getPaymentAmount().add(feeAmount).setScale(2, RoundingMode.CEILING);
		achTransactionRequest.setPaymentAmount(finalAmount.doubleValue());
		achTransactionRequest.setTransactionType(TransactionType.CREDITCARDPAYMENT.name());
		achTransactionRequest.setTransactionDirection(TransactionDirection.PAYMENT.name());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(request.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		achTransactionRequest.setPartner(partner);
		achTransactionRequest.setPaymentRequestId(paymentRequestId.toString());
		achTransactionRequest.setCustomerId(request.getCustomerId());
		achTransactionRequest.setPaymentDate(request.getScheduledDate());
		achTransactionRequest.setLineOfBusiness(LineOfBusiness.CREDITCARD.name());
		achTransactionRequest.setPaymentMode(request.getPaymentMode().name());
		achTransactionRequest.setCreditAccountId(request.getCreditAccountId());
		achTransactionRequest.setReceiverAccountToken(paymentRequestDto.getOneTimeAccessToken());
		achTransactionRequest.setReceiverAccountRouting(paymentRequestDto.getReceiverAccountRoutingNumber());
		achTransactionRequest.setReceiverAccountType(paymentRequestDto.getReceiverAccountType());

		setMetadataMapAchTransactionRequest(paymentRequestDto, achTransactionRequest);

		return achTransactionRequest;
	}

	private static void setMetadataMapAchTransactionRequest(PaymentDataTransferRequest paymentRequestDto, AchTransactionRequest achTransactionRequest) {
		MetaData achTransactionMetaData = new MetaData();
		achTransactionMetaData.setGrantAccessToken(paymentRequestDto.getGrantAccessToken().toString());
		achTransactionMetaData.setOneTimeAccessToken(paymentRequestDto.getOneTimeAccessToken().toString());
		achTransactionRequest.setMetaData(achTransactionMetaData);
	}

	public static DebitTransactionRequest mapDebitTransactionRequest(PaymentServiceRequest request, UUID paymentRequestId, GetDebitCardTokenResponse debitCardTokenResponse) {
		DebitTransactionRequest debitTransactionRequest = new DebitTransactionRequest();
		debitTransactionRequest.setCreditAccountId(request.getCreditAccountId());
		debitTransactionRequest.setChannel(request.getChannel());
		debitTransactionRequest.setFeeAmount(request.getFeeAmount().doubleValue());
		debitTransactionRequest.setPaymentAmount(request.getPaymentAmount().doubleValue());
		debitTransactionRequest.setTransactionType(TransactionType.CREDITCARDPAYMENT.name());
		debitTransactionRequest.setTransactionDirection(TransactionDirection.PAYMENT.name());
		String partner = "";
		for (PaymentType paymentType : PaymentType.values()) {
			if (paymentType.name().equalsIgnoreCase(request.getPaymentType())) {
				partner = paymentType.getPartner();
			}
		}
		debitTransactionRequest.setPartner(partner);
		debitTransactionRequest.setPaymentRequestId(paymentRequestId.toString());
		debitTransactionRequest.setCustomerId(request.getCustomerId());
		debitTransactionRequest.setPaymentDate(request.getScheduledDate());

		debitTransactionRequest.setReceiverAccountToken(debitCardTokenResponse.getDebitCardToken());

		return debitTransactionRequest;
	}

	public static PaymentCommunicationRequest getPaymentCommunicationRequest(PaymentServiceRequest paymentServiceRequest, Map<String, Object> mapResponse, UUID paymentRequestId) {
		PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
		paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);
		paymentCommunicationRequest.setCommunicationIntent((PaymentCommunicationIntent) mapResponse.get(PaymentConstants.COMMUNICATION_INTENT));
		paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(paymentServiceRequest.getCustomerId()));
		paymentCommunicationDetailsRequest.setFirstName((String) mapResponse.get(PaymentConstants.FIRST_NAME));
		paymentCommunicationDetailsRequest.setLastName((String) mapResponse.get(PaymentConstants.LAST_NAME));
		paymentCommunicationDetailsRequest.setCardType((String) mapResponse.get(PaymentConstants.CARD_TYPE));
		paymentCommunicationDetailsRequest.setCardLast4((String) mapResponse.get(PaymentConstants.CARD_LAST4));

		paymentCommunicationDetailsRequest.setPaymentAmount(paymentServiceRequest.getPaymentAmount());
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		paymentCommunicationDetailsRequest.setPaymentDate(zonedDateTime);
		paymentCommunicationDetailsRequest.setDayOfWeek(PaymentUtil.getCurrentDayOfWeek());
		paymentCommunicationDetailsRequest.setInvolvementId((String) mapResponse.get(PaymentConstants.INVOLVEMENT_ID));

		paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
		return paymentCommunicationRequest;
	}

	public static PaymentCommunicationRequest getPaymentCommunicationRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDataDto, UUID paymentRequestId) {
		PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
		paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);
		paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.PAYMENT_PROCESSED);
		paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(paymentServiceRequest.getCustomerId()));
		paymentCommunicationDetailsRequest.setFirstName(paymentDataDto.getFirstName());
		paymentCommunicationDetailsRequest.setLastName(paymentDataDto.getLastName());
		paymentCommunicationDetailsRequest.setCardType(paymentDataDto.getCardType());
		paymentCommunicationDetailsRequest.setCardLast4(paymentDataDto.getCreditAccountLast4());

		paymentCommunicationDetailsRequest.setPaymentAmount(paymentServiceRequest.getPaymentAmount());
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
		paymentCommunicationDetailsRequest.setPaymentDate(zonedDateTime);
		paymentCommunicationDetailsRequest.setDayOfWeek(PaymentUtil.getCurrentDayOfWeek());
		paymentCommunicationDetailsRequest.setInvolvementId(paymentDataDto.getInvolvementId());

		paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);
		return paymentCommunicationRequest;
	}

	public static PaymentDataTransferRequest getPaymentDataMap(AccountDetailsResponse accountDetailsResponse, Map<String, Object> externalAccountResponse, PaymentServiceRequest request, PaymentDataTransferRequest requestDto) {
		requestDto.setCardType(accountDetailsResponse.getDevice().getNetwork());
		requestDto.setCreditAccountLast4(accountDetailsResponse.getDevice().getDeviceLast4());
		requestDto.setProductKey(accountDetailsResponse.getProductKey() != null ? accountDetailsResponse.getProductKey().toString() : null);
		requestDto.setCreditAccountSystemNumber(accountDetailsResponse.getDevice().getSystemNumber());
		requestDto.setInvolvementId(
				accountDetailsResponse.getAccountInvolvements().stream().filter(account -> account.getAccountInvolvementType().equals(PaymentConstants.PRIMARY_INV))
						.map(AccountsInvolvementResponse::getInvolvementId).map(Id -> Id.toString()).findFirst().orElse(null));

		if (request.getPaymentMode().getValue().equals(PaymentModeEnum.EXPRESS_PAYMENT.getValue())) {
			requestDto.setCreditCardEligibility(accountDetailsResponse.getExpressPayEligible());
			requestDto.setExternalAccountElgibility(externalAccountResponse.get(PaymentConstants.EXTERNALACNT_ELIGIBILITY) != null
					? (Boolean) externalAccountResponse.get(PaymentConstants.EXTERNALACNT_ELIGIBILITY)
					: null);
		} else {
			requestDto.setCreditCardEligibility(accountDetailsResponse.getPaymentEligible());
			requestDto.setExternalAccountElgibility(externalAccountResponse.get(PaymentConstants.EXTERNALACNT_ELIGIBILITY) != null
					? (Boolean) externalAccountResponse.get(PaymentConstants.EXTERNALACNT_ELIGIBILITY)
					: null);
		}
		requestDto.setExternalAccountLast4((String) externalAccountResponse.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		requestDto.setExternalBankName((String) externalAccountResponse.get(PaymentConstants.EXTERNAL_BANK_NAME));
		requestDto.setFeeAmount(request.getFeeAmount());
		requestDto.setExternalAccountType((String) externalAccountResponse.get(PaymentConstants.EXT_ACCNT_TYPE));
		requestDto.setPlasticDesignCode(accountDetailsResponse.getDevice().getPlasticDesignCode());
		requestDto.setCardOpenDate(accountDetailsResponse.getAccountOpenDate());
		requestDto.setDelequencyFlag(accountDetailsResponse.getDeliquencyFlag());
		requestDto.setExtAccountStatus(
				externalAccountResponse.get(PaymentConstants.EXT_ACT_STATUS) != null ? externalAccountResponse.get(PaymentConstants.EXT_ACT_STATUS).toString() : null);
		requestDto
				.setIsNewExtAccount(externalAccountResponse.get(PaymentConstants.IS_NEW_ACNT) != null ? (Boolean) externalAccountResponse.get(PaymentConstants.IS_NEW_ACNT) : null);

		return requestDto;
	}

	public static RiskyPaymentRequest getRiskyPaymentRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentrequestDto) {
		RiskyPaymentRequest riskyPaymentRequest = new RiskyPaymentRequest();
		riskyPaymentRequest.setCreditAccountId(paymentServiceRequest.getCreditAccountId());
		riskyPaymentRequest.setCustomerId(paymentServiceRequest.getCustomerId());
		riskyPaymentRequest.setCreditCardEligibility(paymentrequestDto.getCreditCardEligibility());
		riskyPaymentRequest.setExternalAccountElgibility(paymentrequestDto.getExternalAccountElgibility());
		riskyPaymentRequest.setFeeWaived(paymentrequestDto.getFeeWaived());
		riskyPaymentRequest.setPaymentAmount(paymentServiceRequest.getPaymentAmount().doubleValue());
		riskyPaymentRequest.setIsNewExtAccount(paymentrequestDto.getIsNewExtAccount());
		riskyPaymentRequest.setExtAccountStatus(paymentrequestDto.getExtAccountStatus());
		riskyPaymentRequest.setCreditLimit(paymentrequestDto.getCreditCardLimit() != null ? paymentrequestDto.getCreditCardLimit().doubleValue() : null);
		riskyPaymentRequest.setCurrentBalance(paymentrequestDto.getCurrentBalance() != null ? paymentrequestDto.getCurrentBalance().doubleValue() : null);
		riskyPaymentRequest.setPaymentDate(
				PaymentUtil.formatDate(PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE), PaymentConstants.YYYY_MM_DD));
		return riskyPaymentRequest;
	}

	public static FraudCheckRequest getFraudPaymentRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDataDto) {
		FraudCheckRequestExternalAccountVerfication externalAcntVerification = new FraudCheckRequestExternalAccountVerfication();
		FraudCheckRequest fraudRulesreq = new FraudCheckRequest();
		fraudRulesreq.setChannel(ChannelEnum.fromValue(paymentServiceRequest.getChannel().toUpperCase()));
		fraudRulesreq.setCreditAccountBalance(paymentDataDto.getCurrentBalance() != null ? paymentDataDto.getCurrentBalance().doubleValue() : null);
		fraudRulesreq.setCreditOpenDate(paymentDataDto.getCardOpenDate());
		fraudRulesreq.setIntent(IntentEnum.valueOf(paymentServiceRequest.getPaymentMode().getValue()));// PaymentModeEnum
		fraudRulesreq.setPaymentAmount(paymentServiceRequest.getPaymentAmount().doubleValue());
		fraudRulesreq.setPaymentType(PaymentTypeEnum.valueOf(paymentServiceRequest.getPaymentType().toUpperCase()));
		externalAcntVerification.setLastNameMatch(paymentDataDto.getLNameMtch());
		externalAcntVerification.setNameMatch(paymentDataDto.getNameMtch());
		externalAcntVerification.setSsnMatch(paymentDataDto.getSSNMtch());
		fraudRulesreq.setExternalAccountVerfication(externalAcntVerification);
		return fraudRulesreq;
	}

	public static PaymentCommunicationRequest getAutoPaymentNotificationRequest(PaymentServiceRequest paymentServiceRequest, Map<String, Object> mapResponse, UUID paymentRequestId) {

		PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
		paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);
		paymentCommunicationRequest.setCommunicationIntent((PaymentCommunicationIntent) mapResponse.get(PaymentConstants.COMMUNICATION_INTENT));
		paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
		PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
		paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(paymentServiceRequest.getCustomerId()));
		paymentCommunicationDetailsRequest.setFirstName((String) mapResponse.get(PaymentConstants.FIRSTNAME));
		paymentCommunicationDetailsRequest.setLastName((String) mapResponse.get(PaymentConstants.LASTNAME));
		paymentCommunicationDetailsRequest.setCardType((String) mapResponse.get(PaymentConstants.CARDTYPE));
		paymentCommunicationDetailsRequest.setCardLast4((String) mapResponse.get(PaymentConstants.CARDLASTFOUR));
		paymentCommunicationDetailsRequest.setPaymentAmount(paymentServiceRequest.getPaymentAmount());
		paymentCommunicationDetailsRequest.setPaymentBank((String) mapResponse.get(PaymentConstants.PAYMENTBANK));
		paymentCommunicationDetailsRequest.setInvolvementId((String) mapResponse.get(PaymentConstants.INVOLVEMENT_ID));
		paymentCommunicationDetailsRequest.setPaymentLast4((String) mapResponse.get(PaymentConstants.PAYMENTLAST4));
		String paymentDate = (String) mapResponse.get(PaymentConstants.PAYMENTDATE);

		LocalDateTime localDateTime = PaymentUtil.parseDateTime(paymentDate, PaymentConstants.DATETIMEFORMAT_RESPONSE);
		paymentCommunicationDetailsRequest.setPaymentDate(PaymentUtil.toZonedDateTime(localDateTime));
		paymentCommunicationDetailsRequest.setEmailAddress((String) mapResponse.get(PaymentConstants.EMAIL_ADDRESS));
		paymentCommunicationDetailsRequest.setDayOfWeek(PaymentUtil.getCurrentDayOfWeek());
		paymentCommunicationRequest.setPaymentCommunicationDetailsRequest(paymentCommunicationDetailsRequest);

		return paymentCommunicationRequest;
	}

	public static CollectionIntentRequest getCollectionIntentRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentDataTransferDto, UUID paymentRequestId, String correlationId) {
		String scheduleDate = null;
		CollectionIntentRequest collectionIntentRequest = new CollectionIntentRequest();
		collectionIntentRequest.setCorrelationId(correlationId);
		collectionIntentRequest.setConversationId(paymentRequestId.toString());
		collectionIntentRequest.setIntentId(paymentRequestId.toString());
		collectionIntentRequest.setCustomerId(paymentServiceRequest.getCustomerId());
		collectionIntentRequest.setCreditAccountId(paymentServiceRequest.getCreditAccountId());
		collectionIntentRequest.setAgentId(paymentServiceRequest.getAgentId());
		collectionIntentRequest.setCollectionIntentsType(CollectionIntentsTypeEnum.fromValue(paymentDataTransferDto.getCollectionIntentType()));
		collectionIntentRequest.setCollectionIntentSubTypeCode(paymentServiceRequest.getPaymentType());
		collectionIntentRequest.setAmount(paymentServiceRequest.getPaymentAmount());
		if (paymentDataTransferDto.getSchduleTimestampPst() != null) {
			scheduleDate = String.valueOf(paymentDataTransferDto.getSchduleTimestampPst());
			collectionIntentRequest.setPromiseDate(scheduleDate.substring(0, 10));
		}
		collectionIntentRequest.setCallType(PaymentConstants.INBOUND);
		collectionIntentRequest.setAttempted(PaymentConstants.PRIMARY);
		collectionIntentRequest.setContacted(
				(paymentDataTransferDto.getPaymentMode() != null && PaymentModeEnum.THIRDPARTY_PAYMENT.name().equalsIgnoreCase(paymentDataTransferDto.getPaymentMode()))
						? PaymentConstants.THIRD_PARTY
						: PaymentConstants.PRIMARY);
		collectionIntentRequest.setContactedPersonName(
				paymentDataTransferDto.getPaymentMode() != null && PaymentModeEnum.THIRDPARTY_PAYMENT.name().equalsIgnoreCase(paymentDataTransferDto.getPaymentMode())
						? paymentDataTransferDto.getFullName()
						: paymentDataTransferDto.getFirstName() + " " + paymentDataTransferDto.getLastName());

		return collectionIntentRequest;
	}

	public static CollectionIntentRequest getCollectionIntentRequest(PaymentRequestDataDBResponse paymentRequestDataDBResponse, Map<String, Object> inputParams, String correlationId) {
		String scheduleDate = null;
		CollectionIntentRequest collectionIntentRequest = new CollectionIntentRequest();
		collectionIntentRequest.setCorrelationId(correlationId);
		collectionIntentRequest.setConversationId(paymentRequestDataDBResponse.getPaymentRequestId().toString());
		collectionIntentRequest.setIntentId(paymentRequestDataDBResponse.getPaymentRequestId().toString());
		collectionIntentRequest.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString());
		collectionIntentRequest.setCreditAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
		collectionIntentRequest.setAgentId((String) inputParams.get(PaymentConstants.AGENT_ID));
		collectionIntentRequest.setCollectionIntentsType(CollectionIntentsTypeEnum.fromValue(inputParams.get(PaymentConstants.COLLECTION_INTENT).toString()));
		collectionIntentRequest.setCollectionIntentSubTypeCode(paymentRequestDataDBResponse.getPaymentType());
		collectionIntentRequest.setAmount(PaymentMapper.convertObjectToBigDecimal(inputParams.get(PaymentConstants.PAYMENT_AMOUNT)));
		if (paymentRequestDataDBResponse.getPaymentDate() != null) {
			scheduleDate = String.valueOf(paymentRequestDataDBResponse.getPaymentDate());
			collectionIntentRequest.setPromiseDate(scheduleDate.substring(0, 10));
		}
		collectionIntentRequest.setCallType(PaymentConstants.INBOUND);
		collectionIntentRequest.setAttempted(PaymentConstants.PRIMARY);
		collectionIntentRequest.setContacted(((inputParams.get(PaymentConstants.PAYMENT_MODE) != null
				&& PaymentModeEnum.THIRDPARTY_PAYMENT.name().equalsIgnoreCase((String) inputParams.get(PaymentConstants.PAYMENT_MODE))) ? PaymentConstants.THIRD_PARTY
						: PaymentConstants.PRIMARY));
		collectionIntentRequest.setContactedPersonName((inputParams.get(PaymentConstants.PAYMENT_MODE) != null
				&& PaymentModeEnum.THIRDPARTY_PAYMENT.name().equalsIgnoreCase((String) inputParams.get(PaymentConstants.PAYMENT_MODE)))
						? (String) inputParams.get(PaymentConstants.FULL_NAME)
						: null);
		return collectionIntentRequest;
	}

	public static UpdateAccountBalanceRequest getCreditCardBalanceRequest(PaymentServiceRequest paymentServiceRequest, PaymentDataTransferRequest paymentRequestdto) {
		UpdateAccountBalanceRequest updateAccountBalanceRequest = new UpdateAccountBalanceRequest();
		updateAccountBalanceRequest.setChannel(ChannelTypeRequest.fromValue(paymentServiceRequest.getChannel().toUpperCase()));
		updateAccountBalanceRequest.setTransactionMedium(TransactionMediumRequest.fromValue(paymentServiceRequest.getPaymentType().toUpperCase()));
		updateAccountBalanceRequest.setTransactionType(UpdateAccountBalanceRequest.TransactionTypeEnum.fromValue(PaymentConstants.PAYMENT));
		BigDecimal feeAmount = PaymentMapper.convertObjectToBigDecimal(paymentServiceRequest.getFeeAmount());
		BigDecimal finalAmount = paymentServiceRequest.getPaymentAmount().add(feeAmount).setScale(2, RoundingMode.CEILING);
		updateAccountBalanceRequest.setTransactionAmount(finalAmount);
		String formattedTransactionDate = PaymentUtil.getFormattedDateToStr(PaymentConstants.DATEFORMAT, paymentServiceRequest.getScheduledDate(),
				PaymentConstants.DATETIMEFORMAT_RESPONSE);
		updateAccountBalanceRequest.setTransactionDate(formattedTransactionDate);
		updateAccountBalanceRequest.setRiskLevel(paymentRequestdto.getRiskLevel());
		return updateAccountBalanceRequest;
	}

	public static PaymentDataTransferRequest mapPaymentDtoRequest(PaymentServiceRequest request, PaymentRequestDataDBResponse paymentRequestDataDBResponse, String correlationId)
			throws ParseException {
		PaymentDataTransferRequest dtoRequest = new PaymentDataTransferRequest();
		dtoRequest.setCustomerId(request.getCustomerId());
		dtoRequest.setStatus(PaymentStatus.INITIATED.name());
		dtoRequest.setCorrelationId(correlationId);
		dtoRequest.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId());
		if (paymentRequestDataDBResponse.getPaymentRequestId() != null)
			dtoRequest.setCachedPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId().toString());
		dtoRequest.setExternalAccountId(request.getExternalAccountId());
		dtoRequest.setCreditAccountId(request.getCreditAccountId());
		dtoRequest.setScheduledDate(request.getScheduledDate());
		dtoRequest.setAgentId(request.getAgentId());
		dtoRequest.setChannel(request.getChannel());
		dtoRequest.setFeeAmount(request.getFeeAmount());
		dtoRequest.setNotes(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getNotes() : null);
		dtoRequest.setAddress(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getAddress() : null);
		dtoRequest.setFullName(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getFullName() : null);
		dtoRequest.setThirdPartyCustomerId(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getThirdPartyCustomerId() : null);
		dtoRequest.setPaymentType(request.getPaymentType());
		dtoRequest.setPaymentAmount(request.getPaymentAmount());
		dtoRequest.setPaymentPurpose(
				request.getPaymentMetadata() != null ? (request.getPaymentMetadata().getPaymentPurpose() != null ? request.getPaymentMetadata().getPaymentPurpose().name() : null)
						: null);
		dtoRequest.setPaymentMode(request.getPaymentMode() != null ? request.getPaymentMode().name() : null);
		dtoRequest.setDebitExpiration(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getDebitExpiration() : null);
		dtoRequest.setDebitLast4(request.getPaymentMetadata() != null ? request.getPaymentMetadata().getDebitLast4() : null);

		updateDtoRequestForPaymentRequestData(paymentRequestDataDBResponse, dtoRequest);
		return dtoRequest;
	}

	private static void updateDtoRequestForPaymentRequestData(PaymentRequestDataDBResponse paymentRequestDataDBResponse, PaymentDataTransferRequest dtoRequest)
			throws ParseException {

		JSONParser parser = new JSONParser();
		JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());
		dtoRequest.setCreatedBy(paymentRequestDataDBResponse.getCreatedBy());
		dtoRequest.setCreatedTimestamp(paymentRequestDataDBResponse.getCreatedTimestamp());
		dtoRequest.setUpdatedBy(paymentRequestDataDBResponse.getUpdatedBy());
		dtoRequest.setUpdatedTimestamp(paymentRequestDataDBResponse.getUpdatedTimestamp());
		dtoRequest.setFdrStatus((String) paymentRequestData.get(PaymentConstants.FDR_STATUS));
		if (paymentRequestData.get(PaymentConstants.FEE_WAIVER_AMOUNT) != null)
			dtoRequest.setFeeWaiverAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.FEE_WAIVER_AMOUNT)));
		dtoRequest.setPaymentConfirmation((String) paymentRequestData.get(PaymentConstants.PAYMENT_CONFIRMATION));
		dtoRequest.setCollectionIntentId((String) paymentRequestData.get(PaymentConstants.COLLECTION_INTENT_ID));
		JSONArray paymentMetadata = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
		for (int i = 0; i < paymentMetadata.size(); i++) {
			JSONObject processedJson = (JSONObject) paymentMetadata.get(i);
			String paymentStatus = (String) processedJson.get(PaymentConstants.PAYMENT_EVENT);
			if (PaymentStatus.PROCESSED.getValue().equalsIgnoreCase(paymentStatus)) {
				updateDtoRequestFromPaymentMetadata(dtoRequest, processedJson);
			}
		}
	}

	private static void updateDtoRequestFromPaymentMetadata(PaymentDataTransferRequest dtoRequest, JSONObject processedJson) {
		dtoRequest.setInvolvementId((String) processedJson.get(PaymentConstants.INVOLVEMENT_ID));
		dtoRequest.setCardType((String) processedJson.get(PaymentConstants.CARD_TYPE));
		dtoRequest.setCreditAccountLast4((String) processedJson.get(PaymentConstants.CREDIT_ACCOUNT_LAST4));
		dtoRequest.setPlasticDesignCode((String) processedJson.get(PaymentConstants.PLASTIC_DESIGN_CODE));
		dtoRequest.setProductKey((String) processedJson.get(PaymentConstants.PRODUCT_KEY));
		if (processedJson.get(PaymentConstants.FEE_WAIVED) != null)
			dtoRequest.setFeeWaived(Boolean.parseBoolean((String) processedJson.get(PaymentConstants.FEE_WAIVED)));
		if (processedJson.get(PaymentConstants.FLOAT_DAYS) != null)
			dtoRequest.setFloatDays(((Long) processedJson.get(PaymentConstants.FLOAT_DAYS)).intValue());
		dtoRequest.setRiskLevel((String) processedJson.get(PaymentConstants.RISK_LEVEL));
		dtoRequest.setRtpStatus((String) processedJson.get(PaymentConstants.RTP_STATUS));
		dtoRequest.setRiskyPayment((String) processedJson.get(PaymentConstants.RISKY_PAYMENT));
		dtoRequest.setStatementDate((String) processedJson.get(PaymentConstants.STATEMENT_DATE));
		dtoRequest.setPaymentEvent((String) processedJson.get(PaymentConstants.PAYMENT_EVENT));
		if (processedJson.get(PaymentConstants.DAYS_DELINQUENT) != null)
			dtoRequest.setDaysDelinquent(Integer.parseInt((String) processedJson.get(PaymentConstants.DAYS_DELINQUENT)));
		if (processedJson.get(PaymentConstants.DELINQUENT_AMOUNT) != null)
			dtoRequest.setDelinquentAmount(new BigDecimal((String) processedJson.get(PaymentConstants.DELINQUENT_AMOUNT)));
		dtoRequest.setExternalBankName((String) processedJson.get(PaymentConstants.EXTERNAL_BANK_NAME));
		if (processedJson.get(PaymentConstants.MINIMUM_PAYMENT_DUE) != null)
			dtoRequest.setMinimumPaymentDue(new BigDecimal((String) processedJson.get(PaymentConstants.MINIMUM_PAYMENT_DUE)));
		if (processedJson.get(PaymentConstants.EXPRESS_PAY_DECISION) != null)
			dtoRequest.setExpressPayDecesion(Boolean.parseBoolean(String.valueOf(processedJson.get(PaymentConstants.EXPRESS_PAY_DECISION))));
		dtoRequest.setRtpConfirmationCode((String) processedJson.get(PaymentConstants.RTP_CONFIRMATION_CODE));
		dtoRequest.setExternalAccountType((String) processedJson.get(PaymentConstants.EXT_ACCNT_TYPE));
		dtoRequest.setExternalAccountLast4((String) processedJson.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
		dtoRequest.setThirdPartyCustomerId((String) processedJson.get(PaymentConstants.THIRD_PARTY_CUSTOMER_ID));
		dtoRequest.setCommunicationRequestId((String) processedJson.get(PaymentConstants.COMMUNICATION_REQUEST_ID));
		dtoRequest.setCreditAccountSystemNumber((String) processedJson.get(PaymentConstants.CREDIT_ACCOUNT_SYSTEM_NUMBER));
	}
}