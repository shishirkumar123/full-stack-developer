package com.creditone.ucrm.payments.dao;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.model.PaymentRequestEntity;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.achtransactionservice.model.AchVoidPaymentRequest;
import com.ucrm.swagger.debittransactionservice.model.DebitVoidPaymentsRequest;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentResponse;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class PaymentCancellationMapper {

    public static DebitVoidPaymentsRequest mapDebitVoidPaymentsRequest(UUID paymentRequestId, String paymentStatus) {
        DebitVoidPaymentsRequest debitVoidPaymentsRequest = new DebitVoidPaymentsRequest();
        debitVoidPaymentsRequest.setPaymentRequestId(paymentRequestId.toString());
        debitVoidPaymentsRequest.setPaymentStatus(paymentStatus);

        return debitVoidPaymentsRequest;
    }

    public static AchVoidPaymentRequest mapACHVoidPaymentsRequest(UUID paymentRequestId, String paymentStatus) {
        AchVoidPaymentRequest achVoidPaymentRequest = new AchVoidPaymentRequest();
        achVoidPaymentRequest.setPaymentRequestId(paymentRequestId.toString());
        achVoidPaymentRequest.setPaymentStatus(paymentStatus);

        return achVoidPaymentRequest;
    }

    public static CancelACHPaymentResponse mapCancelACHPaymentResponse(String paymentRequestId, String message,
                                                                       String updatedTimeStamp) {
        CancelACHPaymentResponse res = new CancelACHPaymentResponse();
        res.setPaymentRequestId(paymentRequestId);
        res.setMessage(message);
        res.setTimeStamp(updatedTimeStamp);

        return res;
    }

    public static boolean isAutoPayAlreadyCancelled(Json autoPayData, String cancelCurrentMonth, String correlationId) {
        JSONParser parser = new JSONParser();
        JSONObject dataParams = null;
        boolean isAutoPayCancelled = false;
        if (autoPayData != null) {
            try {
                dataParams = (JSONObject) parser.parse(autoPayData.asString());
            }
            catch (ParseException e) {
                String error = PaymentErrors.JSON_ERROR_FROM_AUTO_PAY_DATA + e.toString();
                log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
                PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
                paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
                throw paymentDataException;
            }
            if (dataParams.get(PaymentConstants.AUTO_PAY_OFF) != null) {
                JSONArray existingAutoPayOff = (JSONArray) dataParams.get(PaymentConstants.AUTO_PAY_OFF);
                JSONObject thisConfig = null;

                for (int i = 0; i < existingAutoPayOff.size(); i++) {
                    thisConfig = (JSONObject) existingAutoPayOff.get(i);
                    if(((String)thisConfig.get(PaymentConstants.CANCELLATION_MONTH)).equals(cancelCurrentMonth)) {
                        isAutoPayCancelled = true;
                        break;
                    }
                }
            }
        }
        return isAutoPayCancelled;
    }

    public static PaymentRequestEntity mapFromPaymentRequestDTOToPaymentRequestEntity(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
        PaymentRequestEntity paymentRequestEntity = new PaymentRequestEntity();
        paymentRequestEntity.setPaymentRequestId(paymentRequestDataDBResponse.getPaymentRequestId());
        paymentRequestEntity.setIndividualUniqueIdentifierKey(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey());
        paymentRequestEntity.setPaymentDate(paymentRequestDataDBResponse.getPaymentDate());
        paymentRequestEntity.setRequestStatus(paymentRequestDataDBResponse.getRequestStatus());
        paymentRequestEntity.setAccountKey(paymentRequestDataDBResponse.getAccountKey());
        paymentRequestEntity.setExternalAccountKey(paymentRequestDataDBResponse.getExternalAccountKey());
        paymentRequestEntity.setPaymentType(paymentRequestDataDBResponse.getPaymentType());
        paymentRequestEntity.setPartnerName(paymentRequestDataDBResponse.getPartnerName());
        paymentRequestEntity.setPaymentRequestData(paymentRequestDataDBResponse.getPaymentRequestData());
        paymentRequestEntity.setCreatedTimestamp(paymentRequestDataDBResponse.getCreatedTimestamp());
        paymentRequestEntity.setCreatedBy(paymentRequestDataDBResponse.getCreatedBy());
        paymentRequestEntity.setUpdatedTimestamp(paymentRequestDataDBResponse.getUpdatedTimestamp());
        paymentRequestEntity.setUpdatedBy(paymentRequestDataDBResponse.getUpdatedBy());
        paymentRequestEntity.setNew(paymentRequestDataDBResponse.isNew());
        return paymentRequestEntity;
    }

    public static PaymentCommunicationDetailsRequest getCancelCommunicationDetailsRequest(Map<String, Object> parameters) {
        BigDecimal paymentAmount =PaymentMapper.convertObjectToBigDecimal((Object) parameters.get(PaymentConstants.PAYMENT_AMOUNT)) ;
        String customerId = (String) parameters.get(PaymentConstants.CUSTOMER_ID);
        String plasticCode = (String) parameters.get(PaymentConstants.PLASTICCODE);
        String paymentDate = (String) parameters.get(PaymentConstants.PAYMENTDATE);

        PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest = new PaymentCommunicationDetailsRequest();
        paymentCommunicationDetailsRequest.setFirstName(parameters.get("firstName")!=null?(String)parameters.get("firstName"):null);
        paymentCommunicationDetailsRequest.setLastName(parameters.get("lastName")!=null?(String)parameters.get("lastName"):null);
        paymentCommunicationDetailsRequest.setCardType(parameters.get("cardType")!=null?(String)parameters.get("cardType"):null);
        paymentCommunicationDetailsRequest.setCardLast4(parameters.get("cardLast4")!=null?(String)parameters.get("cardLast4"):null);
        paymentCommunicationDetailsRequest.setPlasticCode(plasticCode);
        paymentCommunicationDetailsRequest.setPaymentAmount(paymentAmount);
        paymentCommunicationDetailsRequest.setCustomerId(UUID.fromString(customerId));

        String dayOfWeek = PaymentUtil.getCurrentDayOfWeek();
        paymentCommunicationDetailsRequest.setDayOfWeek(dayOfWeek);

        paymentCommunicationDetailsRequest.setPaymentDate(PaymentUtil.getZonedDateTime(paymentDate));

        LocalDateTime localDateTime = LocalDateTime.now();
        ZonedDateTime zonedDateTime = PaymentUtil.toZonedDateTime(localDateTime);
        String returnDate = PaymentUtil.formatDate(zonedDateTime, PaymentConstants.DATEFORMAT_MM_DD_UUUU);
        paymentCommunicationDetailsRequest.setReturnDate(returnDate);
        paymentCommunicationDetailsRequest.setInvolvementId((String)parameters.get(PaymentConstants.INVOLVEMENT_ID));
        return paymentCommunicationDetailsRequest;
    }
}
