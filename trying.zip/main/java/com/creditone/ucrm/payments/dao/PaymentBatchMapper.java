package com.creditone.ucrm.payments.dao;

import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.dto.*;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.model.PaymentBatchActivityEntity;
import com.creditone.ucrm.payments.model.PaymentBatchEntity;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentservice.model.BatchProcessRequest;
import com.ucrm.swagger.paymentservice.model.PaymentMetadata;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import io.r2dbc.postgresql.codec.Json;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
public class PaymentBatchMapper {

    public static PaymentBatchEntity mapToPaymentBatchEntity(Map<String, Object> parameters) {
        PaymentBatchEntity paymentBatchEntity = new PaymentBatchEntity();
        paymentBatchEntity.setBatchId((UUID) parameters.get(PaymentConstants.BATCH_ID));
        paymentBatchEntity.setBatchType((String) parameters.get(PaymentConstants.BATCH_TYPE));
        paymentBatchEntity.setStatus((String) parameters.get(PaymentConstants.STATUS.toString()));
        paymentBatchEntity.setProcessedCount((Integer) parameters.get(PaymentConstants.PROCESS_COUNT));
        paymentBatchEntity.setErrorCount((Integer) parameters.get(PaymentConstants.ERROR_COUNT));
        paymentBatchEntity.setStartTimestamp((ZonedDateTime) parameters.get(PaymentConstants.START_TIME));
        paymentBatchEntity.setEndTimestamp((ZonedDateTime) parameters.get(PaymentConstants.END_TIME));
        paymentBatchEntity.setCreatedBy(PaymentConstants.SYSTEM);
        paymentBatchEntity.setCreatedTimestamp(ZonedDateTime.now());
        paymentBatchEntity.setUpdatedBy(PaymentConstants.SYSTEM);
        paymentBatchEntity.setUpdatedTimestamp(ZonedDateTime.now());
        if (parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST) != null && !((List<String>) parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST)).isEmpty()) {
            Json parameter = getJsonParameterInString((List<String>) parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST));
            paymentBatchEntity.setParameter(parameter);
        }

        return paymentBatchEntity;
    }

    private static Json getJsonParameterInString(List<String> processedPaymentIds) {
        JSONArray paymentMetadata = new JSONArray();
        for(String paymentId:processedPaymentIds){
            JSONObject noteJSONObject = new JSONObject();
            noteJSONObject.put("paymentId: ", paymentId.toString());
            paymentMetadata.add(noteJSONObject);
        }
        return Json.of(String.valueOf(paymentMetadata));
    }

    public static Mono<PaymentBatchEntity> mapUpdatedPaymentBatchEntity(PaymentBatchEntity existingPaymentBatchEntity, Map<String, Object> parameters) {
        existingPaymentBatchEntity.setBatchId((UUID) parameters.get(PaymentConstants.BATCH_ID));
        existingPaymentBatchEntity.setBatchType((String) parameters.get(PaymentConstants.BATCH_TYPE));
        existingPaymentBatchEntity.setStatus((String) parameters.get(PaymentConstants.STATUS.toString()));
        existingPaymentBatchEntity.setProcessedCount((Integer) parameters.get(PaymentConstants.PROCESS_COUNT)!=null? (Integer) parameters.get(PaymentConstants.PROCESS_COUNT):0);
        existingPaymentBatchEntity.setErrorCount((Integer) parameters.get(PaymentConstants.ERROR_COUNT)!=null? (Integer) parameters.get(PaymentConstants.ERROR_COUNT) :0);
        existingPaymentBatchEntity.setStartTimestamp((ZonedDateTime) parameters.get(PaymentConstants.START_TIME));
        existingPaymentBatchEntity.setEndTimestamp((ZonedDateTime) parameters.get(PaymentConstants.END_TIME));
        existingPaymentBatchEntity.setCreatedBy(PaymentConstants.SYSTEM);
        existingPaymentBatchEntity.setCreatedTimestamp(ZonedDateTime.now());
        existingPaymentBatchEntity.setUpdatedBy(PaymentConstants.SYSTEM);
        existingPaymentBatchEntity.setUpdatedTimestamp(ZonedDateTime.now());
        existingPaymentBatchEntity.setStatus(getBatchProcessingStatus(existingPaymentBatchEntity.getProcessedCount(), existingPaymentBatchEntity.getErrorCount()));

        if (parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST) != null&& !((List<String>) parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST)).isEmpty()) {
            Json parameter = getJsonParameterInString((List<String>) parameters.get(PaymentConstants.ERROR_PAYMENTS_LIST));
            existingPaymentBatchEntity.setParameter(parameter);
        }
        existingPaymentBatchEntity.setNew(false);
        return Mono.just(existingPaymentBatchEntity);
    }
    public static PaymentBatchDBResponse fromPaymentBatchEntityToPaymentBatchDBResponse(PaymentBatchEntity paymentBatchEntityUpdated) {
        PaymentBatchDBResponse paymentBatchDBResponse = new PaymentBatchDBResponse();
        paymentBatchDBResponse.setBatchId(paymentBatchEntityUpdated.getBatchId());
        paymentBatchDBResponse.setBatchType(paymentBatchEntityUpdated.getBatchType());
        paymentBatchDBResponse.setStatus(paymentBatchEntityUpdated.getStatus());
        paymentBatchDBResponse.setProcessedCount(paymentBatchEntityUpdated.getProcessedCount());
        paymentBatchDBResponse.setErrorCount(paymentBatchEntityUpdated.getErrorCount());
        paymentBatchDBResponse.setStartTimestamp(paymentBatchEntityUpdated.getStartTimestamp());
        paymentBatchDBResponse.setEndTimestamp(paymentBatchEntityUpdated.getEndTimestamp());
        paymentBatchDBResponse.setCreatedBy(paymentBatchEntityUpdated.getCreatedBy());
        paymentBatchDBResponse.setCreatedTimestamp(paymentBatchEntityUpdated.getCreatedTimestamp());
        paymentBatchDBResponse.setUpdatedBy(paymentBatchEntityUpdated.getUpdatedBy());
        paymentBatchDBResponse.setUpdatedTimestamp(paymentBatchEntityUpdated.getUpdatedTimestamp());
        paymentBatchDBResponse.setParameter(paymentBatchEntityUpdated.getParameter());
        return paymentBatchDBResponse;
    }

    public static Map<String, Object> getMapForBatchProcess(List<PaymentRequestDataDBResponse> paymentList, Map<String, Object> result, ZonedDateTime startTime) {
        Map<String, Object> parameters = new HashMap<String, Object>();
        int processCount = (int) result.get(PaymentConstants.PROCESS_COUNT);
        int errorCount = (int) result.get(PaymentConstants.ERROR_COUNT);
        BatchProcessRequest batchProcessRequest = (BatchProcessRequest) result.get(PaymentConstants.BATCH_PROCESS_REQUEST);
        ZonedDateTime endTime = (ZonedDateTime) result.get(PaymentConstants.END_TIME);
        parameters.put(PaymentConstants.BATCH_ID,result.get(PaymentConstants.BATCH_ID));
        parameters.put(PaymentConstants.START_TIME, startTime);
        parameters.put(PaymentConstants.BATCH_PROCESS_REQUEST, batchProcessRequest);
        parameters.put(PaymentConstants.BATCH_TYPE, result.get(PaymentConstants.BATCH_TYPE));
        parameters.put(PaymentConstants.PROCESS_COUNT, processCount);
        parameters.put(PaymentConstants.ERROR_COUNT, errorCount);
        parameters.put(PaymentConstants.STATUS, getBatchProcessingStatus(processCount, errorCount));
        parameters.put(PaymentConstants.END_TIME, endTime);
        parameters.put(PaymentConstants.PAYMENT_REQUEST_ID, paymentList.stream()
                .map(PaymentRequestDataDBResponse::getPaymentRequestId)
                .collect(Collectors.toList()));
        return parameters;
    }

    public static PaymentServiceRequest fromPaymentRequestDataDBResponseToPaymentServiceRequest(PaymentRequestDataDBResponse paymentRequestDataDBResponse) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());

        PaymentServiceRequest debitPaymentRequest = getPaymentServiceRequest(paymentRequestDataDBResponse);

        setPaymentServiceRequestOriginalParameters(paymentRequestData, debitPaymentRequest, paymentRequestDataDBResponse);
        setPaymentServiceRequestUpdatedParameters(paymentRequestData, debitPaymentRequest);

        return debitPaymentRequest;
    }
    public static Map<String,Object> formPaymentRequestDataFromDBResponse(PaymentRequestDataDBResponse paymentRequestDataDBResponse,Map<String,Object> resultMap) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject paymentRequestData = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());

        PaymentServiceRequest debitPaymentRequest = getPaymentServiceRequest(paymentRequestDataDBResponse);
      	resultMap.put(PaymentConstants.INVOLVEMENT_ID, (String) paymentRequestData.get(PaymentConstants.INVOLVEMENT_ID));
        setCommunicationIntentId(paymentRequestData,resultMap);
        setPaymentServiceRequestOriginalParameters(paymentRequestData, debitPaymentRequest, paymentRequestDataDBResponse);
        setPaymentServiceRequestUpdatedParameters(paymentRequestData, debitPaymentRequest);
        resultMap.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, debitPaymentRequest);
        return resultMap;
    }

    private static void setCommunicationIntentId(JSONObject paymentRequestData, Map<String, Object> resultMap) {
    	resultMap.put(PaymentConstants.COLLECTION_INTENT_ID, (String) paymentRequestData.get(PaymentConstants.COLLECTION_INTENT_ID));
	}

	private static PaymentServiceRequest getPaymentServiceRequest(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
        PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
        paymentServiceRequest.setCustomerId(paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey().toString());
        paymentServiceRequest.setCreditAccountId(paymentRequestDataDBResponse.getAccountKey().toString());
        paymentServiceRequest.setExternalAccountId(paymentRequestDataDBResponse.getExternalAccountKey().toString());
        paymentServiceRequest.setPaymentType(paymentRequestDataDBResponse.getPaymentType());
        paymentServiceRequest.setAgentId(paymentRequestDataDBResponse.getCreatedBy());

        return paymentServiceRequest;
    }

    private static void setPaymentServiceRequestOriginalParameters(JSONObject paymentRequestData, PaymentServiceRequest debitPaymentRequest, PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
    	String channel = (String) paymentRequestData.get(PaymentConstants.CHANNEL);
        String dateFormatted = paymentRequestDataDBResponse.getPaymentDate().format(DateTimeFormatter.ofPattern(PaymentConstants.DATETIMEFORMAT_RESPONSE));
        debitPaymentRequest.setFeeAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.FEE_AMOUNT)));
        debitPaymentRequest.setPaymentAmount(PaymentMapper.convertObjectToBigDecimal((Object) paymentRequestData.get(PaymentConstants.PAYMENT_AMOUNT)));
        debitPaymentRequest.setScheduledDate(dateFormatted);
        debitPaymentRequest.setChannel(channel);
    }

    /**
     * Jira Link: https://creditonebank.atlassian.net/browse/SSPP-7160 This service
     * method to enhance the current functionality of the payment service to allow
     * third-party payments
     *
     * @param paymentRequestData
     * @param debitPaymentRequest
     * @return void
     */
	private static void setPaymentServiceRequestUpdatedParameters(JSONObject paymentRequestData, PaymentServiceRequest debitPaymentRequest) {
		setUpdatedParametersPaymentMode(paymentRequestData, debitPaymentRequest);

		JSONObject paymentMetadataJSONObject = getPaymentMetadata(paymentRequestData);

		PaymentMetadata paymentMetadata = new PaymentMetadata();

		setUpdatedParametersPaymentMetadataMandatory(paymentMetadataJSONObject, paymentMetadata);
        String paymentPurpose = (String) paymentRequestData.get(PaymentConstants.PAYMENT_PURPOSE);

        PaymentMetadata.PaymentPurposeEnum paymentPurposeEnum = null;
        for (PaymentMetadata.PaymentPurposeEnum paymentPurposeEnum1 : PaymentMetadata.PaymentPurposeEnum.values()) {
            if (paymentPurposeEnum1.name().equalsIgnoreCase(paymentPurpose)) {
                paymentPurposeEnum = paymentPurposeEnum1;
            }
        }
        paymentMetadata.setPaymentPurpose(paymentPurposeEnum);

		if (paymentMetadataJSONObject.get(PaymentConstants.ADDRESS) != null) {
			paymentMetadata.setAddress((String) paymentMetadataJSONObject.get(PaymentConstants.ADDRESS));
		}

		if (paymentMetadataJSONObject.get(PaymentConstants.DEBIT_EXPIRATION) != null) {
			paymentMetadata.setDebitExpiration((String) paymentMetadataJSONObject.get(PaymentConstants.DEBIT_EXPIRATION));
		}

		if (paymentMetadataJSONObject.get(PaymentConstants.DEBIT_LAST4) != null) {
			paymentMetadata.setDebitLast4((String) paymentRequestData.get(PaymentConstants.DEBIT_LAST4));
		}

		if (paymentMetadataJSONObject.get(PaymentConstants.FULL_NAME) != null) {
			paymentMetadata.setFullName((String) paymentMetadataJSONObject.get(PaymentConstants.FULL_NAME));
		}

		debitPaymentRequest.setPaymentMetadata(paymentMetadata);
	}

    private static void setUpdatedParametersPaymentMode(JSONObject paymentRequestData, PaymentServiceRequest debitPaymentRequest) {
        String paymentMode = (String) paymentRequestData.get(PaymentConstants.PAYMENT_MODE);
        PaymentServiceRequest.PaymentModeEnum paymentModeEnum = null;
        for (PaymentServiceRequest.PaymentModeEnum paymentModeEnum1 : PaymentServiceRequest.PaymentModeEnum.values()) {
            if (paymentModeEnum1.name().equalsIgnoreCase(paymentMode)) {
                paymentModeEnum = paymentModeEnum1;
            }
        }
        debitPaymentRequest.setPaymentMode(paymentModeEnum);
    }

    private static JSONObject getPaymentMetadata(JSONObject paymentRequestData) {
        JSONArray jsonArray = (JSONArray) paymentRequestData.get(PaymentConstants.PAYMENT_METADATA);
        JSONObject jSONObjectPaymentMetadata = (JSONObject) jsonArray.get(0);

        return jSONObjectPaymentMetadata;
    }

    private static void setUpdatedParametersPaymentMetadataMandatory(JSONObject paymentMetadataJSONObject, PaymentMetadata paymentMetadata) {
        String notes = (String) paymentMetadataJSONObject.get(PaymentConstants.NOTES);
        paymentMetadata.setNotes(notes);
    }

    public static Map<String, Object> fillParametersForProcessNotifyAutopayPayment(AutoPayDBResponse autoPayDBResponse, ZonedDateTime statementDate, BigDecimal paymentAmountValidated, String correlationId) throws ParseException{
        JSONParser parser = new JSONParser();
        JSONObject autoPayDBData = (JSONObject) parser.parse(autoPayDBResponse.getAutoPayData().asString());

        Map<String, Object> mapParametersSaveNotifiedPayment = new HashMap<String, Object>();
        PaymentServiceRequest paymentServiceRequest = new PaymentServiceRequest();
        paymentServiceRequest.setCustomerId(autoPayDBResponse.getCustomerId().toString());
        paymentServiceRequest.setExternalAccountId((String)autoPayDBData.get(PaymentConstants.EXTERNAL_ACCOUNT_ID));
        paymentServiceRequest.setCreditAccountId(autoPayDBResponse.getCreditAccountId().toString());
        paymentServiceRequest.setPaymentType(PaymentType.ACH.name());
        paymentServiceRequest.setChannel((String)autoPayDBData.get(PaymentConstants.CHANNEL));
        paymentServiceRequest.setAgentId((String)autoPayDBData.get(PaymentConstants.AGENT_ID));
        paymentServiceRequest.setPaymentAmount(paymentAmountValidated);
        paymentServiceRequest.setPaymentMode(PaymentServiceRequest.PaymentModeEnum.AUTO_PAYMENT);
        paymentServiceRequest.setScheduledDate(PaymentUtil.formatDate(statementDate, PaymentConstants.DATETIMEFORMAT_RESPONSE));
        paymentServiceRequest.setFeeAmount(BigDecimal.ZERO);
        PaymentMetadata paymentMetadata = new PaymentMetadata();
        paymentMetadata.setNotes("Auto Payment");
        paymentMetadata.setPaymentPurpose(PaymentMetadata.PaymentPurposeEnum.valueOf((String)autoPayDBData.get(PaymentConstants.PAYMENT_PURPOSE)));
        paymentServiceRequest.setPaymentMetadata(paymentMetadata);

        mapParametersSaveNotifiedPayment.put(PaymentConstants.PAYMENT_SERVICE_REQUEST, paymentServiceRequest);
        mapParametersSaveNotifiedPayment.put(PaymentConstants.STATUS, PaymentStatus.AUTOPAY_NOTIFIED.name());
        mapParametersSaveNotifiedPayment.put(PaymentConstants.EXTERNAL_ACCOUNT_LAST4, (String)autoPayDBData.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4));
        mapParametersSaveNotifiedPayment.put(PaymentConstants.CREDIT_ACCOUNT_LAST4, (String)autoPayDBData.get(PaymentConstants.CREDIT_ACCOUNT_LAST4));
        mapParametersSaveNotifiedPayment.put(PaymentConstants.EXTERNAL_BANK_NAME, (String)autoPayDBData.get(PaymentConstants.EXTERNAL_BANK_NAME));
        mapParametersSaveNotifiedPayment.put(PaymentConstants.CORRELATION_ID, correlationId);

        return mapParametersSaveNotifiedPayment;
    }

    public static PaymentCommunicationRequest mapPaymentCommunicationRequestForNotifyAutoPay(UUID paymentRequestId) {
        PaymentCommunicationRequest paymentCommunicationRequest = new PaymentCommunicationRequest();
        paymentCommunicationRequest.setCommunicationIntent(PaymentCommunicationIntent.NOTIFY_AUTO_PAY);
        paymentCommunicationRequest.setCommunicationType(PaymentConstants.EMAIL);
        paymentCommunicationRequest.setPaymentRequestId(paymentRequestId);

        return paymentCommunicationRequest;
    }

    public static String getBatchProcessingStatus(int processedCount, int errorCount) {
        String status = null;

        if(processedCount >= 0 && errorCount == 0) {
            status = BatchStatusUpdate.COMPLETED.name();
        }
        else if(processedCount == 0 && errorCount > 0) {
            status = BatchStatusUpdate.ERROR.name();
        }
        else if(processedCount > 0 && errorCount > 0) {
            status = BatchStatusUpdate.PARTIALLY_COMPLETED.name() ;
        }

        return status;
    }

    public static JSONArray getJSONObjectForMappingFromParameterFromBatchResponse(PaymentBatchDBResponse paymentBatchDBResponse, String correlationId) {
        JSONParser parser = new JSONParser();
        JSONArray dataParams = new JSONArray();
        try {
            if (paymentBatchDBResponse.getParameter() != null) {
                dataParams = (JSONArray) parser.parse(paymentBatchDBResponse.getParameter().asString());
            }
            else {
                PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(PaymentErrors.ERROR_BATCH_PROCESS_ID_INVALID);
                paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
                throw paymentDataNotFoundException;
            }
        }
        catch(ParseException e) {
            log.error(PaymentConstants.LOG_PREFIX + "Error Parsing Json: " + e.toString(), correlationId);
            PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
            paymentDataException.setHttpStatusCode(HttpStatus.NOT_FOUND);
            throw paymentDataException;
        }

        return dataParams;
    }

    public static PaymentBatchActivityResponse mapFromPaymentBatchActivityEntityToPaymentBatchActivityResponse(PaymentBatchActivityEntity paymentBatchActivityEntity) {
        PaymentBatchActivityResponse paymentBatchActivityResponse = new PaymentBatchActivityResponse();
        paymentBatchActivityResponse.setPaymentBatchId(paymentBatchActivityEntity.getPaymentBatchId());
        paymentBatchActivityResponse.setPaymentRequestId(paymentBatchActivityEntity.getPaymentRequestId());
        paymentBatchActivityResponse.setPaymentBatchStatus(paymentBatchActivityEntity.getPaymentBatchStatus());
        paymentBatchActivityResponse.setPaymentRequestData(paymentBatchActivityEntity.getPaymentRequestData());
        paymentBatchActivityResponse.setCreatedTimestamp(paymentBatchActivityEntity.getCreatedTimestamp());
        paymentBatchActivityResponse.setCreatedBy(paymentBatchActivityEntity.getCreatedBy());
        paymentBatchActivityResponse.setUpdatedTimestamp(paymentBatchActivityEntity.getUpdatedTimestamp());
        paymentBatchActivityResponse.setUpdatedBy(paymentBatchActivityEntity.getUpdatedBy());
        return paymentBatchActivityResponse;
    }
}