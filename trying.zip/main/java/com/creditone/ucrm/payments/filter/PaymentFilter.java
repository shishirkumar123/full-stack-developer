package com.creditone.ucrm.payments.filter;

import com.creditone.microservice.util.UUIDGenerator;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.util.PaymentUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Component
@Slf4j
public class PaymentFilter implements WebFilter {
    private String appName;
    private static Set<String> uriSubList=new HashSet<String>();
	
    private String healthUri;

    private static final String PROCESSING_TIMEZONE = "US/Pacific";

    public PaymentFilter(@Value(value = "${APP_NAME}") String appName,
                         @Value(value = "${health.uri}") String healthUri) {
        this.appName = appName;
        this.healthUri = healthUri;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    	if (uriSubList.isEmpty()) {
		    uriSubList = new HashSet<String>(Arrays.asList(healthUri.split("\\s*/\\s*")));
		}
    	String apiPath = exchange.getRequest().getPath() != null ? exchange.getRequest().getPath().toString() : null;
        if (Arrays.asList(apiPath.split("\\s*/\\s*")).containsAll(uriSubList)) {
		    return chain.filter(exchange);
		}

        String correlationId = exchange.getRequest().getHeaders() != null && !CollectionUtils
                .isEmpty(exchange.getRequest().getHeaders().get(PaymentConstants.CORRELATION_ID))
                ? exchange.getRequest().getHeaders().get(PaymentConstants.CORRELATION_ID).get(0)
                : null;
        log.info("correlationId: {}", correlationId);

        if (StringUtils.isEmpty(correlationId))
            correlationId = generateUniqueCorrelationId(exchange);

        return chain.filter(exchange).contextWrite(Context.of(PaymentConstants.CORRELATION_ID, correlationId));

    }

    private String generateUniqueCorrelationId(ServerWebExchange exchange) {
        StringBuilder correlationIdBuffer = new StringBuilder();
        String[] pathElements = exchange.getRequest().getPath().toString().split("/");
        correlationIdBuffer.append(appName).append("_").append(pathElements[pathElements.length - 1]).append("_")
                .append(PaymentUtil.formatDate(ZonedDateTime.now(ZoneId.of(PROCESSING_TIMEZONE)),
                        PaymentConstants.DATETIMEFORMAT_RESPONSE));

        return UUIDGenerator.generateType5UUID(correlationIdBuffer.toString()).toString();
    }
}
