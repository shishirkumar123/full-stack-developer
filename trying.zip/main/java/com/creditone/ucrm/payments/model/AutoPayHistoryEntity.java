package com.creditone.ucrm.payments.model;

import io.r2dbc.postgresql.codec.Json;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serial;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@Table("payments.auto_pay_history")
public class AutoPayHistoryEntity implements Serializable, Persistable<UUID> {

	@Serial
	private static final long serialVersionUID = 1L;

    @Id
    @Column("autopay_id")
    private UUID autoPayId;

    @Column("customer_id")
    private UUID customerId;

    @Column("credit_account_id")
    private UUID creditAccountId;

    @Column("autopay_history_data")
    private Json autoPayHistoryData;

    @Column("created_by")
    private String createdBy;

    @Column("created_timestamp")
    private ZonedDateTime createdTimestamp;

    @Column("updated_by")
    private String updatedBy;

    @Column("updated_timestamp")
    private ZonedDateTime updatedTimestamp;

    @Column("intent_code")
    private String intentCode;

    @Column("autopay_enabled")
    private Boolean autoPayEnabled;

    @Transient
    private boolean isNew;
    @Override
    public UUID getId() {
        return autoPayId;
    }
    @Override
    public boolean isNew() { return isNew; }
}
