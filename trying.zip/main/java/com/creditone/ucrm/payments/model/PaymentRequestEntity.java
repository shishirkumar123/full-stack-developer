package com.creditone.ucrm.payments.model;

import io.r2dbc.postgresql.codec.Json;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@Table("payments.payment_request")
public class PaymentRequestEntity implements Serializable, Persistable<UUID> {

	@Serial
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column("payment_request_id")
	private UUID paymentRequestId;
	
	@Column("individual_unique_identifier_key")
	private UUID individualUniqueIdentifierKey;
	
	@Column("payment_date")
	private ZonedDateTime paymentDate;
	
	@Column("request_status")
	private String requestStatus;
	
	@Column("account_key")
	private UUID accountKey;
	
	@Column("external_account_key")
	private UUID externalAccountKey;
	
	@Column("payment_type")
	private String paymentType;
	
	@Column("partner_name")
	private String partnerName;
	
	@Column("payment_request_data")
	private Json paymentRequestData;
	
	@Column("created_timestamp")
	private LocalDateTime createdTimestamp;
	
	@Column("created_by")
	private String createdBy;
	
	@Column("updated_timestamp")
	private LocalDateTime updatedTimestamp;
	
	@Column("updated_by")
	private String updatedBy;
	
	@Transient
	private boolean isNew;

	public PaymentRequestEntity(UUID paymentRequestId) {
		this.setPaymentRequestId(paymentRequestId);
	}

	@Override
	public UUID getId() {
		return paymentRequestId;
	}

	@Override
	public boolean isNew() {
		return isNew;
	}

}