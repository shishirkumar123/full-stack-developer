package com.creditone.ucrm.payments.model;

import io.r2dbc.postgresql.codec.Json;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@Table("payments.payment_batch_activity")
public class PaymentBatchActivityEntity implements Serializable, Persistable<UUID> {

	@Serial
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column("payment_batch_id")
	private UUID paymentBatchId;
	
	@Column("payment_request_id")
	private UUID paymentRequestId;
	
	@Column("payment_batch_status")
	private String paymentBatchStatus;

	@Column("payment_request_data")
	private Json paymentRequestData;
	
	@Column("created_timestamp")
	private LocalDateTime createdTimestamp;
	
	@Column("created_by")
	private String createdBy;
	
	@Column("updated_timestamp")
	private LocalDateTime updatedTimestamp;
	
	@Column("updated_by")
	private String updatedBy;
	
	@Transient
	private boolean isNew;

	public PaymentBatchActivityEntity(UUID paymentBatchId) {
		this.setPaymentBatchId(paymentBatchId);
	}

	@Override
	public UUID getId() {
		return paymentBatchId;
	}

	@Override
	public boolean isNew() {
		return isNew;
	}

}