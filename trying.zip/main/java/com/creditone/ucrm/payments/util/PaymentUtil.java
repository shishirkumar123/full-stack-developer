package com.creditone.ucrm.payments.util;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.r2dbc.postgresql.codec.Json;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.exception.PaymentDataException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PaymentUtil {

	private PaymentUtil() {
	}

	/**
	 * Parses input string to LocalDate
	 * 
	 * @param strDate
	 * @param format
	 * @return LocalDate
	 */
	public static LocalDate parseDate(String strDate, String format) {
		return LocalDate.parse(strDate, DateTimeFormatter.ofPattern(format).withResolverStyle(ResolverStyle.STRICT));
	}

	public static LocalDateTime parseDateTime(String strDateTime, String format) {
		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(format, Locale.US).withResolverStyle(ResolverStyle.STRICT);
		return LocalDateTime.parse(strDateTime, targetFormatter);
	}

	public static ZonedDateTime parseZonedDateTime(String strDateTime, String format) {
		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(format, Locale.US).withResolverStyle(ResolverStyle.STRICT);
		return ZonedDateTime.parse(strDateTime, targetFormatter);
	}

	public static ZonedDateTime toZonedDateTime(LocalDateTime localDateTime) {
		ZonedDateTime zonedTime = localDateTime.atZone(ZoneOffset.UTC);
		return zonedTime;
	}

	public static ZonedDateTime toZonedDateTimePST(ZonedDateTime localDateTime) {
		return localDateTime.withZoneSameInstant(ZoneId.of("America/Los_Angeles"));

	}

	public static ZonedDateTime getZonedDateTime(String date) {
		LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
		return localDate.atStartOfDay().atZone(ZoneOffset.UTC);
	}

	/**
	 * Returns ZonedDateTime to String in specified format
	 * 
	 * @param date
	 * @param format
	 * @return String Date in specified format
	 */
	public static String formatDate(ZonedDateTime date, String format) {
		return date.format(DateTimeFormatter.ofPattern(format));
	}

	public static String formatDate(LocalDate date, String format) {
		return date.format(DateTimeFormatter.ofPattern(format).withResolverStyle(ResolverStyle.STRICT));
	}

	public static String formatDate(LocalDateTime date, String format) {
		return date.format(DateTimeFormatter.ofPattern(format).withResolverStyle(ResolverStyle.STRICT));
	}

	public static ZonedDateTime zoneByIdTimeNow(String paymentZoneId) {
		LocalDateTime localDateTimeNow = LocalDateTime.now();
		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.systemDefault());
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneId.of(paymentZoneId));
		return converted;
	}

	public static ZonedDateTime zoneByIdToUTCTimeNow(String paymentZoneId) {
		ZonedDateTime zonedTime = ZonedDateTime.now(ZoneId.of(paymentZoneId));
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneOffset.UTC);
		return converted;
	}

	public static ZonedDateTime utcNow() {
		LocalDateTime localDateTimeNow = LocalDateTime.now();
		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.systemDefault());
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneOffset.UTC);
		return converted;
	}

	public static Integer getCurrentDayOfMonth(String paymentZoneId) {
		return zoneByIdTimeNow(paymentZoneId).getDayOfMonth();
	}

	public static ZonedDateTime getZonedDateTimeWithOffsetDays(Long offsetDays) {
		return utcNow().plusDays(offsetDays).withHour(0).withMinute(0).withSecond(0).withNano(0);
	}

	/**
	 * Concatenates all error messages to a single String
	 * 
	 * @param errorResponse
	 * @return String
	 */
	public static String mapErrorResponse(String errorResponse, String targetApplication, String correlationId) {
		log.info(PaymentConstants.LOG_PREFIX + ". Error Response: {}, Target Application: {}", correlationId, errorResponse, targetApplication);

		String prefix = "Error connecting to " + targetApplication;
		if (StringUtils.isEmpty(errorResponse)) {
			return prefix;
		}

		JSONObject jsonObject = null;
		JSONParser parser = new JSONParser();
		StringBuffer errorMessages = new StringBuffer();
		boolean errorMapped = false;

		try {
			jsonObject = (JSONObject) parser.parse(errorResponse);

			errorMapped = errorMapped || mapErrorResponsePaymentRules(targetApplication, jsonObject, errorMessages, prefix);
			errorMapped = errorMapped || mapErrorResponseExternalAccountService(targetApplication, jsonObject, errorMessages, prefix);
			errorMapped = errorMapped || mapErrorResponseCommunicationHubApiService(errorResponse, targetApplication, errorMessages, prefix);

			if (!errorMapped) {
				mapErrorResponseOtherServices(jsonObject, errorMessages, prefix);
			}
		} catch (Exception e) {
			log.error(PaymentConstants.LOG_PREFIX + "Failed to parse Json String. Reason: {}", correlationId, e.getMessage(), e);
			errorMessages.append(prefix).append(". Reason: ").append(errorResponse);
		}

		return errorMessages.toString();
	}

	private static boolean mapErrorResponseExternalAccountService(String targetApplication, JSONObject jsonObject, StringBuffer errorMessages, String prefix) {
		if (targetApplication.equalsIgnoreCase(PaymentConstants.EXTERNAL_ACCOUNTS_SERVICE)) {
			List<String> errorList = (List<String>) jsonObject.get("errorMsg");
			for (String errorDescription : errorList) {
				if (errorMessages.length() == 0)
					errorMessages.append(prefix).append(". Reason: ").append(errorDescription);
				else
					errorMessages.append("; ").append(errorDescription);
			}

			return true;
		}

		return false;
	}

	private static boolean mapErrorResponsePaymentRules(String targetApplication, JSONObject jsonObject, StringBuffer errorMessages, String prefix) {
		if (targetApplication.equalsIgnoreCase(PaymentConstants.PAYMENT_RULES_SERVICE)) {
			List<String> errorList = (List<String>) jsonObject.get("errorMsg");
			for (String errorDescription : errorList) {
				if (errorMessages.length() == 0)
					errorMessages.append(prefix).append(". Reason: ").append(errorDescription);
				else
					errorMessages.append("; ").append(errorDescription);
			}

			return true;
		}

		return false;
	}

	private static boolean mapErrorResponseCommunicationHubApiService(String errorResponse, String targetApplication, StringBuffer errorMessages, String prefix) {
		if (targetApplication.equalsIgnoreCase(PaymentConstants.COMMUNICATION_HUB_API_SERVICE)) {
			errorMessages.append(prefix).append(". Reason: ").append(errorResponse);
			return true;
		}

		return false;
	}

	private static void mapErrorResponseOtherServices(JSONObject jsonObject, StringBuffer errorMessages, String prefix) {
		List<JSONObject> errorList = (List<JSONObject>) jsonObject.get("errorMsg");
		for (JSONObject errorDescription : errorList) {
			if (errorMessages.length() == 0)
				errorMessages.append(prefix).append(". Reason: ").append(errorDescription.get("errorDesc"));
			else
				errorMessages.append("; ").append(errorDescription.get("errorDesc"));
		}
	}

	/**
	 * Replaces the default validation message with custom message
	 * 
	 * @param err FieldError
	 * @return String
	 */
	public static String mapCustomError(FieldError err) {
		String result = " " + err.getDefaultMessage();

		if (!StringUtils.isEmpty(err.getDefaultMessage()) && err.getDefaultMessage().contains("must match")) {
			String[] defaultMessage = err.getDefaultMessage().split(" ");
			String regex = defaultMessage[defaultMessage.length - 1].replaceAll("\"", "");

			if (PaymentConstants.UUIDREGEX.equals(regex))
				result = PaymentErrors.VALIDATION_UUID;
			else if (PaymentConstants.UTCTIMESTAMPREGEX.equals(regex))
				result = PaymentErrors.VALIDATION_UTC_DATE_INVALID;
			else if (PaymentConstants.NONBLANKREGEX.equals(regex))
				result = PaymentErrors.VALIDATION_MISSING;
		}

		return result;
	}

	public static String getCustomizedMapping(String result) {
		if(result.contains("is not a valid input for paymentMode")) {
			result = "is not a valid input for paymentMode";
		}
		if(result.contains("is not a valid input for paymentPurpose")) {
			result = "is not a valid input for paymentPurpose";
		}
		if(result.contains("is not a valid input for SortOrder")) {
			result = "is not a valid input for SortOrder";
		}
		if(result.contains("is not a valid input for SortField")) {
			result = "is not a valid input for SortField";
		}
		if(result.contains("is not a valid input for batchProcessType")) {
			result = "is not a valid input for batchProcessType";
		}

		switch (result){
			case "customerId must not be null", "customerId must be a UUID": {
				result = PaymentErrors.ERROR_CUSTOMER_IS_INVALID;
				break;
			}
			case "creditAccountId must not be null", "creditAccountId must be a UUID": {
				result = PaymentErrors.ERROR_CREDIT_ACCOUNT_IS_INVALID;
				break;
			}
			case "externalAccountId must not be null", "externalAccountId must be a UUID": {
				result = PaymentErrors.ERROR_EXTERNAL_ACCOUNT_IS_INVALID;
				break;
			}
			case "agentId must not be null", "agentId must be a UUID": {
				result = PaymentErrors.ERROR_AGENT_IS_INVALID;
				break;
			}
			case "scheduledDate must not be null": {
				result = PaymentErrors.ERROR_SCHEDULE_PAYMENT_IS_INVALID;
				break;
			}
			case "paymentAmount must not be null", "paymentAmount must be greater than or equal to 0": {
				result = PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID;
				break;
			}
            case "feeAmount must not be null", "feeAmount must be greater than or equal to 0": {
				result = PaymentErrors.ERROR_FEE_AMOUNT_IS_INVALID;
				break;
			}
			case "paymentType must not be null": {
				result = PaymentErrors.ERROR_PAYMENT_TYPE_IS_INVALID;
				break;
			}
			case "paymentMetadata must not be null": {
				result = PaymentErrors.ERROR_PAYMENT_METADATA_IS_INVALID;
				break;
			}
			case "paymentMetadata.paymentPurpose must not be null", "paymentPurpose is not a valid input for paymentMetadata", "is not a valid input for paymentPurpose": {
				result = PaymentErrors.ERROR_PAYMENT_PURPOSE_IS_INVALID;
				break;
			}
			case "channel must not be null": {
				result = PaymentErrors.ERROR_CHANNEL_IS_INVALID;
				break;
			}
			case "paymentMode must not be null", "is not a valid input for paymentMode": {
				result = PaymentErrors.ERROR_PAYMENT_MODE_IS_INVALID;
				break;
			}
			case "sort is not a valid input for SortOrder", "is not a valid input for SortOrder": {
				result = PaymentErrors.ERROR_SORT_IS_INVALID;
				break;
			}
			case "sortField is not a valid input for SortField", "is not a valid input for SortField": {
				result = PaymentErrors.ERROR_SORT_FIELD_IS_INVALID;
				break;
			}
			case "is not a valid input for batchProcessType": {
				result = PaymentErrors.ERROR_BATCH_TYPE_IS_INVALID;
				break;
			}
		}

		return result;
	}

	public static LocalDateTime getLocalTimeByZoneId(String paymentZoneId, String correlationId) {
		LocalDateTime localDateTimeNow = LocalDateTime.now();

		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.systemDefault());
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneId.of(paymentZoneId));

		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ssx", Locale.US);
		String formatterUtcDateTime = converted.format(targetFormatter);
		log.debug(PaymentConstants.LOG_PREFIX + "Formatted LocalDateTime {}", correlationId, formatterUtcDateTime);

		LocalDateTime localDateTime = converted.toLocalDateTime();

		return localDateTime;
	}

	public static ZonedDateTime getZonedDateTimeUTC(String correlationId) {
		LocalDateTime localDateTimeNow = LocalDateTime.now();

		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.systemDefault());
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneOffset.UTC);

		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ssx", Locale.US);
		String formatterUtcDateTime = converted.format(targetFormatter);
		log.debug(PaymentConstants.LOG_PREFIX + "Formatted LocalDateTime {}", correlationId, formatterUtcDateTime);

		return converted;
	}

	public static ZonedDateTime getZonedDateTimeUTC(String correlationId, String paymentZoneId) {
		LocalDateTime localDateTimeNow = LocalDateTime.now();

		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.of(paymentZoneId));
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneOffset.UTC);

		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ssx", Locale.US);
		String formatterUtcDateTime = converted.format(targetFormatter);
		log.debug(PaymentConstants.LOG_PREFIX + "Formatted LocalDateTime {}", correlationId, formatterUtcDateTime);

		return converted;
	}

	public static String getCurrentDayOfWeek() {
		LocalDateTime localDateTimeNow = LocalDateTime.now();
		ZonedDateTime zonedTime = localDateTimeNow.atZone(ZoneId.systemDefault());
		ZonedDateTime converted = zonedTime.withZoneSameInstant(ZoneOffset.UTC);

		return converted.getDayOfWeek().name();
	}

	public static String getFormattedDate(String expectedFormat, String scheduleDate, String inputFormat) {
		LocalDateTime date = LocalDateTime.parse(scheduleDate, DateTimeFormatter.ofPattern(inputFormat));
		return date.format(DateTimeFormatter.ofPattern(expectedFormat));
	}

	public static String getFormattedDateToStr(String expectedFormat, String scheduleDate, String inputFormat) {
		LocalDateTime date = LocalDateTime.parse(scheduleDate, DateTimeFormatter.ofPattern(inputFormat));
		return date.format(DateTimeFormatter.ofPattern(expectedFormat));
	}

	public static ZonedDateTime getZonedDateTimeUTCFromDate(String scheduledDate) {
		LocalDateTime localDateTime = PaymentUtil.parseDateTime(scheduledDate, PaymentConstants.DATETIMEFORMAT_RESPONSE);
		ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, ZoneId.of(PaymentConstants.AMERICA_LOS_ANGELES_ID));
		return zonedDateTime.withZoneSameInstant(ZoneId.of("UTC"));
	}

	public static String getValueFromJsonObject(Json data, String field, String correlationId) {
		JSONParser parser = new JSONParser();
		if (data == null)
			return null;
		try {
			JSONObject jsonData = (JSONObject) parser.parse(data.asString());
			if (jsonData.get(field) != null) {
				return String.valueOf(jsonData.get(field));
			}
			else {
				return null;
			}
		}
		catch (ParseException e) {
			String error = "Error While parsing data in getValueFromJsonObject" + data;
			log.error(PaymentConstants.LOG_PREFIX + error, correlationId);
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PARSING_JSON);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
	}

	public static List<String> getPendingTaskType(Json paymentRequestData, String correlationId) throws ParseException {
		log.info(PaymentConstants.LOG_PREFIX + "Start of getPendingTaskType()  paymentRequestData: {}.", correlationId, paymentRequestData);
		List<String> tasksTypeList = new ArrayList<>();
		JSONParser parser = new JSONParser();
		JSONObject paymentRequestDataObject = (JSONObject) parser.parse(paymentRequestData.asString());

		if (paymentRequestDataObject != null) {
			JSONObject asyncJobJson = (JSONObject) paymentRequestDataObject.get(PaymentConstants.ASYNC_JOBS);
			if (asyncJobJson != null) {
				JSONArray taskArray = (JSONArray) asyncJobJson.get(PaymentConstants.TASKS);
				if (taskArray == null) {
					return null;
				}
				for (int i = 0; i < taskArray.size(); i++) {
					JSONObject element = (JSONObject)taskArray.get(i);
					if(element.get(PaymentConstants.TASK_STATUS)!=null) {
						updateTaskTypeListForFailedStatus(element, tasksTypeList);
					}
				}
			}
		}
		log.info(PaymentConstants.LOG_PREFIX + "End of getPendingTaskType()", correlationId);
		return tasksTypeList;
	}

	private static void updateTaskTypeListForFailedStatus(JSONObject element, List<String> tasksTypeList) {
		if (((String) element.get(PaymentConstants.TASK_STATUS)).equalsIgnoreCase(PaymentConstants.FAILED)) {
			tasksTypeList.add((String) element.get(PaymentConstants.TASK_TYPE));
		}
	}
}