package com.creditone.ucrm.payments.util;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.processor.Processor;
import com.creditone.ucrm.payments.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;

@Slf4j
public class ReactiveFlowHelper {

    /**
     * Executes a reactive flow with standard logging, synchronous validation, reactive processing and optional error handling.
     *
     * @param correlationId a unique ID for tracking the request
     * @param validator    a Validator performing synchronous validation (can throw exceptions)
     *                     Assumption: validation is simple and not performing blocking operation like db/external call.
     *                     The cases where this assumption is not valid, can't use this flow at the moment.
     * @param processor     the core reactive Mono-producing business logic
     * @param classMethodNameWithLogParams class name and method name of caller. This can be retrieved dynamically using <code>Stack</code>, but may hit performance.
     *
     * @param toBeLoggedObjects objects like accountId, customerId that needs to be appended to the log message
     * @param <T>           the return type
     * @return a Mono<T> wrapped with logging and error tracking
     */
    public static <T> Mono<T> executeReactiveFlow(
            String correlationId,
            Validator validator,
            Processor<Mono<T>> processor,
            String classMethodNameWithLogParams,
            Object... toBeLoggedObjects) {

        Instant startTime = Instant.now();
        // Prepend correlation ID to log arguments
        Object[] logArgs = prepend(correlationId, toBeLoggedObjects);

        log.info(PaymentConstants.LOG_PREFIX + "Start of " + classMethodNameWithLogParams, logArgs);
        //Note that if a controller class use this flow, in log statements, value of logger_name will always be com.creditone.ucrm.payments.util.ReactiveFlowHelper
        //This becomes redundant information now. But we have to live with that till all controller endpoints don't start using this flow.
        //Once that happens, logger_name attribute can be suppressed.

        try {
            validator.validate();
        } catch (Exception ex) {
            log.error(PaymentConstants.LOG_PREFIX + "Validation failed: " + ex.getMessage(), correlationId);
            return Mono.error(ex);
        }

        return processor.process()
                .doOnSuccess(result -> log.info(PaymentConstants.LOG_PREFIX + "End of " + classMethodNameWithLogParams, logArgs))
                .doOnError(error -> log.error(PaymentConstants.LOG_PREFIX + "Processing failed: " + error.getMessage(), correlationId))
                .doFinally(signalType -> {
                    Duration duration = Duration.between(startTime, Instant.now());
                    log.info(PaymentConstants.LOG_PREFIX + "Operation completed in {} ms", correlationId, duration.toMillis());
                });
    }

    /**
     * Returns an array of Objects by combining an Object object and array of Objects
     * @param first
     * @param rest
     * @return
     */
    private static Object[] prepend(Object first, Object[] rest) {
        Object[] combined = new Object[rest.length + 1];
        combined[0] = first;
        System.arraycopy(rest, 0, combined, 1, rest.length);
        return combined;
    }
}
