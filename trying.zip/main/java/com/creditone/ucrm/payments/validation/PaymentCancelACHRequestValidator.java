package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.constant.PaymentStatus;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.ucrm.swagger.paymentservice.model.CancelACHPaymentRequest;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

public class PaymentCancelACHRequestValidator {
    public static void validate(CancelACHPaymentRequest request) throws PaymentDataException {
        if (request == null) {
            throw new PaymentDataException("Request Body" + PaymentErrors.VALIDATION_NOT_NULL);
        }

        StringBuilder errorMessages = new StringBuilder();
        List<String> validStatus = Arrays.asList(PaymentStatus.VOID.name(), PaymentStatus.CANCEL.name());

        if (!validStatus.contains(request.getPaymentStatus())) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_STATUS_IS_INVALID);
        }

        if (request.getAgentId()==null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_AGENT_IS_INVALID);
        }

        if (request.getIsAutoPay()==null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_IS_AUTOPAY_IS_INVALID);
        }

        if (errorMessages.length() != 0) {
            PaymentDataException paymentDataException = new PaymentDataException(errorMessages.toString());
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            throw paymentDataException;
        }
    }

    public static void appendErrors(StringBuilder errorMessages, String error) {
        if (errorMessages.length() != 0) {
            errorMessages.append(";");
        }

        errorMessages.append(error);
    }
}