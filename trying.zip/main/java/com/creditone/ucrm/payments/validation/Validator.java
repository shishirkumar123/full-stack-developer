package com.creditone.ucrm.payments.validation;
/**
 * Represents a validator of request.
 * This is a functional interface whose functional method is validate().
 *
 */

@FunctionalInterface
public interface Validator {
    void validate();
}
