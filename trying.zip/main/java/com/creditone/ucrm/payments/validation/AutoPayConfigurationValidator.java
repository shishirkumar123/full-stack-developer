package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import org.springframework.http.HttpStatus;

import java.util.regex.Pattern;

public class AutoPayConfigurationValidator {
    public static void validatePathVariables(String customerId, String creditAccountId) throws PaymentDataNotFoundException {

        StringBuilder errorMessages = new StringBuilder();
        Pattern UUID_REGEX = Pattern.compile(PaymentConstants.UUIDREGEX);

        if (customerId.isBlank()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CUSTOMER_IS_INVALID);
        }
        else if(!UUID_REGEX.matcher(customerId).matches()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CUSTOMER_IS_INVALID);
        }

        if (creditAccountId.isBlank()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CREDIT_ACCOUNT_IS_INVALID);
        }
        else if(!UUID_REGEX.matcher(creditAccountId).matches()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CREDIT_ACCOUNT_IS_INVALID);
        }

        if (errorMessages.length() != 0) {
            PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(errorMessages.toString());
            paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
            throw paymentDataNotFoundException;
        }
    }

    private static void appendErrors(StringBuilder errorMessages, String error) {
        if (errorMessages.length() != 0) {
            errorMessages.append("; ");
        }

        errorMessages.append(error);
    }
}

