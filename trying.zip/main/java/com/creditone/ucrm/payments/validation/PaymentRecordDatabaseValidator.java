package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.dto.PaymentRequestDataDBResponse;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.ucrm.swagger.paymentservice.model.PaymentMetadata;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PaymentRecordDatabaseValidator {

	public static void validatePaymentRecordVerificationData(PaymentRequestDataDBResponse paymentRequestDataDBResponse,
			String origin) throws ParseException {
		validateIndividualUniqueIdentifier(paymentRequestDataDBResponse);
		validateAccountKey(paymentRequestDataDBResponse);
		validateExternalAccountKey(paymentRequestDataDBResponse);
		validatePaymentType(paymentRequestDataDBResponse);
		validatePaymentDate(paymentRequestDataDBResponse);
		validateCreatedBy(paymentRequestDataDBResponse);
		validateStatus(paymentRequestDataDBResponse);
		validateJson(paymentRequestDataDBResponse, origin);
	}

	private static void validateIndividualUniqueIdentifier(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getIndividualUniqueIdentifierKey() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_INDIVIDUAL_UNIQUE_IDENTIFIER_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validateAccountKey(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getAccountKey() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_ACCOUNT_KEY_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validateExternalAccountKey(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getExternalAccountKey() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_EXTERNAL_ACCOUNT_KEY_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validatePaymentType(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getPaymentType() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_TYPE_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}

		List<String> listValidPaymentType = Arrays.stream(PaymentType.values()).map(st -> st.name().toUpperCase())
				.collect(Collectors.toList());
		if (!listValidPaymentType.contains(paymentRequestDataDBResponse.getPaymentType().toUpperCase())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_PAYMENT_TYPE_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{paymentType\\}", paymentRequestDataDBResponse.getPaymentType());
			error = error.replaceAll("\\{paymentId\\}", paymentRequestDataDBResponse.getPaymentRequestId().toString());
			throwPaymentDataException(error, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validatePaymentDate(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getPaymentDate() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_DATE_NOT_FOUND_DATABASE,
					paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validateCreatedBy(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getCreatedBy() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_CREATED_BY_NOT_FOUND_DATABASE,
					paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validateStatus(PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		if (paymentRequestDataDBResponse.getRequestStatus() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_STATUS_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}

		List<String> listValidPStatus = Arrays.stream(PaymentStatus.values()).map(st -> st.name()).collect(Collectors.toList());
		if (!listValidPStatus.contains(paymentRequestDataDBResponse.getRequestStatus().toUpperCase())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_STATUS_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{status\\}", paymentRequestDataDBResponse.getRequestStatus());
			error = error.replaceAll("\\{paymentId\\}", paymentRequestDataDBResponse.getPaymentRequestId().toString());
			throwPaymentDataException(error, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}
	}

	private static void validateJson(PaymentRequestDataDBResponse paymentRequestDataDBResponse, String origin) throws ParseException {
		if (paymentRequestDataDBResponse.getPaymentRequestData() == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_REQUEST_DATA_NOT_FOUND_DATABASE, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		}

		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(paymentRequestDataDBResponse.getPaymentRequestData().asString());

		Object objFeeAmount = jsonObject.get(PaymentConstants.FEE_AMOUNT);
		validateFeeAmount(objFeeAmount != null ? objFeeAmount.toString() : null, paymentRequestDataDBResponse.getPaymentRequestId().toString());

		Object objPaymentAmount = jsonObject.get(PaymentConstants.PAYMENT_AMOUNT);
		validatePaymentAmount(objPaymentAmount != null ? objPaymentAmount.toString() : null, paymentRequestDataDBResponse.getPaymentRequestId().toString());

		Object objChannel = jsonObject.get(PaymentConstants.CHANNEL);
		validateChannel(objChannel != null ? (String) objChannel : null, paymentRequestDataDBResponse.getPaymentRequestId().toString());
		Object retryCount = jsonObject.get(PaymentConstants.RETRYABLE_COUNT);
		validateRetryCount(retryCount != null ? retryCount.toString() : null, paymentRequestDataDBResponse.getPaymentRequestId().toString());

		if (origin.equals(PaymentConstants.SCHEDULE_ORIGIN) || origin.equals(PaymentConstants.KAFKA_CONSUMER_ORIGIN)) {
			validateUpdatedParameters(jsonObject, paymentRequestDataDBResponse);
		}
	}

	public static void validateRetryCount(String retryCount, String paymentRequestId) {
		if (retryCount != null) {
			try {
				Integer retryCountInDb = Integer.valueOf(retryCount);
				if (retryCountInDb >=2) {
					String error = PaymentErrors.ERROR_RETRY_EXCEEDED;
					error = error.replaceAll("\\{retryCount\\}", retryCount);
					error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
					throwPaymentDataException(error, paymentRequestId);
				}
			} catch (NumberFormatException e) {
				String error = PaymentErrors.ERROR_RETRY_EXCEEDED;
				error = error.replaceAll("\\{retryCount\\}", retryCount);
				error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
				throwPaymentDataException(error, paymentRequestId);
			}
		}

	}

	private static void validateFeeAmount(String feeAmount, String paymentRequestId) {
		if (feeAmount == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_FEE_AMOUNT_NOT_FOUND_DATABASE, paymentRequestId);
		}

		try {
			Double.valueOf(feeAmount);
		} catch (NumberFormatException e) {
			String error = PaymentErrors.ERROR_ACH_ERROR_FEE_AMOUNT_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{feeAmount\\}", feeAmount);
			error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
			throwPaymentDataException(error, paymentRequestId);
		}
	}

	private static void validatePaymentAmount(String feeAmount, String paymentRequestId) {
		if (feeAmount == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_AMOUNT_NOT_FOUND_DATABASE, paymentRequestId);
		}

		try {
			Double.valueOf(feeAmount);
		} catch (NumberFormatException e) {
			String error = PaymentErrors.ERROR_ACH_ERROR_PAYMENT_AMOUNT_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{paymentAmount\\}", feeAmount);
			error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
			throwPaymentDataException(error, paymentRequestId);
		}
	}

	private static void validateChannel(String channel, String paymentRequestId) {
		if (channel == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_CHANNEL_NOT_FOUND_DATABASE, paymentRequestId);
		}

		List<String> listValidChannel = Arrays.stream(Channel.values()).map(st -> st.name())
				.collect(Collectors.toList());
		if (!listValidChannel.contains(channel.toUpperCase())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_CHANNEL_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{channel\\}", channel);
			error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
			throwPaymentDataException(error, paymentRequestId);
		}
	}

	private static void throwPaymentDataException(String errorMessage, String paymentId) {
		String error = errorMessage.replaceAll("\\{paymentId\\}", paymentId);
		PaymentDataException paymentDataException = new PaymentDataException(error);
		paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
		throw paymentDataException;
	}

	private static void validateUpdatedParameters(JSONObject jsonObject,
			PaymentRequestDataDBResponse paymentRequestDataDBResponse) {
		Object objPaymentMode = jsonObject.get(PaymentConstants.PAYMENT_MODE);
		validatePaymentMode(objPaymentMode != null ? (String) objPaymentMode : null,
				paymentRequestDataDBResponse.getPaymentRequestId().toString(),
				paymentRequestDataDBResponse.getPaymentType());

		String paymentRequestId = String.valueOf(paymentRequestDataDBResponse.getPaymentRequestId());

		Object objPaymentMetadata = jsonObject.get(PaymentConstants.PAYMENT_METADATA);
		validatePaymentMetadata(objPaymentMetadata, paymentRequestId);

		if (jsonObject.get(PaymentConstants.PAYMENT_PURPOSE) == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_PURPOSE_NOT_FOUND_DATABASE, paymentRequestId);
		}
		validatePaymentPurpose(jsonObject, paymentRequestId);
		validatAccountData(jsonObject, paymentRequestId);
	}

	private static void validatePaymentMode(String paymentMode, String paymentRequestId, String paymentType) {
		if (paymentMode == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_MODE_NOT_FOUND_DATABASE, paymentRequestId);
		}

		List<String> listValidPaymentMode = Arrays.stream(PaymentServiceRequest.PaymentModeEnum.values())
				.map(st -> st.name().toUpperCase()).collect(Collectors.toList());
		if (!listValidPaymentMode.contains(paymentMode.toUpperCase())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_PAYMENT_MODE_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{paymentMode\\}", paymentMode);
			error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
			throwPaymentDataException(error, paymentRequestId);
		}

		if (paymentType.equalsIgnoreCase(PaymentType.ACH.name())) {
			if (!(paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.STANDARD_PAYMENT.name())
					|| paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.name())
					|| paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.AUTO_PAYMENT.name()))) {
				String error = PaymentErrors.VALIDATION_INVALID_PAYMENT_MODE_FOR_PAYMENT_TYPE;
				throwPaymentDataException(error, paymentRequestId);
			}
		} else if (paymentType.equalsIgnoreCase(PaymentType.DEBIT.name())) {
			if (!(paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.name())
					|| paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.ONETIME_PAYMENT.name())
					|| paymentMode.equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name()))) {
				String error = PaymentErrors.VALIDATION_INVALID_PAYMENT_MODE_FOR_PAYMENT_TYPE;
				throwPaymentDataException(error, paymentRequestId);
			}
		}
	}

	private static void validatePaymentMetadata(Object objPaymentMetadata, String paymentRequestId) {
		if (objPaymentMetadata == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_METADATA_NOT_FOUND_DATABASE, paymentRequestId);
		}

		if (!(objPaymentMetadata instanceof JSONArray)) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_METADATA_JSON_ARRAY, paymentRequestId);
		}

		JSONArray jsonArrayPaymentMetadata = (JSONArray) objPaymentMetadata;
		if (jsonArrayPaymentMetadata.size() == 0) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_METADATA_EMPTY, paymentRequestId);
		}

		JSONObject jsonObjectNote = (JSONObject) jsonArrayPaymentMetadata.get(0);

		if (jsonObjectNote.get(PaymentConstants.NOTES) == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_NOTES_NOT_FOUND_DATABASE, paymentRequestId);
		}

		if (jsonObjectNote.get(PaymentConstants.DATE) == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_DATE_NOT_FOUND_DATABASE, paymentRequestId);
		}
	}

	private static void validatAccountData(JSONObject jsonObjectNote, String paymentRequestId) {

		if (jsonObjectNote.get(PaymentConstants.CREDIT_ACCOUNT_LAST4) == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_CREDIT_LAST4_NOT_FOUND_DATABASE, paymentRequestId);
		}

		if (jsonObjectNote.get(PaymentConstants.EXTERNAL_ACCOUNT_LAST4) == null) {
			throwPaymentDataException(PaymentErrors.ERROR_ACH_ERROR_EXTERNAL_LAST4_NOT_FOUND_DATABASE, paymentRequestId);
		}
	}

	private static void validatePaymentPurpose(JSONObject jsonObjectNote, String paymentRequestId) {
		String paymentPurpose = (String) jsonObjectNote.get(PaymentConstants.PAYMENT_PURPOSE);

		List<String> listValidPaymentPurpose = Arrays.stream(PaymentMetadata.PaymentPurposeEnum.values())
				.map(st -> st.name().toUpperCase()).collect(Collectors.toList());
		if (!listValidPaymentPurpose.contains(paymentPurpose.toUpperCase())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_PAYMENT_PURPOSE_IN_DATABASE_INVALID;
			error = error.replaceAll("\\{paymentPurpose\\}", paymentPurpose);
			error = error.replaceAll("\\{paymentId\\}", paymentRequestId);
			throwPaymentDataException(error, paymentRequestId);
		}

	}
}