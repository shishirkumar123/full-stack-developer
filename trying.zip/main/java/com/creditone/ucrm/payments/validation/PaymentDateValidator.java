package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.util.PaymentUtil;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PaymentDateValidator {

	private PaymentDateValidator() {
	}

	public static boolean isValid(String value) {
		boolean validationState = true;
		try {
			LocalDateTime localDateTime = PaymentUtil.parseDateTime(value, PaymentConstants.DATETIMEFORMAT_RESPONSE);
			PaymentUtil.toZonedDateTime(localDateTime);
		} catch (Exception e) {
			validationState = false;
		}
		return validationState;
	}

	public static boolean isValidLocalDate(String value) {
		boolean validationState = true;
		try {
			LocalDate.parse(value, DateTimeFormatter.ofPattern(PaymentConstants.DATEFORMAT));
		}
		catch (Exception e) {
			validationState = false;
		}
		return validationState;
	}

	public static boolean isDatePast(String value) {
		boolean validationState = false;
		try {
			LocalDateTime localDateTime = PaymentUtil.parseDateTime(value, PaymentConstants.DATETIMEFORMAT_RESPONSE);
			LocalDate localDate = PaymentUtil.toZonedDateTime(localDateTime).toLocalDate();
			LocalDate systemLocalDate = PaymentUtil.utcNow().toLocalDate();
			if(localDate.isBefore(systemLocalDate)) {
				validationState = true;
			}
		}
		catch (Exception e) {
			validationState = true;
		}
		return validationState;
	}
}