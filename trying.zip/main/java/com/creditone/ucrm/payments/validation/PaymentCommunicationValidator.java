package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.PaymentCommunicationIntent;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.dto.EntityModelIndividualCoreIdentityResponse;
import com.creditone.ucrm.payments.dto.PaymentCommunicationDetailsRequest;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.ucrm.swagger.creditcardaccountservice.model.AccountDetailsResponse;


import java.util.Map;

public class PaymentCommunicationValidator {
    public static void validate(PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, PaymentCommunicationIntent paymentCommunicationIntent) throws PaymentDataException {
        StringBuilder errorMessages = new StringBuilder();

        validateCommonValues(errorMessages, paymentCommunicationDetailsRequest, paymentCommunicationIntent);
        validateVariableValues(errorMessages, paymentCommunicationDetailsRequest, paymentCommunicationIntent);

        if (errorMessages.length() != 0) {
            throw new PaymentDataException(errorMessages.toString());
        }
    }

    private static void validateCommonValues(StringBuilder errorMessages, PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, PaymentCommunicationIntent paymentCommunicationIntent) {
        if(paymentCommunicationDetailsRequest.getFirstName() == null) {
            appendErrors(errorMessages, "firstName" + PaymentErrors.VALIDATION_MISSING);
        }

        if(paymentCommunicationDetailsRequest.getLastName() == null) {
            appendErrors(errorMessages, "lastName" + PaymentErrors.VALIDATION_MISSING);
        }

        if(paymentCommunicationDetailsRequest.getCardType() == null) {
            appendErrors(errorMessages, "cardType" + PaymentErrors.VALIDATION_MISSING);
        }

        if(paymentCommunicationDetailsRequest.getCardLast4() == null) {
            appendErrors(errorMessages, "cardLast4" + PaymentErrors.VALIDATION_MISSING);
        }

        if(paymentCommunicationDetailsRequest.getPaymentAmount() == null) {
            appendErrors(errorMessages, "paymentAmount" + PaymentErrors.VALIDATION_MISSING);
        }

        if(!paymentCommunicationIntent.equals(PaymentCommunicationIntent.NOTIFY_AUTO_PAY)) {
            if (paymentCommunicationDetailsRequest.getDayOfWeek() == null) {
                appendErrors(errorMessages, "dayOfWeek" + PaymentErrors.VALIDATION_MISSING);
            }

            if (paymentCommunicationDetailsRequest.getEmailAddress() == null) {
                appendErrors(errorMessages, "emailAddress" + PaymentErrors.VALIDATION_MISSING);
            }
        }

        if(paymentCommunicationDetailsRequest.getCustomerId() == null) {
            appendErrors(errorMessages, "customerId" + PaymentErrors.VALIDATION_MISSING);
        }
    }

    private static void validateVariableValues(StringBuilder errorMessages, PaymentCommunicationDetailsRequest paymentCommunicationDetailsRequest, PaymentCommunicationIntent paymentCommunicationIntent) {
        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_PROCESSED)) {
            if(paymentCommunicationDetailsRequest.getReferenceNum() == null) {
                appendErrors(errorMessages, "referenceNum" + PaymentErrors.VALIDATION_MISSING);
            }
        }

        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_SCHEDULED) ||
                paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_CANCELLED) ||
                paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_RETURNED)||
                paymentCommunicationIntent.equals(PaymentCommunicationIntent.CANCEL_PAYMENT)) {
            if(paymentCommunicationDetailsRequest.getPaymentDate() == null) {
                appendErrors(errorMessages, "paymentDate" + PaymentErrors.VALIDATION_MISSING);
            }
        }

        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_RETURNED)) {
            if(paymentCommunicationDetailsRequest.getReturnDate() == null) {
                appendErrors(errorMessages, "returnDate" + PaymentErrors.VALIDATION_MISSING);
            }
        }

        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.NOTIFY_AUTO_PAY)) {
            if(paymentCommunicationDetailsRequest.getPaymentBank() == null) {
                appendErrors(errorMessages, "paymentBank" + PaymentErrors.VALIDATION_MISSING);
            }

            if(paymentCommunicationDetailsRequest.getPaymentLast4() == null) {
                appendErrors(errorMessages, "paymentLast4" + PaymentErrors.VALIDATION_MISSING);
            }
        }

        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.CANCEL_PAYMENT)){
            if(paymentCommunicationDetailsRequest.getPlasticCode() == null) {
                appendErrors(errorMessages, "plasticCode" + PaymentErrors.VALIDATION_MISSING);
            }
        }
    }

    private static void appendErrors(StringBuilder errorMessages, String error) {
        if (errorMessages.length() != 0)
            errorMessages.append(";");

        errorMessages.append(error);
    }

    public static void validateFromDatabaseAndRequest(Map<String, Object> parametersValidation) throws PaymentDataException {
        EntityModelIndividualCoreIdentityResponse entityModelIndividualCoreIdentityResponse = (EntityModelIndividualCoreIdentityResponse)parametersValidation.get(PaymentConstants.ENTITY_MODEL_INDIVIDUAL_CORE_IDENTITY);
        String customerId = (String)parametersValidation.get(PaymentConstants.CUSTOMER_ID_PARAM);

        StringBuilder errorMessages = new StringBuilder();

        validateFromDatabase(errorMessages, parametersValidation);

        if(entityModelIndividualCoreIdentityResponse.getFirstName() == null || entityModelIndividualCoreIdentityResponse.getLastName() == null) {
            String error = PaymentErrors.ERROR_CIAM_FIRST_NAME_LAST_NAME_NULL.replace("{customerId}", customerId);
            appendErrors(errorMessages, error);
        }

        validateFromCreditCardServiceResponse(errorMessages, parametersValidation);

        if (errorMessages.length() != 0) {
            throw new PaymentDataException(errorMessages.toString());
        }
    }

    private static void validateFromDatabase(StringBuilder errorMessages, Map<String, Object> parametersValidation) {
        Map<String, Object> parametersDatabase = (Map<String, Object>)parametersValidation.get(PaymentConstants.PARAMETERS_DATABASE);
        PaymentCommunicationIntent paymentCommunicationIntent = (PaymentCommunicationIntent)parametersValidation.get(PaymentConstants.PAYMENT_COMMUNICATION_INTENT);
        String customerId = (String)parametersValidation.get(PaymentConstants.CUSTOMER_ID_PARAM);

        if(paymentCommunicationIntent.equals(PaymentCommunicationIntent.PAYMENT_PROCESSED)) {
            if(parametersDatabase.get(PaymentConstants.REFERENCENUM) == null) {
                String error = PaymentErrors.ERROR_DATABASE_RECORD_PAYMENT_CONFIRMATION_NULL.replace("{customerId}", customerId);
                appendErrors(errorMessages, error);
            }
        }

        if(parametersDatabase.get(PaymentConstants.PAYMENTAMOUNT) == null) {
            String error = PaymentErrors.ERROR_DATABASE_RECORD_PAYMENT_AMOUNT_NULL.replace("{customerId}", customerId);
            appendErrors(errorMessages, error);
        }

        if(parametersDatabase.get(PaymentConstants.PAYMENTDATE) == null) {
            String error = PaymentErrors.ERROR_DATABASE_RECORD_PAYMENT_DATE_NULL.replace("{customerId}", customerId);
            appendErrors(errorMessages, error);
        }
    }

    private static void validateFromCreditCardServiceResponse(StringBuilder errorMessages, Map<String, Object> parametersValidation) {
        AccountDetailsResponse accountDetailsResponse = (AccountDetailsResponse)parametersValidation.get(PaymentConstants.CREDITCARD_DETAILS_RESPONSE);
        String customerId = (String)parametersValidation.get(PaymentConstants.CUSTOMER_ID_PARAM);
        String creditAccountId = (String)parametersValidation.get(PaymentConstants.CREDIT_ACCOUNT_ID);


        if(accountDetailsResponse.getDevice().getDeviceLast4() == null) {
            String error = PaymentErrors.ERROR_CREDITCARD_ACCOUNT_CARD_LAST4_NULL.replace("{customerId}", customerId);
            error = error.replace("{creditCardAccount}", creditAccountId);
            appendErrors(errorMessages, error);
        }

        if(accountDetailsResponse.getDevice().getNetwork()== null) {
            String error = PaymentErrors.ERROR_CREDITCARD_ACCOUNT_CARD_TYPE_NULL.replace("{customerId}", customerId);
            error = error.replace("{creditCardAccount}", creditAccountId);
            appendErrors(errorMessages, error);
        }
    }
}