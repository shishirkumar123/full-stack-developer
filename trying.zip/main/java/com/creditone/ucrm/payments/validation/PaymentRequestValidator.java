package com.creditone.ucrm.payments.validation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;
import com.creditone.ucrm.payments.constant.*;
import com.creditone.ucrm.payments.events.kafka.AchPartnerMoneyMovementKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.creditone.ucrm.payments.events.kafka.PaymentsErrorKafkaEvent;
import com.creditone.ucrm.payments.exception.PaymentDataNotFoundException;
import com.creditone.ucrm.payments.util.PaymentUtil;
import com.ucrm.swagger.paymentrulesservice.model.BlockedDate;
import com.ucrm.swagger.paymentrulesservice.model.PaymentEligibilityDateResponse;
import com.ucrm.swagger.paymentservice.model.BatchProcessRequest;
import com.ucrm.swagger.paymentservice.model.PaymentServiceRequest;
import com.ucrm.swagger.paymentservice.model.PaymentsReplayRequest;
import org.springframework.http.HttpStatus;

public class PaymentRequestValidator {
	
	private PaymentRequestValidator() {
	}

	public static void validate(PaymentServiceRequest paymentServiceRequest) {
		if (paymentServiceRequest == null)
			throw new PaymentDataException("Request Body" + PaymentErrors.VALIDATION_NOT_NULL);

		StringBuilder errorMessages = new StringBuilder();
		if(!paymentServiceRequest.getScheduledDate().matches(PaymentConstants.UTCTIMESTAMPREGEX)) {
			appendErrors(errorMessages, PaymentErrors.ERROR_SCHEDULE_PAYMENT_IS_INVALID);
		}
		else if (!PaymentDateValidator.isValid(paymentServiceRequest.getScheduledDate())) {
			appendErrors(errorMessages, PaymentErrors.ERROR_SCHEDULE_PAYMENT_IS_INVALID);
		}
		else if (PaymentDateValidator.isDatePast(paymentServiceRequest.getScheduledDate())) {
			appendErrors(errorMessages, PaymentErrors.ERROR_SCHEDULE_PAYMENT_IS_INVALID);
		}

		validateAmountPrecision(errorMessages, paymentServiceRequest);
		validateValues(errorMessages, paymentServiceRequest);
		validatePaymentMode(errorMessages, paymentServiceRequest);

		if (errorMessages.length() != 0) {
			PaymentDataException paymentDataException = new PaymentDataException(errorMessages.toString());
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
	}

	public static void validateBatchProcessRequest(BatchProcessRequest request) {
		if (request == null || request.toString().isEmpty()) {
			throw new PaymentDataException("Request Body" + PaymentErrors.VALIDATION_NOT_NULL);
		}

		if (!(BatchProcessRequest.BatchProcessTypeEnum.PROCESS_SCHEDULE_PAYMENT.equals(request.getBatchProcessType())
				|| BatchProcessRequest.BatchProcessTypeEnum.SCHEDULE_AUTOPAY.equals(request.getBatchProcessType())
				|| BatchProcessRequest.BatchProcessTypeEnum.PROCESS_AUTO_PAY_NOTIFICATION.equals(request.getBatchProcessType()))) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_BATCH_TYPE_IS_INVALID);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}
	}

	public static void validatePaymentsReplayRequest(PaymentsReplayRequest paymentsReplayRequest) {
		if (paymentsReplayRequest == null || paymentsReplayRequest.getPaymentRequestIds() == null || (paymentsReplayRequest.getPaymentRequestIds() != null && paymentsReplayRequest.getPaymentRequestIds().isEmpty())) {
			PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
			paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
			throw paymentDataException;
		}

		Pattern pattern = Pattern.compile(PaymentConstants.UUIDREGEX);
		for(String s: paymentsReplayRequest.getPaymentRequestIds()) {
			if(!pattern.matcher(s).matches()) {
				PaymentDataException paymentDataException = new PaymentDataException(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_IS_INVALID);
				paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
				throw paymentDataException;
			}
		}
	}

	private static void validateAmountPrecision(StringBuilder errorMessages, PaymentServiceRequest paymentServiceRequest) {
		Pattern pattern = Pattern.compile(PaymentConstants.AMOUNT_PRECISION_REGEX);

		if (paymentServiceRequest.getPaymentAmount().compareTo(BigDecimal.ZERO) == 0) {
			appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
		}
		else {
			if (!pattern.matcher(paymentServiceRequest.getPaymentAmount().toString()).matches()) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
			}
		}

		if (!pattern.matcher(paymentServiceRequest.getFeeAmount().toString()).matches()) {
			appendErrors(errorMessages, PaymentErrors.ERROR_FEE_AMOUNT_IS_INVALID);
		}
	}

	private static void validateValues(StringBuilder errorMessages, PaymentServiceRequest paymentServiceRequest) {
		if (!isValidStringValue(PaymentType.class, paymentServiceRequest.getPaymentType())) {
			appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_TYPE_IS_INVALID);
		}

		if (!isValidStringValue(Channel.class, paymentServiceRequest.getChannel())) {
			appendErrors(errorMessages, PaymentErrors.ERROR_CHANNEL_IS_INVALID);
		}
	}

	private static void validatePaymentMode(StringBuilder errorMessages, PaymentServiceRequest paymentServiceRequest) {
		if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.ACH.name())) {
			if (!(paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.STANDARD_PAYMENT.name())
					|| paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.ONETIME_PAYMENT.name())
					|| paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.name())
					|| paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name()))) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_MODE_IS_INVALID);
			}
		} else if (paymentServiceRequest.getPaymentType().equalsIgnoreCase(PaymentType.DEBIT.name())) {
			if (!(paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.EXPRESS_PAYMENT.name())
					|| paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.ONETIME_PAYMENT.name())
					|| paymentServiceRequest.getPaymentMode().name().equalsIgnoreCase(PaymentServiceRequest.PaymentModeEnum.THIRDPARTY_PAYMENT.name()))) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_MODE_IS_INVALID);
			}
		}
	}

	private static <T extends Enum<T>> boolean isValidStringValue(Class<T> enumE, String value) {
		for (T enumValue : enumE.getEnumConstants()) {
			if (value.equalsIgnoreCase(enumValue.name()))
				return true;
		}

		return false;
	}

	private static void appendErrors(StringBuilder errorMessages, String error) {
		if (errorMessages.length() != 0)
			errorMessages.append(";");

		errorMessages.append(error);
	}

	public static void validateKafkaACHErrorPayload(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent) {
		UUID paymentId = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null ? paymentsErrorKafkaEvent.getEventData().getPaymentRequestId() : null);
		if (paymentId == null) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_ID_NOT_FOUND);
		}

		String transactionType = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null
				&& paymentsErrorKafkaEvent.getEventData().getTransactionType() != null ? paymentsErrorKafkaEvent.getEventData().getTransactionType() : "");
		if (transactionType.isEmpty()) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_TRANSACTION_TYPE_NOT_FOUND.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		UUID customerId = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null && paymentsErrorKafkaEvent.getEventData().getCustomerId() != null
				? paymentsErrorKafkaEvent.getEventData().getCustomerId()
				: null);
		if (customerId == null) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_CUSTOMER_ID_NOT_FOUND.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		validateStatus(paymentsErrorKafkaEvent, paymentId);

		validateDates(paymentsErrorKafkaEvent, paymentId);
	}

	private static void validateStatus(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent, UUID paymentId) {
		String paymentStatus = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null
				&& paymentsErrorKafkaEvent.getEventData().getPaymentStatus() != null ? paymentsErrorKafkaEvent.getEventData().getPaymentStatus() : "");
		if (paymentStatus.isEmpty()) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_STATUS_NOT_FOUND.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		if (!isValidStringValue(PaymentStatus.class, paymentsErrorKafkaEvent.getEventData().getPaymentStatus())) {
			String error = PaymentErrors.ERROR_ACH_ERROR_STATUS_INVALID;
			error = error.replaceAll("\\{status\\}", paymentStatus);
			error = error.replaceAll("\\{paymentId\\}", paymentId.toString());
			throw new PaymentDataException(error);
		}
	}

	private static void validateDates(PaymentsErrorKafkaEvent paymentsErrorKafkaEvent, UUID paymentId) {
		String paymentDate = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null && paymentsErrorKafkaEvent.getEventData().getPaymentDate() != null
				? paymentsErrorKafkaEvent.getEventData().getPaymentDate()
				: "");
		if (paymentDate.isEmpty()) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_DATE_NOT_FOUND.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		if (!PaymentDateValidator.isValid(paymentDate)) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_PAYMENT_DATE_INVALID.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		String returnDate = (paymentsErrorKafkaEvent != null && paymentsErrorKafkaEvent.getEventData() != null && paymentsErrorKafkaEvent.getEventData().getReturnDate() != null
				? paymentsErrorKafkaEvent.getEventData().getReturnDate()
				: "");
		if (returnDate.isEmpty()) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_RETURN_DATE_NOT_FOUND.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}

		if (!PaymentDateValidator.isValidLocalDate(returnDate)) {
			throw new PaymentDataException(PaymentErrors.ERROR_ACH_ERROR_RETURN_DATE_INVALID.replaceAll("\\{paymentId\\}", paymentId.toString()));
		}
	}

	public static void validateParameters(Map<String, Object> parameters) {
		String paymentType = parameters.get(PaymentConstants.PAYMENT_TYPE) != null ? (String) parameters.get(PaymentConstants.PAYMENT_TYPE) : null;
		String status = parameters.get(PaymentConstants.STATUS) != null ? (String) parameters.get(PaymentConstants.STATUS) : null;
		String startDate = parameters.get(PaymentConstants.START_DATE) != null ? (String) parameters.get(PaymentConstants.START_DATE) : null;
		String endDate = parameters.get(PaymentConstants.END_DATE) != null ? (String) parameters.get(PaymentConstants.END_DATE) : null;
		String sortOrder = parameters.get(PaymentConstants.SORT_ORDER) != null ? (String) parameters.get(PaymentConstants.SORT_ORDER) : null;
		String sortField = parameters.get(PaymentConstants.SORT_FIELD) != null ? (String) parameters.get(PaymentConstants.SORT_FIELD) : null;
		String pageNumber = parameters.get(PaymentConstants.PAGE_NUMBER) != null ? (String) parameters.get(PaymentConstants.PAGE_NUMBER) : null;
		String pageSize = parameters.get(PaymentConstants.PAGE_SIZE) != null ? (String) parameters.get(PaymentConstants.PAGE_SIZE) : null;
		StringBuilder errorMessages = new StringBuilder();

		validateParametersPaymentType(paymentType, errorMessages);
		validateParametersStatus(status, endDate, errorMessages);
		validateParametersEndDate(startDate, endDate, errorMessages);
		validateParametersStartDateEndDate(startDate, endDate, errorMessages);
		validateParametersSortOrder(sortOrder, errorMessages);
		validateParametersSortField(sortField, errorMessages);
		validateParametersPageNumber(pageNumber, pageSize, errorMessages);
		validateParametersPageSize(pageSize, errorMessages);

		if (!errorMessages.isEmpty()) {
			PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(errorMessages.toString());
			paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
			throw paymentDataNotFoundException;
		}
	}

	private static void validateParametersPaymentType(String paymentType, StringBuilder errorMessages) {
		if (paymentType != null) {
			if (!isValidStringValue(PaymentType.class, paymentType)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_TYPE_IS_INVALID);
			}
		}
	}

	private static void validateParametersStatus(String status, String endDate, StringBuilder errorMessages) {
		if (status != null) {
			if (!isValidStringValue(PaymentStatus.class, status)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_STATUS_IS_INVALID);
			}

			if (status.equalsIgnoreCase(PaymentStatus.SCHEDULE.name())) {
				if (endDate != null) {
					ZonedDateTime endDateTemp = PaymentUtil.getZonedDateTime(endDate);
					if (endDateTemp.isBefore(PaymentUtil.utcNow())) {
						appendErrors(errorMessages, PaymentErrors.ERROR_END_DATE_IS_INVALID_03);
						PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(errorMessages.toString());
						paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
						throw paymentDataNotFoundException;
					}
				}
			}
		}
	}

	private static void validateParametersEndDate(String startDate, String endDate, StringBuilder errorMessages) {
		if (endDate != null) {
			if (startDate == null) {
				appendErrors(errorMessages, PaymentErrors.ERROR_END_DATE_IS_INVALID_03);
			}
		}
	}

	private static void validateParametersStartDateEndDate(String startDate, String endDate, StringBuilder errorMessages) {
		if (endDate != null && startDate != null) {
			LocalDate startDateTemp = null;
			LocalDate endDateTemp = null;
			try {
				startDateTemp = LocalDate.parse(startDate);
			}
			catch(DateTimeParseException e) {
				appendErrors(errorMessages, PaymentErrors.ERROR_START_DATE_IS_INVALID);
			}

			try {
				endDateTemp = LocalDate.parse(endDate);
			}
			catch(DateTimeParseException e) {
				appendErrors(errorMessages, PaymentErrors.ERROR_END_DATE_IS_INVALID);
			}

			if (!errorMessages.isEmpty()) {
				PaymentDataNotFoundException paymentDataNotFoundException = new PaymentDataNotFoundException(errorMessages.toString());
				paymentDataNotFoundException.setHttpStatusCode(HttpStatus.NOT_FOUND);
				throw paymentDataNotFoundException;
			}

			if (endDateTemp.isBefore(startDateTemp)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_START_DATE_END_DATE_IS_INVALID);
			}
			// Review this condition
			if (endDateTemp.isEqual(startDateTemp)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_START_DATE_END_DATE_IS_INVALID);
			}
		}
	}

	private static void validateParametersSortOrder(String sortOrder, StringBuilder errorMessages) {
		if (sortOrder != null) {
			if (!isValidStringValue(SortOrder.class, sortOrder)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_SORT_IS_INVALID);
			}
		}
	}

	private static void validateParametersSortField(String sortField, StringBuilder errorMessages) {
		if (sortField != null) {
			if (!isValidStringValue(SortField.class, sortField)) {
				appendErrors(errorMessages, PaymentErrors.ERROR_SORT_FIELD_IS_INVALID);
			}
		}
	}

	private static void validateParametersPageNumber(String pageNumber, String pageSize, StringBuilder errorMessages) {
		if (pageNumber != null) {
			if (pageSize == null) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAGE_SIZE_IS_MISSING);
			}
			try {
				Integer numPage = Integer.parseInt(pageNumber);
				if (numPage <= 0) {
					appendErrors(errorMessages, PaymentErrors.ERROR_PAGE_IS_INVALID);
				}
			}
			catch (NumberFormatException e) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAGE_IS_INVALID);
			}
		}
	}

	private static void validateParametersPageSize(String pageSize, StringBuilder errorMessages) {
		if (pageSize != null) {
			try {
				Integer intPageSize = Integer.parseInt(pageSize);
				if (intPageSize <= 0) {
					appendErrors(errorMessages, PaymentErrors.ERROR_PAGE_SIZE_IS_INVALID);
				}
			}
			catch (NumberFormatException e) {
				appendErrors(errorMessages, PaymentErrors.ERROR_PAGE_SIZE_IS_INVALID);
			}
		}
	}

	public static boolean validateBlockDates(PaymentServiceRequest paymentServiceRequest, PaymentEligibilityDateResponse paymentEligibilityDateResponse, String correlationId) {
		LocalDate localBlockedDate = null;
		LocalDate localScheduledDate = PaymentUtil.parseDate(paymentServiceRequest.getScheduledDate(), PaymentConstants.DATETIMEFORMAT_RESPONSE);

		for (BlockedDate blockedDate : paymentEligibilityDateResponse.getBlockedDates()) {
			localBlockedDate = PaymentUtil.parseDate(blockedDate.getDate(), PaymentConstants.DATEFORMAT_UUUU_MM_DD);
			if (localBlockedDate.isEqual(localScheduledDate)) {
				return false;
			}
		}

		return true;
	}

	public static void validateMoneyMovementKafkaEvent(AchPartnerMoneyMovementKafkaEvent achPartnerMoneyMovementKafkaEvent) {
		List<String> errorMessages = new ArrayList<>();
		if (achPartnerMoneyMovementKafkaEvent != null && achPartnerMoneyMovementKafkaEvent.getEventData() != null) {
			if (achPartnerMoneyMovementKafkaEvent.getEventData().getPayment() == null) {
				errorMessages.add(PaymentErrors.ERROR_PAYMENT_NOT_FOUND_MONEY_MOVEMENT_EVENT);
			} else {
				if (achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getAchTransactionId() == null) {
					errorMessages.add(PaymentErrors.ERROR_TRANSACTION_ID_NOT_FOUND_MONEY_MOVEMENT_EVENT);
				}
				if (achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getStatus() == null) {
					errorMessages.add(PaymentErrors.ERROR_STATUS_NOT_FOUND_MONEY_MOVEMENT_EVENT);
				}
				if (achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getPaymentRequestId() == null) {
					errorMessages.add(PaymentErrors.ERROR_PAYMENT_REQUEST_ID_NOT_FOUND_MONEY_MOVEMENT_EVENT);
				}
				if (achPartnerMoneyMovementKafkaEvent.getEventData().getPayment().getUpdatedTimestamp() == null) {
					errorMessages.add(PaymentErrors.ERROR_UPDATED_TIMESTAMP_NOT_FOUND_MONEY_MOVEMENT_EVENT);
				}
			}
		} else {
			errorMessages.add(PaymentErrors.ERROR_INVALID_MONEY_MOVEMENT_EVENT); }
		if (!errorMessages.isEmpty()) {
			throw new PaymentDataException(String.join("; ", errorMessages));
		}
	}
}