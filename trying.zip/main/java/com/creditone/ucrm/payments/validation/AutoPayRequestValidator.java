package com.creditone.ucrm.payments.validation;

import com.creditone.ucrm.payments.constant.Channel;
import com.creditone.ucrm.payments.constant.PaymentConstants;
import com.creditone.ucrm.payments.constant.PaymentErrors;
import com.creditone.ucrm.payments.exception.PaymentDataException;
import com.ucrm.swagger.paymentservice.model.AutoPayRequest;
import com.ucrm.swagger.paymentservice.model.UpdateAutoPayRequest;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.regex.Pattern;


public class AutoPayRequestValidator {
    public static void validate(AutoPayRequest request) {
        StringBuilder errorMessages = new StringBuilder();
        validateRequest(errorMessages, request);
        validateValues(errorMessages, request);

        if (request.getPaymentAmount() == null && request.getPaymentPurpose().toString().equalsIgnoreCase(AutoPayRequest.PaymentPurposeEnum.OTHER.name())) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
        }
        else if(request.getPaymentAmount()!= null) {
            if (request.getPaymentAmount().compareTo(BigDecimal.ZERO) <= 0 && !request.getPaymentPurpose().toString().equalsIgnoreCase(AutoPayRequest.PaymentPurposeEnum.OTHER.name())) {
                appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_PURPOSE_IS_INVALID);
            }
            else {
                validateAmountPrecision(errorMessages, request);
            }
        }

        if (errorMessages.length() != 0)  {
            PaymentDataException paymentDataException = new PaymentDataException(errorMessages.toString());
            paymentDataException.setHttpStatusCode(HttpStatus.BAD_REQUEST);
            throw paymentDataException;
        }
    }

    private static void validateRequest(StringBuilder errorMessages, AutoPayRequest request) {
        if (request == null) {
            throw new PaymentDataException("Request Body" + PaymentErrors.VALIDATION_NOT_NULL);
        }

        UUID externalAccountId = (request.getExternalAccountId() != null ? UUID.fromString(request.getExternalAccountId()) : null);
        if (externalAccountId == null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_EXTERNAL_ACCOUNT_IS_INVALID);
        }

        if (request.getPaymentPurpose() == null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_PURPOSE_IS_INVALID);
        }

        String agentId = (request.getAgentId() != null ? request.getAgentId() : null);
        if (agentId == null || agentId.isEmpty()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_AGENT_IS_INVALID);
        }
    }

    private static void appendErrors(StringBuilder errorMessages, String error) {
        if (errorMessages.length() != 0) errorMessages.append(";");
        errorMessages.append(error);
    }
    private static void validateAmountPrecision(StringBuilder errorMessages, AutoPayRequest autoPayRequest) {
        Pattern pattern = Pattern.compile(PaymentConstants.AMOUNT_PRECISION_REGEX);
        if (!pattern.matcher(autoPayRequest.getPaymentAmount().toString()).matches()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
        }
    }

    private static void validateValues(StringBuilder errorMessages, AutoPayRequest autoPayRequest) {
        if (!isValidStringValue(Channel.class, autoPayRequest.getChannel())) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CHANNEL_IS_INVALID);
        }
    }

    private static <T extends Enum<T>> boolean isValidStringValue(Class<T> enumE, String value) {
        for (T enumValue : enumE.getEnumConstants()) {
            if (value.equalsIgnoreCase(enumValue.name())) return true;
        }
        return false;
    }

    public static void validate(UpdateAutoPayRequest request) {
        StringBuilder errorMessages = new StringBuilder();
        validateRequest(errorMessages, request);

        if (!isValidStringValue(Channel.class, request.getChannel())) {
            appendErrors(errorMessages, PaymentErrors.ERROR_CHANNEL_IS_INVALID);
        }

        if(request.getPaymentPurpose() != null && request.getPaymentPurpose().toString().equalsIgnoreCase("OTHER")) {
            if (request.getPaymentAmount() == null) {
                appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
            }
        }

        if(request.getPaymentAmount()!=null) {
            validateAmountPrecision(errorMessages, request);
        }

        if (errorMessages.length() != 0) {
            PaymentDataException paymentDataException = new PaymentDataException(errorMessages.toString());
            paymentDataException.setHttpStatusCode(HttpStatus.NOT_FOUND);
            throw paymentDataException;
        }
    }

    private static void validateRequest(StringBuilder errorMessages, UpdateAutoPayRequest request) {
        if (request == null) {
            throw new PaymentDataException("Request Body" + PaymentErrors.VALIDATION_NOT_NULL);
        }

        UUID externalAccountId = (request.getExternalAccountId() != null ? UUID.fromString(request.getExternalAccountId()) : null);

        if (externalAccountId == null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_EXTERNAL_ACCOUNT_IS_INVALID);
        }

        if (request.getPaymentPurpose() == null) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_PURPOSE_IS_INVALID);
        }

        String agentId = (request.getAgentId() != null ? request.getAgentId() : null);
        if (agentId == null || agentId.isEmpty()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_AGENT_IS_INVALID);
        }
    }

    private static void validateAmountPrecision(StringBuilder errorMessages, UpdateAutoPayRequest request) {
        Pattern pattern = Pattern.compile(PaymentConstants.AMOUNT_PRECISION_REGEX);
        if (!pattern.matcher(request.getPaymentAmount().toString()).matches()) {
            appendErrors(errorMessages, PaymentErrors.ERROR_PAYMENT_AMOUNT_IS_INVALID);
        }
    }
}