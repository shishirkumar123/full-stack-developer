delete from payments.rules  where id = '763d4afb-f1c5-4308-b7e1-5deecf6a5d71';
delete from payments.rules  where id = 'b02599da-11b6-4741-98df-4ea809b7fd7f';


INSERT INTO payments.rules VALUES ('763d4afb-f1c5-4308-b7e1-5deecf6a5d71', 'RuleInput((fields.get("payment_type") != null && fields.get("payment_type") == "ACH") &&
(fields.get("expressPayDecesion") != null && fields.get("expressPayDecesion") == "true" ) &&
(fields.get("riskyPayment") != null && fields.get("riskyPayment") == "false" ) &&
(fields.get("feeWaived") != null && (fields.get("feeWaived") == "false" || fields.get("feeWaived") == "true") )
 )', 'output.setDecision("rtp_call","TRUE");', '1', 'RTP Call Rules');
 
 
 INSERT INTO payments.rules VALUES ('b02599da-11b6-4741-98df-4ea809b7fd7f', 'RuleInput((fields.get("payment_type") != null && fields.get("payment_type") == "ACH") &&
(fields.get("expressPayDecesion") != null && fields.get("expressPayDecesion") == "true" ) &&
(fields.get("riskyPayment") != null && fields.get("riskyPayment") == "true" ) &&
(fields.get("feeWaived") != null && (fields.get("feeWaived") == "false" || fields.get("feeWaived") == "true") )
 )', 'output.setDecision("rtp_call","FALSE");', '2', 'RTP Call Rules');
 
 
 INSERT INTO payments.rules VALUES ('b02599da-11b6-4741-98df-4ea809b7fd8f', 'RuleInput(fields != null)', 'output.setDecision("rtp_call","FALSE");', '3', 'RTP Call Rules');