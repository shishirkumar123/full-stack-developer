# Configuration
$BaseUrl = "https://sitapi.vc7.si01.c1busw2.aws/private/creditcard/financials/payment-service/payment/reprocess-batch"
$apiKey = "g92MIIs0NFTc8TF6eJrePrW9P0v0WJQsSSE2iXUnLJoQghzs"
$api_method = "GET"

$url = "$BaseUrl"
$headers = @{
   "Content-Type" = "application/json"
   "apiKey" = $apiKey
}

try{
	# Send the request to start the reprocess pending transaction
	$response = Invoke-WebRequest -Uri $url -Method $api_method -Headers $headers -UseBasicParsing
	
	if ($response.StatusCode -eq 200) {
	   Write-Host "Reprocessing pending transaction completed successfully. Reprocessing pending transaction response :: " 
	   $response.Content | ConvertFrom-Json
	   [Environment]::Exit("1")
	   
	} else {
	   Write-Host "Reprocess pending transaction processed with error. StatusCode::" $($response.StatusCode)
	   [Environment]::Exit("2")  # Error for Reprocess pending transaction
	}
}
catch [System.Net.WebException] {
	$exceptionMessage = $Error[0].Exception
	Write-Host "Exception occurred while making a rest api call to Reprocess pending transaction :: " $exceptionMessage
	[Environment]::Exit("2")
}
