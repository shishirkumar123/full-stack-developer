
	# Configuration
	$HostUrl = "https://sitapi.vc7.si01.c1busw2.aws"
	$BaseUrl = "private/creditcard/financials/payment-service/batch-process"
	$CompleteUrl = "$HostUrl/$BaseUrl"	
	$apiKey = "g92MIIs0NFTc8TF6eJrePrW9P0v0WJQsSSE2iXUnLJoQghzs"	
	
	$api_post_method = "POST"
	$WaitTimeInMinutes = 1 # Configurable wait time	
	$api_get_method = "GET"
    
	$headers = @{
       "Content-Type" = "application/json"
       "apiKey" = $apiKey
	}  
   
	# Define an array with batchProcess type values
	$batchProcessTypeArray = @("PROCESS_AUTO_PAY_NOTIFICATION", "SCHEDULE_AUTOPAY", "PROCESS_SCHEDULE_PAYMENT")

	# Iterate through each batchProcess type in the array
	foreach ($batchProcessTypeVar in $batchProcessTypeArray) {
		Write-Output "Processing current Batch Process Type : $batchProcessTypeVar"   
	   
	   $jsonObject = @{ batchProcessType= $batchProcessTypeVar}
	   
	   $body = $jsonObject | ConvertTo-Json -Depth 10 
	   # Send the request to start the batch process
	   $batchResponse = Invoke-RestMethod -Uri $CompleteUrl -Method $api_post_method -Headers $headers -Body $body
	  
	   if (-not $batchResponse -or -not $batchResponse.batchId) {
		   Write-Host "No batchId received. Exiting script with error."
		   [Environment]::Exit(1)  # Exit with error code for missing batchId
		}

		$BatchId = $batchResponse.batchId
		Write-Host "BatchId received: $BatchId"
		# Step 2: Wait for the configurable window
		Write-Host "Waiting for $WaitTimeInMinutes minute..."
		Start-Sleep -Seconds ($WaitTimeInMinutes * 60)
		# Step 3: Make subsequent API calls to check the status
		$Attempts = 0
		$Status = "Failed"
		$MaxAttempts = 3        # Configurable max attempts
		
		$UpdatedBaseUrlStatus="$CompleteUrl/$BatchId"
		$UpdatedBaseUrlErrorStatus="$UpdatedBaseUrlStatus/$Errors"
				   
		$Errors="Errors"
		$StatusValue = "TEST";
		while ($Attempts -lt $MaxAttempts) {
		   $Attempts++
		   Write-Host "Attempt ${Attempts}: Checking status for batch ID $BatchId..."
		   try {
			   $StatusResponse = Invoke-RestMethod -Uri $UpdatedBaseUrlStatus -Method $api_get_method -Headers $headers		
				Write-Host "Status Response of batch id $BatchId is $StatusResponse"		   
			   $StatusValue = $StatusResponse.status
			   Write-Host "Status value of batch id $BatchId is $StatusValue"
			   if ($StatusResponse -and $StatusValue -eq "COMPLETED") {
				   $Status = "Processed"
				   Write-Host "Batch ID $BatchId is now Completed. Exiting script successfully."
				   [Environment]::Exit(0)  # Success
			   } 
			   
			   if ($StatusResponse -and ($StatusValue -eq "ERROR" -or $StatusValue -eq "PARTIALLY_COMPLETED")) {           
				   
				   $ErrorStatusResponse = Invoke-RestMethod -Uri $UpdatedBaseUrlErrorStatus -Method $api_get_method
				   Write-Host "Errors $ErrorStatusResponse "
				   if($ErrorStatusResponse -and $ErrorStatusResponse.StatusCode -eq 200)
				   {
					$Status = "Processed"
					Write-Host "Batch ID $BatchId is now Completed with status $ErrorStatusResponse.ErrorDescription ,Exiting script successfully."
					[Environment]::Exit(0)  # Success
				   }			   
			   }	   
		   } catch [System.Net.WebException] {
			   Write-Host "Error during status check. Retrying..."
		   }
		   if ($Attempts -lt $MaxAttempts -and $Status -ne "Processed") {
			   Write-Host "Retrying after $WaitTimeInMinutes minutes..."
			   Start-Sleep -Seconds ($WaitTimeInMinutes * 60)
		   }
		} #while loop ends here
		if ($Status -ne "Processed") {
		   Write-Host "Max attempts reached for $batchProcessTypeVar with Batch ID $BatchId did not reach 'Processed' status. Exiting with error."
		   #[Environment]::Exit(1)  # Error
		}
	}
Write-Host "Payments Script completed successfully for all 3 batch types."
#[Environment]::Exit(1)  # Success

